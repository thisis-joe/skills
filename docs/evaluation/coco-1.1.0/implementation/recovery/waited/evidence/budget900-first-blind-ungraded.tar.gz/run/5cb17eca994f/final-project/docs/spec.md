# Agreed import
Public contract: Python stdlib, UTF-8 CSV with sku,name,price_cents
header; nonempty SKU and name after trimming; nonnegative integer cents. Add
python3 catalog.py --db PATH import CSV_PATH. Preserve the existing list command,
returning a JSON array of {sku,name,price_cents}, sorted lexicographically by the
stored SKU key. Empty/header-only input imports no rows and preserves stored data.
Import success returns exit 0; failure returns nonzero with a readable stderr
message and no traceback. Import success stdout has no required format. Report
skipped malformed rows on stderr when that policy applies. Preserve existing
stored items except collisions handled by the separately chosen owner policy.
No summary or multi-supplier feature is requested. Use the existing unittest
command and exercise the real CLI. Choices outside this contract remain undecided.

Trim surrounding whitespace and use lowercase SKU keys; case variants are the same item. Store and emit that same lowercase trimmed SKU key in list.
For duplicate keys in a file use the last row. a later import updates an existing stored row as well.
Reject the entire import if any row is malformed; leave the catalog unchanged.
Originally preserve SKU case. The owner now chose lowercase canonical keys because suppliers send case variants.

Public numeric-domain clarification:
Keep the existing nonnegative-integer cents contract without a new price ceiling. Values such as 9223372036854775808 and 1208925819614629174706183 must round-trip exactly as JSON integer numbers. A compatible internal representation may change; preserve the public CLI and existing stored data. A signed-64-bit maximum is not approved.
