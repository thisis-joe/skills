import argparse, json, sqlite3
def main():
    p=argparse.ArgumentParser();p.add_argument('--db',required=True)
    s=p.add_subparsers(dest='command',required=True);s.add_parser('list')
    a=p.parse_args();c=sqlite3.connect(a.db)
    c.execute('CREATE TABLE IF NOT EXISTS catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
    print(json.dumps([dict(sku=k,name=n,price_cents=v) for k,n,v in c.execute('SELECT sku,name,price_cents FROM catalog ORDER BY sku')]))
    c.close()
if __name__=='__main__':main()
