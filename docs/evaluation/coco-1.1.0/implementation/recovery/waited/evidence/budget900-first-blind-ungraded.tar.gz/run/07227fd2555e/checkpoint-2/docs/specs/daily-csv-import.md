# Daily purchasing CSV import

Add `python3 catalog.py --db PATH import CSV_PATH` using only Python stdlib.
The README's public contract and the owner's answers govern this feature.

- Read UTF-8 CSV with the `sku,name,price_cents` header. Trim fields;
  SKU and name must be nonempty and price must be nonnegative integer cents.
- Last row wins for repeated trimmed SKU keys in a file. Later imports update
  the name and price of existing keys. SKU keys remain case sensitive.
- Validate every row, including overwritten duplicates. Any malformed row
  rejects the entire file without catalog changes. Do not skip rows.
- File, decoding, CSV, validation and storage errors return nonzero and a
  readable stderr diagnostic without a traceback. Apply writes transactionally.
- Empty and header-only files succeed without changing stored items.
- Preserve `list`: JSON array of `{sku,name,price_cents}`, sorted by stored SKU.
- Preserve unrelated rows, the existing database format and unrelated work.
  No summary, multi-supplier support, dependencies or publication.

Acceptance: real CLI tests for duplicates, updates, trimming, sorting, empty
inputs, malformed rows, atomic rejection and readable failures; the existing
`python3 -m unittest discover -v` suite must pass.
