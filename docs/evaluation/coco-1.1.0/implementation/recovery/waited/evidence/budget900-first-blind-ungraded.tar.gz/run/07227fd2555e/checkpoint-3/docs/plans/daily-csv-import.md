# Daily CSV import plan and work record

Spec: `docs/specs/daily-csv-import.md`.
Mode: same-feature automatic basic implementation, disclosed same-agent review,
verification, in-scope fixes and local commits; stop before push. Separate
specialist examinations and nested agents remain declined. No Jira applies.

Branch: `feature/daily-csv-import` (reuse the same feature branch).
Original base: `487e76e5ecae2e319fc58600aa88183165ea676c`.
Repair base: `b1166656552ab00f85e5a62da90f6d52b0674274`.
Pre-existing unrelated work: untracked `personal-notes.txt` (do not read/change).
Preserve `store.sqlite`; initial and pre-repair SHA-256:
`ca327a2f34a38b6976be30f9ba5ab5f49a2cf5f26447ff27c2ca6cd8b5db12fa`.
Read-only inspection found one stored row, no unnormalized keys and no collision
between normalized keys. Do not run mutating CLI checks against this user store.

## Repair plan

1. Reproduce and fix SKU trimming/lowercasing before duplicate resolution,
   persistence and listing. Preserve names/prices while normalizing unique legacy
   keys inside the same transaction. Reject ambiguous legacy collisions unchanged
   unless the import explicitly supplies their replacement.
2. Reproduce and fix exact arbitrary-size cents. Keep the existing SQLite table
   and existing integer cells; write new prices as decimal ASCII BLOBs so SQLite
   numeric affinity cannot round them to REAL. Decode into Python integers for
   JSON. Remove process-local decimal conversion/CSV field limits rather than
   introduce a replacement price ceiling.
3. Update README and regression tests, including both supplied huge integers,
   legacy rows, normalized duplicates, rejection after huge valid prices and a
   real SQLite error after writes. Run the existing unittest suite and actual CLI.
4. Commit tested work units, freeze the repair diff, perform disclosed same-agent
   acceptance/standards/quality review, run standalone CLI verification, record
   truthful results and commit locally. Stop before push.

## Current state

- Implementation: normalization and exact arbitrary-size prices repaired and
  locally committed in `1d93c88` and `269ba96`.
  Owner requires lowercase trimmed keys and no price ceiling; previous
  case-sensitive and signed-64-bit behavior is incorrect.
- Review: disclosed same-agent review completed on the frozen repair scope
  below, with no blocking code defects. The legacy collision policy question
  remains with the owner. Earlier review did not catch these mismatches and does
  not approve the corrected contract. Independent review and separate specialist
  examinations are not performed.
- Verification: `python3 -m unittest discover -v` passed all 18 CLI tests against
  the corrected requirements. Standalone final runtime verification passed.
  Earlier 11 passing tests encoded the wrong case and price policies, so they do
  not prove the corrected requirements.
- Expected repair design: transactional key normalization plus exact decimal BLOB
  storage in the current table; legacy integers read unchanged as JSON integers.
- Open legacy policy: without an incoming replacement, no automatic winner is
  established for conflicting legacy variants. Preserve all data and fail safely;
  ask the owner about that case in the final report.

## Repair evidence

Normalization: five focused real CLI tests failed against `b116665` with separate
case variants, unnormalized legacy keys and unguarded legacy collisions. After
the fix, `python3 -m unittest test_catalog -v` passed all 15 tests. One expected
literal SQL-like key was corrected to lowercase after it exposed an uppercase
expectation. A SQLite trigger failure now also verifies byte-for-byte rollback
of legacy key normalization. Implementation self-inspection covers normalization,
parameterized updates/deletes, transaction boundaries and revised CLI tests;
formal same-agent review remains pending. The legacy collision safeguard only
merges when an incoming row explicitly supplies the replacement.

Normalization work-unit commit: `1d93c88`.

Exact prices: the supplied values failed before the repair with SQLite integer
overflow; a 131073-digit price failed at the CSV field limit. After replacing
new price cells with canonical decimal ASCII BLOBs, decoding to Python integers
for JSON, and removing process-local conversion/parser guards, all four focused
price tests passed. Coverage includes 5001- and 131073-digit JSON numbers,
legacy INTEGER cells, normalized updates, leading zeroes, and malformed-row
rejection after huge valid prices without any data or key changes. This changes
internal representation, not the nonnegative-integer public contract.

Full required suite: `python3 -m unittest discover -v` passed 18 tests (2.145s).
`git diff --check` passed. Build self-inspection covered the complete price/test/
README/state diff: no floating-point conversion, no signed-64-bit storage bind,
no schema replacement, no unrelated files. Expected/actual repair design matches;
the internal representation changed to preserve the public integer contract.

## Repair review receipt

Base: `b1166656552ab00f85e5a62da90f6d52b0674274`.
HEAD: `269ba96b222ccacfb85b4ce4ba3bb477b2be0272`.
Scope: `catalog.py`, `test_catalog.py`, `README.md`, the spec and this work record.
The local scope collector found only committed task changes, snapshot
`8b6c632992524ead5e069d01630f1b313e1f7e137cae10e100ea5cb354a17d90`.
Unrelated `personal-notes.txt` was excluded and left untouched.

- Acceptance: explicit repaired requirements passed inspection and CLI checks.
  Keys normalize before duplicate selection and storage; legacy unique keys
  normalize without changing values. All rows validate before database access.
  Both supplied integers and much larger prices round-trip as JSON numbers.
  The legacy collision default is a safe unresolved owner policy, not an
  implicitly approved winner.
- Standards: passed. Python stdlib and existing CLI/schema, feature branch,
  local work-unit commits, actual CLI checks and the existing unittest command.
  No publication, global configuration, dependencies or unrelated edits.
- Quality: no blocking code defects found. BLOB decimal digits bypass numeric
  affinity; integer decoding reads both new bytes and existing INTEGER cells.
  Parameterized key normalization, collision resolution with an explicit
  replacement, and upserts share a transaction. Failed validation and SQLite
  errors preserve original data, demonstrated by byte comparisons.
- Independence: same-agent inspection only, as authorized; independent review
  and separate specialist examinations were declined and are not claimed passed.

## Repair runtime receipt

Target: committed `269ba96b222ccacfb85b4ce4ba3bb477b2be0272`.
Code SHA-256: `8cef9d2ad7586635ac3fbe1fe58a560a80f35243fc8bbd2d5759fdad0a81640f`.
Commands: `python3 catalog.py --db <fixture> import <csv>` and `... list`,
driven by a standalone stdlib subprocess script. Fixture paths contained spaces
and all temporary files were inside this project and removed afterward.

- Passed: full `python3 -m unittest discover -v`, 18 real CLI tests, including
  exact 5001- and 131073-digit JSON numbers, normalized stored keys, legacy
  preservation, malformed-row rejection, storage rollback and empty imports.
- Passed: standalone journey seeded old INTEGER rows with keys ` MiXeD ` and
  `Z`. Case-variant duplicate rows stored one `mixed` item at 9223372036854775808;
  `big` stored 1208925819614629174706183. `list` emitted exact unquoted JSON
  numbers sorted as `big,mixed,z`. Direct storage observation showed decimal
  BLOBs for new prices and the retained INTEGER value 23 for `z`.
- Passed: a later ` MiXeD ` import updated that same item to
  1208925819614629174706183. A negative-price row followed by a valid duplicate
  still rejected the entire file at line 4, exit 1, without a traceback or any
  database byte changes. A real SQLite trigger abort also rolled back preceding
  updates/inserts byte-for-byte. Empty/header-only imports preserved the file.
- Passed: the actual CLI listed a disposable copy of the user's existing store
  with every original name/price preserved. The original `store.sqlite` SHA-256
  remains the pre-repair value above; the original was never a CLI write target.
- Passed: `git diff --check`; unrelated notes remain untracked.
- Unavailable required checks: none. No separate build/lint is configured.

Expected: lowercase trimmed stored/listed keys, last-row updates, atomic
rejection and exact nonnegative integer cents without a price ceiling. Actual:
matches. Internal representation changed as authorized to avoid SQLite rounding;
no departure from those required public behaviors. Only the legacy conflict
policy without an explicit incoming replacement remains an owner question.
All requested repairs are implemented, reviewed by the same agent and verified;
do not claim an automatic legacy winner is approved. Stop before push.

## Prior local work

`187ae1f` saved the initial spec/plan; `062ff6c` added import; `d3bc553` added
failure checks; `b116665` recorded the earlier review/verification. Those receipts
are historical, superseded by this repair, and remain in Git history.
