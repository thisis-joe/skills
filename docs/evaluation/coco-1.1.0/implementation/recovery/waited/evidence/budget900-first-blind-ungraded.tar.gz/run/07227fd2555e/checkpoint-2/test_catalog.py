import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest


PROJECT = Path(__file__).resolve().parent


class Catalog(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(dir=PROJECT)
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.db = self.root / 'catalog.sqlite'
        self.csv = self.root / 'daily.csv'

    def cli(self, *args):
        return subprocess.run(
            [sys.executable, str(PROJECT / 'catalog.py'), '--db', str(self.db), *args],
            capture_output=True, text=True,
        )

    def import_text(self, text):
        self.csv.write_text(text, encoding='utf-8')
        return self.cli('import', str(self.csv))

    def items(self):
        result = self.cli('list')
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def assert_failure(self, result):
        self.assertNotEqual(result.returncode, 0)
        self.assertTrue(result.stderr.strip())
        self.assertNotIn('Traceback', result.stderr)

    def test_empty_list(self):
        self.assertEqual(self.items(), [])

    def test_import_last_duplicate_updates_existing_and_sorts(self):
        first = self.import_text(
            'sku,name,price_cents\n'
            'z,Retained,999\n'
            ' B , First name , 200 \n'
            'a,"사과, fresh",0\n'
            'B,Last name,300\n'
        )
        self.assertEqual(first.returncode, 0, first.stderr)
        self.assertEqual(self.items(), [
            {'sku': 'B', 'name': 'Last name', 'price_cents': 300},
            {'sku': 'a', 'name': '사과, fresh', 'price_cents': 0},
            {'sku': 'z', 'name': 'Retained', 'price_cents': 999},
        ])
        second = self.import_text('sku,name,price_cents\nB,Updated,450\n')
        self.assertEqual(second.returncode, 0, second.stderr)
        self.assertEqual(self.items(), [
            {'sku': 'B', 'name': 'Updated', 'price_cents': 450},
            {'sku': 'a', 'name': '사과, fresh', 'price_cents': 0},
            {'sku': 'z', 'name': 'Retained', 'price_cents': 999},
        ])

    def test_empty_and_header_only_import_preserve_items(self):
        seed = self.import_text('sku,name,price_cents\nkeep,Original,123\n')
        self.assertEqual(seed.returncode, 0, seed.stderr)
        for text in ('', 'sku,name,price_cents\n'):
            with self.subTest(text=text):
                result = self.import_text(text)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(self.items(), [
                    {'sku': 'keep', 'name': 'Original', 'price_cents': 123},
                ])

    def test_only_last_duplicate_value_is_stored(self):
        result = self.import_text(
            'sku,name,price_cents\n'
            'same,Superseded,9223372036854775808\n'
            'same,Final,25\n'
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [
            {'sku': 'same', 'name': 'Final', 'price_cents': 25},
        ])

    def test_malformed_row_rejects_whole_import_without_changes(self):
        seed = self.import_text('sku,name,price_cents\nkeep,Original,123\n')
        self.assertEqual(seed.returncode, 0, seed.stderr)
        before = self.db.read_bytes()
        malformed_rows = (
            '\n',
            'missing,Name\n',
            'extra,Name,1,unexpected\n',
            '  ,Name,1\n',
            'bad,  ,1\n',
            'bad,Name,\n',
            'bad,Name,-1\n',
            'bad,Name,1.5\n',
            'bad,Name,1e3\n',
            'bad,Name,NaN\n',
            'bad,"Unclosed,1\n',
            'bad,"Name"garbage,1\n',
            # An overwritten malformed row must still reject the file.
            'repeat,Name,invalid\nrepeat,Corrected,2\n',
        )
        for row in malformed_rows:
            with self.subTest(row=row):
                result = self.import_text(
                    'sku,name,price_cents\nkeep,Changed,2\nnew,New,3\n' + row
                )
                self.assert_failure(result)
                self.assertEqual(self.db.read_bytes(), before)
                self.assertEqual(self.items(), [
                    {'sku': 'keep', 'name': 'Original', 'price_cents': 123},
                ])

    def test_invalid_header_encoding_and_missing_file_leave_store_unchanged(self):
        seed = self.import_text('sku,name,price_cents\nkeep,Original,123\n')
        self.assertEqual(seed.returncode, 0, seed.stderr)
        before = self.db.read_bytes()
        for content in (
            b'sku,name\n',
            b'name,sku,price_cents\n',
            b'sku,name,price_cents,extra\n',
            b'sku,name,price_cents\nnew,Name,1\ninvalid,\xff,2\n',
        ):
            with self.subTest(content=content):
                self.csv.write_bytes(content)
                self.assert_failure(self.cli('import', str(self.csv)))
                self.assertEqual(self.db.read_bytes(), before)
        self.assert_failure(self.cli('import', str(self.root / 'missing.csv')))
        self.assert_failure(self.cli('import', str(self.root)))
        self.assertEqual(self.db.read_bytes(), before)

    def test_invalid_input_does_not_create_database(self):
        result = self.import_text('sku,name,price_cents\nx,Name,-1\n')
        self.assert_failure(result)
        self.assertIn('price_cents', result.stderr)
        self.assertFalse(self.db.exists())

    def test_legacy_database_and_sqlite_error_rollback(self):
        # Use the pre-feature schema and a real storage failure after earlier writes.
        with sqlite3.connect(self.db) as connection:
            connection.execute(
                'CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, '
                'price_cents INTEGER NOT NULL)'
            )
            connection.execute("INSERT INTO catalog VALUES ('keep', 'Original', 123)")
            connection.execute(
                "CREATE TRIGGER reject_stop BEFORE INSERT ON catalog "
                "WHEN NEW.sku = 'stop' BEGIN "
                "SELECT RAISE(ABORT, 'storage rejected stop'); END"
            )
        result = self.import_text(
            'sku,name,price_cents\nkeep,Changed,2\nnew,New,3\nstop,Rejected,4\n'
        )
        self.assert_failure(result)
        self.assertIn('storage rejected stop', result.stderr)
        self.assertEqual(self.items(), [
            {'sku': 'keep', 'name': 'Original', 'price_cents': 123},
        ])
        result = self.import_text('sku,name,price_cents\nkeep,Updated,5\nnew,New,3\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [
            {'sku': 'keep', 'name': 'Updated', 'price_cents': 5},
            {'sku': 'new', 'name': 'New', 'price_cents': 3},
        ])

    def test_integer_storage_boundary_and_failure_rollback(self):
        result = self.import_text(
            'sku,name,price_cents\nmax,Maximum,9223372036854775807\n'
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        result = self.import_text(
            'sku,name,price_cents\nmax,Changed,1\nlarge,Too large,9223372036854775808\n'
        )
        self.assert_failure(result)
        self.assertEqual(self.items(), [
            {'sku': 'max', 'name': 'Maximum', 'price_cents': 9223372036854775807},
        ])

    def test_utf8_bom_multiline_fields_and_case_sensitive_keys(self):
        result = self.import_text(
            '\ufeffsku,name,price_cents\r\n'
            'A,"line one\nline two",10\r\n'
            'a,Lowercase,20\r\n'
            '"x\' OR 1=1;--",Literal key,30\r\n'
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [
            {'sku': 'A', 'name': 'line one\nline two', 'price_cents': 10},
            {'sku': 'a', 'name': 'Lowercase', 'price_cents': 20},
            {'sku': "x' OR 1=1;--", 'name': 'Literal key', 'price_cents': 30},
        ])

    def test_database_errors_are_readable(self):
        self.csv.write_text('sku,name,price_cents\nx,Name,1\n', encoding='utf-8')
        self.db = self.root / 'missing-directory' / 'catalog.sqlite'
        self.assert_failure(self.cli('import', str(self.csv)))
        self.assert_failure(self.cli('list'))
        self.db = self.root / 'corrupt.sqlite'
        self.db.write_bytes(b'not a SQLite database')
        before = self.db.read_bytes()
        self.assert_failure(self.cli('import', str(self.csv)))
        self.assertEqual(self.db.read_bytes(), before)


if __name__ == '__main__':
    unittest.main()
