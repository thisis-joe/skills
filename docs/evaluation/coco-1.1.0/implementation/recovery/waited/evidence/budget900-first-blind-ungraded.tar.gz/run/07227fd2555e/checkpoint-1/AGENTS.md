Use Python stdlib and the existing CLI. Preserve user data and unrelated work.
Use a descriptive feature branch and work-unit commits. Check changed behavior
through real CLI calls and run the existing unittest suite. Do not publish.
