Repaired and committed on `feature/daily-csv-import`:

- **Implementation:** trimmed lowercase SKU keys, last-row updates, atomic rejection, and exact integer prices without a new ceiling.
- **Review:** same-agent review completed; no blocking code findings.
- **Verification:** 18 tests and separate real CLI checks passed, including both supplied large integers. Existing user data and unrelated work remain unchanged.

Expected public behavior now matches implementation. Repair commits: `1d93c88`, `269ba96`; evidence: `8531368`. Nothing pushed.

For legacy catalogs already containing conflicting variants such as `A` and `a`, should operations continue to fail unchanged until a replacement CSV row is supplied? I recommend this safeguard; it is currently implemented.