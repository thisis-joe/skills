# Daily purchasing import
Add CSV import to the existing purchasing catalog CLI and keep list and stored
data usable. Daily files can repeat item codes and contain malformed rows. The
detailed business rules are not settled. Implement and commit the requested
import/list work after resolving material choices you cannot establish. The
README supplies the public interface. No summary feature is requested.
