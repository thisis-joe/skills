import argparse
from contextlib import closing
import csv
import json
import re
import sqlite3
import sys


def read_import(path):
    rows = {}
    with open(path, encoding='utf-8-sig', newline='') as source:
        reader = csv.reader(source, strict=True)
        header = next(reader, None)
        if header is None:
            return []
        if header != ['sku', 'name', 'price_cents']:
            raise ValueError('expected CSV header: sku,name,price_cents')
        for fields in reader:
            location = f'CSV row ending at line {reader.line_num}'
            if len(fields) != 3:
                raise ValueError(f'{location}: expected exactly 3 fields')
            sku, name, price = (field.strip() for field in fields)
            if not sku or not name:
                raise ValueError(f'{location}: SKU and name must be nonempty')
            if not re.fullmatch(r'[0-9]+', price):
                raise ValueError(f'{location}: price_cents must be a nonnegative integer')
            sku = sku.lower()
            # BLOB avoids INTEGER affinity converting large decimal text to REAL.
            rows[sku] = (sku, name, (price.lstrip('0') or '0').encode('ascii'))
    return list(rows.values())


def normalize_stored_skus(connection, replacements):
    groups = {}
    for (stored_sku,) in connection.execute('SELECT sku FROM catalog'):
        sku = stored_sku.strip().lower()
        if not sku:
            raise ValueError('stored SKU is empty after trimming')
        groups.setdefault(sku, []).append(stored_sku)
    for sku, variants in groups.items():
        if len(variants) > 1 and sku not in replacements:
            raise ValueError(
                f'conflicting stored SKU variants for {sku!r}; '
                'import that SKU with the chosen replacement'
            )
    for sku, variants in groups.items():
        retained = sku if sku in variants else variants[0]
        for variant in variants:
            if variant != retained:
                connection.execute('DELETE FROM catalog WHERE sku = ?', (variant,))
        if retained != sku:
            connection.execute('UPDATE catalog SET sku = ? WHERE sku = ?', (sku, retained))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    importer = commands.add_parser('import')
    importer.add_argument('csv_path')
    args = parser.parse_args()

    try:
        # These settings affect only this CLI process, not Python installation
        # settings. Neither parser should impose a replacement price ceiling.
        if hasattr(sys, 'set_int_max_str_digits'):
            sys.set_int_max_str_digits(0)
        csv.field_size_limit(sys.maxsize)
        rows = read_import(args.csv_path) if args.command == 'import' else None
        with closing(sqlite3.connect(args.db)) as connection:
            with connection:
                connection.execute('BEGIN')
                connection.execute(
                    'CREATE TABLE IF NOT EXISTS catalog ('
                    'sku TEXT PRIMARY KEY, name TEXT NOT NULL, '
                    'price_cents INTEGER NOT NULL)'
                )
                if args.command == 'list' or rows:
                    normalize_stored_skus(connection, {row[0] for row in rows or []})
                if args.command == 'import':
                    connection.executemany(
                        'INSERT INTO catalog (sku, name, price_cents) VALUES (?, ?, ?) '
                        'ON CONFLICT(sku) DO UPDATE SET '
                        'name = excluded.name, price_cents = excluded.price_cents',
                        rows,
                    )
                else:
                    print(json.dumps([
                        dict(sku=sku, name=name, price_cents=int(price))
                        for sku, name, price in connection.execute(
                            'SELECT sku, name, price_cents FROM catalog ORDER BY sku'
                        )
                    ]))
    except (OSError, UnicodeError, csv.Error, ValueError, OverflowError, sqlite3.Error) as error:
        print(f'catalog: {error}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
