import argparse
from contextlib import closing
import csv
import json
import re
import sqlite3
import sys


def read_import(path):
    rows = {}
    with open(path, encoding='utf-8-sig', newline='') as source:
        reader = csv.reader(source, strict=True)
        header = next(reader, None)
        if header is None:
            return []
        if header != ['sku', 'name', 'price_cents']:
            raise ValueError('expected CSV header: sku,name,price_cents')
        for fields in reader:
            location = f'CSV row ending at line {reader.line_num}'
            if len(fields) != 3:
                raise ValueError(f'{location}: expected exactly 3 fields')
            sku, name, price = (field.strip() for field in fields)
            if not sku or not name:
                raise ValueError(f'{location}: SKU and name must be nonempty')
            if not re.fullmatch(r'[0-9]+', price):
                raise ValueError(f'{location}: price_cents must be a nonnegative integer')
            rows[sku] = (sku, name, int(price))
    return list(rows.values())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    importer = commands.add_parser('import')
    importer.add_argument('csv_path')
    args = parser.parse_args()

    try:
        rows = read_import(args.csv_path) if args.command == 'import' else None
        with closing(sqlite3.connect(args.db)) as connection:
            with connection:
                connection.execute('BEGIN')
                connection.execute(
                    'CREATE TABLE IF NOT EXISTS catalog ('
                    'sku TEXT PRIMARY KEY, name TEXT NOT NULL, '
                    'price_cents INTEGER NOT NULL)'
                )
                if args.command == 'import':
                    connection.executemany(
                        'INSERT INTO catalog (sku, name, price_cents) VALUES (?, ?, ?) '
                        'ON CONFLICT(sku) DO UPDATE SET '
                        'name = excluded.name, price_cents = excluded.price_cents',
                        rows,
                    )
                else:
                    print(json.dumps([
                        dict(sku=sku, name=name, price_cents=price)
                        for sku, name, price in connection.execute(
                            'SELECT sku, name, price_cents FROM catalog ORDER BY sku'
                        )
                    ]))
    except (OSError, UnicodeError, csv.Error, ValueError, OverflowError, sqlite3.Error) as error:
        print(f'catalog: {error}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
