# Daily purchasing CSV import

Add `python3 catalog.py --db PATH import CSV_PATH` using only Python stdlib.
The owner's corrected requirements supersede the earlier case-sensitive/64-bit
assumptions. Preserve the public CLI and existing stored data.

- Read UTF-8 CSV with the `sku,name,price_cents` header. Trim fields;
  SKU and name must be nonempty and price must be nonnegative integer cents.
- Normalize SKU keys with `strip().lower()` before duplicate resolution and
  persistence. Store and emit this same key; case variants identify one item.
- Last row wins for repeated normalized keys in a file. Later imports update the
  name and price of existing keys, including legacy keys needing normalization.
- Validate every row, including overwritten duplicates. Any malformed row
  rejects the entire file without catalog changes. Do not skip rows.
- There is no price ceiling. In particular, 9223372036854775808 and
  1208925819614629174706183 must round-trip exactly as JSON integer numbers.
  Compatible internal representations may change; retain existing integer rows.
- File, decoding, CSV, validation and storage errors return nonzero and a
  readable stderr diagnostic without a traceback. Apply writes transactionally.
- Empty and header-only imports succeed without changing stored items.
- Preserve `list`: JSON array of `{sku,name,price_cents}`, sorted lexicographically
  by the normalized stored SKU. Normalize unique legacy keys transactionally.
- Preserve unrelated rows and unrelated work. No summary, multi-supplier support,
  dependencies or publication.

Legacy collision safety: if multiple existing rows normalize to one key, an
import supplying that key explicitly chooses its replacement. Without such an
explicit replacement, refuse the operation without changes rather than discard
an owner's row arbitrarily. The owner's preference for any automatic winner in
that legacy situation is not established.

Acceptance: real CLI tests for normalized duplicates and updates, exact large
integer JSON values, legacy-data compatibility, trimming, sorting, empty inputs,
malformed rows, atomic rejection and readable failures. Run the existing
`python3 -m unittest discover -v` suite.
