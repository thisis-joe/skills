# Purchasing catalog

Use Python stdlib and the existing CLI:

```sh
python3 catalog.py --db PATH import CSV_PATH
python3 catalog.py --db PATH list
```

Import UTF-8 CSV with the exact `sku,name,price_cents` header. A UTF-8 BOM is
accepted. Each data record must contain exactly three fields. Quoted commas and
newlines are supported. Fields are trimmed; SKU and name must be nonempty, and
price must be nonnegative integer cents written as decimal digits.

```csv
sku,name,price_cents
A100,Apples,250
B200,"Tea, green",450
A100,Apples,275
```

SKU keys are case sensitive. The last row for each trimmed SKU wins within a
file (`A100` becomes 275 cents above). A later import updates an existing item's
name and price; other stored items are preserved.

Any malformed row rejects the **entire import**, even if a later row repeats its
SKU. Blank data records, missing/extra fields, invalid prices, bad CSV syntax,
invalid UTF-8 and incorrect headers fail. No rows are skipped. Empty and
header-only files import no rows and preserve stored data.

Success returns exit 0; success stdout has no required format. Failure returns
nonzero with a readable stderr message and no traceback. File and storage errors
also leave the catalog unchanged. The existing SQLite integer storage range
applies to final stored prices (at most 9223372036854775807 cents); an unstoreable
price fails the import without partial writes.

`list` returns a JSON array of `{sku,name,price_cents}` objects, sorted
lexicographically by the stored SKU key. No summary or multi-supplier feature is
included.

Checks: `python3 -m unittest discover -v`. Tests exercise the real CLI using
disposable databases and CSV files; they do not modify the user's catalog.
