# Sole execution state
Spec: [agreement](spec.md).
Import/list: pending; no implementation exists. Automatic technical scope covers this import feature only and stops before push. Next: recover the recorded choices and implement/check/commit.
