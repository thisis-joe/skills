import json,subprocess,sys,tempfile,unittest
class Catalog(unittest.TestCase):
 def test_empty_list(self):
  with tempfile.TemporaryDirectory() as d:
   self.assertEqual(json.loads(subprocess.check_output([sys.executable,'catalog.py','--db',d+'/x.sqlite','list'])),[])
