import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest


PROJECT = Path(__file__).resolve().parent


class Catalog(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(dir=PROJECT)
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.db = self.root / 'catalog.sqlite'
        self.csv = self.root / 'daily.csv'

    def cli(self, *args):
        return subprocess.run(
            [sys.executable, str(PROJECT / 'catalog.py'), '--db', str(self.db), *args],
            capture_output=True, text=True,
        )

    def import_text(self, text):
        self.csv.write_text(text, encoding='utf-8')
        return self.cli('import', str(self.csv))

    def items(self):
        result = self.cli('list')
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def assert_failure(self, result):
        self.assertNotEqual(result.returncode, 0)
        self.assertTrue(result.stderr.strip())
        self.assertNotIn('Traceback', result.stderr)

    def test_empty_list(self):
        self.assertEqual(self.items(), [])

    def test_import_last_duplicate_updates_existing_and_sorts(self):
        first = self.import_text(
            'sku,name,price_cents\n'
            'z,Retained,999\n'
            ' B , First name , 200 \n'
            'a,"사과, fresh",0\n'
            'b,Last name,300\n'
        )
        self.assertEqual(first.returncode, 0, first.stderr)
        self.assertEqual(self.items(), [
            {'sku': 'a', 'name': '사과, fresh', 'price_cents': 0},
            {'sku': 'b', 'name': 'Last name', 'price_cents': 300},
            {'sku': 'z', 'name': 'Retained', 'price_cents': 999},
        ])
        second = self.import_text('sku,name,price_cents\n B ,Updated,450\n')
        self.assertEqual(second.returncode, 0, second.stderr)
        self.assertEqual(self.items(), [
            {'sku': 'a', 'name': '사과, fresh', 'price_cents': 0},
            {'sku': 'b', 'name': 'Updated', 'price_cents': 450},
            {'sku': 'z', 'name': 'Retained', 'price_cents': 999},
        ])

    def test_empty_and_header_only_import_preserve_items(self):
        seed = self.import_text('sku,name,price_cents\nkeep,Original,123\n')
        self.assertEqual(seed.returncode, 0, seed.stderr)
        for text in ('', 'sku,name,price_cents\n'):
            with self.subTest(text=text):
                result = self.import_text(text)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(self.items(), [
                    {'sku': 'keep', 'name': 'Original', 'price_cents': 123},
                ])

    def test_only_last_duplicate_value_is_stored(self):
        result = self.import_text(
            'sku,name,price_cents\n'
            'same,Superseded,9223372036854775808\n'
            'same,Final,25\n'
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [
            {'sku': 'same', 'name': 'Final', 'price_cents': 25},
        ])

    def test_malformed_row_rejects_whole_import_without_changes(self):
        seed = self.import_text('sku,name,price_cents\nkeep,Original,123\n')
        self.assertEqual(seed.returncode, 0, seed.stderr)
        before = self.db.read_bytes()
        malformed_rows = (
            '\n',
            'missing,Name\n',
            'extra,Name,1,unexpected\n',
            '  ,Name,1\n',
            'bad,  ,1\n',
            'bad,Name,\n',
            'bad,Name,-1\n',
            'bad,Name,1.5\n',
            'bad,Name,1e3\n',
            'bad,Name,NaN\n',
            'bad,"Unclosed,1\n',
            'bad,"Name"garbage,1\n',
            # An overwritten malformed row must still reject the file.
            'repeat,Name,invalid\nrepeat,Corrected,2\n',
        )
        for row in malformed_rows:
            with self.subTest(row=row):
                result = self.import_text(
                    'sku,name,price_cents\nkeep,Changed,2\nnew,New,3\n' + row
                )
                self.assert_failure(result)
                self.assertEqual(self.db.read_bytes(), before)
                self.assertEqual(self.items(), [
                    {'sku': 'keep', 'name': 'Original', 'price_cents': 123},
                ])

    def test_invalid_header_encoding_and_missing_file_leave_store_unchanged(self):
        seed = self.import_text('sku,name,price_cents\nkeep,Original,123\n')
        self.assertEqual(seed.returncode, 0, seed.stderr)
        before = self.db.read_bytes()
        for content in (
            b'sku,name\n',
            b'name,sku,price_cents\n',
            b'sku,name,price_cents,extra\n',
            b'sku,name,price_cents\nnew,Name,1\ninvalid,\xff,2\n',
        ):
            with self.subTest(content=content):
                self.csv.write_bytes(content)
                self.assert_failure(self.cli('import', str(self.csv)))
                self.assertEqual(self.db.read_bytes(), before)
        self.assert_failure(self.cli('import', str(self.root / 'missing.csv')))
        self.assert_failure(self.cli('import', str(self.root)))
        self.assertEqual(self.db.read_bytes(), before)

    def test_invalid_input_does_not_create_database(self):
        result = self.import_text('sku,name,price_cents\nx,Name,-1\n')
        self.assert_failure(result)
        self.assertIn('price_cents', result.stderr)
        self.assertFalse(self.db.exists())

    def test_legacy_database_and_sqlite_error_rollback(self):
        # Use the pre-feature schema and a real storage failure after earlier writes.
        with sqlite3.connect(self.db) as connection:
            connection.execute(
                'CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, '
                'price_cents INTEGER NOT NULL)'
            )
            connection.execute("INSERT INTO catalog VALUES (' KEEP ', 'Original', 123)")
            connection.execute(
                "CREATE TRIGGER reject_stop BEFORE INSERT ON catalog "
                "WHEN NEW.sku = 'stop' BEGIN "
                "SELECT RAISE(ABORT, 'storage rejected stop'); END"
            )
        before = self.db.read_bytes()
        result = self.import_text(
            'sku,name,price_cents\nkeep,Changed,2\nnew,New,3\nstop,Rejected,4\n'
        )
        self.assert_failure(result)
        self.assertIn('storage rejected stop', result.stderr)
        self.assertEqual(self.db.read_bytes(), before)
        self.assertEqual(self.items(), [
            {'sku': 'keep', 'name': 'Original', 'price_cents': 123},
        ])
        result = self.import_text('sku,name,price_cents\nkeep,Updated,5\nnew,New,3\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [
            {'sku': 'keep', 'name': 'Updated', 'price_cents': 5},
            {'sku': 'new', 'name': 'New', 'price_cents': 3},
        ])

    def test_arbitrary_integer_prices_round_trip_exactly_with_legacy_rows(self):
        self.seed_legacy([('Legacy', 'Retained integer', 17)])
        result = self.import_text(
            'sku,name,price_cents\n'
            ' FIRST ,Earlier,1\n'
            'first,Above signed 64 bit,9223372036854775808\n'
            'SECOND,Above 80 bits,1208925819614629174706183\n'
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        result = self.cli('list')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), [
            {'sku': 'first', 'name': 'Above signed 64 bit', 'price_cents': 9223372036854775808},
            {'sku': 'legacy', 'name': 'Retained integer', 'price_cents': 17},
            {'sku': 'second', 'name': 'Above 80 bits', 'price_cents': 1208925819614629174706183},
        ])
        self.assertIn('"price_cents": 9223372036854775808', result.stdout)
        self.assertIn('"price_cents": 1208925819614629174706183', result.stdout)
        for item in json.loads(result.stdout):
            self.assertIs(type(item['price_cents']), int)
        with sqlite3.connect(self.db) as connection:
            self.assertEqual(connection.execute(
                "SELECT price_cents, typeof(price_cents) FROM catalog WHERE sku = 'legacy'"
            ).fetchone(), (17, 'integer'))
        result = self.import_text(
            'sku,name,price_cents\n FIRST ,Updated huge price,1208925819614629174706183\n'
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items()[0], {
            'sku': 'first', 'name': 'Updated huge price', 'price_cents': 1208925819614629174706183,
        })

    def test_malformed_row_after_huge_prices_rejects_without_changes(self):
        self.seed_legacy([(' KEEP ', 'Original', 123)])
        before = self.db.read_bytes()
        result = self.import_text(
            'sku,name,price_cents\nKEEP,Changed,9223372036854775808\n'
            'new,New,1208925819614629174706183\n bad ,Invalid,-1\nBAD,Corrected,0\n'
        )
        self.assert_failure(result)
        self.assertIn('line 4', result.stderr)
        self.assertEqual(self.db.read_bytes(), before)

    def test_price_has_no_decimal_conversion_or_csv_field_ceiling(self):
        for digits in (5001, 131073):
            with self.subTest(digits=digits):
                price = '9' * digits
                result = self.import_text(f'sku,name,price_cents\nHUGE,Large,{price}\n')
                self.assertEqual(result.returncode, 0, result.stderr)
                result = self.cli('list')
                self.assertEqual(result.returncode, 0, result.stderr)
                # Parse numbers as strings only in this test process, whose
                # default Python conversion guard otherwise caps 4300 digits.
                self.assertEqual(json.loads(result.stdout, parse_int=str), [
                    {'sku': 'huge', 'name': 'Large', 'price_cents': price},
                ])
                self.assertIn('"price_cents": ' + price, result.stdout)

    def test_leading_zero_prices_are_json_integers(self):
        result = self.import_text(
            'sku,name,price_cents\nZero,Zero,0000\nONE,One,0001\n'
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [
            {'sku': 'one', 'name': 'One', 'price_cents': 1},
            {'sku': 'zero', 'name': 'Zero', 'price_cents': 0},
        ])

    def test_utf8_bom_multiline_fields_and_normalized_keys(self):
        result = self.import_text(
            '\ufeffsku,name,price_cents\r\n'
            ' M ,"line one\nline two",10\r\n'
            'A,Uppercase,15\r\n'
            'a,Lowercase,20\r\n'
            '"x\' OR 1=1;--",Literal key,30\r\n'
            ' Ä ,Unicode key,40\r\n'
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [
            {'sku': 'a', 'name': 'Lowercase', 'price_cents': 20},
            {'sku': 'm', 'name': 'line one\nline two', 'price_cents': 10},
            {'sku': "x' or 1=1;--", 'name': 'Literal key', 'price_cents': 30},
            {'sku': 'ä', 'name': 'Unicode key', 'price_cents': 40},
        ])
        with sqlite3.connect(self.db) as connection:
            self.assertEqual(connection.execute('SELECT sku FROM catalog ORDER BY sku').fetchall(),
                             [('a',), ('m',), ("x' or 1=1;--",), ('ä',)])

    def seed_legacy(self, rows):
        with sqlite3.connect(self.db) as connection:
            connection.execute(
                'CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, '
                'price_cents INTEGER NOT NULL)'
            )
            connection.executemany('INSERT INTO catalog VALUES (?, ?, ?)', rows)

    def test_list_normalizes_unique_legacy_keys_without_changing_values(self):
        self.seed_legacy([(' Z ', 'Retained', 999), ('A', 'Original', 123)])
        self.assertEqual(self.items(), [
            {'sku': 'a', 'name': 'Original', 'price_cents': 123},
            {'sku': 'z', 'name': 'Retained', 'price_cents': 999},
        ])
        with sqlite3.connect(self.db) as connection:
            self.assertEqual(connection.execute(
                'SELECT sku, name, price_cents, typeof(price_cents) FROM catalog ORDER BY sku'
            ).fetchall(), [('a', 'Original', 123, 'integer'), ('z', 'Retained', 999, 'integer')])

    def test_import_updates_legacy_case_variant_and_retains_other_rows(self):
        self.seed_legacy([(' MiXeD ', 'Old', 7), ('Z', 'Retained', 999)])
        result = self.import_text(
            'sku,name,price_cents\nMIXED,First,20\n mixed ,Last,30\n'
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [
            {'sku': 'mixed', 'name': 'Last', 'price_cents': 30},
            {'sku': 'z', 'name': 'Retained', 'price_cents': 999},
        ])

    def test_legacy_collisions_require_explicit_replacement(self):
        self.seed_legacy([('A', 'Uppercase', 10), (' a ', 'Spaced', 20), ('a', 'Lowercase', 30)])
        before = self.db.read_bytes()
        result = self.cli('list')
        self.assert_failure(result)
        self.assertIn('conflicting stored SKU', result.stderr)
        self.assertEqual(self.db.read_bytes(), before)
        self.assert_failure(self.import_text('sku,name,price_cents\nz,Unrelated,1\n'))
        self.assertEqual(self.db.read_bytes(), before)
        for empty in ('', 'sku,name,price_cents\n'):
            result = self.import_text(empty)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(self.db.read_bytes(), before)
        result = self.import_text('sku,name,price_cents\n A ,Chosen replacement,40\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [
            {'sku': 'a', 'name': 'Chosen replacement', 'price_cents': 40},
        ])

    def test_invalid_import_does_not_normalize_legacy_keys(self):
        self.seed_legacy([(' KEEP ', 'Original', 123)])
        before = self.db.read_bytes()
        result = self.import_text(
            'sku,name,price_cents\nkeep,Changed,1\nBad,Name,-1\n bad ,Corrected,2\n'
        )
        self.assert_failure(result)
        self.assertEqual(self.db.read_bytes(), before)

    def test_database_errors_are_readable(self):
        self.csv.write_text('sku,name,price_cents\nx,Name,1\n', encoding='utf-8')
        self.db = self.root / 'missing-directory' / 'catalog.sqlite'
        self.assert_failure(self.cli('import', str(self.csv)))
        self.assert_failure(self.cli('list'))
        self.db = self.root / 'corrupt.sqlite'
        self.db.write_bytes(b'not a SQLite database')
        before = self.db.read_bytes()
        self.assert_failure(self.cli('import', str(self.csv)))
        self.assertEqual(self.db.read_bytes(), before)


if __name__ == '__main__':
    unittest.main()
