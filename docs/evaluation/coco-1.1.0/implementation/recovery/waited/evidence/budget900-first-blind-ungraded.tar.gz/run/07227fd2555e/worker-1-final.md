Three owner choices are needed before implementation:

1. **Repeated SKU within a CSV:** should the last valid row win, the first win, or duplicates fail? I recommend **last valid row wins** so later corrections take effect.
2. **SKU already stored:** replace its name/price, keep the stored item, or fail? I recommend **replace** for daily catalog updates.
3. **Malformed rows:** skip them with stderr diagnostics and import valid rows, or reject the entire file without changes? I recommend **skip malformed rows**; file/header/read failures would still fail without changes.

Do you accept these recommendations, or prefer other choices?

Implementation: pending these decisions; no changes or commits. Review: pending. Verification: existing unittest passed (1 test); feature checks pending. Unrelated files and stored data remain untouched.