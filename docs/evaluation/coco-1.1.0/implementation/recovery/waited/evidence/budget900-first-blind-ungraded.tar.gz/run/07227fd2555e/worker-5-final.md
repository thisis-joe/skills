These requirements are already implemented and locally committed through `8531368`, together with your earlier lowercase-SKU, atomic-rejection, and exact-integer requirements.

- **Implementation:** complete.
- **Review:** same-agent review complete.
- **Verification:** 18 tests and real CLI checks previously passed; no code changed afterward.

The unanswered legacy-collision policy remains open; current behavior preserves conflicting rows and fails unchanged. No new commits or push.