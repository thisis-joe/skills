The current implementation already satisfies this contract, alongside your earlier lowercase-SKU, whole-file rejection, and unlimited exact-integer requirements. No new changes or commits were needed.

- **Implementation:** committed through `8531368`; nothing pushed.
- **Review:** same-agent review completed.
- **Verification:** previously observed 18 passing tests and real CLI checks remain applicable; code is unchanged.

One policy remains undecided: when existing rows such as `A` and `a` conflict and the CSV supplies no replacement, should the operation fail unchanged? I recommend retaining that current safeguard.