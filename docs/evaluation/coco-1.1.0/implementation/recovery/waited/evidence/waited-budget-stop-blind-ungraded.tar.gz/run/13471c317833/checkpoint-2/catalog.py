import argparse
from contextlib import closing
import csv
import json
import sqlite3
import sys


def read_items(path):
    items = {}
    with open(path, encoding='utf-8', newline='') as source:
        reader = csv.reader(source, strict=True)
        try:
            header = next(reader, None)
            if header is None:
                return items
            if header != ['sku', 'name', 'price_cents']:
                raise ValueError('CSV header must be sku,name,price_cents')
            for row in reader:
                if len(row) != 3:
                    raise ValueError(f'CSV line {reader.line_num}: expected 3 fields')
                sku, name, price = (value.strip() for value in row)
                if not sku or not name:
                    raise ValueError(
                        f'CSV line {reader.line_num}: SKU and name must be nonempty'
                    )
                if not price.isdecimal():
                    raise ValueError(
                        f'CSV line {reader.line_num}: '
                        'price_cents must be a nonnegative integer'
                    )
                try:
                    cents = int(price)
                except ValueError:
                    raise ValueError(
                        f'CSV line {reader.line_num}: price_cents is too large'
                    ) from None
                items[sku] = (sku, name, cents)
        except csv.Error as error:
            raise ValueError(f'CSV line {reader.line_num}: {error}') from None
    return items


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    importer = commands.add_parser('import')
    importer.add_argument('csv_path')
    args = parser.parse_args()

    try:
        items = read_items(args.csv_path) if args.command == 'import' else None
        if items == {}:
            return 0
        with closing(sqlite3.connect(args.db)) as connection:
            with connection:
                connection.execute('BEGIN')
                connection.execute(
                    'CREATE TABLE IF NOT EXISTS catalog '
                    '(sku TEXT PRIMARY KEY, name TEXT NOT NULL, '
                    'price_cents INTEGER NOT NULL)'
                )
                if args.command == 'import':
                    connection.executemany(
                        'INSERT INTO catalog (sku,name,price_cents) VALUES (?,?,?) '
                        'ON CONFLICT(sku) DO UPDATE SET '
                        'name=excluded.name, price_cents=excluded.price_cents',
                        items.values(),
                    )
                else:
                    print(json.dumps([
                        dict(sku=sku, name=name, price_cents=cents)
                        for sku, name, cents in connection.execute(
                            'SELECT sku,name,price_cents FROM catalog ORDER BY sku'
                        )
                    ]))
    except (OSError, UnicodeError, ValueError, OverflowError, sqlite3.Error) as error:
        print(f'{args.command} failed: {error}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
