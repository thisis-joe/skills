Public contract: Python stdlib, UTF-8 CSV with sku,name,price_cents
header; nonempty SKU and name after trimming; nonnegative integer cents. Add
python3 catalog.py --db PATH import CSV_PATH. Preserve the existing list command,
returning a JSON array of {sku,name,price_cents}, sorted lexicographically by the
stored SKU key. Empty/header-only input imports no rows and preserves stored data.
Import success returns exit 0; failure returns nonzero with a readable stderr
message and no traceback. Import success stdout has no required format.
Every row is validated, even if a later row repeats its SKU. Any malformed row
rejects the entire import and leaves the catalog unchanged. For repeated SKUs
in a valid file, the last row wins. Later imports update matching stored items;
all other stored items are preserved.
No summary or multi-supplier feature is requested. Use the existing unittest
command and exercise the real CLI. Choices outside this contract remain undecided.

Checks: python3 -m unittest discover -v.
