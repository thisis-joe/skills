# Daily CSV import

Authority: `BRIEF.md`, the public interface in `README.md`, and the owner's
collision/error decisions. No material product decisions remain open.

- Add `python3 catalog.py --db PATH import CSV_PATH` using Python stdlib.
- Read UTF-8 CSV with the `sku,name,price_cents` header. Trim SKU/name; both must
  be nonempty. Prices must be nonnegative integer cents.
- Validate every row, including rows later superseded by a duplicate. Any
  malformed row rejects the entire import with nonzero status, readable stderr
  and no traceback; the catalog remains unchanged.
- Within one file the last row for a trimmed SKU wins. Later imports update the
  stored name and price for matching keys. Unrelated stored items survive.
- Empty and header-only files succeed without changing stored data. File,
  decoding, CSV and database failures must be readable and cannot partially
  apply an import.
- Preserve `list`: JSON objects with `sku`, `name`, `price_cents`, ordered
  lexicographically by stored SKU. Keep the existing database schema usable.
- No summary, suppliers, dependencies, external services or publication.

Acceptance: exercise success, repeat imports, collisions, trimming, Unicode,
empty input, malformed data and rollback through the actual CLI on disposable
databases. Run `python3 -m unittest discover -v`. Review the whole feature diff
in the same agent (disclosed, not independent) and commit local work units.
