Implementation is pending owner decisions; no files changed or commits created. Same-agent review has not started. Baseline verification passed: the existing unittest and real `list` CLI check. Import remains unverified. Existing data and unrelated notes are preserved.

Three choices block implementation:

1. **Repeated SKU within one CSV:** use the first valid row, last valid row, or reject duplicates? I recommend **last valid row wins**, allowing later corrections.
2. **SKU already stored:** replace its name/price, preserve the stored item, or reject the collision? I recommend **replace**, so daily imports can update the catalog.
3. **Malformed rows:** skip them with stderr diagnostics, or reject the entire import without changes? I recommend **skip invalid rows** to retain usable daily entries; invalid headers or unreadable CSV structure would still fail without changes.

Do you accept these recommendations, or which alternatives should apply?