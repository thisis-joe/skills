import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest


CLI = Path(__file__).with_name('catalog.py')


class Catalog(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(dir=CLI.parent)
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.db = self.root / 'catalog.sqlite'

    def cli(self, *arguments):
        return subprocess.run(
            [sys.executable, str(CLI), '--db', str(self.db), *arguments],
            capture_output=True, text=True, encoding='utf-8',
        )

    def import_csv(self, contents):
        path = self.root / 'daily.csv'
        path.write_text(contents, encoding='utf-8')
        return self.cli('import', str(path))

    def items(self):
        result = self.cli('list')
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def test_empty_list(self):
        self.assertEqual(self.items(), [])

    def test_import_last_row_updates_existing_and_preserves_other_items(self):
        result = self.import_csv(
            'sku,name,price_cents\n'
            'keep,Legacy item,41\n'
            'b,Old name,10\n'
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        result = self.import_csv(
            'sku,name,price_cents\n'
            ' b , Earlier value , 12 \n'
            'a,"배, 사과",0\n'
            'b," Final\nname ",25\n'
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [
            {'sku': 'a', 'name': '배, 사과', 'price_cents': 0},
            {'sku': 'b', 'name': 'Final\nname', 'price_cents': 25},
            {'sku': 'keep', 'name': 'Legacy item', 'price_cents': 41},
        ])

    def test_malformed_rows_reject_whole_import_even_if_later_overwritten(self):
        for index, malformed in enumerate((
            ' ,Missing SKU,1',
            'bad,   ,1',
            'bad,Negative,-1',
            'bad,Fraction,1.5',
            'bad,Text,free',
            'bad,Missing price,',
            'bad,Underscores,1_000',
            'bad,Missing field',
            'bad,Extra field,1,unexpected',
            '',
        )):
            with self.subTest(row=malformed):
                self.db = self.root / f'invalid-{index}.sqlite'
                result = self.import_csv(
                    'sku,name,price_cents\nkeep,Legacy item,41\n'
                )
                self.assertEqual(result.returncode, 0, result.stderr)
                before = self.items()
                result = self.import_csv(
                    'sku,name,price_cents\n'
                    'keep,Changed,99\n'
                    'new,Must roll back,7\n'
                    + malformed + '\n'
                    'bad,Later valid duplicate,2\n'
                )
                self.assertNotEqual(result.returncode, 0)
                self.assertIn('CSV line 4', result.stderr)
                self.assertNotIn('Traceback', result.stderr)
                self.assertEqual(self.items(), before)

    def test_empty_and_header_only_inputs_preserve_stored_items(self):
        result = self.import_csv('sku,name,price_cents\nkeep,Legacy item,41\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        before = self.items()
        for contents in ('', 'sku,name,price_cents\n', 'sku,name,price_cents\r\n'):
            with self.subTest(contents=contents):
                result = self.import_csv(contents)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(self.items(), before)

    def test_invalid_headers_and_csv_syntax_preserve_stored_items(self):
        result = self.import_csv('sku,name,price_cents\nkeep,Legacy item,41\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        before = self.items()
        for contents in (
            'name,sku,price_cents\nName,new,1\n',
            'sku,name\nnew,Name\n',
            'sku,name,price_cents,other\nnew,Name,1,extra\n',
            'sku,sku,price_cents\nnew,Name,1\n',
            'sku,name,price_cents\nkeep,Changed,99\nnew,"Unclosed,1\n',
            'sku,name,price_cents\nkeep,Changed,99\nnew,"Name"junk,1\n',
        ):
            with self.subTest(contents=contents):
                result = self.import_csv(contents)
                self.assertNotEqual(result.returncode, 0)
                self.assertIn('CSV', result.stderr)
                self.assertNotIn('Traceback', result.stderr)
                self.assertEqual(self.items(), before)

    def test_missing_file_and_invalid_utf8_have_readable_errors(self):
        result = self.import_csv('sku,name,price_cents\nkeep,Legacy item,41\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        before = self.items()
        invalid = self.root / 'invalid.csv'
        invalid.write_bytes(b'sku,name,price_cents\nkeep,Changed,99\nnew,\xff,1\n')
        for path in (self.root / 'missing.csv', invalid):
            with self.subTest(path=path.name):
                result = self.cli('import', str(path))
                self.assertNotEqual(result.returncode, 0)
                self.assertIn('import failed:', result.stderr)
                self.assertNotIn('Traceback', result.stderr)
                self.assertEqual(self.items(), before)

    def test_database_failure_rolls_back_updates_and_inserts(self):
        result = self.import_csv('sku,name,price_cents\nkeep,Legacy item,41\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        before = self.items()
        with sqlite3.connect(self.db) as connection:
            connection.execute(
                "CREATE TRIGGER reject_item BEFORE INSERT ON catalog "
                "WHEN NEW.sku = 'blocked' BEGIN "
                "SELECT RAISE(ABORT, 'blocked item'); END"
            )
        result = self.import_csv(
            'sku,name,price_cents\n'
            'keep,Changed,99\n'
            'new,Must roll back,7\n'
            'blocked,Rejected,3\n'
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('blocked item', result.stderr)
        self.assertNotIn('Traceback', result.stderr)
        self.assertEqual(self.items(), before)

    def test_storage_integer_overflow_rolls_back_without_traceback(self):
        result = self.import_csv('sku,name,price_cents\nkeep,Legacy item,41\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        before = self.items()
        result = self.import_csv(
            'sku,name,price_cents\n'
            'keep,Changed,99\n'
            'large,Too large,9223372036854775808\n'
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('import failed:', result.stderr)
        self.assertNotIn('Traceback', result.stderr)
        self.assertEqual(self.items(), before)

    def test_invalid_import_does_not_create_a_database(self):
        result = self.import_csv('sku,name,price_cents\nbad,Negative,-1\n')
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('CSV line 2', result.stderr)
        self.assertFalse(self.db.exists())

    def test_unopenable_database_has_readable_error(self):
        self.db = self.root / 'missing-directory' / 'catalog.sqlite'
        result = self.import_csv('sku,name,price_cents\nnew,Name,1\n')
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('import failed:', result.stderr)
        self.assertNotIn('Traceback', result.stderr)
