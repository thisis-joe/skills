import argparse
from contextlib import closing
import csv
import json
import sqlite3
import sys


def read_items(path):
    items = {}
    with open(path, encoding='utf-8', newline='') as source:
        reader = csv.reader(source, strict=True)
        try:
            header = next(reader, None)
            if header is None:
                return items
            if header != ['sku', 'name', 'price_cents']:
                raise ValueError('CSV header must be sku,name,price_cents')
            for row in reader:
                if len(row) != 3:
                    raise ValueError(f'CSV line {reader.line_num}: expected 3 fields')
                sku, name, price = (value.strip() for value in row)
                sku = sku.lower()
                if not sku or not name:
                    raise ValueError(
                        f'CSV line {reader.line_num}: SKU and name must be nonempty'
                    )
                if not price.isdecimal():
                    raise ValueError(
                        f'CSV line {reader.line_num}: '
                        'price_cents must be a nonnegative integer'
                    )
                cents = int(price)
                items[sku] = (sku, name, cents)
        except csv.Error as error:
            raise ValueError(f'CSV line {reader.line_num}: {error}') from None
    return items


def normalize_stored_keys(connection, replacements):
    groups = {}
    for sku, name, cents in connection.execute('SELECT sku,name,price_cents FROM catalog'):
        key = sku.strip().lower()
        if not key:
            raise ValueError('stored SKU is empty after trimming')
        groups.setdefault(key, []).append((sku, name, cents))

    for key, rows in groups.items():
        values = {(name, int(cents)) for _, name, cents in rows}
        if len(values) > 1 and key not in replacements:
            raise ValueError(
                f'conflicting stored SKUs normalize to {key!r}; '
                'import an explicit replacement for this key'
            )

    for key, rows in groups.items():
        keeper = next((row for row in rows if row[0] == key), rows[0])
        connection.executemany(
            'DELETE FROM catalog WHERE sku=?',
            ((sku,) for sku, _, _ in rows if sku != keeper[0]),
        )
        if keeper[0] != key:
            connection.execute('UPDATE catalog SET sku=? WHERE sku=?', (key, keeper[0]))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    importer = commands.add_parser('import')
    importer.add_argument('csv_path')
    args = parser.parse_args()

    # These limits apply only to this CLI process, not to accepted price values.
    if hasattr(sys, 'set_int_max_str_digits'):
        sys.set_int_max_str_digits(0)
    csv.field_size_limit(sys.maxsize)

    try:
        items = read_items(args.csv_path) if args.command == 'import' else None
        if items == {}:
            return 0
        with closing(sqlite3.connect(args.db)) as connection:
            with connection:
                connection.execute('BEGIN')
                connection.execute(
                    'CREATE TABLE IF NOT EXISTS catalog '
                    '(sku TEXT PRIMARY KEY, name TEXT NOT NULL, '
                    'price_cents INTEGER NOT NULL)'
                )
                normalize_stored_keys(connection, items or {})
                if args.command == 'import':
                    # BLOB decimal digits avoid SQLite INTEGER affinity rounding to REAL.
                    connection.executemany(
                        'INSERT INTO catalog (sku,name,price_cents) VALUES (?,?,?) '
                        'ON CONFLICT(sku) DO UPDATE SET '
                        'name=excluded.name, price_cents=excluded.price_cents',
                        ((sku, name, str(cents).encode('ascii'))
                         for sku, name, cents in items.values()),
                    )
                else:
                    print(json.dumps([
                        dict(sku=sku, name=name, price_cents=int(cents))
                        for sku, name, cents in connection.execute(
                            'SELECT sku,name,price_cents FROM catalog ORDER BY sku'
                        )
                    ]))
    except (OSError, UnicodeError, ValueError, OverflowError, sqlite3.Error) as error:
        print(f'{args.command} failed: {error}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
