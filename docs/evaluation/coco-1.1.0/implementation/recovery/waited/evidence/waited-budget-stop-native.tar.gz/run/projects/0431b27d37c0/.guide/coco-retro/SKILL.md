---
name: coco-retro
description: "Use when examining a completed task or incident, repeated failures, an agent workflow, or a demonstrated lesson that needs a reusable improvement."
license: MIT
---

# coco-retro

Convert observed failure patterns into a narrow, verifiable structural improvement.

Read the [common contract](../_coco-shared/contracts.md) before acting; when the request already shows that the file below applies, read both in one call. Initially and on new scope, risk, state, or missing prerequisites, check for a session retrospective, a recurring mistake class that needs a guardrail, reflecting lessons into maintained instructions or skills, and a work-environment audit (navigation, checks, ownership, context economy). If any applies or is unclear, read the [advanced modes](../_coco-shared/advanced/retro.md) before dependent work.

## Procedure and output

1. Define the task/run boundary and collect actual diffs, commands, outcomes and decision evidence. Do not treat a persuasive summary as proof.
2. Separate requirement misunderstanding, reasoning/implementation defect, missing feedback, tool/coordination failure and unnecessary process. Record what worked as well as what failed.
3. Identify a concrete recurring or consequential failure and its load-bearing cause. Prefer a test, invariant, helper or precise instruction that prevents it over a general motivational rule.
4. For skill/evaluation experiments, establish a no-guidance baseline and realistic held-out tasks; record repetitions, scoring, artifacts and limitations. Independent evaluation receives raw artifacts and contract rather than the author's desired answer.
5. Apply only supported changes inside scope. Preserve original intent and compare before/after behavior; remove instructions whose cost exceeds their demonstrated value.
6. Surface unresolved risks and required user decisions. A lesson does not authorize changing global settings, installing tools, messaging others or scheduling follow-up work automatically.

Return: evidence-backed findings, targeted improvement, checking scenario and result/limitations.
