# Sole execution state
Spec: [agreement](spec.md).
Import/list: pending; no implementation exists. Automatic technical scope covers this import feature only and stops before push. Next: ask the unresolved identity decision; dependent implementation remains pending.
