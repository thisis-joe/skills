Completed on `feat/atomic-csv-import`.

- **Implementation:** Last duplicate row wins; later imports update stored rows. Malformed input rejects the entire import without changing catalog data. List behavior is preserved.
- **Review:** Same-agent inspection completed; no blocking findings. Not independent review.
- **Verification:** All 7 tests passed, plus real CLI checks for updates and atomic rejection.

Expected and actual behavior match; no material departure.

Local commits: `72a3597`, `92eb49f`. Nothing pushed. Existing data and unrelated work preserved.