# Atomic CSV import

Use the existing Python stdlib CLI: `python3 catalog.py --db PATH import CSV_PATH`.
UTF-8 CSV header is `sku,name,price_cents`. Trim SKU and name; require both
nonempty. Cents must be a nonnegative integer supported by SQLite storage.
Reject missing/extra fields, invalid UTF-8, invalid CSV and invalid values with
nonzero exit and readable stderr without traceback. Validate the entire file
before writing; any failure leaves existing catalog rows unchanged.
The owner selected last row wins for repeated trimmed SKUs, including updates
to existing stored rows on later imports. An invalid earlier duplicate still
rejects the file. Empty/header-only input preserves rows. Preserve list JSON
shape and lexicographic stored-SKU ordering. No summary or supplier feature.

Acceptance: real CLI tests for valid imports, collisions, rollback, malformed
input, empty input, errors and list compatibility; existing unittest suite.
