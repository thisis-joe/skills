import json,subprocess,sys,tempfile,unittest
class Catalog(unittest.TestCase):
 def test_empty_list(self):
  with tempfile.TemporaryDirectory() as d:
   self.assertEqual(json.loads(subprocess.check_output([sys.executable,'catalog.py','--db',d+'/x.sqlite','list'])),[])

class ImportCatalog(unittest.TestCase):
 def setUp(self):
  self.temp = tempfile.TemporaryDirectory()
  self.addCleanup(self.temp.cleanup)
  from pathlib import Path
  self.root = Path(self.temp.name)
  self.db = self.root / 'catalog.sqlite'
 def cli(self, *args):
  return subprocess.run([sys.executable, 'catalog.py', '--db', str(self.db), *args], capture_output=True, text=True)
 def load(self, content):
  path = self.root / 'items.csv'
  path.write_bytes(content.encode('utf-8') if isinstance(content, str) else content)
  return self.cli('import', str(path))
 def rows(self):
  result = self.cli('list')
  self.assertEqual(result.returncode, 0, result.stderr)
  return json.loads(result.stdout)
 def test_import_updates_duplicates_and_preserves_sorted_items(self):
  result = self.load('sku,name,price_cents\nz,Zed,9\n a , First ,1\na,Last,2\n')
  self.assertEqual(result.returncode, 0, result.stderr)
  self.assertEqual(self.rows(), [{'sku':'a','name':'Last','price_cents':2}, {'sku':'z','name':'Zed','price_cents':9}])
  self.assertEqual(self.load('sku,name,price_cents\na,Updated,0\n').returncode, 0)
  self.assertEqual(self.rows(), [{'sku':'a','name':'Updated','price_cents':0}, {'sku':'z','name':'Zed','price_cents':9}])
 def test_rejects_entire_malformed_import(self):
  self.assertEqual(self.load('sku,name,price_cents\na,Original,7\n').returncode, 0)
  invalid = ['a,Bad,-1', ',Blank,1', 'a, ,1', 'a,Bad,1.5', 'a,Bad', 'a,Bad,1,extra', 'a,Bad,9223372036854775808', 'a,"unterminated,1', 'a,Bad,nope\na,Valid,1', '']
  for row in invalid:
   with self.subTest(row=row):
    result = self.load('sku,name,price_cents\na,Changed,3\nb,New,4\n' + row + '\n')
    self.assertNotEqual(result.returncode, 0)
    self.assertTrue(result.stderr.strip())
    self.assertNotIn('Traceback', result.stderr)
    self.assertNotIn('invalid choice', result.stderr)
    self.assertEqual(self.rows(), [{'sku':'a','name':'Original','price_cents':7}])
 def test_empty_and_header_only_preserve_data(self):
  self.assertEqual(self.load('sku,name,price_cents\na,Original,7\n').returncode, 0)
  for content in ['', 'sku,name,price_cents\n']:
   self.assertEqual(self.load(content).returncode, 0)
   self.assertEqual(self.rows(), [{'sku':'a','name':'Original','price_cents':7}])
 def test_file_and_header_errors_are_readable(self):
  for content in ['wrong,header,here\na,Name,1\n', b'sku,name,price_cents\na,\xff,1\n']:
   result = self.load(content)
   self.assertNotEqual(result.returncode, 0)
   self.assertTrue(result.stderr.strip())
   self.assertNotIn('Traceback', result.stderr)
   self.assertNotIn('invalid choice', result.stderr)
  result = self.cli('import', str(self.root / 'missing.csv'))
  self.assertNotEqual(result.returncode, 0)
  self.assertTrue(result.stderr.strip())
  self.assertNotIn('Traceback', result.stderr)
 def test_quoted_csv_and_maximum_cents(self):
  result = self.load('sku,name,price_cents\nq,"Name, with comma",9223372036854775807\n')
  self.assertEqual(result.returncode, 0, result.stderr)
  self.assertEqual(self.rows(), [{'sku':'q','name':'Name, with comma','price_cents':9223372036854775807}])

 def test_database_failure_rolls_back_prior_updates(self):
  import sqlite3
  self.assertEqual(self.load('sku,name,price_cents\na,Original,7\n').returncode, 0)
  with sqlite3.connect(self.db) as connection:
   connection.execute("CREATE TRIGGER reject_b BEFORE INSERT ON catalog WHEN NEW.sku = 'b' BEGIN SELECT RAISE(ABORT, 'fixture write failure'); END")
  result = self.load('sku,name,price_cents\na,Changed,3\nb,New,4\n')
  self.assertNotEqual(result.returncode, 0)
  self.assertIn('fixture write failure', result.stderr)
  self.assertNotIn('Traceback', result.stderr)
  self.assertEqual(self.rows(), [{'sku':'a','name':'Original','price_cents':7}])
