Public contract: Python stdlib, UTF-8 CSV with sku,name,price_cents
header; nonempty SKU and name after trimming; nonnegative integer cents. Add
python3 catalog.py --db PATH import CSV_PATH. Preserve the existing list command,
returning a JSON array of {sku,name,price_cents}, sorted lexicographically by the
stored SKU key. Empty/header-only input imports no rows and preserves stored data.
Import success returns exit 0; failure returns nonzero with a readable stderr
message and no traceback. Import success stdout has no required format. Report
skipped malformed rows on stderr when that policy applies. Preserve existing
stored items except collisions handled by the separately chosen owner policy.
No summary or multi-supplier feature is requested. Use the existing unittest
command and exercise the real CLI. Choices outside this contract remain undecided.

Checks: python3 -m unittest discover -v.

## Import policy

Run `python3 catalog.py --db PATH import CSV_PATH`, then use
`python3 catalog.py --db PATH list` to read the stored catalog.

The last row for a trimmed SKU wins; later imports update matching stored rows.
All rows must be valid, including duplicates that would later be overwritten.
Any malformed row rejects the whole file and leaves existing catalog rows unchanged.
Errors return nonzero with readable stderr. No rows are skipped.

The header must be exactly `sku,name,price_cents`. Every data row must have
exactly three fields. SKU and name are trimmed and must be nonempty. Cents are
trimmed decimal digits from 0 through 9223372036854775807 (SQLite's integer
limit). Blank data rows, invalid UTF-8, and malformed CSV are rejected.
Empty files and header-only files import no rows and preserve existing items.
