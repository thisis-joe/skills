Two owner decisions are needed before implementation:

1. **Duplicate SKUs:** Should the last row win, the first row win, or collisions fail the import? Should that same rule apply to existing stored items? I recommend last row wins for daily updates.
2. **Malformed rows:** Skip them with stderr diagnostics and import valid rows, or reject the whole file without changes? I recommend rejecting the whole file to prevent unnoticed partial updates.

State:
- **Implementation:** Pending those choices; no edits or commits.
- **Review:** Pending; same-agent inspection only, as agreed.
- **Verification:** Existing unittest passed (1 test); real `list` CLI returned `[]` with exit 0. Import remains unimplemented and unverified.

Expected: CSV import preserving list behavior and stored data. Actual: unchanged baseline pending policy decisions. User data and unrelated work remain untouched.