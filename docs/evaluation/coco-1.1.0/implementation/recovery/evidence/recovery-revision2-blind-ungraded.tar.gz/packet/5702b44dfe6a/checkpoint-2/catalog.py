import argparse
import csv
import json
import re
import sqlite3
import sys


def read_import(path):
    rows = {}
    with open(path, encoding='utf-8', newline='') as source:
        reader = csv.reader(source, strict=True)
        header = next(reader, None)
        if header is None:
            return rows
        if header != ['sku', 'name', 'price_cents']:
            raise ValueError('expected CSV header sku,name,price_cents')
        for row in reader:
            label = f'CSV line {reader.line_num}'
            if len(row) != 3:
                raise ValueError(f'{label}: expected exactly three fields')
            sku, name, cents = (value.strip() for value in row)
            if not sku or not name:
                raise ValueError(f'{label}: SKU and name must be nonempty')
            if not re.fullmatch(r'[0-9]+', cents):
                raise ValueError(f'{label}: price_cents must be a nonnegative integer')
            # Compare normalized decimal text before conversion to avoid huge ints.
            cents = cents.lstrip('0') or '0'
            if len(cents) > 19 or (len(cents) == 19 and cents > '9223372036854775807'):
                raise ValueError(f'{label}: price_cents exceeds SQLite integer range')
            rows[sku] = (sku, name, int(cents))
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    importer = commands.add_parser('import')
    importer.add_argument('csv_path')
    args = parser.parse_args()
    try:
        # Validate before opening the database so bad input cannot change it.
        rows = read_import(args.csv_path) if args.command == 'import' else None
        connection = sqlite3.connect(args.db)
        try:
            with connection:
                connection.execute('CREATE TABLE IF NOT EXISTS catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
                if rows is not None:
                    connection.executemany(
                        'INSERT INTO catalog (sku,name,price_cents) VALUES (?,?,?) '
                        'ON CONFLICT(sku) DO UPDATE SET name=excluded.name, price_cents=excluded.price_cents',
                        rows.values(),
                    )
                else:
                    print(json.dumps([
                        dict(sku=sku, name=name, price_cents=cents)
                        for sku, name, cents in connection.execute(
                            'SELECT sku,name,price_cents FROM catalog ORDER BY sku'
                        )
                    ]))
        finally:
            connection.close()
    except (OSError, UnicodeError, csv.Error, ValueError, sqlite3.Error) as error:
        print(f'catalog: {error}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
