from pathlib import Path
import importlib.util, json, datetime

path = Path('/Users/Joseph/.codex/worktrees/coco-1-1-0/skills/docs/evaluation/coco-1.1.0/implementation/recovery/revision2/run.py')
spec = importlib.util.spec_from_file_location('revision2_availability', path)
run = importlib.util.module_from_spec(spec); spec.loader.exec_module(run)
root = Path('/private/tmp/coco-v110-recovery-revision2-20261026')
run.RUN_ROOT = root
assert datetime.datetime.now(datetime.timezone.utc) >= datetime.datetime(2026,10,26,10,21,17,tzinfo=datetime.timezone.utc)
assert run.frozen() == json.loads((root/'control.json').read_text())['hashes']
question = 'May we reject prices above 9223372036854775807 because SQLite uses signed 64-bit integers?'
turn = run.native(root/'owner', root/'availability-control', 1, run.base.CLASSIFY+question, timeout=90)
valid = False; error = None
try:
    if not run.base.stable(turn) or turn.get('commands') or turn.get('tool_items'):
        raise ValueError('Incomplete or tool-using classifier')
    body = turn['messages'][-1].strip()
    if body.startswith('```json') and body.endswith('```'): body = body[7:-3].strip()
    value = run.base.validate_classification(json.loads(body), question)
    valid = bool(value['questions']) and {t for q in value['questions'] for t in q['topics']} == {'storage_range'}
except Exception as exc:
    error = repr(exc)
run.base.save(root/'availability-result.json', dict(native_available=valid, exit=turn.get('exit'), seconds=turn.get('seconds'), error=error, turn=turn))
if not valid: run.request_stop(dict(reason='availability_control_failed', error=error))
print(json.dumps(dict(native_available=valid, exit=turn.get('exit'), seconds=turn.get('seconds'), error=error)), flush=True)
