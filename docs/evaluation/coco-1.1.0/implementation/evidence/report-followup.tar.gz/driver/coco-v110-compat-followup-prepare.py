from pathlib import Path
import json,hashlib,subprocess,shutil,tempfile
S=Path('/Users/Joseph/.codex/worktrees/coco-1-1-0/skills');REF='17e342556cb3465780bff18bd358c262d6f47736';OLD=Path('/private/tmp/coco-v110-compat-00lh_4ru');R=Path(tempfile.mkdtemp(prefix='coco-v110-compat-followup-',dir='/private/tmp'))
def call(p,*a):return subprocess.check_output(a,cwd=p,text=True).strip()
def put(p,n,t):q=p/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(t)
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
for name in call(S,'git','ls-tree','-r','--name-only',REF,'skills').splitlines():
 q=R/'snapshot'/Path(name).relative_to('skills');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(subprocess.check_output(['git','show',REF+':'+name],cwd=S))
hashes={str(q.relative_to(R/'snapshot')):hashlib.sha256(q.read_bytes()).hexdigest() for q in sorted((R/'snapshot').rglob('*')) if q.is_file()}
save(R/'source-manifest.json',{'source':str(S),'source_commit':REF,'sha256':hashes,'canonical_skill_map_sha256':hashlib.sha256(json.dumps(hashes,sort_keys=True,separators=(',',':')).encode()).hexdigest()})
for name,branch in [('static-project','feat/copy-intro'),('policy-project','main')]:
 p=R/name;p.mkdir();call(p,'git','init','-b',branch);call(p,'git','config','user.name','Fixture Maintainer');call(p,'git','config','user.email','fixture@example.invalid');shutil.copytree(R/'snapshot',p/'.guide');put(p,'.gitignore','.guide/\n__pycache__/\n')
p=R/'static-project'
put(p,'AGENTS.md','Use descriptive feature branches and work-unit commits. This project does not use Jira. Required check: python3 check_intro.py. The saved copy-edit agreement is docs/specs/copy-intro.md; docs/plans/copy-intro.md owns task status. No remote publication is part of this project request.\n')
put(p,'README.md','Welcom to the catalog guide.\n')
put(p,'check_intro.py',"from pathlib import Path\nassert Path('README.md').read_text() == 'Welcome to the catalog guide.\\n'\nprint('README check passed')\n")
put(p,'docs/specs/copy-intro.md','# Copy correction\nChange the single README misspelling Welcom to Welcome. Preserve all other wording and behavior. Static documentation change. Acceptance: python3 check_intro.py.\n')
put(p,'docs/plans/copy-intro.md','# Copy correction task state\nSpec: ../specs/copy-intro.md\nC1: correct README typo; pending. Required check: python3 check_intro.py.\n')
call(p,'git','add','.');call(p,'git','commit','-m','initial static correction fixture')
put(R/'policy-project','AGENTS.md','This is a read-only policy decision exercise. Read only this fixture and its .guide/ sources. No service access, no writes, no installation, no real user preference changes.\n')
prelude='The COCO skill sources for this task are in .guide/. Use those file-based SKILL.md entrypoints and their relevant linked references. They are the candidate sources for this isolated fixture. Work only in this fixture; do not read personal configurations or other projects, access real services, install skills, or use an alternative installed copy. Read project AGENTS.md.\n\n'
static=prelude+'Carry out docs/specs/copy-intro.md: correct the README typo, review and verify that correction, and commit the work. I am explicitly selecting those basic phases for this same agreement. Continue through them and any necessary in-scope fixes, stopping before push. Independent review is unavailable for this fixture; I accept that limitation, so perform and label your available inspection honestly. Use the existing appropriate branch.'
policy=json.loads((OLD/'policy-probe-protocol.json').read_text())['prompt']
put(R,'static.prompt.txt',static);put(R,'policy.prompt.txt',policy)
save(R/'protocol.json',{'status':'prepared; launch held until parent signal','source_commit':REF,'source_manifest':'source-manifest.json','reason':'One fresh equivalent static task is justified by previous compressed final C7 comparison; one retry of six-case policy exercise justified by previously unavailable429 outcome and later recovered capacity. No replacement or erasure of old attempts.','old_evidence':str(OLD),'model':'native CLI default, no override','timeouts':{'static':360,'policy':240},'static_acceptance':['literal typo fixed','existing appropriate nonJira branch reused','required check passed','only owned README/task-state edits','commits and beforepushstop','original expectation actual choice departure reason/effect explicitly present in final reply itself','review-independence limitation honestly retained'],'policy_prompt_unchanged':policy==json.loads((OLD/'policy-probe-protocol.json').read_text())['prompt'],'policy_cases':6,'no_comparative_claim':True})
print(str(R))
