from pathlib import Path
import json,hashlib,subprocess,sys
S=Path('/Users/Joseph/.codex/worktrees/coco-1-1-0/skills');R=Path('/private/tmp/coco-v110-compat-followup-p5v2h4m_');P=R/'static-project';E=R/'records/static-c7'
sys.path.insert(0,str(S/'docs/evaluation/collaboration-value'))
from engine import native

def git(*args):return subprocess.check_output(['git',*args],cwd=P,text=True).strip()
def state():return {'head':git('rev-parse','HEAD'),'branch':git('branch','--show-current'),'status':git('status','--porcelain','--untracked-files=all'),'index':git('diff','--cached','--binary'),'files':{str(q.relative_to(P)):hashlib.sha256(q.read_bytes()).hexdigest() for q in sorted(P.rglob('*')) if q.is_file() and not any(x in q.relative_to(P).parts for x in ['.git','.guide','__pycache__'])}}
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
save(E/'before.json',state());r=native(P,E,1,(R/'static.prompt.txt').read_text(),timeout=360);save(E/'after.json',state());save(E/'result.json',r)
print(json.dumps({'exit':r.get('exit'),'timeout':r.get('timeout'),'seconds':r.get('seconds'),'messages':r.get('messages')},ensure_ascii=False),flush=True)
