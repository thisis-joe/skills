import json,subprocess,sys,tempfile,unittest
class Catalog(unittest.TestCase):
 def test_empty_list(self):
  with tempfile.TemporaryDirectory() as d:
   self.assertEqual(json.loads(subprocess.check_output([sys.executable,'catalog.py','--db',d+'/x.sqlite','list'])),[])

class ImportCatalog(unittest.TestCase):
 def test_normalized_duplicates_and_updates(self):
  with tempfile.TemporaryDirectory() as d:
   from pathlib import Path
   db=d+'/x.sqlite'; source=Path(d)/'items.csv'
   def cli(*args):
    return subprocess.run([sys.executable,'catalog.py','--db',db,*args],capture_output=True,text=True)
   source.write_text('sku,name,price_cents\n B , First ,10\na,Keep,2\nb,Last,30\n',encoding='utf-8')
   result=cli('import',str(source)); self.assertEqual(result.returncode,0,result.stderr)
   self.assertEqual(json.loads(cli('list').stdout),[{'sku':'a','name':'Keep','price_cents':2},{'sku':'b','name':'Last','price_cents':30}])
   source.write_text('sku,name,price_cents\n B ,Updated,40\n',encoding='utf-8')
   self.assertEqual(cli('import',str(source)).returncode,0)
   self.assertEqual(json.loads(cli('list').stdout)[1],{'sku':'b','name':'Updated','price_cents':40})

 def test_atomic_failures_and_empty_inputs(self):
  with tempfile.TemporaryDirectory() as d:
   from pathlib import Path
   db=d+'/x.sqlite'; source=Path(d)/'items.csv'
   def cli(*args):
    return subprocess.run([sys.executable,'catalog.py','--db',db,*args],capture_output=True,text=True)
   source.write_text('sku,name,price_cents\nkeep,Original,7\n',encoding='utf-8')
   self.assertEqual(cli('import',str(source)).returncode,0)
   original=json.loads(cli('list').stdout)
   invalid=[
    b'sku,name,price_cents\nkeep,Changed,8\nbad,Oops,-1\n',
    b'sku,name,price_cents\nkeep,Changed,8\n ,Oops,1\n',
    b'sku,name,price_cents\nkeep,Changed,8\nbad, ,1\n',
    b'sku,name,price_cents\nkeep,Changed,8\nbad,Oops,1.5\n',
    b'sku,name,price_cents\nkeep,Changed,8\nbad,Oops\n',
    b'sku,name,price_cents\nkeep,Changed,8\nbad,Oops,1,extra\n',
    b'sku,name,price_cents\nkeep,Changed,8\n"unterminated',
    b'sku,name,price_cents\nkeep,Changed,8\nbad,\xff,1\n',
    b'wrong,header\n',
    b'sku,name,price_cents\nbad,Oops,9223372036854775808\n',
   ]
   for content in invalid:
    with self.subTest(content=content):
     source.write_bytes(content)
     result=cli('import',str(source))
     self.assertNotEqual(result.returncode,0)
     self.assertTrue(result.stderr.strip())
     self.assertNotIn('Traceback',result.stderr)
     self.assertEqual(json.loads(cli('list').stdout),original)
   for content in ['', 'sku,name,price_cents\n']:
    source.write_text(content,encoding='utf-8')
    self.assertEqual(cli('import',str(source)).returncode,0)
    self.assertEqual(json.loads(cli('list').stdout),original)
   result=cli('import',d+'/missing.csv')
   self.assertNotEqual(result.returncode,0)
   self.assertTrue(result.stderr.strip())
   self.assertNotIn('Traceback',result.stderr)
   self.assertEqual(json.loads(cli('list').stdout),original)

 def test_database_error_is_readable(self):
  with tempfile.TemporaryDirectory() as d:
   result=subprocess.run([sys.executable,'catalog.py','--db',d+'/missing/x.sqlite','list'],capture_output=True,text=True)
   self.assertNotEqual(result.returncode,0)
   self.assertTrue(result.stderr.strip())
   self.assertNotIn('Traceback',result.stderr)
