import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class ImportCatalog(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.db = self.root / 'catalog.sqlite'
        self.csv = self.root / 'items.csv'

    def cli(self, *args):
        return subprocess.run([sys.executable, 'catalog.py', '--db', str(self.db),
                               *args], text=True, capture_output=True)

    def load(self, content):
        self.csv.write_text(content, encoding='utf-8')
        return self.cli('import', str(self.csv))

    def items(self):
        result = self.cli('list')
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def test_duplicates_updates_and_sorted_list(self):
        result = self.load('sku,name,price_cents\nz,Zed,10\na,First,1\na, Last ,2\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [dict(sku='a', name='Last', price_cents=2),
                                       dict(sku='z', name='Zed', price_cents=10)])
        self.assertEqual(self.load('sku,name,price_cents\n a ,New,8\n').returncode, 0)
        self.assertEqual(self.items()[0], dict(sku='a', name='New', price_cents=8))

    def test_malformed_rows_leave_catalog_unchanged(self):
        self.assertEqual(self.load('sku,name,price_cents\nkeep,Original,7\n').returncode, 0)
        original = self.items()
        for bad in ['bad,Name,-1', 'bad,Name,1.5', ',Name,2',
                    'bad, ,2', 'bad,Name', 'bad,Name,2,extra',
                    'bad,Name,9223372036854775808', 'bad,Name,+2',
                    'bad,Name,NaN', 'bad,"unterminated,2', '']:
            with self.subTest(row=bad):
                before = self.db.read_bytes()
                result = self.load('sku,name,price_cents\nkeep,Changed,9\n' + bad + '\n')
                self.assertNotEqual(result.returncode, 0)
                self.assertTrue(result.stderr.strip())
                self.assertNotIn('Traceback', result.stderr)
                self.assertEqual(self.db.read_bytes(), before)
                self.assertEqual(self.items(), original)

    def test_empty_and_header_only_preserve_data(self):
        self.assertEqual(self.load('sku,name,price_cents\nkeep,Original,7\n').returncode, 0)
        for content in ['', 'sku,name,price_cents\n']:
            result = self.load(content)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(self.items(), [dict(sku='keep', name='Original', price_cents=7)])

    def test_input_errors_do_not_create_database(self):
        for content in [b'name,sku,price_cents\n', b'sku,name,price_cents\na,\xff,1\n']:
            self.csv.write_bytes(content)
            result = self.cli('import', str(self.csv))
            self.assertNotEqual(result.returncode, 0)
            self.assertTrue(result.stderr.startswith('catalog:'), result.stderr)
            self.assertNotIn('Traceback', result.stderr)
            self.assertFalse(self.db.exists())
        result = self.cli('import', str(self.root / 'missing.csv'))
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn('Traceback', result.stderr)
        self.assertFalse(self.db.exists())

    def test_quoted_unicode_and_storage_boundary(self):
        result = self.load('sku,name,price_cents\n한,"Rice, white\nlarge",9223372036854775807\nzero,Zero,000\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [dict(sku='zero', name='Zero', price_cents=0),
                                       dict(sku='한', name='Rice, white\nlarge',
                                            price_cents=9223372036854775807)])

    def test_database_error_is_readable(self):
        self.db.mkdir()
        result = self.load('sku,name,price_cents\na,Name,1\n')
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('unable to open database', result.stderr)
        self.assertNotIn('Traceback', result.stderr)

    def test_database_failure_rolls_back_prior_rows(self):
        import sqlite3
        self.assertEqual(self.load('sku,name,price_cents\nkeep,Original,7\n').returncode, 0)
        with sqlite3.connect(self.db) as connection:
            connection.execute("CREATE TRIGGER reject_bad BEFORE INSERT ON catalog "
                               "WHEN NEW.sku = 'bad' BEGIN SELECT RAISE(ABORT, 'blocked'); END")
        result = self.load('sku,name,price_cents\nkeep,Changed,9\nbad,Name,1\n')
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn('Traceback', result.stderr)
        self.assertEqual(self.items(), [dict(sku='keep', name='Original', price_cents=7)])
