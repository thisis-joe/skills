import argparse
import csv
import json
import re
import sqlite3
import sys


def read_import(path):
    items = {}
    with open(path, encoding='utf-8', newline='') as source:
        reader = csv.reader(source, strict=True)
        header = next(reader, None)
        if header is None:
            return items
        if header != ['sku', 'name', 'price_cents']:
            raise ValueError('expected CSV header sku,name,price_cents')
        for row in reader:
            if len(row) != 3:
                raise ValueError(f'line {reader.line_num}: expected three fields')
            sku, name, price = (field.strip() for field in row)
            sku = sku.lower()
            if not sku or not name or not re.fullmatch(r'[0-9]+', price):
                raise ValueError(f'line {reader.line_num}: require SKU, name and nonnegative integer cents')
            cents = int(price)
            if cents > 9223372036854775807:
                raise ValueError(f'line {reader.line_num}: price exceeds SQLite integer range')
            items[sku] = (sku, name, cents)
    return items


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    importer = commands.add_parser('import')
    importer.add_argument('csv_path')
    args = parser.parse_args()
    try:
        items = read_import(args.csv_path) if args.command == 'import' else None
        connection = sqlite3.connect(args.db)
        try:
            with connection:
                connection.execute('CREATE TABLE IF NOT EXISTS catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
                if items is not None:
                    connection.executemany(
                        'INSERT INTO catalog (sku,name,price_cents) VALUES (?,?,?) '
                        'ON CONFLICT(sku) DO UPDATE SET name=excluded.name, price_cents=excluded.price_cents',
                        items.values(),
                    )
                else:
                    print(json.dumps([
                        dict(sku=sku, name=name, price_cents=price)
                        for sku, name, price in connection.execute(
                            'SELECT sku,name,price_cents FROM catalog ORDER BY sku'
                        )
                    ]))
        finally:
            connection.close()
    except (OSError, UnicodeError, csv.Error, ValueError, sqlite3.Error) as error:
        print(f'catalog: {error}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
