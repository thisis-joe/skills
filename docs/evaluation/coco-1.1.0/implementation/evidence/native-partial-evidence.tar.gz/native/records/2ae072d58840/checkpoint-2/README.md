Public contract: Python stdlib, UTF-8 CSV with sku,name,price_cents
header; nonempty SKU and name after trimming; nonnegative integer cents. Add
python3 catalog.py --db PATH import CSV_PATH. Preserve the existing list command,
returning a JSON array of {sku,name,price_cents}, sorted lexicographically by the
stored SKU key. Empty/header-only input imports no rows and preserves stored data.
Import success returns exit 0; failure returns nonzero with a readable stderr
message and no traceback. Import success stdout has no required format. Report
skipped malformed rows on stderr when that policy applies. Preserve existing
stored items except collisions handled by the separately chosen owner policy.
No summary or multi-supplier feature is requested. Use the existing unittest
command and exercise the real CLI. Choices outside this contract remain undecided.

Checks: python3 -m unittest discover -v.

CSV import:

    python3 catalog.py --db catalog.sqlite import daily.csv
    python3 catalog.py --db catalog.sqlite list

Use exactly the header `sku,name,price_cents`. SKU and name are trimmed and must
be nonempty. Prices are decimal digits representing nonnegative integer cents,
up to SQLite's maximum integer (9223372036854775807). Quoted CSV fields may
contain commas and newlines. Each data row must contain exactly three fields.

The last row for a SKU wins; later imports update existing items with that SKU.
Any malformed row rejects the entire import and leaves stored data unchanged.
File, encoding, CSV, and database failures return nonzero with a readable stderr
message. Empty and header-only files import nothing. Unrelated items remain.
