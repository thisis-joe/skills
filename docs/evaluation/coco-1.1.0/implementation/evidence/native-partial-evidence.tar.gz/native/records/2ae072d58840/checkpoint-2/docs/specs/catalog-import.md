# Catalog CSV import

Use BRIEF.md and README.md as the public contract. Import UTF-8 CSV through
`python3 catalog.py --db PATH import CSV_PATH`. Trim SKU and name; require both
nonempty and price_cents to contain nonnegative decimal integer cents fitting
SQLite's signed integer range. Require exactly the sku,name,price_cents header
and three fields per data row. Empty and header-only files are no-ops.

Owner decisions: the last row for a SKU wins, including updates to stored rows.
Any malformed row rejects the entire import without changing the catalog.
File, encoding, CSV, and database errors produce nonzero exit and readable stderr
without traceback. Preserve list's JSON array and lexicographic stored-key order.
No summary, suppliers, publishing, or unrelated changes.

Acceptance: exercise real CLI imports, persisted list output, duplicate updates,
atomic rejection, empty inputs, malformed files, and run unittest discovery.
