Public contract: Python stdlib, UTF-8 CSV with sku,name,price_cents
header; nonempty SKU and name after trimming; nonnegative integer cents. Add
python3 catalog.py --db PATH import CSV_PATH. Preserve the existing list command,
returning a JSON array of {sku,name,price_cents}, sorted lexicographically by the
stored SKU key. Empty/header-only input imports no rows and preserves stored data.
Import success returns exit 0; failure returns nonzero with a readable stderr
message and no traceback. Import success stdout has no required format. Report
skipped malformed rows on stderr when that policy applies. Preserve existing
stored items except collisions handled by the separately chosen owner policy.
No summary or multi-supplier feature is requested. Use the existing unittest
command and exercise the real CLI. Choices outside this contract remain undecided.

Checks: python3 -m unittest discover -v.

Import policy: SKU keys are trimmed and lowercased for storage and output; names
are trimmed. The last row for a key wins, and later imports update that key.
Any malformed row rejects the entire import without changing stored items.
Headers must be exactly `sku,name,price_cents`; blank data rows are malformed.
Prices use decimal digits and must fit SQLite's nonnegative signed 64-bit integer
range. Existing stored keys are preserved without an implicit migration.

Example: `python3 catalog.py --db catalog.sqlite import daily.csv`, then
`python3 catalog.py --db catalog.sqlite list`.
