# Daily CSV import

Add `python3 catalog.py --db PATH import CSV_PATH` using Python stdlib.
Read UTF-8 CSV with exactly `sku,name,price_cents` header. Empty files and
header-only files succeed without changing stored rows. Trim SKU and name;
lowercase SKU for storage and list output. Require nonempty SKU/name and
nonnegative integer cents. Last row for a normalized key wins, including updates
to an existing stored key. Reject the entire import on any malformed row;
file, decoding, CSV and database failures return nonzero with readable stderr
and no traceback. No rows are skipped. Preserve unrelated stored rows.

Keep list's JSON array and lexicographic stored-key ordering. Existing stored
keys are not migrated implicitly. No summary, suppliers, publishing or new dependencies.

Owner choices supersede initial recommendations: lowercase rather than
case-sensitive identity, and atomic rejection rather than skipping bad rows.
Acceptance: real CLI import/list round trips, duplicate/update behavior,
atomic failures, empty inputs, readable errors, and existing unittest suite.
