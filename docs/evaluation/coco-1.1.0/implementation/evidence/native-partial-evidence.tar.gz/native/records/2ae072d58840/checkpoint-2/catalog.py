import argparse
import csv
import json
import re
import sqlite3
import sys


HEADER = ['sku', 'name', 'price_cents']


def read_items(path):
    items = {}
    with open(path, encoding='utf-8', newline='') as source:
        reader = csv.reader(source, strict=True)
        header = next(reader, None)
        if header is None:
            return items
        if header != HEADER:
            raise ValueError('CSV header must be sku,name,price_cents')
        for row in reader:
            if len(row) != 3:
                raise ValueError(f'CSV line {reader.line_num}: expected three fields')
            sku, name, price = (value.strip() for value in row)
            if not sku or not name or not re.fullmatch(r'[0-9]+', price):
                raise ValueError(f'CSV line {reader.line_num}: invalid SKU, name or price_cents')
            # Strip leading zeros before conversion to avoid Python integer digit limits.
            digits = price.lstrip('0') or '0'
            if len(digits) > 19 or int(digits) > 9223372036854775807:
                raise ValueError(f'CSV line {reader.line_num}: price_cents exceeds storage range')
            items[sku] = (sku, name, int(digits))
    return items


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    importer = commands.add_parser('import')
    importer.add_argument('csv_path')
    args = parser.parse_args()
    connection = None
    try:
        # Validate the complete input before opening or modifying the database.
        items = read_items(args.csv_path) if args.command == 'import' else None
        connection = sqlite3.connect(args.db)
        with connection:
            connection.execute('CREATE TABLE IF NOT EXISTS catalog '
                               '(sku TEXT PRIMARY KEY, name TEXT NOT NULL, '
                               'price_cents INTEGER NOT NULL)')
            if items is not None:
                connection.executemany(
                    'INSERT INTO catalog (sku,name,price_cents) VALUES (?,?,?) '
                    'ON CONFLICT(sku) DO UPDATE SET name=excluded.name, '
                    'price_cents=excluded.price_cents', items.values())
            else:
                print(json.dumps([dict(sku=k, name=n, price_cents=v)
                                  for k, n, v in connection.execute(
                                      'SELECT sku,name,price_cents FROM catalog ORDER BY sku')]))
        return 0
    except (OSError, UnicodeError, csv.Error, ValueError, sqlite3.Error) as error:
        print(f'catalog: {error}', file=sys.stderr)
        return 1
    finally:
        if connection is not None:
            connection.close()


if __name__ == '__main__':
    sys.exit(main())
