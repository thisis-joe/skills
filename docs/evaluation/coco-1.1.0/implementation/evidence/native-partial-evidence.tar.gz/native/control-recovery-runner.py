import importlib.util,json
from pathlib import Path
path=Path('/Users/Joseph/.codex/worktrees/coco-1-1-0/skills/docs/evaluation/coco-1.1.0/implementation/run.py')
spec=importlib.util.spec_from_file_location('v110_recovery',path);run=importlib.util.module_from_spec(spec);spec.loader.exec_module(run)
root=Path('/private/tmp/coco-v110-implementation-20261026')
control=json.loads((root/'control.json').read_text())
if run.frozen()!=control['hashes']:raise RuntimeError('Frozen sources changed')
controls=[('Should the stored and displayed SKU retain the first spelling or use the canonical lowercase key?',{'identity'},False),('What should the list JSON fields and ordering be?',{'public_contract'},False),('Should we email a purchasing manager whenever an import is rejected?',set(),True)]
results=[]
for number,(question,topics,unresolved) in enumerate(controls,1):
 turn=run.native(root/'owner',root/'classifier-controls-recovery',number,run.CLASSIFY+question,timeout=90)
 try:
  if not run.stable(turn) or turn.get('commands') or turn.get('tool_items'):raise ValueError('Incomplete or tool-using classifier')
  body=turn['messages'][-1].strip()
  if body.startswith('```json') and body.endswith('```'):body=body[7:-3].strip()
  value=run.validate_classification(json.loads(body),question)
  classified=dict(**value,valid=True,attempts=[turn])
  actual=set(t for q in classified['questions'] for t in q['topics'])
  answer=run.reply(classified['questions'],0)
  passed=bool(classified['questions'] and actual==topics and bool(answer['unresolved'])==unresolved)
  result=dict(question=question,expected_topics=sorted(topics),result=classified,answer=answer,passed=passed)
 except Exception as error:
  result=dict(question=question,passed=False,error=repr(error),attempt=turn)
 results.append(result)
 run.save(root/'classifier-controls-recovery.json',dict(results=results,passed=len(results)==3 and all(v['passed'] for v in results),infrastructure_recovery='One attempt per control after original server cooldown; original 90s cap and exact cases unchanged; original two failed calls retained.'))
 print(json.dumps(dict(control=number,passed=result['passed'],seconds=turn.get('seconds'))),flush=True)
 if not result['passed']:raise RuntimeError('Recovery control failed; no further native retries or primary actors')
run.save(root/'classifier-controls.json',dict(results=results,passed=True,recovery_record='classifier-controls-recovery.json',original_unavailable_record='capacity-unavailable.json'))
