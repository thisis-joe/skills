Two owner decisions block implementation:

1. **Repeated SKU**, within a CSV or already stored: should the last row replace the item, the first/stored item win, or the import fail? I recommend **last valid row wins** for daily updates.
2. **Malformed rows**: skip them with stderr warnings and import valid rows, or reject the entire file without changes? I recommend **skip with warnings** for daily files. Unreadable files and invalid headers would still fail.

States:
- **Implementation:** pending these choices; no edits or commits.
- **Review:** pending; eventual inspection will be same-agent, not independent.
- **Verification:** existing unittest passed (1 test); import verification pending.

I read the project files and local `.guide` procedures. The unrelated `personal-notes.txt` remains untouched.