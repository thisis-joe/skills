Completed on `feature/catalog-csv-import`.

- **Implementation:** CSV import uses last-row-wins updates. Any malformed row rejects the whole import without changing stored data. Sorted JSON `list` output is preserved.
- **Review:** same-agent inspection complete; no actionable findings. Not independent review.
- **Verification:** all 8 unittests and real CLI checks passed, including persistence and rollback.

Expected and actual behavior match; no material departure.

Local commits: `9978d14`, `9cf9e80`. Nothing pushed. Unrelated `personal-notes.txt` preserved.