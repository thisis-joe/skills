Three owner choices block implementation:

1. **SKU identity:** Should ` abc ` and `abc` match, while `ABC` stays distinct? I recommend trimming and case-sensitive matching, storing the trimmed SKU.
2. **Collisions:** If a SKU repeats within a CSV or already exists in storage, should the last valid row replace its name and price? I recommend yes for daily updates. Alternatives are keeping the first/existing item or rejecting collisions.
3. **Malformed rows:** Should valid rows still import when another row is invalid? I recommend skipping invalid rows, reporting their line numbers on stderr, and returning success; unreadable files or invalid headers would fail without changing stored items. Alternatively, reject the entire import on any malformed row.

Baseline: the existing unittest passed, and actual CLI help confirms only `list` exists.

**Implementation:** pending these decisions; no changes or commits.  
**Review:** pending; eventual inspection will be same-agent, not independent.  
**Verification:** baseline passed; import verification pending.

The requested import/list scope is unchanged. Unrelated work remains untouched; nothing was published.