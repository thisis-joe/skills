Committed locally on `feat/daily-csv-import`:

- **Implementation:** `bd3af62` adds lowercase trimmed SKU keys, last-row updates, and whole-import rejection.
- **Review:** same-agent inspection completed; not independent. Results recorded in `4273974`.
- **Verification:** all 4 unittest cases passed. Real CLI checks confirmed sorted output, unchanged data after malformed input, and rollback after a database write failure.

Unrelated work is untouched. Nothing was pushed.

One contract limitation needs your decision: prices currently cannot exceed SQLite’s integer maximum, `9223372036854775807` cents. Larger values fail readably without changes. **May this existing storage limit become part of the contract?** I recommend yes. Final acceptance remains pending that choice; the other requested behavior matches your decisions.