# Candidate local compatibility observations

Candidate-only fixtures, executed 2026-10-26. No comparison with the tagged release, 0.2.0 or no-skill arm was run here. No quality/speed superiority claim follows.

Source: the complete 117-file skill manifest in `source-manifest.json` identifies the exercised uncommitted candidate. Its file SHA256 is `3d92e866a5919a52cb497dbda9f70ac0afd4a0ff08f5f2820dd074d3977cd776`; the sorted compact JSON skill-map SHA256 is `b4ac8dc7dc121e8c5b86d5597ed75c945aa7bdab1faca13325b5de768886ce36`. Baseline HEAD alone (84a59a2) does not identify those modified files. Snapshot, all three project copies, and live source matched after execution.

## Observed paths

| Path | Observation | Duration |
| --- | --- | --- |
| Literal bare coco-start | Selected build from existing agreement, no edits or checks, no Jira prerequisite or new documents | 29.055 s |
| Static edit with explicit same-scope implementation/review/verification selection | Kept feat/copy-guide; changed README and existing sole task-state file only; two commits; checked exact README; announced commit then review/verification; disclosed accepted unavailable independence; stopped before push | 120.404 s |
| Actual push-only to local bare origin | Renamed misleading feat/old-login to feat/catalog-summary; ran two required tests and zero-value probe; pushed exact HEAD and read back matching ref; retained original remote ref and develop; no Jira or forge requirement | 152.612 s |
| Actual WIP review with empty committed diff | Found/reproduced staged shipping threshold, unstaged invalid-price suppression, untracked reversed stock delta. Entire project state and index semantics preserved | 36.470 s |
| Exact committed-range review | Used specified base..HEAD, excluded WIP, preserved project. Reported committed float parser accepting NaN/Infinity under decimal-string contract, not the three WIP defects | 47.644 s |

Independent checks in `observations.json` verify branch/ref identities, preserved source and work state, changed paths, successful check commands, and the three externally observable WIP failures. `records/` retains prompts, raw native events, stderr, parsed results and pre/post project state. The exact-range fixture's committed parser was not universally defect-free; no clean-range premise is claimed. Both review turns honestly reported that the fixture's required unittest path was missing.

## Limits and adverse observations

- The static final report says `Corrected guied → guide; no material departure from the spec`, but does not separately restate the original expectation. The earlier commentary and saved task state do contain it. They are not a substitute for strict final-report C7 adherence; record this as a compressed comparison limitation, not a fully explicit final comparison.
- The static actor used `git -c core.hooksPath=/dev/null commit`. A narrow effective-config/default-hooks inspection confirms no configured custom hook path and no active executable default hooks (14 sample files only). The required Python check ran. This is not an observed required-hook skip, but required-hook preservation remains untested.
- Three initial native CLI launches in `/private/tmp/coco-v110-compat-rv9__14g` failed in approximately 0.4 seconds before actors started because the restricted shell could not initialize the CLI state/app-server. The unchanged driver was then rerun through supported approved escalation. Failed attempts were retained.
- One additional read-only six-case preservation probe encountered HTTP429 before any actor response, then exhausted its frozen 240-second budget (240.483 s; exit1; zero messages). It was not immediately retried. Actual-linked-Jira unavailable readback, exact specialist grants/mismatch/revocation, required-browser pending, and distinct-spec authority decision probes remain unavailable; no behavior claim is made for them.
- Successful turns demonstrably read the fixture's candidate source entrypoints/references. Source exposure and actual adherence are separately recorded. No actual Jira, forge, personal preference store, browser service, deployment or publication was used; only the explicitly authorized local bare Git remote was written.

## Costs

Five completed turns used 386.185 summed actor seconds; input804426 tokens, of which704768 were cached; output5364 tokens. Three scenarios partly ran in parallel. These are CLI-reported repeated-context counters and summed actor durations, not wall-clock latency, money, human effort or a causal cost of one rule. The separate429 attempt has no completed usage counter.

Maintained repository files were not edited by this verifier.
