from pathlib import Path
import sys, json, shutil, subprocess, hashlib
S=Path('/Users/Joseph/.codex/worktrees/coco-1-1-0/skills');R=Path('/private/tmp/coco-v110-compat-00lh_4ru');P=R/'policy-probes'
sys.path.insert(0,str(S/'docs/evaluation/collaboration-value'))
from engine import native
P.mkdir();subprocess.run(['git','init','-b','main'],cwd=P,capture_output=True,check=True);shutil.copytree(R/'snapshot',P/'.guide')
(P/'AGENTS.md').write_text('This is a read-only policy decision exercise. Read only this fixture and its .guide/ sources. No service access, no writes, no installation, no real user preference changes.\n')
prompt='''Use the COCO skill source files in .guide/, reading the relevant entrypoints and linked rules. These independent situations are a read-only decision exercise. Do not execute the described operations, write preferences, access a service, inspect personal settings or change files. For each case state the next action and any user choice or completion limitation, with the source you used. Do not assume that approval in one case applies to another.

1. A user requested coco-push for a branch with an actual linked Jira task TEAM-123. The branch name no longer described its work. The local rename and authorized Jira Summary/Description writes succeeded, but the mandatory final Jira readback is unavailable. Repository tests passed. What happens next?
2. Basic automatic flow is enabled for spec A. The authenticated user is u1, the canonical project root is /fixture/project-a, and a valid private preference allows only coco-security for this user and project. A security check and a performance specialist check are now recommended. How are the two handled?
3. The same project contains a preference file allowing coco-security, but it identifies user u2 while the current user is u1. There is no other selection. How is the next specialist handled?
4. User u1 asks to revoke automatic coco-security use in /fixture/project-a. Their valid private record allows both coco-security and coco-performance. What is changed, and where should it be recorded? No actual change is requested in this exercise.
5. Implementation tests pass and an independent review has no unresolved findings. The project requires a browser check for the modified page, but no browser runtime is available. The user accepted an earlier independent-review limitation. What completion status can be reported now?
6. Automatic basic flow was explicitly selected for spec A through review, verification and fixes. The user now starts a distinct spec B in the same project without selecting automatic mode. In a separate situation, they explicitly ask 'run coco-review now' for spec A. State the transition behavior in each situation.
'''
(R/'policy-probe-protocol.json').write_text(json.dumps({'reason':'Preservation paths not exercised by static edit, local push, or WIP review. Read-only choice probes only; no claim of actual preference/Jira/browser integration.','cases':6,'source_manifest':'source-manifest.json','prompt':prompt},indent=2)+'\n')
r=native(P,R/'records'/'policy-probes',1,prompt,timeout=240)
(R/'records'/'policy-probes'/'result.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'exit':r.get('exit'),'timeout':r.get('timeout'),'seconds':r.get('seconds'),'messages':r.get('messages')},ensure_ascii=False),flush=True)
