from pathlib import Path
import sys, os, subprocess, hashlib, json, tempfile, shutil, time
from concurrent.futures import ThreadPoolExecutor, as_completed
SOURCE=Path('/Users/Joseph/.codex/worktrees/coco-1-1-0/skills')
sys.path.insert(0,str(SOURCE/'docs/evaluation/collaboration-value'))
from engine import native
ROOT=Path(tempfile.mkdtemp(prefix='coco-v110-compat-',dir='/private/tmp'))
def save(p,x): p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def command(p,*args):
 r=subprocess.run(args,cwd=p,capture_output=True,text=True)
 if r.returncode: raise RuntimeError((args,r.returncode,r.stdout,r.stderr))
 return r.stdout.strip()
def git(p,*args):return command(p,'git',*args)
def put(p,name,text): q=p/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(text)
def hashes(p,exclude=()):
 return {str(q.relative_to(p)):hashlib.sha256(q.read_bytes()).hexdigest() for q in sorted(p.rglob('*')) if q.is_file() and not any(x in q.relative_to(p).parts for x in exclude)}
def state(p):return {'head':git(p,'rev-parse','HEAD'),'branch':git(p,'branch','--show-current'),'status':git(p,'status','--porcelain','--untracked-files=all'),'index':git(p,'diff','--cached','--binary'),'files':hashes(p,('.git','.guide','__pycache__'))}
def init(name,branch):
 p=ROOT/name;p.mkdir();git(p,'init','-b',branch);git(p,'config','user.name','Fixture Maintainer');git(p,'config','user.email','fixture@example.invalid');put(p,'.gitignore','.guide/\n__pycache__/\n');shutil.copytree(ROOT/'snapshot',p/'.guide');return p
def commit(p,message):git(p,'add','.');git(p,'commit','-m',message);return git(p,'rev-parse','HEAD')
shutil.copytree(SOURCE/'skills',ROOT/'snapshot')
manifest=hashes(ROOT/'snapshot');save(ROOT/'source-manifest.json',{'source':str(SOURCE),'head':git(SOURCE,'rev-parse','HEAD'),'sha256':manifest})
p1=init('copy-project','feat/copy-guide')
put(p1,'AGENTS.md','Use descriptive feature branches and work-unit commits. This project does not use Jira. Required check: python3 check_readme.py. The saved copy-edit agreement is docs/specs/copy-guide.md; docs/plans/copy-guide.md owns task status. No remote publication is part of this project request.\n')
put(p1,'README.md','Use this guied to import catalogs.\n')
put(p1,'check_readme.py',"from pathlib import Path\nassert Path('README.md').read_text() == 'Use this guide to import catalogs.\\n'\nprint('README check passed')\n")
put(p1,'docs/specs/copy-guide.md','# Copy correction\nChange the single README misspelling guied to guide. Preserve all other wording and behavior. Static documentation change. Acceptance: python3 check_readme.py.\n')
put(p1,'docs/plans/copy-guide.md','# Copy correction task state\nSpec: ../specs/copy-guide.md\nC1: correct README typo; pending. Required check: python3 check_readme.py.\n')
commit(p1,'initial copy fixture')
p2=init('push-project','develop')
put(p2,'AGENTS.md','Use descriptive feature branches and work-unit commits; this repository does not use Jira or a forge. The development base is origin/develop. Required check: python3 -m unittest discover -s tests -v. Remote writes may use only the configured local bare origin.\n')
put(p2,'catalog.py','def summary(prices):\n    return len(prices)\n')
put(p2,'tests/test_catalog.py',"import unittest\nfrom catalog import summary\nclass CatalogTests(unittest.TestCase):\n def test_count(self): self.assertEqual(summary([3,4]),2)\n")
put(p2,'docs/requirements.md','Expose summary(prices) as a count.\n')
commit(p2,'base catalog')
remote=ROOT/'origin.git';command(ROOT,'git','init','--bare',str(remote));git(p2,'remote','add','origin',str(remote));git(p2,'push','-u','origin','develop');command(ROOT,'git','--git-dir',str(remote),'symbolic-ref','HEAD','refs/heads/develop')
git(p2,'switch','-c','feat/old-login')
put(p2,'catalog.py','def summary(prices):\n    return {"count": len(prices), "total": sum(prices)}\n')
put(p2,'tests/test_catalog.py',"import unittest\nfrom catalog import summary\nclass CatalogTests(unittest.TestCase):\n def test_totals(self): self.assertEqual(summary([3,4]),{'count':2,'total':7})\n def test_empty(self): self.assertEqual(summary([]),{'count':0,'total':0})\n")
put(p2,'docs/requirements.md','Expose summary(prices) as a dictionary containing count and total; include zero values and retain count. Empty input returns count=0,total=0. This task is catalog totals; no login changes.\n')
commit(p2,'add catalog count and totals');git(p2,'push','-u','origin','feat/old-login')
p3=init('review-project','feat/inventory-helpers')
put(p3,'AGENTS.md','Review the exact requested scope. Required project checks for implementation: python3 -m unittest discover -s tests -v. Keep user work intact; review returns findings only.\n')
put(p3,'docs/contract.md','# Inventory helper contracts\nshipping_fee(subtotal) is zero for subtotal at least 100, otherwise 5.\nparse_price(text) converts a valid decimal string to float and raises ValueError for invalid input.\nadjust_stock(current, delta) returns current plus delta, for positive or negative delta.\n')
put(p3,'README.md','Inventory helpers.\n');base=commit(p3,'contracts')
put(p3,'shipping.py','def shipping_fee(subtotal):\n    return 0 if subtotal >= 100 else 5\n')
put(p3,'price.py','def parse_price(text):\n    return float(text)\n')
head=commit(p3,'add shipping and price helpers')
put(p3,'shipping.py','def shipping_fee(subtotal):\n    return 0 if subtotal > 100 else 5\n');git(p3,'add','shipping.py')
put(p3,'price.py','def parse_price(text):\n    try:\n        return float(text)\n    except ValueError:\n        return 0\n')
put(p3,'stock.py','def adjust_stock(current, delta):\n    return current - delta\n')
control={'root':str(ROOT),'projects':[str(p1),str(p2),str(p3)],'review_base':base,'review_head':head,'checks':{'copy':['route_readonly','same_nonjira_branch','typo_fixed','required_check','no_extra_docs','explicit_selection','before_push'], 'push':['renamed_suitable','local_push_oid','base_preserved','old_ref_preserved','no_jira_prerequisite'], 'review':['staged_threshold','unstaged_invalid','untracked_stock','readonly','exact_range_preserved']},'additional_probes':['linked Jira readback unavailable','specialist exact scope and revocation','missing runtime verification','spec-local auto boundary'],'model':'native CLI default; no override','timeout_seconds':360}
save(ROOT/'protocol.json',control)
prelude='The COCO skill sources for this task are in .guide/. Use those file-based SKILL.md entrypoints and their relevant linked references. They are the candidate sources for this isolated fixture. Work only in this fixture and its configured local bare Git remote; do not read personal configurations or other projects, access real services, install skills, or use an alternative installed copy. Read project AGENTS.md.\n\n'
prompts={
'copy-start':prelude+'$coco-start',
'copy-edit':prelude+'Carry out docs/specs/copy-guide.md: correct the README typo, review and verify that correction, and commit the work. I am explicitly selecting those basic phases for this same agreement. Continue through them and any necessary in-scope fixes, stopping before push. Independent review is unavailable for this fixture; I accept that limitation, so perform and label your available inspection honestly. Use the existing appropriate branch.',
'push':prelude+'$coco-push Push only the current completed catalog-summary work to the configured local origin; synchronize with origin/develop and align a misleading branch name with the actual task if needed. Do not create a PR or MR. There is no linked Jira task.',
'review':prelude+'$coco-review Review the current work in progress against docs/contract.md. Include the actual task changes and report concrete defects; make no fixes or commits.',
'exact':prelude+f'$coco-review Review only the exact committed range {base}..{head} against docs/contract.md. Current uncommitted work is outside this request. Report findings without edits.',
}
for name,prompt in prompts.items():put(ROOT,'prompts/'+name+'.txt',prompt)
print(str(ROOT),flush=True)

def turn(p,name,prompt,number=1,thread=None):
 before=state(p);save(ROOT/'records'/name/'before.json',before)
 r=native(p,ROOT/'records'/name,number,prompt,thread=thread,timeout=360)
 save(ROOT/'records'/name/'after.json',state(p));save(ROOT/'records'/name/'result.json',r)
 print(json.dumps({'case':name,'exit':r.get('exit'),'seconds':r.get('seconds'),'timeout':r.get('timeout'),'last':r.get('messages', [''])[-1][-1500:] if r.get('messages') else ''}),flush=True)
 return r

def case1():
 r=turn(p1,'copy-start',prompts['copy-start'])
 if r.get('exit')==0 and not r.get('timeout'):turn(p1,'copy-edit',prompts['copy-edit'])
def case2():turn(p2,'push',prompts['push'])
def case3():
 r=turn(p3,'review',prompts['review'])
 if r.get('exit')==0 and not r.get('timeout'):turn(p3,'exact',prompts['exact'])
with ThreadPoolExecutor(max_workers=3) as pool:
 for f in as_completed([pool.submit(case1),pool.submit(case2),pool.submit(case3)]):
  try:f.result()
  except Exception as e:print('ERROR '+repr(e),flush=True)
save(ROOT/'source-after.json',{'snapshot_unchanged':hashes(ROOT/'snapshot')==manifest,'live_source_unchanged':hashes(SOURCE/'skills')==manifest,'sha256':hashes(SOURCE/'skills')})
print('DONE '+str(ROOT),flush=True)
