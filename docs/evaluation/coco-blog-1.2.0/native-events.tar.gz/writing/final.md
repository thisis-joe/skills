한국어 [개발 글 초안](/private/tmp/coco-articles-run/writing/blog-queue-request-id/content/posts/queue-requests.md)과 실제 저장소 템플릿으로 작성한 [PR 본문](/private/tmp/coco-articles-run/writing/queue-request-id-pr-body.md)을 준비했습니다.

- Mina / backend / `status: draft` 유지
- 기존 초안을 보강하고, 동시 요청·실패 후 처리 등은 미확인으로 명시
- 로컬 검사와 `git diff --check` 통과, 공개 출력에서 draft 제외 확인
- 원본 노트와 앱의 staged/unstaged 작업 보존
- 커밋·push·PR 생성·공개 없음

앱 `.git` 쓰기 제한으로 로컬 origin의 별도 복제본에서 worktree를 만들었습니다. 브랜치는 `blog/queue-request-id`, 기준 리비전은 `87b9343`입니다. 내용 검토 후 사용자가 `content` 대상 PR을 만들 수 있도록 준비한 상태입니다.