[원고](/private/tmp/coco-articles-run/hugo/queue-release/content/posts/queue-requests.md:7)의 `draft`를 `false`로 변경했습니다. 승인된 본문은 그대로입니다.

- `python3 check.py`, 로컬 렌더, `git diff --check` 통과
- [생성 HTML](/private/tmp/coco-articles-run/hugo/preview-queue-release/queue-requests.html)의 제목·저자·본문 확인
- 원래 앱 브랜치와 staged/unstaged 변경 보존 확인

환경의 `.git` 쓰기 제한으로 worktree 대신 설정된 로컬 origin에서 별도 복제한 `blog/queue-release` 브랜치를 사용했습니다. 기준은 `origin/content`의 `dd20bda`입니다.

변경은 미커밋 상태이며, push·PR·머지·서비스 배포는 수행하지 않았습니다.