공개 전환 준비와 push를 완료했습니다.

- 원고의 `published`만 `true`로 변경했습니다.
- 별도 worktree: `/private/tmp/coco-articles-run/release/queue-release`
- 브랜치: `blog/queue-release`
- 커밋: `c07601e`
- 검사와 로컬 렌더 통과, 생성된 HTML의 제목·작성자·본문 확인 완료
- 설정된 로컬 origin에 토픽 브랜치만 push했습니다.

[저장소 템플릿으로 작성한 PR 본문](/private/tmp/coco-articles-run/release/queue-release-pr-body.md)을 준비했습니다. PR 대상은 `content`입니다.

원래 앱의 브랜치와 staged/unstaged 변경은 유지했습니다. Git 쓰기 제한으로 같은 origin의 별도 복제본에서 worktree를 만들었습니다. PR 생성·`content` 직접 push·머지·서비스 배포는 수행하지 않았습니다.