import unittest
import json
from pathlib import Path
import subprocess
import sys
from catalog import page
class Catalog(unittest.TestCase):
 def test_far_offset(self): self.assertEqual(page(100,3),[])
 def test_consecutive_pages(self):
  first=page(0,3)
  second=page(3,3)
  self.assertEqual(first,['amber','birch','cedar'])
  self.assertEqual(second,['dawn','elm','fern'])
  self.assertEqual(len(set(first+second)),6)
 def test_final_page(self): self.assertEqual(page(6,3),['gold'])
 def test_exact_end(self): self.assertEqual(page(7,3),[])
 def test_invalid_values(self):
  for offset,limit in [(-1,3),(0,0),(0,-1)]:
   with self.subTest(offset=offset,limit=limit):
    with self.assertRaises(ValueError): page(offset,limit)
 def run_cli(self,*args):
  return subprocess.run([sys.executable,str(Path(__file__).with_name('catalog.py')),*args],capture_output=True,text=True)
 def test_cli_pages(self):
  for offset,expected in [(0,['amber','birch','cedar']),(3,['dawn','elm','fern']),(100,[])]:
   with self.subTest(offset=offset):
    result=self.run_cli('--offset',str(offset),'--limit','3')
    self.assertEqual(result.returncode,0,result.stderr)
    self.assertEqual(json.loads(result.stdout),expected)
 def test_cli_invalid_values(self):
  for flag,value,message in [('--offset','-1','offset must be nonnegative'),('--limit','0','limit must be greater than zero'),('--limit','-1','limit must be greater than zero')]:
   with self.subTest(flag=flag,value=value):
    result=self.run_cli(flag,value)
    self.assertNotEqual(result.returncode,0)
    self.assertIn(message,result.stderr)
    self.assertNotIn('Traceback',result.stderr)
    self.assertEqual(result.stdout,'')
