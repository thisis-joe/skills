import argparse,json
ITEMS=['amber','birch','cedar','dawn','elm','fern','gold']
def page(offset,limit): return ITEMS[offset:offset+limit-1]
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--offset',type=int,default=0);p.add_argument('--limit',type=int,default=3);a=p.parse_args();print(json.dumps(page(a.offset,a.limit)))
