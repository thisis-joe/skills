import http.client
import json
import os
import threading
import unittest
from http.server import HTTPServer
from unittest.mock import patch

from service import Handler


class Service(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.env = patch.dict(os.environ, {"SUM_TOKEN": "fixture-token"})
        cls.env.start()
        cls.server = HTTPServer(("127.0.0.1", 0), Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.thread.join()
        cls.server.server_close()
        cls.env.stop()

    def request(self, body=b'{"amounts":[2,-5,10]}', auth="Bearer fixture-token",
                path="/sum", method="POST", headers=None):
        connection = http.client.HTTPConnection(*self.server.server_address, timeout=3)
        request_headers = {} if auth is None else {"Authorization": auth}
        request_headers.update(headers or {})
        try:
            connection.request(method, path, body, request_headers)
            response = connection.getresponse()
            return response.status, response.getheader("Content-Type"), response.read()
        finally:
            connection.close()

    def test_sum(self):
        status, content_type, body = self.request()
        self.assertEqual(status, 200)
        self.assertEqual(content_type, "application/json")
        self.assertEqual(json.loads(body), {"total": 7})
        self.assertEqual(json.loads(self.request(b'{"amounts":[]}')[2]), {"total": 0})

    def test_authentication(self):
        for auth in (None, "Bearer wrong", "bearer fixture-token", "Bearer fixture-token ",
                     "Bearer  fixture-token", "Basic fixture-token"):
            with self.subTest(auth=auth):
                self.assertEqual(self.request(auth=auth)[0], 401)
        with patch.dict(os.environ, {}, clear=True):
            self.assertEqual(self.request(auth="Bearer ")[0], 401)
        self.assertEqual(self.request(headers={"authorization": "Bearer fixture-token"})[0], 401)

    def test_invalid_input(self):
        for body in (b'{', b'\xff', b'[]', b'null', b'{}', b'{"amounts":null}',
                     b'{"amounts":1}', b'{"amounts":[true]}', b'{"amounts":[1.5]}',
                     b'{"amounts":["2"]}', b'{"amounts":[{}]}'):
            with self.subTest(body=body):
                self.assertEqual(self.request(body)[0], 400)

    def test_body_limit(self):
        body = b'{"amounts":[]}'
        self.assertEqual(self.request(body + b' ' * (1024 - len(body)))[0], 200)
        self.assertEqual(self.request(body + b' ' * (1025 - len(body)))[0], 413)

    def test_invalid_length(self):
        for value in ("-1", "bad"):
            with self.subTest(value=value):
                self.assertEqual(self.request(headers={"Content-Length": value})[0], 400)

    def test_other_post_path(self):
        self.assertEqual(self.request(path="/other", auth=None)[0], 404)

    def test_health(self):
        status, content_type, body = self.request(method="GET", path="/", body=None, auth=None)
        self.assertEqual((status, content_type, json.loads(body)),
                         (200, "application/json", {"status": "ok"}))
