from http.server import BaseHTTPRequestHandler,HTTPServer
import argparse,json,os
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  self.send_response(200); self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(b'{"status":"ok"}')
 def do_POST(self):
  if self.path != '/sum':
   self.send_error(404); return
  token = os.environ.get('SUM_TOKEN')
  if not token or self.headers.get_all('Authorization', []) != ['Bearer ' + token]:
   self.send_error(401); return
  lengths = self.headers.get_all('Content-Length', [])
  if len(lengths) != 1 or not lengths[0].isascii() or not lengths[0].isdigit() or self.headers.get('Transfer-Encoding'):
   self.send_error(400); return
  try:
   length = int(lengths[0])
  except ValueError:
   self.send_error(400); return
  if length > 1024:
   self.send_error(413); return
  try:
   data = json.loads(self.rfile.read(length))
  except (ValueError, UnicodeError, RecursionError):
   self.send_error(400); return
  if not isinstance(data, dict) or not isinstance(data.get('amounts'), list) or any(type(value) is not int for value in data['amounts']):
   self.send_error(400); return
  body = json.dumps({'total': sum(data['amounts'])}).encode('utf-8')
  self.send_response(200)
  self.send_header('Content-Type', 'application/json')
  self.send_header('Content-Length', str(len(body)))
  self.end_headers()
  self.wfile.write(body)
 def log_message(self,*args): pass
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--port',type=int,required=True);a=p.parse_args();HTTPServer(('127.0.0.1',a.port),Handler).serve_forever()
