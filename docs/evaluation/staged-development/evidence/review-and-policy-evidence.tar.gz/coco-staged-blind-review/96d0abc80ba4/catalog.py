import argparse
import json

ITEMS = ['amber', 'birch', 'cedar', 'dawn', 'elm', 'fern', 'gold']


def page(offset, limit):
    return ITEMS[offset:offset + limit]


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--offset', type=int, default=0)
    parser.add_argument('--limit', type=int, default=3)
    args = parser.parse_args()
    if args.offset < 0:
        parser.error('--offset must be >= 0')
    if args.limit <= 0:
        parser.error('--limit must be > 0')
    print(json.dumps(page(args.offset, args.limit)))
