import json
from pathlib import Path
import subprocess
import sys
import unittest

from catalog import page


class Catalog(unittest.TestCase):
    def test_consecutive_pages(self):
        first = page(0, 3)
        second = page(3, 3)
        self.assertEqual(first, ['amber', 'birch', 'cedar'])
        self.assertEqual(second, ['dawn', 'elm', 'fern'])
        self.assertEqual(len(set(first + second)), 6)

    def test_page_boundaries(self):
        self.assertEqual(page(2, 1), ['cedar'])
        self.assertEqual(page(6, 3), ['gold'])
        self.assertEqual(page(7, 3), [])
        self.assertEqual(page(100, 3), [])

    def cli(self, *args):
        return subprocess.run(
            [sys.executable, str(Path(__file__).with_name('catalog.py')), *args],
            capture_output=True, text=True,
        )

    def test_cli_pages(self):
        for offset, expected in [('0', ['amber', 'birch', 'cedar']),
                                 ('3', ['dawn', 'elm', 'fern']),
                                 ('100', [])]:
            with self.subTest(offset=offset):
                result = self.cli('--offset', offset, '--limit', '3')
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(json.loads(result.stdout), expected)

    def test_invalid_cli_pagination(self):
        for args, message in [
            (('--offset', '-1'), '--offset must be >= 0'),
            (('--limit', '0'), '--limit must be > 0'),
            (('--limit', '-2'), '--limit must be > 0'),
        ]:
            with self.subTest(args=args):
                result = self.cli(*args)
                self.assertNotEqual(result.returncode, 0)
                self.assertIn(message, result.stderr)
                self.assertEqual(result.stdout, '')
                self.assertNotIn('Traceback', result.stderr)
