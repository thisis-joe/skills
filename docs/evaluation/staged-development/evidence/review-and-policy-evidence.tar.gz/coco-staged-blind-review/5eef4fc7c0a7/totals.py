import argparse
import csv
import json


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('path')
    parser.add_argument('--format', choices=('text', 'json'), default='text')
    args = parser.parse_args()
    count = total = 0
    try:
        with open(args.path, newline='') as stream:
            reader = csv.DictReader(stream)
            if reader.fieldnames is None or 'amount' not in reader.fieldnames:
                parser.error("missing required 'amount' header")
            for row in reader:
                amount = row['amount']
                try:
                    value = int(amount)
                except (ValueError, TypeError):
                    parser.error(
                        f'invalid integer amount at line {reader.line_num}: {amount!r}'
                    )
                count += 1
                total += value
    except (OSError, csv.Error, UnicodeError) as error:
        parser.error(str(error))
    if args.format == 'json':
        print(json.dumps({'count': count, 'total': total}))
    else:
        print('count=%d total=%d' % (count, total))


if __name__ == '__main__':
    main()
