import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


SCRIPT = Path(__file__).with_name('totals.py')


class Totals(unittest.TestCase):
    def run_cli(self, content, *options):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'input.csv'
            path.write_text(content)
            return subprocess.run(
                [sys.executable, str(SCRIPT), str(path), *options],
                capture_output=True, text=True,
            )

    def test_text(self):
        for options in ((), ('--format', 'text')):
            with self.subTest(options=options):
                result = self.run_cli('amount\n2\n7\n-1\n', *options)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(result.stdout, 'count=3 total=8\n')
                self.assertEqual(result.stderr, '')

    def test_json(self):
        for content, expected in (
            ('amount\n2\n7\n-1\n', {'count': 3, 'total': 8}),
            ('amount\n', {'count': 0, 'total': 0}),
        ):
            with self.subTest(content=content):
                result = self.run_cli(content, '--format', 'json')
                self.assertEqual(result.returncode, 0, result.stderr)
                data = json.loads(result.stdout)
                self.assertEqual(data, expected)
                self.assertTrue(all(type(value) is int for value in data.values()))
                self.assertEqual(result.stderr, '')

    def test_input_errors(self):
        for content, message in (
            ('amount\n2\noops\n', 'invalid integer'),
            ('other\n2\n', 'amount'),
            ('other\n', 'amount'),
            ('', 'amount'),
            ('amount,other\n,foo\n', 'invalid integer'),
            ('other,amount\nfoo\n', 'invalid integer'),
        ):
            for mode in (None, 'text', 'json'):
                with self.subTest(content=content, mode=mode):
                    options = () if mode is None else ('--format', mode)
                    result = self.run_cli(content, *options)
                    self.assertNotEqual(result.returncode, 0)
                    self.assertEqual(result.stdout, '')
                    self.assertIn(message, result.stderr)
                    self.assertNotIn('Traceback', result.stderr)


if __name__ == '__main__':
    unittest.main()
