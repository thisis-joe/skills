from pathlib import Path
import subprocess
import sys
import unittest

from catalog import page


class Catalog(unittest.TestCase):
    def test_consecutive_pages(self):
        self.assertEqual(page(0, 3), ['amber', 'birch', 'cedar'])
        self.assertEqual(page(3, 3), ['dawn', 'elm', 'fern'])

    def test_limit_boundaries(self):
        self.assertEqual(page(0, 1), ['amber'])
        self.assertEqual(page(6, 3), ['gold'])
        self.assertEqual(page(0, 20),
                         ['amber', 'birch', 'cedar', 'dawn', 'elm', 'fern', 'gold'])

    def test_far_offset(self):
        self.assertEqual(page(100, 3), [])
        self.assertEqual(page(7, 3), [])

    def test_cli_rejects_invalid_pagination(self):
        for flag, value in [('--offset', '-1'), ('--limit', '0'), ('--limit', '-1')]:
            with self.subTest(flag=flag, value=value):
                result = subprocess.run(
                    [sys.executable, str(Path(__file__).with_name('catalog.py')),
                     flag, value], capture_output=True, text=True)
                self.assertNotEqual(result.returncode, 0)
                self.assertIn(flag, result.stderr)
                self.assertIn('must be', result.stderr)
                self.assertEqual(result.stdout, '')
