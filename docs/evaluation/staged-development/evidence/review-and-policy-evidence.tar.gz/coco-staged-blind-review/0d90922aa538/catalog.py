import argparse, json
ITEMS=['amber','birch','cedar','dawn','elm','fern','gold']
def page(offset,limit): return ITEMS[offset:offset+limit]
if __name__=='__main__':
 p=argparse.ArgumentParser(); p.add_argument('--offset',type=int,default=0); p.add_argument('--limit',type=int,default=3)
 a=p.parse_args()
 if a.offset < 0: p.error('--offset must be >= 0')
 if a.limit <= 0: p.error('--limit must be > 0')
 print(json.dumps(page(a.offset,a.limit)))
