import unittest
from pathlib import Path
class Page(unittest.TestCase):
 def test_content(self): self.assertIn('Order details',Path('index.html').read_text())
