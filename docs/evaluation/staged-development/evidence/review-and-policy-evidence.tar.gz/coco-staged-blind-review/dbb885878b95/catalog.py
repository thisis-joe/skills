import argparse, json
ITEMS=['amber','birch','cedar','dawn','elm','fern','gold']
def page(offset,limit):
 if offset < 0:
  raise ValueError('offset must be nonnegative (zero or greater)')
 if limit <= 0:
  raise ValueError('limit must be greater than zero')
 return ITEMS[offset:offset+limit]
if __name__=='__main__':
 p=argparse.ArgumentParser(); p.add_argument('--offset',type=int,default=0); p.add_argument('--limit',type=int,default=3)
 a=p.parse_args()
 try:
  result=page(a.offset,a.limit)
 except ValueError as error:
  p.error(str(error))
 print(json.dumps(result))
