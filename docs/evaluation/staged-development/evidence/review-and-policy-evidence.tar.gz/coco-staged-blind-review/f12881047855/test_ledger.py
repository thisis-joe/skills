import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


CLI = Path(__file__).with_name('ledger.py')


class Ledger(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.db = str(Path(self.directory.name) / 'ledger.db')

    def run_cli(self, *args):
        return subprocess.run(
            [sys.executable, str(CLI), '--db', self.db, *args],
            text=True, capture_output=True,
        )

    def succeeds(self, *args):
        result = self.run_cli(*args)
        self.assertEqual(result.returncode, 0, result.stderr)
        return result.stdout.strip()

    def test_empty(self):
        self.assertEqual(json.loads(self.succeeds('list')), [])

    def test_persistent_add_retry_and_conflict(self):
        self.succeeds('add', 'z', '-7')
        self.succeeds('add', 'a', '12')
        self.succeeds('add', 'zero', '0')
        expected = [dict(key='a', amount=12), dict(key='z', amount=-7),
                    dict(key='zero', amount=0)]
        self.succeeds('add', 'a', '12')
        self.assertEqual(json.loads(self.succeeds('list')), expected)
        conflict = self.run_cli('add', 'a', '99')
        self.assertNotEqual(conflict.returncode, 0)
        self.assertIn('different amount', conflict.stderr)
        self.assertEqual(json.loads(self.succeeds('list')), expected)

    def test_invalid_amount_does_not_change_entries(self):
        self.succeeds('add', 'kept', '4')
        self.assertNotEqual(self.run_cli('add', 'bad', '1.5').returncode, 0)
        self.assertEqual(json.loads(self.succeeds('list')),
                         [dict(key='kept', amount=4)])

    def test_total_empty_and_signed_persistent_entries(self):
        self.assertEqual(self.succeeds('total'), '0')
        self.succeeds('add', 'positive', '12')
        self.succeeds('add', 'negative', '-17')
        self.succeeds('add', 'zero', '0')
        self.succeeds('add', 'positive', '12')
        self.assertNotEqual(self.run_cli('add', 'positive', '99').returncode, 0)
        self.assertEqual(self.succeeds('total'), '-5')

    def test_total_exceeds_sqlite_integer_range(self):
        self.succeeds('add', 'a', str(2**63 - 1))
        self.succeeds('add', 'b', '1')
        self.assertEqual(self.succeeds('total'), str(2**63))
