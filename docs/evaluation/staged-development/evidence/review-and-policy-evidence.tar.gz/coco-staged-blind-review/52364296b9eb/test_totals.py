import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


SCRIPT = Path(__file__).with_name('totals.py')


class Totals(unittest.TestCase):
    def run_cli(self, content, *options):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'input.csv'
            path.write_text(content)
            return subprocess.run(
                [sys.executable, str(SCRIPT), str(path), *options],
                capture_output=True, text=True,
            )

    def test_text(self):
        result = self.run_cli('amount\n1\n2\n5\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, 'count=3 total=8\n')
        self.assertEqual(result.stderr, '')

    def test_json(self):
        for content, expected in [
            ('amount\n1\n2\n5\n', {'count': 3, 'total': 8}),
            ('amount\n', {'count': 0, 'total': 0}),
            ('amount\n-3\n2\n', {'count': 2, 'total': -1}),
        ]:
            with self.subTest(content=content):
                result = self.run_cli(content, '--format', 'json')
                self.assertEqual(result.returncode, 0, result.stderr)
                actual = json.loads(result.stdout)
                self.assertEqual(actual, expected)
                self.assertTrue(all(type(value) is int for value in actual.values()))
                self.assertEqual(result.stderr, '')

    def test_invalid_csv(self):
        for content, message in [
            ('amount\nnope\n', 'invalid integer amount'),
            ('name,amount\nitem,\n', 'invalid integer amount'),
            ('name,amount\nitem\n', 'invalid integer amount'),
            ('price\n1\n', "missing required 'amount' header"),
            ('', "missing required 'amount' header"),
        ]:
            for output_format in ('text', 'json'):
                with self.subTest(content=content, output_format=output_format):
                    result = self.run_cli(content, '--format', output_format)
                    self.assertNotEqual(result.returncode, 0)
                    self.assertEqual(result.stdout, '')
                    self.assertIn(message, result.stderr)
                    self.assertNotIn('Traceback', result.stderr)


if __name__ == '__main__':
    unittest.main()
