import argparse
import csv
import json
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('path')
    parser.add_argument('--format', choices=('text', 'json'), default='text')
    args = parser.parse_args()
    try:
        with open(args.path, newline='') as stream:
            reader = csv.DictReader(stream)
            if not reader.fieldnames or 'amount' not in reader.fieldnames:
                raise ValueError("missing required 'amount' header")
            values = []
            for row in reader:
                amount = row['amount']
                try:
                    values.append(int(amount))
                except (TypeError, ValueError):
                    raise ValueError(
                        f'invalid integer amount {amount!r} at CSV line {reader.line_num}'
                    ) from None
    except (OSError, ValueError, csv.Error) as error:
        print(f'error: {error}', file=sys.stderr)
        return 1

    result = {'count': len(values), 'total': sum(values)}
    if args.format == 'json':
        print(json.dumps(result))
    else:
        print('count=%d total=%d' % (result['count'], result['total']))
    return 0


if __name__ == '__main__':
    sys.exit(main())
