import unittest
from html.parser import HTMLParser
from pathlib import Path


class Elements(HTMLParser):
    def __init__(self, source):
        super().__init__()
        self.by_id = {}
        self.feed(source)

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if 'id' in attrs:
            self.by_id[attrs['id']] = (tag, attrs)


class Page(unittest.TestCase):
    def test_content(self):
        self.assertIn('Order details', Path('index.html').read_text())

    def test_initial_accessible_details_contract(self):
        elements = Elements(Path('index.html').read_text()).by_id
        tag, button = elements['toggle']
        self.assertEqual(tag, 'button')
        self.assertEqual(button['aria-expanded'], 'false')
        self.assertEqual(button.get('aria-controls'), 'details')
        self.assertIn('hidden', elements['details'][1])
