import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class Ledger(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.db = str(Path(self.directory.name) / 'ledger.db')

    def cli(self, *args):
        return subprocess.run(
            [sys.executable, str(Path(__file__).with_name('ledger.py')),
             '--db', self.db, *args],
            capture_output=True, text=True,
        )

    def succeeds(self, *args):
        result = self.cli(*args)
        self.assertEqual(result.returncode, 0, result.stderr)
        return result.stdout

    def test_empty(self):
        self.assertEqual(json.loads(self.succeeds('list')), [])
        self.assertEqual(self.succeeds('total').strip(), '0')

    def test_persistence_sorting_and_signed_total(self):
        for key, amount in [('z', '15'), ('a', '-7'), ('m', '0')]:
            self.succeeds('add', key, amount)
        self.assertEqual(json.loads(self.succeeds('list')), [
            {'key': 'a', 'amount': -7},
            {'key': 'm', 'amount': 0},
            {'key': 'z', 'amount': 15},
        ])
        self.assertEqual(self.succeeds('total').strip(), '8')

    def test_duplicate_is_idempotent_and_conflict_preserves_data(self):
        self.succeeds('add', 'item', '12')
        self.succeeds('add', 'item', '12')
        before = self.succeeds('list')
        result = self.cli('add', 'item', '-12')
        self.assertNotEqual(result.returncode, 0)
        self.assertTrue(result.stderr)
        self.assertEqual(self.succeeds('list'), before)
        self.assertEqual(self.succeeds('total').strip(), '12')

    def test_invalid_amount_does_not_change_data(self):
        self.succeeds('add', 'existing', '3')
        before = self.succeeds('list')
        for amount in ['1.5', 'oops', str(2**63)]:
            with self.subTest(amount=amount):
                self.assertNotEqual(self.cli('add', 'bad', amount).returncode, 0)
                self.assertEqual(self.succeeds('list'), before)
