from http.server import BaseHTTPRequestHandler, HTTPServer
import argparse
import json
import os


class Handler(BaseHTTPRequestHandler):
    def respond_json(self, status, payload):
        body = json.dumps(payload).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        self.respond_json(200, {'status': 'ok'})

    def do_POST(self):
        if self.path != '/sum':
            self.respond_json(404, {'error': 'not found'})
            return
        token = os.environ.get('SUM_TOKEN')
        if not token or self.headers.get_all('Authorization') != [f'Bearer {token}']:
            self.respond_json(401, {'error': 'unauthorized'})
            return
        lengths = self.headers.get_all('Content-Length', [])
        if (len(lengths) != 1 or not lengths[0].isascii()
                or not lengths[0].isdigit() or self.headers.get('Transfer-Encoding')):
            self.respond_json(400, {'error': 'invalid body length'})
            return
        length = int(lengths[0])
        if length > 1024:
            self.respond_json(413, {'error': 'body too large'})
            return
        try:
            payload = json.loads(self.rfile.read(length))
        except (ValueError, UnicodeError):
            self.respond_json(400, {'error': 'invalid JSON'})
            return
        if (not isinstance(payload, dict)
                or not isinstance(payload.get('amounts'), list)
                or any(type(value) is not int for value in payload['amounts'])):
            self.respond_json(400, {'error': 'invalid amounts'})
            return
        self.respond_json(200, {'total': sum(payload['amounts'])})

    def log_message(self, *args):
        pass


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, required=True)
    args = parser.parse_args()
    HTTPServer(('127.0.0.1', args.port), Handler).serve_forever()
