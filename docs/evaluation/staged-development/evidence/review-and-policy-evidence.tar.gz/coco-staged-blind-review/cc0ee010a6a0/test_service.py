import http.client
from http.server import HTTPServer
import json
import os
import threading
import unittest
from unittest.mock import patch

from service import Handler


class Service(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.environment = patch.dict(os.environ, {'SUM_TOKEN': 'local-test-token'})
        cls.environment.start()
        cls.server = HTTPServer(('127.0.0.1', 0), Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.thread.join()
        cls.server.server_close()
        cls.environment.stop()

    def request(self, body=b'', path='/sum', authorization='Bearer local-test-token',
                method='POST', extra_headers=None):
        connection = http.client.HTTPConnection(*self.server.server_address, timeout=3)
        headers = {} if authorization is None else {'Authorization': authorization}
        headers.update(extra_headers or {})
        try:
            connection.request(method, path, body=body, headers=headers)
            response = connection.getresponse()
            self.assertEqual(response.getheader('Content-Type'), 'application/json')
            return response.status, json.loads(response.read())
        finally:
            connection.close()

    def test_valid_amounts(self):
        for amounts in ([], [1, 2, -4], [10**100, 2]):
            with self.subTest(amounts=amounts):
                self.assertEqual(self.request(json.dumps({'amounts': amounts})),
                                 (200, {'total': sum(amounts)}))

    def test_invalid_input(self):
        for body in (b'{', b'\xff', b'null', b'[]', b'{}', b'{"amounts":null}',
                     b'{"amounts":1}', b'{"amounts":[true]}',
                     b'{"amounts":[1.5]}', b'{"amounts":["2"]}',
                     b'{"amounts":[null]}', b''):
            with self.subTest(body=body):
                self.assertEqual(self.request(body)[0], 400)

    def test_authentication(self):
        for auth in (None, '', 'Bearer wrong', 'bearer local-test-token',
                     'Bearer local-test-token ', 'Bearer  local-test-token'):
            with self.subTest(auth=auth):
                self.assertEqual(self.request(b'{"amounts":[]}', authorization=auth)[0], 401)
        with patch.dict(os.environ, {'SUM_TOKEN': ''}):
            self.assertEqual(self.request(b'{"amounts":[]}')[0], 401)

    def test_body_limit(self):
        body = b'{"amounts":[]}'
        self.assertEqual(self.request(body + b' ' * (1024 - len(body)))[0], 200)
        self.assertEqual(self.request(body + b' ' * (1025 - len(body)))[0], 413)

    def test_bad_length(self):
        for length in ('-1', 'abc'):
            self.assertEqual(self.request(extra_headers={'Content-Length': length})[0], 400)

    def test_routes(self):
        self.assertEqual(self.request(path='/other')[0], 404)
        self.assertEqual(self.request(path='/sum?query=1')[0], 404)
        self.assertEqual(self.request(method='GET', path='/health'),
                         (200, {'status': 'ok'}))


if __name__ == '__main__':
    unittest.main()
