import http.client
import json
import os
import threading
import unittest
from http.server import HTTPServer
from unittest.mock import patch

from service import Handler


class Service(unittest.TestCase):
    def setUp(self):
        self.env = patch.dict(os.environ, {'SUM_TOKEN': 'test-secret'})
        self.env.start()
        self.server = HTTPServer(('127.0.0.1', 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever)
        self.thread.start()
        self.addCleanup(self.cleanup)

    def cleanup(self):
        self.server.shutdown()
        self.thread.join()
        self.server.server_close()
        self.env.stop()

    def request(self, body='', path='/sum', auth='Bearer test-secret', method='POST'):
        conn = http.client.HTTPConnection(*self.server.server_address, timeout=3)
        headers = {} if auth is None else {'Authorization': auth}
        try:
            conn.request(method, path, body, headers)
            response = conn.getresponse()
            return response.status, json.loads(response.read())
        finally:
            conn.close()

    def test_sum(self):
        for amounts, total in [([1, -2, 4], 3), ([], 0)]:
            with self.subTest(amounts=amounts):
                self.assertEqual(self.request(json.dumps({'amounts': amounts})),
                                 (200, {'total': total}))

    def test_auth(self):
        for auth in [None, '', 'Bearer wrong', 'bearer test-secret',
                     'Bearer test-secret ', 'Bearer  test-secret']:
            with self.subTest(auth=auth):
                self.assertEqual(self.request('{"amounts": []}', auth=auth)[0], 401)
        with patch.dict(os.environ, {}, clear=True):
            self.assertEqual(self.request('{"amounts": []}', auth='Bearer ')[0], 401)

    def test_invalid_input(self):
        for body in ['{', '[]', 'null', '{}', '{"amounts": null}',
                     '{"amounts": [true]}', '{"amounts": [1.0]}',
                     '{"amounts": ["1"]}', '{"amounts": {}}', b'\xff']:
            with self.subTest(body=body):
                self.assertEqual(self.request(body)[0], 400)

    def test_size_limit(self):
        body = '{"amounts": []}'
        self.assertEqual(self.request(body + ' ' * (1024 - len(body)))[0], 200)
        self.assertEqual(self.request(body + ' ' * (1025 - len(body)))[0], 413)

    def test_routes_and_health(self):
        self.assertEqual(self.request(path='/other')[0], 404)
        self.assertEqual(self.request(path='/sum?x=1')[0], 404)
        self.assertEqual(self.request(method='GET'), (200, {'status': 'ok'}))


if __name__ == '__main__':
    unittest.main()
