from http.server import BaseHTTPRequestHandler, HTTPServer
import argparse
import json
import os


class Handler(BaseHTTPRequestHandler):
    def respond(self, status, value):
        body = json.dumps(value).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        self.respond(200, {'status': 'ok'})

    def do_POST(self):
        if self.path != '/sum':
            self.respond(404, {'error': 'not found'})
            return
        token = os.environ.get('SUM_TOKEN')
        if not token or self.headers.get_all('Authorization', []) != ['Bearer ' + token]:
            self.respond(401, {'error': 'unauthorized'})
            return
        lengths = self.headers.get_all('Content-Length', [])
        if (self.headers.get('Transfer-Encoding') is not None or len(lengths) != 1
                or not lengths[0].isascii() or not lengths[0].isdecimal()):
            self.respond(400, {'error': 'invalid body length'})
            return
        # Compare decimal strings before conversion to bound even huge length headers.
        length_text = lengths[0].lstrip('0') or '0'
        if len(length_text) > 4 or int(length_text) > 1024:
            self.respond(413, {'error': 'body too large'})
            return
        body = self.rfile.read(int(length_text))
        try:
            value = json.loads(body)
        except (ValueError, UnicodeError, RecursionError):
            self.respond(400, {'error': 'invalid JSON'})
            return
        if (not isinstance(value, dict) or not isinstance(value.get('amounts'), list)
                or any(type(amount) is not int for amount in value['amounts'])):
            self.respond(400, {'error': 'invalid amounts'})
            return
        self.respond(200, {'total': sum(value['amounts'])})

    def log_message(self, *args):
        pass


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, required=True)
    args = parser.parse_args()
    HTTPServer(('127.0.0.1', args.port), Handler).serve_forever()
