import unittest
from html.parser import HTMLParser
from pathlib import Path


class PageElements(HTMLParser):
    def __init__(self):
        super().__init__()
        self.elements = {}

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if 'id' in attrs:
            self.elements[attrs['id']] = (tag, attrs)


class Page(unittest.TestCase):
    def test_content(self):
        self.assertIn('Order details', Path('index.html').read_text())

    def test_initial_disclosure_semantics(self):
        page = PageElements()
        page.feed(Path('index.html').read_text())
        tag, button = page.elements['toggle']
        self.assertEqual(tag, 'button')
        self.assertEqual(button['aria-expanded'], 'false')
        self.assertEqual(button['aria-controls'], 'details')
        self.assertIn('hidden', page.elements['details'][1])
