import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class Ledger(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.db = str(Path(directory.name) / 'ledger.db')

    def run_cli(self, *args, success=True):
        result = subprocess.run(
            [sys.executable, str(Path(__file__).with_name('ledger.py')),
             '--db', self.db, *args], capture_output=True, text=True,
        )
        if success:
            self.assertEqual(result.returncode, 0, result.stderr)
        else:
            self.assertNotEqual(result.returncode, 0)
        return result

    def test_empty(self):
        self.assertEqual(json.loads(self.run_cli('list').stdout), [])
        self.assertEqual(self.run_cli('total').stdout, '0\n')

    def test_persistent_add_retry_conflict_and_total(self):
        self.run_cli('add', 'z', '12')
        self.run_cli('add', 'a', '-5')
        self.run_cli('add', 'zero', '0')
        self.run_cli('add', 'z', '12')
        self.run_cli('add', 'a', '99', success=False)
        self.assertEqual(json.loads(self.run_cli('list').stdout), [
            {'key': 'a', 'amount': -5},
            {'key': 'z', 'amount': 12},
            {'key': 'zero', 'amount': 0},
        ])
        self.assertEqual(self.run_cli('total').stdout, '7\n')

    def test_invalid_amount_preserves_data(self):
        self.run_cli('add', 'a', '3')
        for amount in ('1.5', 'abc', str(2**63), str(-2**63 - 1)):
            self.run_cli('add', 'b', amount, success=False)
        self.assertEqual(json.loads(self.run_cli('list').stdout), [
            {'key': 'a', 'amount': 3},
        ])

    def test_total_exceeds_sqlite_integer_range(self):
        self.run_cli('add', 'a', str(2**63 - 1))
        self.run_cli('add', 'b', str(2**63 - 1))
        self.assertEqual(self.run_cli('total').stdout, f'{2 * (2**63 - 1)}\n')
