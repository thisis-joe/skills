import argparse
import json
import sqlite3


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    add = commands.add_parser('add')
    add.add_argument('key')
    add.add_argument('amount', type=int)
    commands.add_parser('total')
    args = parser.parse_args()

    connection = sqlite3.connect(args.db)
    try:
        connection.execute(
            'CREATE TABLE IF NOT EXISTS entries '
            '(key TEXT PRIMARY KEY, amount INTEGER NOT NULL)'
        )
        if args.command == 'add':
            if not -(2**63) <= args.amount < 2**63:
                parser.error('amount must fit in a signed 64-bit integer')
            with connection:
                connection.execute(
                    'INSERT INTO entries (key, amount) VALUES (?, ?) '
                    'ON CONFLICT(key) DO NOTHING',
                    (args.key, args.amount),
                )
                amount = connection.execute(
                    'SELECT amount FROM entries WHERE key = ?', (args.key,)
                ).fetchone()[0]
                if amount != args.amount:
                    parser.error('key already exists with a different amount')
        elif args.command == 'list':
            print(json.dumps([
                dict(key=key, amount=amount)
                for key, amount in connection.execute(
                    'SELECT key, amount FROM entries ORDER BY key'
                )
            ]))
        else:
            print(sum(amount for amount, in connection.execute(
                'SELECT amount FROM entries'
            )))
    finally:
        connection.close()


if __name__ == '__main__':
    main()
