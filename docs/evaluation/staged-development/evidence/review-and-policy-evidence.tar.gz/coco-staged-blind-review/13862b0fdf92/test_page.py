import unittest
from pathlib import Path
class Page(unittest.TestCase):
 def test_page(self): self.assertIn("Saved records",Path("index.html").read_text())
