import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


SCRIPT = Path(__file__).with_name('totals.py')


class Totals(unittest.TestCase):
    def run_cli(self, contents, *options):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'input.csv'
            path.write_text(contents)
            return subprocess.run(
                [sys.executable, str(SCRIPT), str(path), *options],
                text=True, capture_output=True,
            )

    def test_text(self):
        result = self.run_cli('amount\n2\n7\n-1\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, 'count=3 total=8\n')
        self.assertEqual(result.stderr, '')

    def test_json(self):
        result = self.run_cli('amount\n2\n7\n-1\n', '--format', 'json')
        self.assertEqual(result.returncode, 0, result.stderr)
        data = json.loads(result.stdout)
        self.assertEqual(data, {'count': 3, 'total': 8})
        self.assertTrue(all(type(value) is int for value in data.values()))
        self.assertEqual(result.stderr, '')

    def test_empty_column(self):
        for options in [(), ('--format', 'json')]:
            with self.subTest(options=options):
                result = self.run_cli('amount\n', *options)
                self.assertEqual(result.returncode, 0, result.stderr)
                if options:
                    self.assertEqual(json.loads(result.stdout), {'count': 0, 'total': 0})
                else:
                    self.assertEqual(result.stdout, 'count=0 total=0\n')

    def test_invalid_input(self):
        for contents, message in [
            ('amount\n2\nwrong\n', 'integer'),
            ('other\n2\n', 'amount'),
            ('other\n', 'amount'),
            ('', 'amount'),
            ('amount,other\n,2\n', 'integer'),
            ('other,amount\n2\n', 'integer'),
        ]:
            for options in [(), ('--format', 'json')]:
                with self.subTest(contents=contents, options=options):
                    result = self.run_cli(contents, *options)
                    self.assertNotEqual(result.returncode, 0)
                    self.assertEqual(result.stdout, '')
                    self.assertIn(message, result.stderr)
                    self.assertNotIn('Traceback', result.stderr)


if __name__ == '__main__':
    unittest.main()
