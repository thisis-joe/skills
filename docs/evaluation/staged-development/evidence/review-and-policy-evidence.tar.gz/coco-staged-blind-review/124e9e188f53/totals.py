import argparse
import csv
import json
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('path')
    parser.add_argument('--format', choices=('text', 'json'), default='text')
    args = parser.parse_args()
    count = 0
    total = 0
    try:
        with open(args.path, newline='') as stream:
            reader = csv.DictReader(stream)
            if not reader.fieldnames or 'amount' not in reader.fieldnames:
                raise ValueError("missing required 'amount' header")
            for row in reader:
                amount = row['amount']
                try:
                    value = int(amount)
                except (ValueError, TypeError):
                    raise ValueError(
                        f'line {reader.line_num}: invalid integer amount {amount!r}'
                    ) from None
                count += 1
                total += value
    except (OSError, ValueError, csv.Error) as error:
        print(f'error: {error}', file=sys.stderr)
        return 1

    if args.format == 'json':
        print(json.dumps({'count': count, 'total': total}))
    else:
        print('count=%d total=%d' % (count, total))
    return 0


if __name__ == '__main__':
    sys.exit(main())
