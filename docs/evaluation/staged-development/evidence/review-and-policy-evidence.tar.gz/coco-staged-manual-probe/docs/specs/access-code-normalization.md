# Access-code normalization

Spec ID: `access-code-normalization`  
Version: 1  
Status: agreed behavior; ready for planning  
Authority: [recorded request](../../request.txt)  
Work record: [work-state.json](../../work-state.json)

## Objective and scope

Callers of `normalize(code)` need a consistent access-code string. Normalize ASCII letters to uppercase, remove leading and trailing ASCII spaces, preserve internal spaces, and reject an empty normalized result.

The existing public function remains `normalize(code)` in `normalizer.py`. This contract covers string inputs. No new requirement is established for non-string inputs, an exception message, access-code length, storage, authentication, or external services.

## Behavioral contract

For a string input:

1. Remove only leading and trailing ASCII space characters (`U+0020`).
2. Convert ASCII lowercase letters `a` through `z` to `A` through `Z`.
3. Preserve all other characters, including internal ASCII spaces, tabs, newlines, non-ASCII whitespace, and non-ASCII letters.
4. Raise `ValueError` if the normalized result is the empty string; otherwise return the normalized string.

The function has no specified side effects. Implementation technique is left to the implementation task.

## Acceptance criteria

| Input (Python string literal) | Expected result | Boundary covered |
| --- | --- | --- |
| `"abc"` | `"ABC"` | ASCII case conversion |
| `"  aB9-z  "` | `"AB9-Z"` | Edge ASCII spaces, existing uppercase, digits, punctuation |
| `"  ab  cd  "` | `"AB  CD"` | Internal ASCII spaces preserved exactly |
| `""` | `ValueError` | Empty input |
| `"   "` | `ValueError` | Empty after trimming |
| `" \tab\n "` | `"\tAB\n"` | Tabs and newlines preserved at normalized edges |
| `" \u00a0az\u00a0 "` | `"\u00a0AZ\u00a0"` | Non-ASCII whitespace preserved |
| `" éßaz "` | `"éßAZ"` | Non-ASCII letters preserved |
| `"\t"` | `"\t"` | Nonempty whitespace other than ASCII space accepted |

## Verification strategy

Verify these independent expected results through the public `normalize(code)` function when implementation is selected. Include error assertions for the empty-result cases and exact string equality for preservation cases. These checks cover the complete specified pure-function behavior; they do not establish behavior for non-string inputs or any external caller integration.

The project currently has no test suite, CI configuration, or prescribed verification command. Planning must name a runnable local check using the project's available Python runtime. No runtime acceptance check has been run against an implementation for this spec: `normalizer.py` remains the original identity function.

## Constraints and handoff

Follow [project instructions](../../AGENTS.md): specifications belong in `docs/specs`, plans in `docs/plans`, use only project-local `.guide` procedures, preserve `normalizer.py` until implementation is selected, and perform no external operations.

Task scheduling remains continuous. Skill transitions remain manual, with automatic basic transitions disabled. The next proposed skill is `coco-plan`, which will save dependency-ready implementation work and its checks. It has not been selected; no plan or implementation is authorized by this handoff alone.

## Open decisions

No unresolved behavioral decisions block planning. The pending workflow selection is whether to run `coco-plan` once or enable automatic basic transitions for this spec's agreed scope. Record the user's choice in the authoritative work record before switching skills.
