def normalize(code):
    return code
