Use only project-local procedures in .guide. Preserve normalizer.py until implementation is selected. Specifications belong in docs/specs and plans in docs/plans. No external operations.
