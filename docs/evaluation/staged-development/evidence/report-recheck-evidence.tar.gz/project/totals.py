import argparse, csv, json, sys
def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('path')
    parser.add_argument('--format', choices=('text', 'json'), default='text')
    args=parser.parse_args()
    with open(args.path, newline='') as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames is None or 'amount' not in reader.fieldnames:
            parser.error("missing required 'amount' header")
        values = []
        for row in reader:
            amount = row['amount']
            try:
                values.append(int(amount))
            except (ValueError, TypeError):
                parser.error('invalid integer amount at line %d: %r' %
                             (reader.line_num, amount))
    if args.format == 'json':
        print(json.dumps({'count': len(values), 'total': sum(values)}))
    else:
        print('count=%d total=%d' % (len(values),sum(values)))
if __name__=='__main__': main()
