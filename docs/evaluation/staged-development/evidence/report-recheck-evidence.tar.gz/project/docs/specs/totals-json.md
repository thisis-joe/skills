# Totals JSON output

Source: BRIEF.md.

Add optional `--format json` output with integer `count` and `total` fields.
Keep default text output unchanged; allow explicit `--format text`.
An amount header with no data rows produces zero count and total.
Malformed integer amounts and missing amount headers must produce useful stderr
errors, a nonzero exit status, no traceback, and no partial stdout.
Use only the Python standard library. Exercise the actual CLI and commit locally.
