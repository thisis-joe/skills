import json, subprocess, sys, unittest
class Totals(unittest.TestCase):
 def test_text(self):
  self.assertEqual(subprocess.check_output([sys.executable,'totals.py','sales.csv'],text=True).strip(),'count=3 total=8')

 def test_json(self):
  result = subprocess.run([sys.executable, 'totals.py', 'sales.csv', '--format', 'json'], text=True, capture_output=True)
  self.assertEqual(result.returncode, 0, result.stderr)
  self.assertEqual(json.loads(result.stdout), {'count': 3, 'total': 8})
  self.assertEqual(result.stderr, '')

 def test_boundaries(self):
  import tempfile
  from pathlib import Path
  cases = [
   ('amount\n', 0, {'count': 0, 'total': 0}, None),
   ('amount\nnope\n', 1, None, 'amount'),
   ('other\n2\n', 1, None, 'amount'),
   ('other\n', 1, None, 'amount'),
   ('', 1, None, 'amount'),
   ('amount,other\n,foo\n', 1, None, 'amount'),
   ('other,amount\nfoo\n', 1, None, 'amount'),
  ]
  with tempfile.TemporaryDirectory() as directory:
   path = Path(directory) / 'input.csv'
   for contents, status, expected, error in cases:
    for output_format in ('text', 'json'):
     with self.subTest(contents=contents, output_format=output_format):
      path.write_text(contents)
      result = subprocess.run([sys.executable, 'totals.py', str(path), '--format', output_format], text=True, capture_output=True)
      if error:
       self.assertNotEqual(result.returncode, 0)
       self.assertIn(error, result.stderr)
       self.assertNotIn('Traceback', result.stderr)
       self.assertEqual(result.stdout, '')
      else:
       self.assertEqual(result.returncode, status, result.stderr)
       self.assertEqual(result.stderr, '')
       if output_format == 'json':
        self.assertEqual(json.loads(result.stdout), expected)
        self.assertTrue(all(type(value) is int for value in json.loads(result.stdout).values()))
       else:
        self.assertEqual(result.stdout, 'count=0 total=0\n')
