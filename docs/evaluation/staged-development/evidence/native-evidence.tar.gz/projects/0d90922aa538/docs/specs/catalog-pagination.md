# Catalog pagination

`BRIEF.md` is the originating requirement. Offset is zero-based and limit is
maximum count. Offsets 0 and 3 with limit 3 return amber/birch/cedar and
dawn/elm/fern respectively, preserving order. Beyond-end offsets return [].
Negative offsets and nonpositive limits produce readable nonzero CLI errors.
Only Python standard library and local checks are permitted; no publication.
