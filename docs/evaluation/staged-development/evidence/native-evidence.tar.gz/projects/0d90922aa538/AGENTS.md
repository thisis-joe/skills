# Project rules
Use only the Python standard library and local files/services. Work on a feature
branch and make work-unit commits. Preserve unrelated user work. Run
`python3 -m unittest discover -v` and the actual affected CLI/HTTP path. Do not
access external services, publish, install packages or change global settings.
