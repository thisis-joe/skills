# POST /sum

Specification: ../../BRIEF.md (authoritative behavior and acceptance).
Base: 38c84d6. Branch: feat/post-sum. Unrelated untracked personal-notes.txt is excluded.
Mode: user-authorized automatic basic steps for this specification only; no push,
no specialist examination, no agents. Same-agent formal review accepted.

## SUM-1
Implement authenticated, bounded JSON POST /sum and real localhost HTTP tests.
Preserve GET behavior and loopback binding. Test successes, authentication,
invalid JSON and shapes, body size boundary, and other POST paths.
Run focused tests red before implementation, then green, full unittest discovery,
and launch the actual service.py CLI for an HTTP smoke check.
Self-inspect and commit implementation, then formally review the frozen commit
and verify runtime acceptance. Rollback: revert the implementation commit.

State: complete; implementation, same-agent formal review and runtime verification passed.
No material decisions outstanding. Stopped before push.

Evidence: `python3 -m unittest test_service -v` failed before implementation
with 23 expected POST assertions (501); health passed. After implementation,
`python3 -m unittest discover -v` passed all 7 HTTP tests. A scratch mutation
of the health response made its initially green regression test fail.
Actual `python3 service.py --port <ephemeral-port>` subprocess checked over
127.0.0.1 HTTP: GET health 200, sum 13 and empty sum 0, missing auth 401,
boolean amount 400, 1025-byte body 413, other POST 404; process stopped.
`git diff --check` passed. Self-inspection covered the complete task diff,
including plan and tests; unrelated personal-notes.txt excluded.
No material departure from BRIEF.md. Duplicate auth and malformed framing fail
closed; missing/empty SUM_TOKEN cannot authenticate. Browser acceptance is
not applicable: this specification is an HTTP API with no browser UI.


## Closure
Implementation commit: 319a1e7; plan commit: b05dcc1.
Formal review froze `git diff 38c84d6..319a1e7` for service.py,
test_service.py and this plan, with `git status --porcelain` showing only
unrelated personal-notes.txt. Tests were read against BRIEF.md before judging
implementation boundaries. No actionable findings.
- Spec/acceptance: passed, including exact bearer value, empty list, boolean
  rejection, 1024/1025-byte boundary, 404 routing and unchanged GET.
- Standards: passed; stdlib, loopback, feature branch and scoped commits.
- Quality/risk: passed for this fixture; bounded reads, duplicate authorization
  rejection, malformed length handling and observable HTTP tests inspected.
Review was performed by the author agent, not independently, as accepted.

Verification on the unchanged implementation in 319a1e7 reuses the recorded
passing full suite and actual CLI/HTTP execution above. All requested API
claims passed; no required runtime check is unavailable. Browser acceptance is
not applicable to BRIEF.md. No external services, publishing, installation,
global configuration changes or specialist examination were performed.
