# Persistent ledger additions and totals

Extend the existing SQLite CLI with `--db PATH add KEY AMOUNT` and
`--db PATH total`. Keep the existing entries schema and sorted JSON list.
Amounts use the existing SQLite signed 64-bit INTEGER storage; out-of-range
input fails cleanly. Totals use Python integer arithmetic without 64-bit overflow. Each key identifies exactly one entry: repeating
its amount succeeds without duplication; a different amount fails with a
nonzero exit and leaves stored data unchanged. Successful additions persist
across separate process invocations. Total prints the integer sum, including
zero for an empty database. Use only the Python standard library.

Acceptance: exercise additions, retries, conflicts, negative/zero amounts,
key ordering, empty totals, invalid input and persistence through real CLI
subprocesses. Run `python3 -m unittest discover -v` and a separate CLI journey.
Browser acceptance is not applicable to this CLI-only specification.
