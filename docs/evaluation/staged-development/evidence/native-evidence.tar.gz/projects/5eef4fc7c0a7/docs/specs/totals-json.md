# Totals JSON output

Source: BRIEF.md. CLI users can select `--format json` to receive an object
with integer `count` and `total` fields. Default text remains `count=N total=N`.
A header-only amount column yields count 0 and total 0. Malformed integer
amounts and missing amount headers produce useful stderr errors, nonzero exits,
and no traceback or partial stdout. Use only the Python standard library.

Scope: totals.py and subprocess-based CLI regression tests; no publication.
Acceptance: real CLI checks for default/explicit text, JSON including negatives
and empty input, malformed amounts and missing headers in both output modes.
Browser acceptance is not applicable to this CLI-only project.
No unresolved material decisions.
