# Details toggle

Preserve the Details label and Order details content. Initially details are hidden
and aria-expanded is false. Each activation toggles #details.hidden and updates
aria-expanded to the corresponding visible state. Use a native button with
aria-controls="details" so keyboard activation uses the same click handler.

Acceptance requires actual browser interaction: load the page, activate twice,
observe hidden/false → visible/true → hidden/false, repeat with keyboard, and
check the console. No browser runner is configured; do not substitute source
checks for this acceptance or install tools. Browser verification stays pending.
