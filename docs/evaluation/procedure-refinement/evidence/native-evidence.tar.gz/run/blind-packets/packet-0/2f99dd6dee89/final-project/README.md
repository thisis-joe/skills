Use Python stdlib and local files. BRIEF.md describes the current work. Existing regression command: python3 -m unittest discover -v. No publication is authorized.
