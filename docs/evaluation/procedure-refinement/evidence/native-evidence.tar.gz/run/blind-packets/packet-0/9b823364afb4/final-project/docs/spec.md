# Purchasing catalog
Add `import PATH` and `summary` to the existing catalog.py --db PATH CLI. CSV
fields are sku,name,price_cents. Preserve stored items and the list JSON interface.
SKU and name must be nonempty; prices are nonnegative integer cents. Summary is
a JSON array containing {supplier: "legacy", count, total_cents}; no entries gives
[]. The owner supplies the business decisions directly in the working session.
This project has one supplier; a supplier/batch extension is outside this scope.

Current agreement:
- Trim surrounding whitespace and use lowercase SKU keys; case variants are the same item.
- For duplicate keys in a file use the last row. a later import updates an existing stored row as well.
- Reject the entire import if any row is malformed; leave the catalog unchanged.
- Summary excludes zero-price rows from both count and total. List retains them.

Decision history: The original saved agreement included zero-price rows in the
summary count (adding zero to total). The owner superseded that expectation
because the purchasing report must match the new accounting convention. Only
positive-price rows now contribute to summary; a catalog with no qualifying rows
will produce []. Summary implementation is deferred to the next session.

Import accepts the header sku,name,price_cents and exactly three fields per row.
Trim SKU and name; reject whitespace-only values. Prices are decimal digits
representing nonnegative integer cents (surrounding whitespace is allowed).
Malformed CSV, invalid headers, missing/extra fields or invalid values reject
the whole file before stored catalog rows change. Import updates matching SKU
keys and preserves other stored items. List keeps its JSON array and SKU order.

Implementation boundary: prices must fit SQLite's signed 64-bit integer storage
(0 through 9223372036854775807). On import, touched pre-existing SKU spellings
are compared after trimming/lowercasing and replaced by the canonical key;
unrelated stored rows are not rewritten. Successful import exits 0 silently;
rejection exits nonzero with an error on stderr.
