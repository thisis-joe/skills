import json,subprocess,sys,tempfile,unittest
class Catalog(unittest.TestCase):
 def test_empty_list(self):
  with tempfile.TemporaryDirectory() as d:
   self.assertEqual(json.loads(subprocess.check_output([sys.executable,'catalog.py','--db',d+'/x.sqlite','list'])),[])

class ImportCatalog(unittest.TestCase):
 def test_import_normalizes_upserts_and_preserves(self):
  with tempfile.TemporaryDirectory() as d:
   from pathlib import Path
   db=d+'/x.sqlite'; source=Path(d)/'items.csv'
   def run(*args):
    return subprocess.run([sys.executable,'catalog.py','--db',db,*args],capture_output=True,text=True)
   source.write_text('sku,name,price_cents\nkeep,Existing,41\n')
   self.assertEqual(run('import',str(source)).returncode,0)
   source.write_text('sku,name,price_cents\n A , First ,12\na, Last ,0\nb,Other,7\n')
   result=run('import',str(source)); self.assertEqual(result.returncode,0,result.stderr)
   self.assertEqual(json.loads(run('list').stdout),[
    {'sku':'a','name':'Last','price_cents':0},
    {'sku':'b','name':'Other','price_cents':7},
    {'sku':'keep','name':'Existing','price_cents':41}])
   source.write_text('sku,name,price_cents\n A ,Updated,19\n')
   self.assertEqual(run('import',str(source)).returncode,0)
   self.assertEqual(json.loads(run('list').stdout)[0],{'sku':'a','name':'Updated','price_cents':19})

 def test_bad_import_leaves_catalog_unchanged(self):
  with tempfile.TemporaryDirectory() as d:
   from pathlib import Path
   import sqlite3
   db=d+'/x.sqlite'; source=Path(d)/'items.csv'
   with sqlite3.connect(db) as connection:
    connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
    connection.execute("INSERT INTO catalog VALUES ('keep','Existing',41)")
   before=Path(db).read_bytes()
   invalid=[
    'wrong,name,price_cents\na,Item,2\n',
    'sku,name,price_cents\na,Valid,2\nb,Bad,-1\n',
    'sku,name,price_cents\na,Valid,2\n ,Bad,3\n',
    'sku,name,price_cents\na,Valid,2\nb, ,3\n',
    'sku,name,price_cents\na,Valid,2\nb,Bad,1.5\n',
    'sku,name,price_cents\na,Valid,2\nb,Bad\n',
    'sku,name,price_cents\na,Valid,2\nb,Bad,3,extra\n',
    'sku,name,price_cents\na,Valid,2\nb,Bad,9223372036854775808\n',
    'sku,name,price_cents\na,Valid,2\nb,"unclosed,3\n',
   ]
   for content in invalid:
    with self.subTest(content=content):
     source.write_text(content)
     result=subprocess.run([sys.executable,'catalog.py','--db',db,'import',str(source)],capture_output=True,text=True)
     self.assertNotEqual(result.returncode,0)
     self.assertIn('catalog:',result.stderr)
     self.assertEqual(Path(db).read_bytes(),before)
   result=subprocess.run([sys.executable,'catalog.py','--db',db,'import',d+'/missing.csv'],capture_output=True,text=True)
   self.assertNotEqual(result.returncode,0)
   self.assertEqual(Path(db).read_bytes(),before)
