Python standard library. Public CLI: python3 app.py INPUT.json.
Existing version: python3 app.py --version.
Checks: python3 -m unittest discover -v.

INPUT.json contains an array of nonnegative integer session durations in minutes.
Empty input returns {"units": 0}. Sessions divisible by 30 return their total
30-minute units; for example [30, 60, 0] returns {"units": 3}.

The feature is incomplete pending owner charging decisions. Any session with a
partial 30-minute unit currently exits with an explicit pending-policy error
and no billing JSON. This does not establish rounding or aggregation rules.
Invalid input and unreadable files also exit nonzero with an error on stderr.
See docs/specs/service-duration-billing.md and docs/plans/service-duration-billing.md.
