# Purchasing catalog
Add `import PATH` and `summary` to the existing catalog.py --db PATH CLI. CSV
fields are sku,name,price_cents. Preserve stored items and the list JSON interface.
SKU and name must be nonempty; prices are nonnegative integer cents. Summary is
a JSON array containing {supplier: "legacy", count, total_cents}; no entries gives
[]. The owner supplies the business decisions directly in the working session.
This project has one supplier; a supplier/batch extension is outside this scope.

Original agreement:
- Trim surrounding whitespace and use lowercase SKU keys; case variants are the same item.
- For duplicate keys in a file use the last row. a later import updates an existing stored row as well.
- Reject the entire import if any row is malformed; leave the catalog unchanged.
- Summary includes zero-price rows in count; they add zero to total. List retains them.

## Superseding owner decision (2026-10-23)

The original summary expectation above included zero-price rows in count.
The owner now requires summary to exclude zero-price rows from both count and
sum so the purchasing report matches the new accounting convention. List still
retains them. This supersedes only that original expectation; the other agreed
import rules stand. Summary is implemented in the resumed summary work unit.

## Import/list acceptance

`python3 catalog.py --db PATH import CSV_PATH` reads the exact CSV header
`sku,name,price_cents`, trims surrounding field whitespace, lowercases SKU keys,
and upserts validated rows without deleting other items. Last duplicate wins.
Every row must have three fields, nonempty SKU/name and nonnegative integer
cents representable in SQLite. A malformed file fails with a nonzero exit and
leaves the catalog unchanged. List remains a SKU-sorted JSON array, including
zero-price items. No supplier/batch extension; summary is a separate work unit.
