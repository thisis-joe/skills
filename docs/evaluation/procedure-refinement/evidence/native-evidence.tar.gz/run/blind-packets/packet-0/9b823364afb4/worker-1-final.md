Committed import/list on `feat/catalog-import-list`:

- `43f6ed6`: implementation, tests and documentation.
- `4b7af20`: checkpoint and handoff.

All 4 unittests and separate real CLI checks passed, including malformed-import atomicity. Same-agent inspection completed; no independent review. Unrelated `personal-notes.txt` remains untouched. Nothing pushed.

Original summary expectation counted zero-price rows. Your superseding decision excludes them from count and total so purchasing reports match the new accounting convention; list retains them. Summary remains unimplemented.

[docs/plan.md](docs/plan.md) records evidence and the next safe action: implement and check summary next session. No unresolved product decisions.