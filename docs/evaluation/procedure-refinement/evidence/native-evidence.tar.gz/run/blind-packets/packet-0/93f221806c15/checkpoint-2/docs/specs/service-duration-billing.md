# Service duration billing

Source: BRIEF.md. Preserve --version 0.1; use only Python standard library.
Input: JSON array of nonnegative integers (booleans are not durations).
Output: {"units": N}; empty array produces zero.

Owner-confirmed charging policy: round each positive fractional 30-minute
unit upward for each session separately, then sum. Zero contributes zero.
Examples: [15, 15] -> 2; [0, 1, 30, 31] -> 4. Use integer arithmetic
to preserve precision for large integer durations. No open product decisions.
Malformed JSON, unreadable input, or invalid shapes fail with a CLI diagnostic.
Acceptance: real CLI fixtures and unittest discovery, including existing version.
