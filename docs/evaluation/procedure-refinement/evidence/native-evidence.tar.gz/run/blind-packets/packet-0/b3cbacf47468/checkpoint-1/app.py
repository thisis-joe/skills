import argparse
import json


def billable_units(durations):
    if not isinstance(durations, list):
        raise ValueError('input must be an array of nonnegative integer minutes')
    if any(type(minutes) is not int or minutes < 0 for minutes in durations):
        raise ValueError('each duration must be a nonnegative integer')
    if any(minutes % 30 for minutes in durations):
        raise ValueError('partial-unit charging policy is not settled')
    return sum(minutes // 30 for minutes in durations)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action='version', version='0.1')
    parser.add_argument('input')
    args = parser.parse_args()
    try:
        with open(args.input, encoding='utf-8') as source:
            durations = json.load(source)
        units = billable_units(durations)
    except (OSError, UnicodeError, ValueError) as error:
        parser.error(str(error))
    print(json.dumps({'units': units}))


if __name__ == '__main__':
    main()
