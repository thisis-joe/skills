Use a descriptive feature branch and work-unit commits. Preserve unrelated work. Exercise the public CLI and existing unittest suite. No publication.
