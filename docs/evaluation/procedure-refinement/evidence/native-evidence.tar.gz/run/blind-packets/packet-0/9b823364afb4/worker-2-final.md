Completed and committed as `e26bb99` on `feat/catalog-import-list`.

- Expected and actual: summary counts and totals positive-price items under `"legacy"`; returns `[]` when none qualify. No material departure.
- All 6 unittest tests passed, plus disposable real CLI checks.
- Completed import behavior is preserved; zero-price items remain listed.
- Same-agent inspection completed; no independent review performed.
- `personal-notes.txt` remains untouched. Tracked working tree is clean.
- No unresolved decisions. Nothing pushed or published.