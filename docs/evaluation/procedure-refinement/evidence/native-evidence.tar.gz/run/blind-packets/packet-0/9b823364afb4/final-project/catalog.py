import argparse
import csv
import json
import sqlite3


def read_import(path):
    items = {}
    with open(path, newline='', encoding='utf-8') as source:
        rows = csv.reader(source, strict=True)
        if next(rows, None) != ['sku', 'name', 'price_cents']:
            raise ValueError('expected CSV header sku,name,price_cents')
        for row in rows:
            if len(row) != 3:
                raise ValueError(f'line {rows.line_num}: expected three fields')
            sku, name, price = (value.strip() for value in row)
            sku = sku.lower()
            if not sku or not name or not price or any(c not in '0123456789' for c in price):
                raise ValueError(f'line {rows.line_num}: invalid SKU, name or price')
            cents = int(price)
            if cents > 9223372036854775807:
                raise ValueError(f'line {rows.line_num}: price exceeds SQLite integer range')
            items[sku] = (sku, name, cents)
    return list(items.values())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    commands.add_parser('summary')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    args = parser.parse_args()
    try:
        # Validate the entire file before opening or changing the catalog.
        items = read_import(args.path) if args.command == 'import' else None
        connection = sqlite3.connect(args.db)
        try:
            with connection:
                connection.execute('CREATE TABLE IF NOT EXISTS catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
                if items is not None:
                    keys = {item[0] for item in items}
                    # Replace touched legacy spellings with the canonical SKU.
                    legacy_keys = [
                        (sku,) for (sku,) in connection.execute('SELECT sku FROM catalog')
                        if sku.strip().lower() in keys and sku not in keys
                    ]
                    connection.executemany('DELETE FROM catalog WHERE sku=?', legacy_keys)
                    connection.executemany(
                        'INSERT INTO catalog (sku,name,price_cents) VALUES (?,?,?) '
                        'ON CONFLICT(sku) DO UPDATE SET name=excluded.name, price_cents=excluded.price_cents',
                        items,
                    )
                elif args.command == 'summary':
                    count = 0
                    total = 0
                    # Python integers keep totals exact beyond SQLite SUM's range.
                    for (price,) in connection.execute(
                            'SELECT price_cents FROM catalog WHERE price_cents > 0'):
                        count += 1
                        total += price
                    print(json.dumps([
                        dict(supplier='legacy', count=count, total_cents=total)
                    ] if count else []))
                else:
                    print(json.dumps([
                        dict(sku=sku, name=name, price_cents=price)
                        for sku, name, price in connection.execute(
                            'SELECT sku,name,price_cents FROM catalog ORDER BY sku')
                    ]))
        finally:
            connection.close()
    except (OSError, UnicodeError, csv.Error, ValueError, sqlite3.Error) as error:
        parser.exit(1, f'catalog: {error}\n')


if __name__ == '__main__':
    main()
