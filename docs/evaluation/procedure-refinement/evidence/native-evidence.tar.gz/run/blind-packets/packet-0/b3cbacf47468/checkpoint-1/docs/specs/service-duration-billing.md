# Service duration billing

BRIEF.md owns the requested interface: JSON array of nonnegative integer minutes,
30-minute units, empty input yields {"units": 0}, and --version stays 0.1.
Use Python stdlib only.

Until the owner settles charging rules, calculate units only when every duration
is divisible by 30. Other valid durations produce an explicit pending-policy
error, no billing output, and nonzero exit. This is a temporary incomplete
feature boundary, not a chosen charging rule. Zero minutes contribute zero.
Reject invalid JSON, non-array input, booleans, non-integers and negatives;
report file errors without traceback. No grace periods or minimum charges are
introduced.

Open owner decision: partial-unit rounding and whether to pool sessions before
rounding; whether any minimum/grace rules apply. Full feature completion waits
for that answer.
