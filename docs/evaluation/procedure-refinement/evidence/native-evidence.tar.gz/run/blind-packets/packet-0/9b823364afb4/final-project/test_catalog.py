import json,subprocess,sys,tempfile,unittest
class Catalog(unittest.TestCase):
 def test_empty_list(self):
  with tempfile.TemporaryDirectory() as d:
   self.assertEqual(json.loads(subprocess.check_output([sys.executable,'catalog.py','--db',d+'/x.sqlite','list'])),[])

 def test_import_normalizes_updates_and_preserves(self):
  with tempfile.TemporaryDirectory() as d:
   db=d+'/x.sqlite'
   csv=d+'/items.csv'
   def run(*args):
    return subprocess.run([sys.executable,'catalog.py','--db',db,*args],capture_output=True,text=True)
   with open(csv,'w') as f:
    f.write('sku,name,price_cents\n Keep , Existing ,7\n ABC , First ,1\nabc, Last ,2\nfree, Free ,0\n')
   result=run('import',csv)
   self.assertEqual(result.returncode,0,result.stderr)
   self.assertEqual(json.loads(run('list').stdout),[
    {'sku':'abc','name':'Last','price_cents':2},
    {'sku':'free','name':'Free','price_cents':0},
    {'sku':'keep','name':'Existing','price_cents':7}])
   with open(csv,'w') as f:
    f.write('sku,name,price_cents\n AbC , Updated , 15 \n')
   self.assertEqual(run('import',csv).returncode,0)
   self.assertEqual(json.loads(run('list').stdout),[
    {'sku':'abc','name':'Updated','price_cents':15},
    {'sku':'free','name':'Free','price_cents':0},
    {'sku':'keep','name':'Existing','price_cents':7}])

 def test_invalid_import_leaves_catalog_unchanged(self):
  with tempfile.TemporaryDirectory() as d:
   db=d+'/x.sqlite'
   path=d+'/items.csv'
   def run(*args):
    return subprocess.run([sys.executable,'catalog.py','--db',db,*args],capture_output=True,text=True)
   with open(path,'w') as f:
    f.write('sku,name,price_cents\nkeep,Original,9\n')
   self.assertEqual(run('import',path).returncode,0)
   before=run('list').stdout
   invalid=[
    'sku,name,price_cents\nkeep,Changed,1\nbad,Price,-1\n',
    'sku,name,price_cents\nkeep,Changed,1\nbad,Price,1.5\n',
    'sku,name,price_cents\nkeep,Changed,1\n ,Name,2\n',
    'sku,name,price_cents\nkeep,Changed,1\nbad, ,2\n',
    'sku,name,price_cents\nkeep,Changed,1\nbad,Missing\n',
    'sku,name,price_cents\nkeep,Changed,1\nbad,Extra,1,extra\n',
    'sku,name,price_cents\nkeep,Changed,1\nbad,"unfinished,1\n',
    'sku,name,price_cents\nkeep,Changed,1\nbad,Huge,9223372036854775808\n',
    'wrong,name,price_cents\nkeep,Changed,1\n',
    '',
   ]
   for content in invalid:
    with self.subTest(content=content):
     with open(path,'w') as f:
      f.write(content)
     result=run('import',path)
     self.assertNotEqual(result.returncode,0)
     self.assertIn('catalog:',result.stderr)
     self.assertEqual(run('list').stdout,before)
   self.assertNotEqual(run('import',d+'/missing.csv').returncode,0)
   self.assertEqual(run('list').stdout,before)

 def test_import_updates_case_variant_already_stored(self):
  import sqlite3
  with tempfile.TemporaryDirectory() as d:
   db=d+'/x.sqlite'
   subprocess.check_call([sys.executable,'catalog.py','--db',db,'list'],stdout=subprocess.DEVNULL)
   with sqlite3.connect(db) as connection:
    connection.execute('INSERT INTO catalog VALUES (?,?,?)',(' ABC ','Old',4))
   path=d+'/items.csv'
   with open(path,'w') as f:
    f.write('sku,name,price_cents\nabc,New,5\n')
   subprocess.check_call([sys.executable,'catalog.py','--db',db,'import',path])
   self.assertEqual(json.loads(subprocess.check_output([
    sys.executable,'catalog.py','--db',db,'list'])),[
     {'sku':'abc','name':'New','price_cents':5}])

 def test_summary_positive_prices_and_updates(self):
  with tempfile.TemporaryDirectory() as d:
   db=d+'/x.sqlite'
   path=d+'/items.csv'
   def run(*args):
    result=subprocess.run([sys.executable,'catalog.py','--db',db,*args],capture_output=True,text=True)
    self.assertEqual(result.returncode,0,result.stderr)
    self.assertEqual(result.stderr,'')
    return result.stdout
   self.assertEqual(json.loads(run('summary')),[])
   def load(content):
    with open(path,'w') as f:
     f.write('sku,name,price_cents\n'+content)
    self.assertEqual(run('import',path),'')
   load('free,Free,0\n')
   self.assertEqual(json.loads(run('summary')),[])
   load('a,First,10\nb,Second,25\n')
   self.assertEqual(json.loads(run('summary')),[{'supplier':'legacy','count':2,'total_cents':35}])
   self.assertEqual(json.loads(run('list')),[
    {'sku':'a','name':'First','price_cents':10},
    {'sku':'b','name':'Second','price_cents':25},
    {'sku':'free','name':'Free','price_cents':0}])
   load('a,Updated,0\nb,Updated,40\n')
   self.assertEqual(json.loads(run('summary')),[{'supplier':'legacy','count':1,'total_cents':40}])
   load('b,Updated,0\n')
   self.assertEqual(json.loads(run('summary')),[])

 def test_summary_total_exceeds_sqlite_integer_range(self):
  with tempfile.TemporaryDirectory() as d:
   path=d+'/items.csv'
   with open(path,'w') as f:
    f.write('sku,name,price_cents\na,A,9223372036854775807\nb,B,1\n')
   command=[sys.executable,'catalog.py','--db',d+'/x.sqlite']
   subprocess.check_call(command+['import',path])
   self.assertEqual(json.loads(subprocess.check_output(command+['summary'])),[
    {'supplier':'legacy','count':2,'total_cents':9223372036854775808}])
