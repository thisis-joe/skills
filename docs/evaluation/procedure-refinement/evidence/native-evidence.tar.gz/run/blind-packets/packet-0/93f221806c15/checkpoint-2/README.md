Python standard library. Public CLI: `python3 app.py INPUT.json`.
Version: `python3 app.py --version` (0.1).
Checks: `python3 -m unittest discover -v`.

Input is a JSON array of nonnegative integer session durations in minutes.
Each session rounds upward to a whole 30-minute unit, then units are summed.
Zero-duration sessions contribute zero; an empty array also produces zero.
For example, `[15, 15]` produces `{"units": 2}`, and `[0, 1, 30, 31]`
produces `{"units": 4}`. Invalid input fails with a CLI diagnostic.
See docs/specs/service-duration-billing.md for the confirmed policy.
