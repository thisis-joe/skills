I recommend **`coco-clarify`**, at the requirements stage.

[BRIEF.md](BRIEF.md) leaves channel, timing, opt-out rules and first-release scope undecided. The existing CLI only lists catalog items; it provides no renewal behavior to extend yet. Clarification fits because those choices determine what should be specified and built.

Following the [local procedure](.guide/coco-clarify/SKILL.md), expect a focused discussion producing agreed behavior, scope, exclusions, acceptance checks and explicitly open decisions. `coco-spec` would follow once those decisions are usable, with a separate manual handoff.

Copy this when you want to begin:

```text
$coco-clarify Help me define customer renewal reminders using BRIEF.md and the existing CLI context. Ask focused questions with recommended answers and concrete tradeoffs. Resolve the intended user, meaning of renewal, reminder channel, timing, opt-out behavior and first-release scope. Return agreed behavior, exclusions, acceptance checks and remaining decisions in chat. Keep Python stdlib and local-file constraints. Do not modify files, implement, commit or publish. Keep skill transitions manual and stop before switching skills.
```

This is a recommendation only; I haven’t started that workflow or changed anything.