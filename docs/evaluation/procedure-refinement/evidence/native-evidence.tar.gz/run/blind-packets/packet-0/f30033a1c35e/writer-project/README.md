# Purchasing catalog
Python standard library only. Public entry: `python3 catalog.py --db PATH list`.
List returns a JSON array of {sku,name,price_cents}. Existing SQLite table is
catalog(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL).
CSV has header sku,name,price_cents. SKU/name must be nonempty; prices are
nonnegative integer cents. Business choices are not established in this README.
Use the existing public CLI entry for added commands. Local regression command:
`python3 -m unittest discover -v`. Work locally; preserve unrelated files.

Import with `python3 catalog.py --db PATH import CSV_PATH`. Imports trim fields,
lowercase SKU keys, keep the last duplicate row and update existing keys. Invalid
files fail without changing catalog rows. Successful imports exit 0 with no output.
The summary command is deferred; see [specification](docs/spec.md) and the
[execution checkpoint](docs/plan.md).
