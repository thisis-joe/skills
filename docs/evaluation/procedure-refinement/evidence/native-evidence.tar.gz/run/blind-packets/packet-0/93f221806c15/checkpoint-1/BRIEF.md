# Service duration billing

Implement app.py INPUT.json for a service desk.
Input is an array of nonnegative integer session durations in minutes. Output is
{"units": N}, the total billable units using 30-minute units. An empty input has
zero units. Detailed charging business rules are not settled. Keep
the existing --version behavior and use only the standard library.
