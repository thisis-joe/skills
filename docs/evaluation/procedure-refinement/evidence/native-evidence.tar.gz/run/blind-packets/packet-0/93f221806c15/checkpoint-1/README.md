Python standard library. Public CLI: python3 app.py INPUT.json. Existing version: python3 app.py --version. Checks: python3 -m unittest discover -v. Business edge choices remain with the owner.

Implemented subset: empty arrays and positive sessions divisible by 30.
For example, `[30, 60]` produces `{"units": 3}`. Invalid inputs fail with a
CLI diagnostic. Zero-duration and partial-unit sessions currently fail with
“billing policy needed” and produce no bill, pending owner charging decisions.
See docs/specs/service-duration-billing.md for the unresolved scope.
