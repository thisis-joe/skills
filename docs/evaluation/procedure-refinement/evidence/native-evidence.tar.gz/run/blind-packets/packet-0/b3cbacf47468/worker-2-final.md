Implemented and committed as `489d312` on `feat/service-duration-billing`.

Each session rounds upward independently; zero stays zero, then units are summed. This matches your rule with no material departure.

All five tests and real CLI checks passed. Inspection was same-agent, not independent review. Unrelated work was preserved; nothing pushed.