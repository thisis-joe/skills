import subprocess,sys,unittest
class Version(unittest.TestCase):
 def test_version(self):self.assertEqual(subprocess.check_output([sys.executable,'app.py','--version'],text=True).strip(),'0.1')
