# Service duration billing

BRIEF.md and the owner's clarification define the interface: JSON array of
nonnegative integer minutes, 30-minute units, empty input yields {"units": 0},
and --version stays 0.1. Use Python stdlib only.

Round each session separately upward to whole 30-minute units, then sum.
Zero stays zero. Examples: [10, 20] yields 2; [0, 30, 31] yields 3.
Use integer arithmetic so large durations retain exact precision.
Reject invalid JSON, non-array input, booleans, non-integers and negatives;
report file errors without traceback. No additional charging rules apply.

Acceptance: exercise the public CLI for empty, zero, exact, partial, mixed and
large durations; preserve validation and the existing version test.
