I’ll read the project context and any local `.guide` procedures, then recommend a next step and a prompt you can use. I’ll keep everything read-only.


The brief leaves the main renewal-reminder decisions open: channel, timing, opt-out rules, and first-release scope. The local routing guide points to `coco-clarify`. I’m using those procedures to ground the recommendation, without starting the clarification workflow.


You’re at the **requirements stage**. I recommend **`coco-clarify`** to decide what customer renewal reminders should do.

[BRIEF.md](BRIEF.md) leaves channel, timing, opt-out rules and first-release scope undecided. The existing CLI only lists catalog items, so those decisions need agreement before implementation. This matches the [local routing procedure](.guide/_coco-shared/routing.md).

Expect a concrete behavior agreement, explicit open decisions, first-release boundaries and observable acceptance checks.

Here’s a copyable starting point:

```text
$coco-clarify Help me settle the customer renewal reminders described in
BRIEF.md. Ask dependency-ordered questions with concrete alternatives and
reasoned recommendations. Cover channel, timing, opt-out behavior,
required customer/renewal data, and first-release scope. Return agreed
behavior, open decisions, exclusions, and acceptance checks in chat.
Use local read-only project context only. Do not modify files, implement,
commit, delegate, or use external services. Keep skill transitions manual.
```

This is a recommendation only; I haven’t started that workflow. After clarification, you can choose **run the next skill once** or **automatically continue basic steps for an agreed spec**. Manual remains the default.

No files were changed or commits created.