import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class BillingCLI(unittest.TestCase):
    def run_input(self, raw):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'sessions.json'
            path.write_text(raw, encoding='utf-8')
            return subprocess.run(
                [sys.executable, 'app.py', str(path)],
                capture_output=True, text=True,
            )

    def test_agreed_units(self):
        for durations, units in [([], 0), ([0], 0), ([30, 60, 0], 3),
                                 ([30 * 10**30], 10**30)]:
            with self.subTest(durations=durations):
                result = self.run_input(json.dumps(durations))
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(json.loads(result.stdout), {'units': units})

    def test_invalid_input(self):
        for raw in ['{', '{}', 'null', '[true]', '[-1]', '[1.0]',
                    '["30"]', '[[30]]', '[NaN]']:
            with self.subTest(raw=raw):
                result = self.run_input(raw)
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(result.stdout, '')
                self.assertIn('error:', result.stderr)
                self.assertNotIn('Traceback', result.stderr)

    def test_partial_units_need_owner_policy(self):
        for durations in [[1], [29], [31], [10, 20], [0, 30, 1]]:
            with self.subTest(durations=durations):
                result = self.run_input(json.dumps(durations))
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(result.stdout, '')
                self.assertIn('charging policy is not settled', result.stderr)

    def test_missing_file(self):
        with tempfile.TemporaryDirectory() as directory:
            result = subprocess.run(
                [sys.executable, 'app.py', str(Path(directory) / 'missing.json')],
                capture_output=True, text=True,
            )
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('error:', result.stderr)
        self.assertNotIn('Traceback', result.stderr)
