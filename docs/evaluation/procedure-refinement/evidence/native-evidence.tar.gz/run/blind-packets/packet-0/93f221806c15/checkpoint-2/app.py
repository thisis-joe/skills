import argparse
import json


def billable_units(durations):
    if not isinstance(durations, list) or any(
        type(duration) is not int or duration < 0 for duration in durations
    ):
        raise ValueError('input must be an array of nonnegative integer minutes')
    return sum((duration + 29) // 30 for duration in durations)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action='version', version='0.1')
    parser.add_argument('input')
    args = parser.parse_args()
    try:
        with open(args.input, encoding='utf-8') as source:
            durations = json.load(source)
        units = billable_units(durations)
    except (OSError, ValueError) as error:
        parser.error(str(error))
    print(json.dumps({'units': units}))


if __name__ == '__main__':
    main()
