# Purchasing catalog
Python standard library only. Public entry: `python3 catalog.py --db PATH list`.
List returns a JSON array of {sku,name,price_cents}. Existing SQLite table is
catalog(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL).
CSV has header sku,name,price_cents. SKU/name must be nonempty; prices are
nonnegative integer cents. Business choices are not established in this README.
Use the existing public CLI entry for added commands. Local regression command:
`python3 -m unittest discover -v`. Work locally; preserve unrelated files.

Import: `python3 catalog.py --db PATH import ITEMS.csv`. Successful imports exit
0 with no output; rejected imports exit nonzero with an error on stderr.
Import trims SKU/name, lowercases SKU, takes the last duplicate, and updates
stored matches while retaining unrelated rows. Zero-price rows remain listed.
The entire CSV is validated before any catalog changes. Prices must fit SQLite's
signed 64-bit integer range. See [spec](docs/spec.md) for business decisions and
[execution plan](docs/plan.md) for the implementation and verification receipts.

Summary: `python3 catalog.py --db PATH summary` returns a JSON array with one
`{"supplier": "legacy", "count": N, "total_cents": T}` entry for positive-price
items, or `[]` when none qualify. Zero-price items remain in list but contribute
to neither summary aggregate. Totals use exact Python integers.
