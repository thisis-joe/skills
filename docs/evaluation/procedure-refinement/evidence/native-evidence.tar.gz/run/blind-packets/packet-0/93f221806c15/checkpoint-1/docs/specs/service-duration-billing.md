# Service duration billing

Source: BRIEF.md. Preserve --version 0.1; use only Python standard library.
Input: JSON array of nonnegative integers (booleans are not durations).
Output: {"units": N}; empty array produces zero.

Unblocked slice: positive exact multiples of 30 produce their total unit count.
Pending owner decisions: partial-unit rounding, per-session versus aggregate
rounding, and zero-duration minimum charges. Until settled, any zero or partial
session fails explicitly without emitting a bill. This is a temporary guard,
not a settled charging rule. No configurable policy or default is invented.
Malformed JSON, unreadable input, or invalid shapes fail with a CLI diagnostic.
Acceptance: real CLI fixtures and unittest discovery, including existing version.
