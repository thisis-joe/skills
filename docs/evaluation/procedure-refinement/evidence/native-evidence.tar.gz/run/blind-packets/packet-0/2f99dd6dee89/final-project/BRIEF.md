# Unsettled feature

We want customer renewal reminders. Channel, timing, opt-out rules and first-release scope have not been decided. No implementation has started.
