I’ll apply your rule: round each session up to a 30-minute unit, keep zero at zero, then sum. I’ll update the tests and docs, exercise the CLI, and commit locally.


The CLI now returns two units for `[10, 20]` and three for `[0, 30, 31]`, matching your rule. All five tests pass, including validation and `--version`. Same-agent inspection found no further issues; I’m committing the change locally.


Implemented and committed as `489d312` on `feat/service-duration-billing`.

Each session rounds upward independently; zero stays zero, then units are summed. This matches your rule with no material departure.

All five tests and real CLI checks passed. Inspection was same-agent, not independent review. Unrelated work was preserved; nothing pushed.