Committed `a8b40ea` on `feat/service-duration-billing`. Nothing pushed; unrelated `personal-notes.txt` preserved.

Expected: full billing support. Actual: validation, empty input, and positive exact 30-minute sessions implemented. Partial and zero-duration sessions temporarily fail explicitly because charging rules remain unresolved.

All five unittest tests and real CLI checks passed. `--version` remains `0.1`. Inspection was same-agent, not independent review.

Please decide:

1. Should partial units round up, round down, or follow another rule?
2. Apply rounding per session or after summing durations? For example, rounding up makes `[15,15]` either two units or one.
3. Should a zero-minute session cost zero units or incur a minimum charge?

The full feature remains incomplete pending these decisions.