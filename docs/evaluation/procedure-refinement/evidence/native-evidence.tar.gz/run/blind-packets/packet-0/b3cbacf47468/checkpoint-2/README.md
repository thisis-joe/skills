Python standard library. Public CLI: python3 app.py INPUT.json.
Existing version: python3 app.py --version.
Checks: python3 -m unittest discover -v.

INPUT.json contains an array of nonnegative integer session durations in minutes.
Each session is rounded upward to whole 30-minute units, then the units are
summed. Zero stays zero; empty input returns {"units": 0}.
For example, [10, 20] returns {"units": 2}, and [0, 30, 31] returns {"units": 3}.

Invalid input and unreadable files exit nonzero with an error on stderr.
See docs/specs/service-duration-billing.md and docs/plans/service-duration-billing.md.
