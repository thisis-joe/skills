Implemented and committed as `fd57eb8` on `feat/service-duration-billing`.

Each session rounds upward separately; zero stays zero. Actual behavior matches your rules with no material departure.

All five unittest tests and real CLI checks passed; `--version` remains `0.1`. Same-agent inspection completed, not independent review. No unresolved decisions, nothing pushed, and unrelated work preserved.