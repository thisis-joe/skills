import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class BillingCLI(unittest.TestCase):
    def run_input(self, raw):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'input.json'
            path.write_text(raw, encoding='utf-8')
            return subprocess.run([sys.executable, 'app.py', str(path)],
                                  text=True, capture_output=True)

    def test_settled_cases(self):
        for durations, units in [([], 0), ([30], 1), ([30, 60, 90], 6)]:
            with self.subTest(durations=durations):
                result = self.run_input(json.dumps(durations))
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(json.loads(result.stdout), {'units': units})

    def test_rounds_each_session_up_and_keeps_zero_free(self):
        cases = [([0], 0), ([0, 0], 0), ([1], 1), ([29], 1),
                 ([31], 2), ([59], 2), ([61], 3), ([15, 15], 2),
                 ([0, 1, 30, 31], 4), ([30 * 10**30 + 1], 10**30 + 1)]
        for durations, units in cases:
            with self.subTest(durations=durations):
                result = self.run_input(json.dumps(durations))
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(json.loads(result.stdout), {'units': units})
                self.assertEqual(result.stderr, '')

    def test_invalid_input(self):
        for raw in ['{', '{}', 'null', '[true]', '[-1]', '[1.0]', '["30"]']:
            with self.subTest(raw=raw):
                result = self.run_input(raw)
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(result.stdout, '')
                self.assertIn('error:', result.stderr)
                self.assertNotIn('Traceback', result.stderr)

    def test_missing_file(self):
        with tempfile.TemporaryDirectory() as directory:
            result = subprocess.run(
                [sys.executable, 'app.py', str(Path(directory) / 'missing.json')],
                text=True, capture_output=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(result.stdout, '')
        self.assertIn('error:', result.stderr)
