import argparse
import csv
import json
import re
import sqlite3


def read_import(path):
    rows = {}
    with open(path, newline='', encoding='utf-8') as source:
        reader = csv.reader(source, strict=True)
        if next(reader, None) != ['sku', 'name', 'price_cents']:
            raise ValueError('expected CSV header sku,name,price_cents')
        for fields in reader:
            if len(fields) != 3:
                raise ValueError(f'line {reader.line_num}: expected three fields')
            sku, name, price = (field.strip() for field in fields)
            if not sku or not name or not re.fullmatch(r'[0-9]+', price):
                raise ValueError(f'line {reader.line_num}: invalid SKU, name or price')
            cents = int(price)
            if cents > 9223372036854775807:
                raise ValueError(f'line {reader.line_num}: price exceeds SQLite integer range')
            rows[sku.lower()] = (sku.lower(), name, cents)
    return list(rows.values())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    commands.add_parser('import').add_argument('path')
    args = parser.parse_args()
    try:
        # Validate the whole file before opening or changing the database.
        rows = read_import(args.path) if args.command == 'import' else None
        connection = sqlite3.connect(args.db)
        try:
            with connection:
                connection.execute('CREATE TABLE IF NOT EXISTS catalog '
                                   '(sku TEXT PRIMARY KEY, name TEXT NOT NULL, '
                                   'price_cents INTEGER NOT NULL)')
                if rows is not None:
                    connection.executemany(
                        'INSERT INTO catalog(sku,name,price_cents) VALUES (?,?,?) '
                        'ON CONFLICT(sku) DO UPDATE SET name=excluded.name, '
                        'price_cents=excluded.price_cents', rows)
                else:
                    print(json.dumps([
                        dict(sku=sku, name=name, price_cents=price)
                        for sku, name, price in connection.execute(
                            'SELECT sku,name,price_cents FROM catalog ORDER BY sku')]))
        finally:
            connection.close()
    except (OSError, UnicodeError, ValueError, csv.Error, sqlite3.Error) as error:
        parser.exit(1, f'catalog: {error}\n')


if __name__ == '__main__':
    main()
