Implemented and committed on `feat/catalog-import-list`.

- `19ce591`: summary implementation, regression test and docs.
- `1b999c6`: completion receipt.

Summary excludes zero-price rows, returns `[]` when none qualify, and preserves import/list behavior. This follows the recorded superseding owner decision; no material departure or unresolved business choice remains.

All 4 unittests and disposable real-CLI checks passed. Same-agent inspection completed; no independent review was performed.

Existing database preserved; `personal-notes.txt` remains unread and untouched. Nothing pushed.