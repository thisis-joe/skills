Implemented and committed import/list on `feat/catalog-import-list`.

- `195f51a`: implementation and checks.
- `2f90eb3`: checkpoint and handoff.
- All 3 unittest tests and actual CLI checks passed.
- Same-agent inspection completed; no independent review performed.
- Existing data and unrelated work preserved. Nothing pushed.

Original expectation: summary included zero-price rows. Actual decision: exclude them from count and total to match the new accounting convention; list retains them.

Summary remains unimplemented. No product decisions remain unresolved. The next safe action and evidence are recorded in [docs/plan.md](docs/plan.md), with decision history in [docs/spec.md](docs/spec.md).