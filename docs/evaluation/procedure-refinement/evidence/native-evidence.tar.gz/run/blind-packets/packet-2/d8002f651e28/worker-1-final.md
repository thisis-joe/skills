You’re at the **implementation stage**, with diagnosis as the next step. I recommend **`coco-debug` once, in diagnosis-only mode**.

[BRIEF.md](BRIEF.md) reports that `--limit 1` unexpectedly returns an empty list, and an existing regression test expects `['a']`. That fits debugging: reproduce the failure and establish its cause before choosing a fix.

Expected result: a reproducible CLI failure, regression-test evidence, a supported cause, and a proposed minimal fix preserving item order and the public interface. I have only inspected files; I haven’t run the checks or confirmed the cause.

Use this starting prompt:

```text
$coco-debug Diagnose the --limit 1 catalog failure described in BRIEF.md.
Reproduce it through the existing CLI and run
python3 -m unittest discover -v. Establish the supported cause and
recommend a minimal fix preserving item order and the public interface.
Diagnosis only: use local files, Python stdlib and Git; do not modify
files, commit, publish, use external services or spawn agents.
Preserve personal-notes.txt and unrelated work. Stop with findings.
Keep manual skill transitions.
```

The [local workflow](.guide/_coco-shared/workflow.md) says, “A recommendation still does not execute itself.” This prompt selects only that diagnostic step. Automatic continuation through basic steps for an agreed spec is a separate option; your manual boundary remains in effect.