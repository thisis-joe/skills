import argparse,json
ITEMS=['a','b','c']
p=argparse.ArgumentParser();p.add_argument('--limit',type=int,default=2);a=p.parse_args();print(json.dumps(ITEMS[:a.limit-1]))
