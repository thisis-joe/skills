import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class StandingsCLI(unittest.TestCase):
    def invoke(self, entries):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / 'input.json'
            source.write_text(json.dumps(entries), encoding='utf-8')
            return subprocess.run(
                [sys.executable, 'app.py', str(source)],
                capture_output=True, text=True,
            )

    def test_agreed_standings(self):
        cases = [
            ([], []),
            ([{'name': 'Solo', 'score': 9}], [{'name': 'Solo', 'rank': 1}]),
            ([{'name': 'Low', 'score': -4}, {'name': 'High', 'score': 12},
              {'name': 'Zero', 'score': 0}],
             [{'name': 'High', 'rank': 1}, {'name': 'Zero', 'rank': 2},
              {'name': 'Low', 'rank': 3}]),
        ]
        for entries, expected in cases:
            with self.subTest(entries=entries):
                result = self.invoke(entries)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(json.loads(result.stdout), expected)

    def test_competition_ranks_and_name_order(self):
        cases = [
            ([{'name': 'Zoe', 'score': 9}, {'name': 'Low', 'score': 8},
              {'name': 'Ada', 'score': 9}, {'name': 'Bo', 'score': 8},
              {'name': 'Last', 'score': -1}],
             [{'name': 'Ada', 'rank': 1}, {'name': 'Zoe', 'rank': 1},
              {'name': 'Bo', 'rank': 3}, {'name': 'Low', 'rank': 3},
              {'name': 'Last', 'rank': 5}]),
            ([{'name': 'b', 'score': 0}, {'name': 'aa', 'score': 0},
              {'name': 'A', 'score': 0}, {'name': 'a', 'score': 0}],
             [{'name': 'A', 'rank': 1}, {'name': 'a', 'rank': 1},
              {'name': 'aa', 'rank': 1}, {'name': 'b', 'rank': 1}]),
        ]
        for entries, expected in cases:
            with self.subTest(entries=entries):
                result = self.invoke(entries)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(json.loads(result.stdout), expected)
