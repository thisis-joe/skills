import json,subprocess,sys,tempfile,unittest
class Catalog(unittest.TestCase):
 def test_empty_list(self):
  with tempfile.TemporaryDirectory() as d:
   self.assertEqual(json.loads(subprocess.check_output([sys.executable,'catalog.py','--db',d+'/x.sqlite','list'])),[])


class ImportCatalog(unittest.TestCase):
 def setUp(self):
  self.temp = tempfile.TemporaryDirectory()
  self.addCleanup(self.temp.cleanup)
  self.db = self.temp.name + '/catalog.sqlite'
  self.csv = self.temp.name + '/items.csv'
 def cli(self, *args):
  return subprocess.run([sys.executable, 'catalog.py', '--db', self.db, *args], text=True, capture_output=True)
 def load(self, content):
  with open(self.csv, 'w') as f:
   f.write(content)
  return self.cli('import', self.csv)
 def items(self):
  result = self.cli('list')
  self.assertEqual(result.returncode, 0, result.stderr)
  return json.loads(result.stdout)
 def test_import_normalizes_skips_and_retains_zero(self):
  result = self.load('sku,name,price_cents\n B , Book ,125\nZERO,Free,0\nbad,Wrong,-1\n,Empty,20\nx,Missing\ny,Extra,2,field\nz,Decimal,1.5\n')
  self.assertEqual(result.returncode, 0, result.stderr)
  self.assertIn('row 4', result.stderr)
  self.assertEqual(result.stderr.count('Skipping'), 5)
  self.assertEqual(self.items(), [dict(sku='b',name='Book',price_cents=125), dict(sku='zero',name='Free',price_cents=0)])
 def test_duplicate_file_is_atomic_even_identical(self):
  for second in ('A,First,1', ' a ,Other,2'):
   with self.subTest(second=second):
    result = self.load('sku,name,price_cents\nfresh,New,3\nA,First,1\n' + second + '\n')
    self.assertNotEqual(result.returncode, 0)
    self.assertIn('Duplicate', result.stderr)
    self.assertEqual(self.items(), [])
 def test_stored_collision_preserves_data(self):
  import sqlite3
  self.items()
  with sqlite3.connect(self.db) as c:
   c.execute('INSERT INTO catalog VALUES (?, ?, ?)', (' Old ', 'Existing', 9))
  result = self.load('sku,name,price_cents\nfresh,New,3\nOLD,Replacement,2\n')
  self.assertNotEqual(result.returncode, 0)
  self.assertIn('Duplicate', result.stderr)
  self.assertEqual(self.items(), [dict(sku=' Old ',name='Existing',price_cents=9)])
 def test_invalid_header_and_missing_file_fail(self):
  self.assertIn('Expected CSV header', self.load('sku,name\na,Name\n').stderr)
  self.assertIn('No such file', self.cli('import', self.csv + '.missing').stderr)
  self.assertEqual(self.items(), [])
 def test_duplicate_key_on_malformed_row_rejects_file(self):
  result = self.load('sku,name,price_cents\na,Valid,2\n A ,Bad,nope\n')
  self.assertNotEqual(result.returncode, 0)
  self.assertIn('Duplicate', result.stderr)
  self.assertEqual(self.items(), [])

 def test_summary_positive_prices_only(self):
  for content, expected in (
   ('', []),
   ('zero,Free,0\n', []),
   ('a,Apple,120\nb,Book,35\nzero,Free,0\n',
    [dict(supplier='legacy', count=2, total_cents=155)]),
   ('a,Large,9223372036854775807\nb,More,1\n',
    [dict(supplier='legacy', count=2, total_cents=9223372036854775808)]),
  ):
   with self.subTest(content=content), tempfile.TemporaryDirectory() as d:
    self.db = d + '/catalog.sqlite'
    self.csv = d + '/items.csv'
    imported = self.load('sku,name,price_cents\n' + content)
    self.assertEqual(imported.returncode, 0, imported.stderr)
    before = self.items()
    result = self.cli('summary')
    self.assertEqual(result.returncode, 0, result.stderr)
    self.assertEqual(result.stderr, '')
    self.assertEqual(json.loads(result.stdout), expected)
    self.assertEqual(self.items(), before)
