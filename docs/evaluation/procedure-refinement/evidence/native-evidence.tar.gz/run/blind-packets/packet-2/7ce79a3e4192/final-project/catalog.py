import argparse
import csv
import json
import re
import sqlite3
import sys


def import_items(connection, path):
    stored = {sku.strip().lower() for (sku,) in connection.execute('SELECT sku FROM catalog')}
    seen = set()
    items = []
    collision = False
    with open(path, newline='', encoding='utf-8') as source:
        reader = csv.reader(source, strict=True)
        if next(reader, None) != ['sku', 'name', 'price_cents']:
            raise ValueError('expected CSV header sku,name,price_cents')
        while True:
            row_number = reader.line_num + 1
            try:
                row = next(reader)
            except StopIteration:
                break
            except csv.Error as error:
                print(f'row {row_number}: skipped: {error}', file=sys.stderr)
                continue
            sku = row[0].strip().lower() if row else ''
            if sku:
                if sku in seen or sku in stored:
                    print(f'row {row_number}: duplicate SKU {sku!r}; file rejected', file=sys.stderr)
                    collision = True
                seen.add(sku)
            if (len(row) != 3 or not sku or not row[1].strip()
                    or re.fullmatch(r'[0-9]+', row[2].strip()) is None):
                print(f'row {row_number}: skipped: expected nonempty SKU/name and nonnegative integer cents', file=sys.stderr)
                continue
            try:
                price = int(row[2].strip())
                if price > 9223372036854775807:
                    raise ValueError('price exceeds SQLite integer range')
            except ValueError:
                print(f'row {row_number}: skipped: price exceeds SQLite integer range', file=sys.stderr)
                continue
            items.append((sku, row[1].strip(), price))
    if collision:
        raise ValueError('duplicate SKU; no rows imported')
    with connection:
        connection.executemany('INSERT INTO catalog VALUES (?, ?, ?)', items)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    commands.add_parser('summary')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    args = parser.parse_args()
    connection = sqlite3.connect(args.db)
    try:
        connection.execute('CREATE TABLE IF NOT EXISTS catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
        if args.command == 'import':
            import_items(connection, args.path)
        elif args.command == 'summary':
            count = 0
            total = 0
            for (price,) in connection.execute('SELECT price_cents FROM catalog WHERE price_cents > 0'):
                count += 1
                total += price
            print(json.dumps([dict(supplier='legacy', count=count, total_cents=total)] if count else []))
        else:
            print(json.dumps([dict(sku=k, name=n, price_cents=v) for k, n, v in connection.execute('SELECT sku,name,price_cents FROM catalog ORDER BY sku')]))
    except (OSError, UnicodeError, csv.Error, ValueError, sqlite3.Error) as error:
        print(f'import failed: {error}', file=sys.stderr)
        return 1
    finally:
        connection.close()
    return 0


if __name__ == '__main__':
    sys.exit(main())
