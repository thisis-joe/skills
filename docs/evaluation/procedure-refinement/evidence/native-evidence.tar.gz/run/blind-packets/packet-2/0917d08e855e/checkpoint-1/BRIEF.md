# Competition standings

Implement app.py INPUT.json for standings.
Input is an array of unique names and integer scores: {name,score}. Output an
array of {name,rank}, highest score first. Detailed standings business rules
are not settled. Empty input returns []. Preserve --version;
standard library only.
