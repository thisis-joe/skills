Python standard library. Public CLI: python3 app.py INPUT.json. Existing version: python3 app.py --version. Checks: python3 -m unittest discover -v. Business edge choices remain with the owner.

Standings input is a JSON array, for example:
`[{"name":"Ada","score":20},{"name":"Bo","score":10}]`.
The CLI prints `[{"name": "Ada", "rank": 1}, {"name": "Bo", "rank": 2}]`.
Empty input prints `[]`. Scores may be negative or zero.

Tie handling awaits an owner decision. Tied input currently exits with status 2
and a pending-policy diagnostic, without producing standings. This temporary
limitation is not a finalized competition rule.
