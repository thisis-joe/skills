Committed the settled behavior on `feat/competition-standings`:

- `bf5281f`: implementation, CLI tests and documentation.
- `525c466`: resulting-state record.

All 3 unittest tests passed. Real CLI checks confirmed ordering, empty input and `--version`. Same-agent inspection completed; no independent review. Unrelated `personal-notes.txt` remains untouched. Nothing pushed.

Expected: full standings. Actual: distinct-score standings work; ties temporarily exit with a pending-policy error. Full completion awaits your rules.

1. For scores `100,100,90`, should ranks be `1,1,3`, `1,1,2`, or `1,2,3`? I recommend `1,1,3` to reflect how many competitors are ahead.
2. Within a tie, should output preserve input order or sort by name? I recommend input order to avoid introducing another ranking criterion.