import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class StandingsCLI(unittest.TestCase):
    def invoke(self, entries):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / 'input.json'
            source.write_text(json.dumps(entries), encoding='utf-8')
            return subprocess.run(
                [sys.executable, 'app.py', str(source)],
                capture_output=True, text=True,
            )

    def test_agreed_standings(self):
        cases = [
            ([], []),
            ([{'name': 'Solo', 'score': 9}], [{'name': 'Solo', 'rank': 1}]),
            ([{'name': 'Low', 'score': -4}, {'name': 'High', 'score': 12},
              {'name': 'Zero', 'score': 0}],
             [{'name': 'High', 'rank': 1}, {'name': 'Zero', 'rank': 2},
              {'name': 'Low', 'rank': 3}]),
        ]
        for entries, expected in cases:
            with self.subTest(entries=entries):
                result = self.invoke(entries)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(json.loads(result.stdout), expected)

    def test_ties_await_owner_policy(self):
        result = self.invoke([{'name': 'A', 'score': 10},
                              {'name': 'B', 'score': 10}])
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(result.stdout, '')
        self.assertIn('tie policy is not settled', result.stderr)
