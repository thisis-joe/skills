Python standard library. Public CLI: python3 app.py INPUT.json. Existing version: python3 app.py --version. Checks: python3 -m unittest discover -v. Business edge choices remain with the owner.

Standings read a UTF-8 JSON array of objects with unique string `name` values
and integer `score` values. Output is a JSON array of `{name,rank}` objects,
highest score first, with ranks starting at 1. Empty input prints `[]`.
Negative scores are supported. Invalid input reports an error to stderr and exits
nonzero without standings output.

Equal scores share competition ranks: scores `9,9,8` receive ranks `1,1,3`.
Within equal scores, names sort in ascending lexicographic order (case-sensitive
Unicode code point order).
