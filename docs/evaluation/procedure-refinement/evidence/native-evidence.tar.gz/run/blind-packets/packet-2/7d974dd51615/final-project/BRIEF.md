# Unexpected failure

The catalog page CLI unexpectedly returns an empty list for --limit 1. A regression test fails; the cause has not been established. Preserve the item order and public interface.
