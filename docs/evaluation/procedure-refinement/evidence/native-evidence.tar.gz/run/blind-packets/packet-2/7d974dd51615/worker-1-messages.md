I’ll read the project context and any local `.guide` procedures, then recommend a next step with a prompt you can use. I’ll keep this read-only and won’t open global skill bodies.

The brief reports a failing `--limit 1` case with an unconfirmed cause. I’ll use the local skill-selection guidance to recommend the next procedure without starting the investigation.

I recommend **`coco-debug`, diagnosis only**. You’re at the implementation/debugging stage: [BRIEF.md](BRIEF.md) reports that `--limit 1` returns an empty list, and an existing regression test expects `["a"]`. Establishing the cause is the next useful step.

The local [routing guidance](.guide/_coco-shared/routing.md) matches unexpected failures to [coco-debug](.guide/coco-debug/SKILL.md). Expect a reproducible CLI failure, evidence supporting the cause, and a focused fix recommendation. Implementation would be a separate step.

Copy this when you want to begin:

```text
$coco-debug Diagnose the --limit 1 failure described in BRIEF.md.
Reproduce it through the existing CLI and run the existing unittest suite.
Establish the supported cause and recommend the smallest correction while
preserving item order and the public interface. Diagnosis only: do not modify
files, commit, or publish. Preserve unrelated work, including personal-notes.txt.
Keep manual skill transitions; stop with findings before implementation.
```

This recommendation does **not** select or execute the skill or enable automatic continuation. I only read local project material; no tests were run and no files were changed.