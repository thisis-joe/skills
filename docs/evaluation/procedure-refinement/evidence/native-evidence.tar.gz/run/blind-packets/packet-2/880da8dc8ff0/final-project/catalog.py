import argparse
import csv
import json
import sqlite3
import sys


def import_items(connection, path):
    rows = []
    seen = set()
    stored = {key.strip().lower() for (key,) in connection.execute('SELECT sku FROM catalog')}
    with open(path, newline='', encoding='utf-8') as source:
        reader = csv.reader(source)
        if next(reader, None) != ['sku', 'name', 'price_cents']:
            raise ValueError('Expected CSV header sku,name,price_cents')
        for row in reader:
            line = reader.line_num
            key = row[0].strip().lower() if row else ''
            if key:
                if key in seen or key in stored:
                    raise ValueError(f'Duplicate SKU {key!r} at row {line}; file rejected')
                seen.add(key)
            try:
                if len(row) != 3:
                    raise ValueError('expected three fields')
                name = row[1].strip()
                price_text = row[2].strip()
                if not key or not name:
                    raise ValueError('SKU and name must be nonempty')
                if not price_text or any(ch not in '0123456789' for ch in price_text):
                    raise ValueError('price must be nonnegative integer cents')
                price = int(price_text)
                if price > 9223372036854775807:
                    raise ValueError('price exceeds SQLite integer range')
            except ValueError as error:
                print(f'Skipping row {line}: {error}', file=sys.stderr)
                continue
            rows.append((key, name, price))
    with connection:
        connection.executemany('INSERT INTO catalog (sku,name,price_cents) VALUES (?,?,?)', rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    commands.add_parser('summary')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    args = parser.parse_args()
    connection = None
    try:
        connection = sqlite3.connect(args.db)
        connection.execute('CREATE TABLE IF NOT EXISTS catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
        if args.command == 'import':
            import_items(connection, args.path)
        elif args.command == 'summary':
            count = 0
            total = 0
            for (price,) in connection.execute('SELECT price_cents FROM catalog WHERE price_cents > 0'):
                count += 1
                total += price
            print(json.dumps([dict(supplier='legacy', count=count, total_cents=total)] if count else []))
        else:
            print(json.dumps([dict(sku=k, name=n, price_cents=v) for k, n, v in connection.execute('SELECT sku,name,price_cents FROM catalog ORDER BY sku')]))
    except (OSError, UnicodeError, csv.Error, ValueError, sqlite3.Error) as error:
        print(f'Error: {error}', file=sys.stderr)
        return 1
    finally:
        if connection is not None:
            connection.close()
    return 0


if __name__ == '__main__':
    sys.exit(main())
