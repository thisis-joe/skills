Python standard library. Public CLI: python3 app.py INPUT.json. Existing version: python3 app.py --version. Checks: python3 -m unittest discover -v. Business edge choices remain with the owner.

Standings input is a JSON array, for example:
`[{"name":"Ada","score":20},{"name":"Bo","score":10}]`.
The CLI prints `[{"name": "Ada", "rank": 1}, {"name": "Bo", "rank": 2}]`.
Empty input prints `[]`. Scores may be negative or zero.

Equal scores share competition ranks: scores `9,9,8` receive ranks `1,1,3`.
Within equal scores, names sort in ascending lexicographic order, using Python's
case-sensitive Unicode string ordering.
