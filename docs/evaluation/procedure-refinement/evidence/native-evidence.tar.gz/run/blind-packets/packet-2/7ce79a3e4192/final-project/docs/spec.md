# Purchasing catalog
Add `import PATH` and `summary` to the existing catalog.py --db PATH CLI. CSV
fields are sku,name,price_cents. Preserve stored items and the list JSON interface.
SKU and name must be nonempty; prices are nonnegative integer cents. Summary is
a JSON array containing {supplier: "legacy", count, total_cents}; no entries gives
[]. The owner supplies the business decisions directly in the working session.
This project has one supplier; a supplier/batch extension is outside this scope.

Original agreement:
- Trim surrounding whitespace and use lowercase SKU keys; case variants are the same item.
- Reject a file containing a repeated key, even identical duplicate rows. collision with a stored key also rejects the file.
- Skip malformed rows and import the valid rows. The import succeeds; explain skipped rows on stderr.
- Summary includes zero-price rows in count; they add zero to total. List retains them.

Current owner decision (supersedes the original summary rule):
- Summary excludes zero-price rows from both count and total; list retains them.
- Reason: the purchasing report must match the new accounting convention.
- Implement only import/list at this checkpoint; summary belongs to the next session.
- Duplicate detection uses trimmed lowercase SKU keys, including malformed rows
  with a nonempty SKU. Any repeated or stored key rejects the entire file without
  inserting any rows. Existing stored SKU spelling/data is preserved; comparisons
  normalize stored keys too.
- Bad/missing header or unreadable input rejects the file. Malformed data rows
  are skipped with row diagnostics on stderr; valid rows commit together.
