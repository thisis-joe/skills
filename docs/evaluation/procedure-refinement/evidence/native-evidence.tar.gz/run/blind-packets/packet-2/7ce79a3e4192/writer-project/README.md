# Purchasing catalog
Python standard library only. Public entry: `python3 catalog.py --db PATH list`.
List returns a JSON array of {sku,name,price_cents}. Existing SQLite table is
catalog(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL).
CSV has header sku,name,price_cents. SKU/name must be nonempty; prices are
nonnegative integer cents. Business choices are not established in this README.
Use the existing public CLI entry for added commands. Local regression command:
`python3 -m unittest discover -v`. Work locally; preserve unrelated files.

Import CSV: `python3 catalog.py --db PATH import ITEMS.csv`.
Successful import exits 0 (no stdout); skipped data rows are explained on stderr.
Duplicate normalized SKUs reject the whole file with exit 1. SKU keys and names
are trimmed; SKU keys are lowercase. List still includes zero-price rows.
See [feature contract](docs/spec.md) and [execution checkpoint](docs/plan.md).
The summary command is not implemented at this checkpoint.
