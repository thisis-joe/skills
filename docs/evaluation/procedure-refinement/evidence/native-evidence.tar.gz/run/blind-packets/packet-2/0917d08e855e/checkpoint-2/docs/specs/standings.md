# Standings

Source: BRIEF.md. Implement the file-based JSON CLI using only the standard
library; preserve version 0.1. Input records have unique string names and integer
scores. Output name/rank records in descending score order,
using competition ranks starting at 1: scores 9,9,8 have ranks 1,1,3. Empty input produces [].

Owner decision: equal scores share a rank; the next rank skips tied positions.
Within equal scores, names sort in ascending lexicographic order using Python
string ordering (case-sensitive Unicode code points).
Validate the stated input contract and report file/JSON/contract errors on stderr
with a nonzero exit and no partial output. No extra name restrictions or score
bounds are introduced.

Acceptance: exercise actual CLI with unsorted distinct scores, empty input,
version, invalid input and ties; run existing unittest discovery.
