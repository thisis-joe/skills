import argparse
import json


def standings(entries):
    if not isinstance(entries, list):
        raise ValueError('input must be an array')
    names = set()
    scores = set()
    for entry in entries:
        if (not isinstance(entry, dict)
                or not isinstance(entry.get('name'), str)
                or type(entry.get('score')) is not int):
            raise ValueError('each entry must contain a name string and integer score')
        if entry['name'] in names:
            raise ValueError('names must be unique')
        names.add(entry['name'])
        scores.add(entry['score'])
    if len(scores) != len(entries):
        raise ValueError('tie policy is not settled; owner decision required')
    return [
        {'name': entry['name'], 'rank': rank}
        for rank, entry in enumerate(
            sorted(entries, key=lambda entry: entry['score'], reverse=True), 1
        )
    ]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action='version', version='0.1')
    parser.add_argument('input')
    args = parser.parse_args()
    try:
        with open(args.input, encoding='utf-8') as source:
            result = standings(json.load(source))
    except (OSError, ValueError) as error:
        parser.error(str(error))
    print(json.dumps(result))


if __name__ == '__main__':
    main()
