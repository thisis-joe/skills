import argparse
import json


def standings(records):
    if not isinstance(records, list):
        raise ValueError('input must be an array')
    names = set()
    scores = set()
    for record in records:
        if not isinstance(record, dict):
            raise ValueError('each entry must be an object')
        if not isinstance(record.get('name'), str):
            raise ValueError('each name must be a string')
        if type(record.get('score')) is not int:
            raise ValueError('each score must be an integer')
        if record['name'] in names:
            raise ValueError('names must be unique')
        names.add(record['name'])
        scores.add(record['score'])
    if len(scores) != len(records):
        raise ValueError('tie policy is unresolved; tied scores are not yet supported')
    return [
        {'name': record['name'], 'rank': rank}
        for rank, record in enumerate(
            sorted(records, key=lambda record: record['score'], reverse=True), 1
        )
    ]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action='version', version='0.1')
    parser.add_argument('input')
    args = parser.parse_args()
    try:
        with open(args.input, encoding='utf-8') as source:
            records = json.load(source)
        result = standings(records)
    except (OSError, ValueError) as error:
        parser.error(str(error))
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
