import unittest,subprocess,sys,json
class Page(unittest.TestCase):
 def test_one(self): self.assertEqual(json.loads(subprocess.check_output([sys.executable,'catalog.py','--limit','1'])),['a'])
