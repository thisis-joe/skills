# Purchasing catalog
Add `import PATH` and `summary` to the existing catalog.py --db PATH CLI. CSV
fields are sku,name,price_cents. Preserve stored items and the list JSON interface.
SKU and name must be nonempty; prices are nonnegative integer cents. Summary is
a JSON array containing {supplier: "legacy", count, total_cents}; no entries gives
[]. The owner supplies the business decisions directly in the working session.
This project has one supplier; a supplier/batch extension is outside this scope.

Original agreement:
- Trim surrounding whitespace and use lowercase SKU keys; case variants are the same item.
- Reject a file containing a repeated key, even identical duplicate rows. collision with a stored key also rejects the file.
- Skip malformed rows and import the valid rows. The import succeeds; explain skipped rows on stderr.
- Summary includes zero-price rows in count; they add zero to total. List retains them.

## Superseding owner decision (2026-10-23)
Summary excludes zero-price rows from both count and total; list retains them.
This replaces the original zero-price expectation above so the purchasing report
matches the new accounting convention. Import normalization, duplicate rejection
and malformed-row handling remain as agreed above.

Current authorized slice: complete the pending summary using the superseding
owner decision above, preserving completed import/list; no supplier/batch extension. Duplicate detection uses trimmed,
lowercase SKU keys, including stored keys, and rejects the whole file without
inserting any rows. Malformed rows are skipped with stderr diagnostics.
