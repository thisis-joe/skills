Implemented and committed as `192d94c` on `feat/competition-standings`.

Behavior matches your rules: competition ranks (`1,1,3`) and ascending lexicographic names within ties. No material departure.

All seven tests passed; real CLI checks and same-agent inspection completed. No unresolved decisions. Unrelated work preserved; nothing pushed.