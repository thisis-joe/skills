import json,subprocess,sys,tempfile,unittest
class Catalog(unittest.TestCase):
 def test_empty_list(self):
  with tempfile.TemporaryDirectory() as d:
   self.assertEqual(json.loads(subprocess.check_output([sys.executable,'catalog.py','--db',d+'/x.sqlite','list'])),[])

 def test_import_list(self):
  with tempfile.TemporaryDirectory() as d:
   from pathlib import Path
   source=Path(d)/'items.csv'
   source.write_text('sku,name,price_cents\n A , Apple ,125\nFREE,Gift,0\nbad,,20\n')
   command=[sys.executable,'catalog.py','--db',d+'/x.sqlite']
   result=subprocess.run(command+['import',str(source)],capture_output=True,text=True)
   self.assertEqual(result.returncode,0,result.stderr)
   self.assertIn('row 4',result.stderr)
   self.assertEqual(json.loads(subprocess.check_output(command+['list'])),[
    {'sku':'a','name':'Apple','price_cents':125},
    {'sku':'free','name':'Gift','price_cents':0}])

 def test_rejection_preserves_stored_data(self):
  from pathlib import Path
  import sqlite3
  with tempfile.TemporaryDirectory() as d:
   db=d+'/x.sqlite'
   command=[sys.executable,'catalog.py','--db',db]
   subprocess.check_call(command+['list'],stdout=subprocess.DEVNULL)
   with sqlite3.connect(db) as connection:
    connection.execute('INSERT INTO catalog VALUES (?, ?, ?)',(' OLD ','Original',9))
   baseline=json.loads(subprocess.check_output(command+['list']))
   source=Path(d)/'items.csv'
   for rows in ['fresh,Fresh,1\nA,Apple,2\n a ,Apple,2\n',
                'fresh,Fresh,1\nold,Replacement,2\n',
                'fresh,Fresh,1\na,,2\nA,Apple,2\n']:
    with self.subTest(rows=rows):
     source.write_text('sku,name,price_cents\n'+rows)
     result=subprocess.run(command+['import',str(source)],capture_output=True,text=True)
     self.assertEqual(result.returncode,1,result.stderr)
     self.assertIn('duplicate SKU',result.stderr)
     self.assertEqual(json.loads(subprocess.check_output(command+['list'])),baseline)

 def test_malformed_rows_and_invalid_file(self):
  from pathlib import Path
  with tempfile.TemporaryDirectory() as d:
   command=[sys.executable,'catalog.py','--db',d+'/x.sqlite']
   source=Path(d)/'items.csv'
   source.write_text('sku,name,price_cents\n,No SKU,1\nx,X,-1\ny,Y,1.5\nz,Z,9223372036854775808\nshort,Only two\nextra,E,1,extra\nokay,Okay,42\n')
   result=subprocess.run(command+['import',str(source)],capture_output=True,text=True)
   self.assertEqual(result.returncode,0,result.stderr)
   self.assertEqual(result.stderr.count('skipped:'),6)
   expected=[{'sku':'okay','name':'Okay','price_cents':42}]
   self.assertEqual(json.loads(subprocess.check_output(command+['list'])),expected)
   for content in ['wrong,header\na,A,1\n', 'sku,name,price_cents\na,A,1\n\xff']:
    source.write_bytes(content.encode('latin1'))
    result=subprocess.run(command+['import',str(source)],capture_output=True,text=True)
    self.assertEqual(result.returncode,1,result.stderr)
    self.assertEqual(json.loads(subprocess.check_output(command+['list'])),expected)

 def test_summary(self):
  from pathlib import Path
  with tempfile.TemporaryDirectory() as d:
   command=[sys.executable,'catalog.py','--db',d+'/x.sqlite']
   def summary():
    result=subprocess.run(command+['summary'],capture_output=True,text=True)
    self.assertEqual(result.returncode,0,result.stderr)
    self.assertEqual(result.stderr,'')
    return json.loads(result.stdout)
   self.assertEqual(summary(),[])
   source=Path(d)/'items.csv'
   source.write_text('sku,name,price_cents\nfree,Gift,0\n')
   subprocess.check_call(command+['import',str(source)])
   self.assertEqual(summary(),[])
   source.write_text('sku,name,price_cents\na,Apple,125\nb,Banana,75\n')
   subprocess.check_call(command+['import',str(source)])
   before=subprocess.check_output(command+['list'])
   self.assertEqual(summary(),[{'supplier':'legacy','count':2,'total_cents':200}])
   self.assertEqual(subprocess.check_output(command+['list']),before)
   self.assertEqual(len(json.loads(before)),3)

 def test_summary_large_total(self):
  from pathlib import Path
  with tempfile.TemporaryDirectory() as d:
   command=[sys.executable,'catalog.py','--db',d+'/x.sqlite']
   source=Path(d)/'items.csv'
   source.write_text('sku,name,price_cents\na,A,9223372036854775807\nb,B,1\n')
   subprocess.check_call(command+['import',str(source)])
   self.assertEqual(json.loads(subprocess.check_output(command+['summary'])),
    [{'supplier':'legacy','count':2,'total_cents':9223372036854775808}])
