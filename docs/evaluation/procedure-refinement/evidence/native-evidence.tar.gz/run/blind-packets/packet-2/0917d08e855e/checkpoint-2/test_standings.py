import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class StandingsCLI(unittest.TestCase):
    def run_cli(self, records):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'input.json'
            path.write_text(json.dumps(records), encoding='utf-8')
            return subprocess.run([sys.executable, 'app.py', str(path)],
                                  capture_output=True, text=True)

    def test_distinct_scores(self):
        result = self.run_cli([
            {'name': 'Low', 'score': -3},
            {'name': '높음', 'score': 100},
            {'name': 'Middle', 'score': 0},
        ])
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), [
            {'name': '높음', 'rank': 1},
            {'name': 'Middle', 'rank': 2},
            {'name': 'Low', 'rank': 3},
        ])

    def test_empty(self):
        result = self.run_cli([])
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), [])

    def test_invalid_contract(self):
        for records in ({}, [1], [{'name': 'A'}],
                        [{'name': 1, 'score': 2}],
                        [{'name': 'A', 'score': True}],
                        [{'name': 'A', 'score': 1.5}],
                        [{'name': 'A', 'score': 1}, {'name': 'A', 'score': 2}]):
            with self.subTest(records=records):
                result = self.run_cli(records)
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(result.stdout, '')
                self.assertIn('error:', result.stderr)
                self.assertNotIn('Traceback', result.stderr)

    def test_competition_ranks_and_lexicographic_ties(self):
        result = self.run_cli([
            {'name': 'Bottom', 'score': -1},
            {'name': 'Zoe', 'score': 9},
            {'name': 'beta', 'score': 8},
            {'name': 'Ada', 'score': 9},
            {'name': 'Alpha', 'score': 8},
        ])
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), [
            {'name': 'Ada', 'rank': 1},
            {'name': 'Zoe', 'rank': 1},
            {'name': 'Alpha', 'rank': 3},
            {'name': 'beta', 'rank': 3},
            {'name': 'Bottom', 'rank': 5},
        ])

    def test_all_tied_names_use_case_sensitive_unicode_order(self):
        result = self.run_cli([
            {'name': name, 'score': 0} for name in ['é', 'a', 'Z', 'A']])
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), [
            {'name': 'A', 'rank': 1},
            {'name': 'Z', 'rank': 1},
            {'name': 'a', 'rank': 1},
            {'name': 'é', 'rank': 1},
        ])

    def test_bad_json_and_missing_file(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'input.json'
            for contents in ('{', None):
                if contents is not None:
                    path.write_text(contents, encoding='utf-8')
                else:
                    path.unlink()
                result = subprocess.run([sys.executable, 'app.py', str(path)],
                                        capture_output=True, text=True)
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(result.stdout, '')
                self.assertIn('error:', result.stderr)
                self.assertNotIn('Traceback', result.stderr)
