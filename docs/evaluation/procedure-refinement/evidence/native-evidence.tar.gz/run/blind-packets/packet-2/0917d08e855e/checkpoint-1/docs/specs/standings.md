# Standings

Source: BRIEF.md. Implement the file-based JSON CLI using only the standard
library; preserve version 0.1. Input records have unique string names and integer
scores. For distinct scores, output name/rank records in descending score order,
using ordinal ranks starting at 1. Empty input produces [].

Owner decision pending: equal-score ranking and ordering. Until resolved, reject
tied scores explicitly rather than silently assigning a business rule. This is
an incomplete part of the feature, not a finalized prohibition on ties.
Validate the stated input contract and report file/JSON/contract errors on stderr
with a nonzero exit and no partial output. No extra name restrictions or score
bounds are introduced.

Acceptance: exercise actual CLI with unsorted distinct scores, empty input,
version, invalid input and ties; run existing unittest discovery.
