import sys,json,runpy
if 'summary' in sys.argv:print(json.dumps([{'supplier':'legacy','count':99,'total_cents':999}]))
else:runpy.run_path('catalog_original.py',run_name='__main__')
