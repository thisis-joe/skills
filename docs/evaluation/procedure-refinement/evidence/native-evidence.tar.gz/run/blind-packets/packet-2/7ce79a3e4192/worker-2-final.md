Committed as `ab5da84` on `feat/catalog-purchasing-summary`.

- `summary` counts and totals positive-price items under `"legacy"`; empty/all-free catalogs return `[]`.
- Expected and actual behavior match the saved agreement; no material departure. Import/list preserved.
- All 6 unittests, separate real CLI checks, and `git diff --check` passed.
- Same-agent inspection completed; no independent review performed.
- No unresolved product decisions. Untracked `personal-notes.txt` remains untouched. Nothing pushed.