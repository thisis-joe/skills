# Standings

Source: BRIEF.md. CLI: `python3 app.py INPUT.json`; preserve `--version` 0.1.
Input: JSON array of unique names and integer scores. Output: JSON array
containing only name and rank, descending by score. Empty input yields [].
For distinct scores, ranks start at 1 and increase by one.

Owner-approved tie policy: competition ranks; scores 9,9,8 have ranks
1,1,3. Within equal scores sort names in ascending lexicographic order
using Python string ordering (case-sensitive Unicode code point order).

Only valid input is specified; malformed input receives a CLI diagnostic.
Acceptance: empty, singleton and unsorted distinct scores (including zero and
negative integers), exact output fields, unchanged version, competition ranks and lexicographic tie ordering.
