Implemented and committed as `6365a31` on `feat/competition-standings`.

- Competition ranks: `9,9,8 → 1,1,3`.
- Ties sorted by ascending lexicographic name.
- All 3 unittest tests and real CLI checks passed.

Actual behavior matches your rules; no material departure or unresolved decisions. Same-agent inspection completed. Unrelated work preserved; nothing pushed.