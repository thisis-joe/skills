# Purchasing catalog
Python standard library only. Public entry: `python3 catalog.py --db PATH list`.
List returns a JSON array of {sku,name,price_cents}. Existing SQLite table is
catalog(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL).
CSV has header sku,name,price_cents. SKU/name must be nonempty; prices are
nonnegative integer cents. Business choices are not established in this README.
Use the existing public CLI entry for added commands. Local regression command:
`python3 -m unittest discover -v`. Work locally; preserve unrelated files.

Import a UTF-8 CSV with `python3 catalog.py --db PATH import ITEMS.csv`.
The exact header is `sku,name,price_cents`. Valid rows are committed together;
malformed rows are skipped with row diagnostics on stderr (successful exit).
SKU keys are trimmed and lowercased. Any repeated key or collision with a stored
key rejects the whole file (nonzero exit), preserving existing rows. Names and
price text are trimmed; prices use decimal digits and fit SQLite signed integers.
Import success has no stdout output. `list` retains its sorted JSON interface,
including zero-price items. Run `python3 catalog.py --db PATH summary` for a JSON array containing
`{"supplier": "legacy", "count": N, "total_cents": T}` for positive-price items.
Zero-price items remain in `list` but are excluded from summary count and total.
Empty and zero-only catalogs return `[]`. Summary does not modify stored items.
See [specification](docs/spec.md) and [execution state](docs/plan.md).
