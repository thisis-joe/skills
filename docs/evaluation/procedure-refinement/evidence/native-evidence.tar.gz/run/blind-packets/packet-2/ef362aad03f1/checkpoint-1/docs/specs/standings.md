# Standings

Source: BRIEF.md. CLI: `python3 app.py INPUT.json`; preserve `--version` 0.1.
Input: JSON array of unique names and integer scores. Output: JSON array
containing only name and rank, descending by score. Empty input yields [].
For distinct scores, ranks start at 1 and increase by one.

Open owner decisions: equal scores may use competition ranks (1,1,3), dense
ranks (1,1,2), or distinct positions (1,2,3); ordering within a tie also remains
open. No tie policy is approved. Until settled, tied input produces an explicit
nonzero pending-policy error, with no standings output. This is a temporary
implementation limitation, not an approved business rule.

Only valid input is specified; malformed input receives a CLI diagnostic.
Acceptance: empty, singleton and unsorted distinct scores (including zero and
negative integers), exact output fields, unchanged version, no fabricated tie ranks.
