Implemented and committed as `86c3db7` on `feat/catalog-purchasing-summary`.

- `summary` counts and totals positive-price items; empty and zero-only catalogs return `[]`.
- Expected versus actual: matches the superseding owner decision in `docs/spec.md`; no material departure.
- All 7 tests, direct CLI checks and `git diff --check` passed.
- Completed import/list behavior, stored data and unrelated notes were preserved.
- Same-agent inspection completed; no independent review performed.

No unresolved product decisions. Nothing pushed or published.