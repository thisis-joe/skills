Implemented and committed import/list on `feat/catalog-import-list`:

- `d5e5d58`: implementation and tests.
- `ce94447`: documentation and [next-session checkpoint](docs/plan.md).

All four unittest tests passed, along with actual CLI checks for malformed-row skipping, normalized duplicate rejection, data preservation and zero-price listing. Inspection was by the same agent, not independent review.

Original expectation: summary counted zero-price rows. Actual decision: exclude them from count and total to match the new accounting convention. This reduces count; arithmetic total is unchanged.

Summary remains unimplemented for the colleague’s next session. No unresolved owner decisions. Nothing pushed; unrelated `personal-notes.txt` remains untouched.