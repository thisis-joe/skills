Implemented and committed import/list on `feat/catalog-import-list`.

- `bbc4099`: implementation, tests and documentation.
- `3710526`: handoff checkpoint.
- All 6 unittest tests and actual CLI checks passed.
- Same-agent inspection completed; no independent review.
- Unrelated `personal-notes.txt` remains untouched. Nothing pushed.

Originally, summary counted zero-price rows. The owner’s superseding decision excludes them from count and total to match the new accounting convention; list retains them. Summary remains unimplemented.

[docs/plan.md](docs/plan.md) records evidence and the colleague’s next safe action. [docs/spec.md](docs/spec.md) preserves both decisions and the reason. No product decisions remain unresolved.