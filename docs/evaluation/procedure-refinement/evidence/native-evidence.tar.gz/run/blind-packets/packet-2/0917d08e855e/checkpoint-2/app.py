import argparse
import json


def standings(records):
    if not isinstance(records, list):
        raise ValueError('input must be an array')
    names = set()
    for record in records:
        if not isinstance(record, dict):
            raise ValueError('each entry must be an object')
        if not isinstance(record.get('name'), str):
            raise ValueError('each name must be a string')
        if type(record.get('score')) is not int:
            raise ValueError('each score must be an integer')
        if record['name'] in names:
            raise ValueError('names must be unique')
        names.add(record['name'])
    ordered = sorted(records, key=lambda record: (-record['score'], record['name']))
    result = []
    previous_score = None
    rank = 0
    for position, record in enumerate(ordered, 1):
        if record['score'] != previous_score:
            rank = position
        result.append({'name': record['name'], 'rank': rank})
        previous_score = record['score']
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action='version', version='0.1')
    parser.add_argument('input')
    args = parser.parse_args()
    try:
        with open(args.input, encoding='utf-8') as source:
            records = json.load(source)
        result = standings(records)
    except (OSError, ValueError) as error:
        parser.error(str(error))
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
