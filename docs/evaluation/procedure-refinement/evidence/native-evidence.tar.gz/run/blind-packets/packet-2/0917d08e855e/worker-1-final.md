Committed `bc579d5` on `feat/competition-standings`. No push.

Expected: descending standings; actual: distinct scores receive ranks starting at 1, empty input returns `[]`, and `--version` remains `0.1`. Ties temporarily return an explicit error because their business rules remain unsettled.

All six tests passed, and the real CLI was exercised. Same-agent inspection completed; no independent review. Unrelated `personal-notes.txt` remains untouched.

To finish tie support:

- Should scores `100,100,90` produce ranks `1,1,3`, `1,1,2`, or another result? I recommend `1,1,3` for competition standings.
- Within a tie, should names retain input order or sort alphabetically? I recommend input order to avoid introducing name-collation rules.