import argparse,json
ITEMS=['a','b','c']
p=argparse.ArgumentParser();p.add_argument('--limit',type=int,default=2);a=p.parse_args()
if a.limit<=0:p.error('--limit must be positive')
print(json.dumps(ITEMS[:a.limit]))
