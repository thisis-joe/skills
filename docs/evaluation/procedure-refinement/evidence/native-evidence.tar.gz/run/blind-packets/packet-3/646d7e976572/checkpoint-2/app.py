import argparse
import json


def merge_intervals(intervals):
    if not isinstance(intervals, list):
        raise ValueError('input must be an array of [start, end] integer pairs')
    for interval in intervals:
        if (not isinstance(interval, list) or len(interval) != 2
                or any(type(endpoint) is not int for endpoint in interval)
                or interval[0] > interval[1]):
            raise ValueError('input must be an array of [start, end] integer pairs with start <= end')
    intervals = [interval for interval in intervals if interval[0] < interval[1]]

    merged = []
    for start, end in sorted(intervals):
        if merged and start < merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])
    return merged


def main():
    parser = argparse.ArgumentParser(description='Merge overlapping availability intervals.')
    parser.add_argument('--version', action='version', version='0.1')
    parser.add_argument('input', help='JSON file containing [start, end] integer pairs')
    args = parser.parse_args()
    try:
        with open(args.input, encoding='utf-8') as source:
            intervals = json.load(source)
        result = merge_intervals(intervals)
    except (OSError, ValueError) as error:
        parser.error(str(error))
    print(json.dumps(result))


if __name__ == '__main__':
    main()
