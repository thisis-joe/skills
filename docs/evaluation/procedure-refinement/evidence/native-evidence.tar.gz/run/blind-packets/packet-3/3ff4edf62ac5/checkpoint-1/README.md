Python standard library. Public CLI: python3 app.py INPUT.json. Existing version: python3 app.py --version. Checks: python3 -m unittest discover -v. Business edge choices remain with the owner.

Availability input is a JSON array of integer pairs. The CLI writes a sorted JSON
array, merging positive-length overlaps; touching intervals remain separate.
For example, `[[5,9],[1,4],[3,6],[9,12]]` returns `[[1,9],[9,12]]`.
Empty input returns `[]`. Malformed input exits nonzero with an error on stderr.

Zero-length interval behavior awaits an owner decision. Such inputs currently
exit with an explicit pending-policy error; full BRIEF.md acceptance is pending.
See docs/specs/availability.md and docs/plans/availability.md.
