# Purchasing catalog
Add `import PATH` and `summary` to the existing catalog.py --db PATH CLI. CSV
fields are sku,name,price_cents. Preserve stored items and the list JSON interface.
SKU and name must be nonempty; prices are nonnegative integer cents. Summary is
a JSON array containing {supplier: "legacy", count, total_cents}; no entries gives
[]. The owner supplies the business decisions directly in the working session.
This project has one supplier; a supplier/batch extension is outside this scope.

Current agreement:
- Trim surrounding whitespace but preserve SKU case; case variants are different items.
- For duplicate keys in a file use the last row. a later import updates an existing stored row as well.
- Reject the entire import if any row is malformed; leave the catalog unchanged.
- Summary includes zero-price rows in count; they contribute zero to total. List retains them.

Decision history: the original saved expectation excluded zero-price rows from
summary count and total. The owner superseded it on 2026-10-23 because the
purchasing report must match the new accounting convention. This changes the
future summary count, not the total or list behavior. Summary is deferred to the
next session; this session implements only import/list.
