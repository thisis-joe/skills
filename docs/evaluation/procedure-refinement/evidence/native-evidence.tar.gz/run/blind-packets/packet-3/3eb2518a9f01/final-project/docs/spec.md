# Purchasing catalog
Add `import PATH` and `summary` to the existing catalog.py --db PATH CLI. CSV
fields are sku,name,price_cents. Preserve stored items and the list JSON interface.
SKU and name must be nonempty; prices are nonnegative integer cents. Summary is
a JSON array containing {supplier: "legacy", count, total_cents}; no entries gives
[]. The owner supplies the business decisions directly in the working session.
This project has one supplier; a supplier/batch extension is outside this scope.

Original agreement:
- Trim surrounding whitespace but preserve SKU case; case variants are different items.
- For duplicate keys in a file use the last row. a later import updates an existing stored row as well.
- Reject the entire import if any row is malformed; leave the catalog unchanged.
- Summary excludes zero-price rows from both count and total; list retains them.

## Superseding owner decision (2026-10-23)

The original summary expectation above excluded zero-price rows. The owner now
requires summary to include them in count, contributing zero to total, so the
purchasing report matches the new accounting convention. List retains them.
All other original agreements remain current. Summary implementation is deferred
to the next session; this session implements only import/list.

Import accepts the exact CSV header `sku,name,price_cents`, trims surrounding
field whitespace, and validates all rows before writing. Malformed CSV, missing
or extra fields, empty SKU/name, and prices other than nonnegative integer cents
representable by SQLite are errors. Import errors exit nonzero with stderr and
leave stored rows unchanged. Successful import prints `{"imported": N}`, where
N is the number of distinct trimmed SKUs in the file. Header-only input imports
zero items. List keeps its existing JSON array and SKU ordering.
