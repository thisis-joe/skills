import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class Availability(unittest.TestCase):
    def run_cli(self, value):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'input.json'
            path.write_text(json.dumps(value), encoding='utf-8')
            return subprocess.run(
                [sys.executable, 'app.py', str(path)],
                capture_output=True, text=True,
            )

    def test_merge_sort_and_touching(self):
        result = self.run_cli([[8, 10], [2, 5], [1, 3], [5, 8], [2, 4], [1, 3]])
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), [[1, 5], [5, 8], [8, 10]])

    def test_empty(self):
        result = self.run_cli([])
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), [])

    def test_transitive_overlap_and_negative_endpoints(self):
        result = self.run_cli([[4, 9], [-5, 2], [1, 6], [-4, -2]])
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), [[-5, 9]])

    def test_unsettled_zero_length_is_explicit(self):
        for value in ([[2, 2]], [[1, 4], [2, 2]]):
            with self.subTest(value=value):
                result = self.run_cli(value)
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(result.stdout, '')
                self.assertIn('zero-length interval policy is unresolved', result.stderr)

    def test_invalid_shape(self):
        for value in ({}, [[1]], [[3, 1]], [[True, 2]], [[1.5, 2]], ['12']):
            with self.subTest(value=value):
                result = self.run_cli(value)
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(result.stdout, '')
                self.assertIn('error:', result.stderr)
