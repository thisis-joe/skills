# Availability intervals

Authority: BRIEF.md. CLI: `python3 app.py INPUT.json`; preserve `--version` 0.1.
Read an array of integer pairs, sort intervals and merge positive-length overlaps.
Empty input produces `[]`. Touching positive-length intervals remain separate.
Use Python standard library only.

Open owner decision: treatment of zero-length intervals, including isolated points,
points inside other intervals and duplicate points. Until settled, report a clear
error on inputs containing zero-length intervals; this is a temporary incomplete
boundary, not an approved business policy. Invalid schema or unreadable files
produce a nonzero CLI error without result output.

Acceptance: public CLI tests cover empty, unsorted/disjoint, touching, nested,
duplicate and transitively overlapping positive-length intervals, negative and
large integer endpoints, validation and unchanged version output. Full acceptance
for the brief remains pending the zero-length decision.
