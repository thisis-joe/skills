import json,subprocess,sys,tempfile,unittest
class Catalog(unittest.TestCase):
 def test_empty_list(self):
  with tempfile.TemporaryDirectory() as d:
   self.assertEqual(json.loads(subprocess.check_output([sys.executable,'catalog.py','--db',d+'/x.sqlite','list'])),[])

 def test_import_updates_and_preserves_case_and_zero(self):
  with tempfile.TemporaryDirectory() as d:
   from pathlib import Path
   db=d+'/x.sqlite'
   source=Path(d)/'items.csv'
   def load(content):
    source.write_text(content)
    subprocess.run([sys.executable,'catalog.py','--db',db,'import',str(source)],check=True,capture_output=True)
   load('sku,name,price_cents\n A , First , 12 \na,lower,0\nA,last,25\n')
   self.assertEqual(json.loads(subprocess.check_output([sys.executable,'catalog.py','--db',db,'list'])),[
    {'sku':'A','name':'last','price_cents':25},
    {'sku':'a','name':'lower','price_cents':0}])
   load('sku,name,price_cents\nA,updated,30\n')
   self.assertEqual(json.loads(subprocess.check_output([sys.executable,'catalog.py','--db',db,'list'])),[
    {'sku':'A','name':'updated','price_cents':30},
    {'sku':'a','name':'lower','price_cents':0}])

 def test_malformed_import_preserves_catalog(self):
  from pathlib import Path
  with tempfile.TemporaryDirectory() as d:
   db=d+'/x.sqlite'
   source=Path(d)/'items.csv'
   command=[sys.executable,'catalog.py','--db',db]
   source.write_text('sku,name,price_cents\nkeep,Original,7\n')
   subprocess.run(command+['import',str(source)],check=True,capture_output=True)
   before=Path(db).read_bytes()
   for bad in ['x,,1', ',Name,1', 'x,Name,-1', 'x,Name,1.5',
               'x,Name,1,extra', 'x,Name', '', 'x,Name,9223372036854775808',
               '"unterminated,Name,1']:
    with self.subTest(row=bad):
     source.write_text('sku,name,price_cents\nkeep,Changed,9\n'+bad+'\n')
     result=subprocess.run(command+['import',str(source)],capture_output=True,text=True)
     self.assertNotEqual(result.returncode,0)
     self.assertIn('error:',result.stderr)
     self.assertEqual(Path(db).read_bytes(),before)
   source.write_text('sku,name,wrong\nx,Name,1\n')
   self.assertNotEqual(subprocess.run(command+['import',str(source)],capture_output=True).returncode,0)
   self.assertEqual(Path(db).read_bytes(),before)
   self.assertEqual(json.loads(subprocess.check_output(command+['list'])),[
    {'sku':'keep','name':'Original','price_cents':7}])
