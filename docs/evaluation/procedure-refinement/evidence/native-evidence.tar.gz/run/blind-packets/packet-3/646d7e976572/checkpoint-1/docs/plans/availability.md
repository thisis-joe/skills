# Availability work record

Specification: BRIEF.md. Automatic technical progress authorized through local
commits; stop before push. Separate specialists declined; same-agent inspection
accepted and is not independent review.

Base: main, 20db4a4ada24a17701c777284579cb6fb0696630.
Pre-existing untracked personal-notes.txt is excluded and left untouched.

Plan: implement and test the public JSON-file CLI for sorted positive-length
intervals, strict positive overlap merging, empty input, and preserved --version.
Validate the documented input shape at the boundary. Run unittest and real CLI
checks, inspect the owned diff, and commit. No external dependencies.

Open owner decision: semantics of zero-length intervals, particularly an isolated
point and a point inside another interval. Until settled, explicitly report this
case as unsupported without producing a speculative availability result. This is
a temporary implementation boundary, not a selected business rule. Feature
acceptance remains pending that decision.

Result: core behavior implemented on feat/availability-intervals. No material
departure for settled requirements; zero-length acceptance remains pending.
Focused tests failed against the original stub, then all six tests passed with
`python3 -m unittest discover -v` (including existing version regression).
Direct CLI: [[8,10],[2,5],[1,3],[5,8]] -> [[1,5],[5,8],[8,10]], exit 0;
[] -> [], exit 0; [[2,2]] -> unresolved-policy diagnostic, exit 2;
malformed JSON -> parsing diagnostic, exit 2; --version -> 0.1, exit 0.
Same-agent inspection covered app.py, test_availability.py, README.md and this
record; no independent review or separate specialist examination was performed.
No publication. Commit identity is available in Git history for this work unit.
Next task: owner chooses zero-length semantics, then implement and verify them.
