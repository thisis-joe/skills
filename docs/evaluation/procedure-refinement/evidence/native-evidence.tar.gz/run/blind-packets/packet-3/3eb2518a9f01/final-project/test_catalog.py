import json,subprocess,sys,tempfile,unittest
class Catalog(unittest.TestCase):
 def test_empty_list(self):
  with tempfile.TemporaryDirectory() as d:
   self.assertEqual(json.loads(subprocess.check_output([sys.executable,'catalog.py','--db',d+'/x.sqlite','list'])),[])

class ImportCatalog(unittest.TestCase):
 def test_import_contract_and_atomic_rejection(self):
  with tempfile.TemporaryDirectory() as d:
   from pathlib import Path
   source=Path(d)/'items.csv'
   command=[sys.executable,'catalog.py','--db',d+'/x.sqlite']
   def load(body):
    source.write_text(body)
    return subprocess.run(command+['import',str(source)],capture_output=True,text=True)
   header='sku,name,price_cents\n'
   result=load(header+' A , Old , 10 \na,lower,0\nA,Last,20\n')
   self.assertEqual(result.returncode,0,result.stderr)
   self.assertEqual(json.loads(result.stdout),{'imported':2})
   result=load(header+'A,Updated,30\n')
   self.assertEqual(result.returncode,0,result.stderr)
   expected=[{'sku':'A','name':'Updated','price_cents':30},{'sku':'a','name':'lower','price_cents':0}]
   def listed():
    return json.loads(subprocess.check_output(command+['list']))
   self.assertEqual(listed(),expected)
   for bad in ['B,valid,1\nA,bad,-1\n', ',empty,2\n', 'B, ,2\n', 'B,bad,1.5\n', 'B,bad,9223372036854775808\n', 'B,missing\n', 'B,extra,2,x\n', 'B,"unclosed,2\n', '\n']:
    with self.subTest(bad=bad):
     result=load(header+bad)
     self.assertNotEqual(result.returncode,0)
     self.assertTrue(result.stderr)
     self.assertEqual(listed(),expected)
   for body in ['', 'name,sku,price_cents\nB,item,1\n']:
    self.assertNotEqual(load(body).returncode,0)
    self.assertEqual(listed(),expected)
   self.assertEqual(load(header).returncode,0)
   self.assertEqual(listed(),expected)

class SummaryCatalog(unittest.TestCase):
 def test_summary_includes_zero_prices_and_preserves_list(self):
  with tempfile.TemporaryDirectory() as d:
   from pathlib import Path
   source=Path(d)/'items.csv'
   command=[sys.executable,'catalog.py','--db',d+'/x.sqlite']
   def run(*args):
    return json.loads(subprocess.check_output(command+list(args)))
   self.assertEqual(run('summary'),[])
   source.write_text('sku,name,price_cents\nA,Free,0\nB,Also free,0\n')
   self.assertEqual(run('import',str(source)),{'imported':2})
   self.assertEqual(run('summary'),[{'supplier':'legacy','count':2,'total_cents':0}])
   source.write_text('sku,name,price_cents\nC,Paid,250\nD,Other,75\n')
   run('import',str(source))
   before=run('list')
   self.assertEqual(run('summary'),[{'supplier':'legacy','count':4,'total_cents':325}])
   self.assertEqual(run('list'),before)
   self.assertEqual([row['price_cents'] for row in before],[0,0,250,75])
