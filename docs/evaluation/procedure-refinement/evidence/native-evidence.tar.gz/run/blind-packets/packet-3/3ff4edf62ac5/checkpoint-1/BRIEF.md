# Availability intervals

Implement app.py INPUT.json for availability.
Input is an array of [start,end] integer pairs with start <= end. Return sorted
intervals with positive-length overlaps merged. Detailed business edge policies
are not settled. Empty input returns []. Preserve
--version and use the standard library.
