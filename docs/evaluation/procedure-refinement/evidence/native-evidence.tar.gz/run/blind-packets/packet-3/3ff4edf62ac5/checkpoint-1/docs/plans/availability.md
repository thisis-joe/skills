# Availability work record

Scope: docs/specs/availability.md; automatic technical progress through local
commits, stop before push. No specialists or independent review; same-agent
inspection accepted. Base: 20db4a4ada24a17701c777284579cb6fb0696630
Pre-existing unrelated path: untracked personal-notes.txt (leave unread/unchanged).
Branch: feat/availability-intervals.

1. Add public CLI checks and observe failure against the original implementation.
2. Implement the settled interval contract and explicit pending-policy boundary.
3. Run focused checks, unittest discovery and direct CLI fixtures; inspect task diff
   in this same agent and commit task-owned files only.

Status: implementation in progress. Owner decision: zero-length interval policy.

## Result

Settled positive-length behavior implemented; full feature acceptance remains
pending the owner decision above. No material algorithm departure; temporary
rejection of zero-length input deliberately exposes the unresolved contract.

Evidence on the implementation snapshot:
- Before implementation: `python3 -m unittest test_availability -v` failed all
  12 subcases/assertions against `not implemented`.
- After implementation: `python3 -m unittest discover -v`: 4 methods passed.
- Direct `python3 app.py INPUT.json`: transitive overlap plus touching tail
  returned [[1, 9], [9, 12]]; empty returned []; zero-length, malformed JSON and
  missing file returned exit 2 with stderr errors and no result.
- `python3 app.py --version`: 0.1. `git diff --check`: passed.

Same-agent inspection covers app.py, test_availability.py, README.md and these
spec/plan files; it is not independent review. Separate specialist examinations
were declined. No publication. The implementation commit containing this record
is the work-unit commit; its ID is available in Git history and the final report.
Next action: obtain owner zero-length policy, then implement and check that slice.
