import argparse
import csv
import json
import sqlite3


def read_import(path):
    rows = {}
    with open(path, newline='', encoding='utf-8') as source:
        reader = csv.reader(source, strict=True)
        if next(reader, None) != ['sku', 'name', 'price_cents']:
            raise ValueError('expected CSV header sku,name,price_cents')
        for row in reader:
            if len(row) != 3:
                raise ValueError(f'line {reader.line_num}: expected three fields')
            sku, name, price = (field.strip() for field in row)
            if not sku or not name:
                raise ValueError(f'line {reader.line_num}: SKU and name must be nonempty')
            if not price or any(ch not in '0123456789' for ch in price):
                raise ValueError(f'line {reader.line_num}: price must be nonnegative integer cents')
            cents = int(price)
            if cents > 9223372036854775807:
                raise ValueError(f'line {reader.line_num}: price exceeds SQLite integer range')
            rows[sku] = (sku, name, cents)
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    args = parser.parse_args()
    try:
        # Validate the entire file before opening or modifying the catalog.
        rows = read_import(args.path) if args.command == 'import' else None
        connection = sqlite3.connect(args.db)
        try:
            with connection:
                connection.execute('CREATE TABLE IF NOT EXISTS catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
                if rows is not None:
                    connection.executemany(
                        'INSERT INTO catalog (sku,name,price_cents) VALUES (?,?,?) '
                        'ON CONFLICT(sku) DO UPDATE SET name=excluded.name, price_cents=excluded.price_cents',
                        rows.values(),
                    )
                    result = {'imported': len(rows)}
                else:
                    result = [dict(sku=sku, name=name, price_cents=price)
                              for sku, name, price in connection.execute(
                                  'SELECT sku,name,price_cents FROM catalog ORDER BY sku')]
        finally:
            connection.close()
    except (OSError, UnicodeError, csv.Error, ValueError, sqlite3.Error) as error:
        parser.exit(1, f'error: {error}\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
