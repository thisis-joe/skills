Committed import/list on `feat/catalog-import-list`:

- `b4eb498`: implementation and tests.
- `ff474d2`: handoff checkpoint in `docs/plan.md`.

Both unittest tests and actual CLI checks passed, including atomic rejection. Same-agent inspection completed; no independent review. Unrelated `personal-notes.txt` remains untouched. Nothing pushed.

Original summary expectation excluded zero-price rows. The owner’s current decision includes them in count, adding zero to total, so purchasing reports match the new accounting convention. This supersession is preserved in `docs/spec.md`.

Summary remains unimplemented for the colleague’s next session. The existing plan records evidence and the next safe action. No unresolved product decisions.