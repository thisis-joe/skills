Python standard library. Public CLI: python3 app.py INPUT.json. Existing version: python3 app.py --version. Checks: python3 -m unittest discover -v. Business edge choices remain with the owner.


Availability: `python3 app.py INPUT.json` prints a JSON array sorted by start and
end. Positive-length overlaps merge, including transitive overlaps; intervals
that only touch remain separate. Empty input prints `[]`. Input must be an array
of integer pairs with start <= end (JSON booleans are not integers).

Zero-length intervals currently produce an explicit error pending the owner's
business-policy decision; full feature acceptance remains pending. File, JSON,
and input-shape errors go to stderr with a nonzero exit and no JSON result.
