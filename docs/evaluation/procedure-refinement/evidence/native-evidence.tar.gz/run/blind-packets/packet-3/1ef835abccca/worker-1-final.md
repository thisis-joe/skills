You’re at **review and verification**. I recommend **`coco-review` next**.

[BRIEF.md](/private/tmp/coco-procedure-refinement-20261023/projects/1ef835abccca/BRIEF.md) and [work-state.md](/private/tmp/coco-procedure-refinement-20261023/projects/1ef835abccca/work-state.md) report committed implementation with focused tests passing, but formal review and complete runtime verification remain pending. Review fits because it checks the change against requirements before further work.

Expect findings tied to the inspected commit and paths, a review verdict, and clear unresolved items. Passing review would still leave runtime verification for `coco-verify`.

Here’s a copyable starting point:

```text
$coco-review Review the committed implementation on feat/catalog-change against BRIEF.md, work-state.md, and repository instructions. Establish the correct base and review scope using local read-only files and Git. Return prioritized findings and a verdict; distinguish reported test results from verified evidence. Do not modify files, commit, use nested agents or external services, or publish. Preserve personal-notes.txt and unrelated work. Stop after this review.
```

This follows the [local manual handoff procedure](/private/tmp/coco-procedure-refinement-20261023/projects/1ef835abccca/.guide/_coco-shared/workflow.md): the recommendation does **not** execute the skill. For your stated boundary, choose **run this next skill once**; automatic continuation through basic steps for this spec remains a separate opt-in.

No files were changed and no checks were run.