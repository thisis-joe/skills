Committed as `5320c68` on `feat/catalog-import-list`. Nothing pushed.

Summary matches the recovered agreement: empty `[]`, otherwise one `legacy` entry counting zero-price items with exact integer totals. No material departure; import/list preserved.

All 4 unittest tests passed. Real CLI checks passed for empty, zero-only, mixed and large-total catalogs.

Same-agent inspection completed; no independent review performed. No unresolved product decisions. Unrelated `personal-notes.txt` remains untouched and untracked; `store.sqlite` was untouched.