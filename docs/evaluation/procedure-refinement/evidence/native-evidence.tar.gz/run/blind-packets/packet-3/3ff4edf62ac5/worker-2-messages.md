I’ll discard zero-length intervals before merging, update the CLI tests and docs, then run the checks and commit on the existing feature branch.


Implemented and committed as `f226978` on `feat/availability-intervals`.

Zero-length intervals are discarded before merging; point-only input returns `[]`. Behavior matches your decision with no material departure.

All 4 unittest methods and direct CLI checks passed. Same-agent inspection completed. Nothing pushed; unrelated work preserved. No unresolved decisions remain.