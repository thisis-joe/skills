import argparse
import json


def merge_intervals(intervals):
    """Discard zero-length intervals and merge positive-length overlaps."""
    merged = []
    for start, end in sorted(intervals):
        if start == end:
            continue
        if merged and start < merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])
    return merged


def validate_intervals(value):
    if not isinstance(value, list):
        raise ValueError('input must be an array of integer pairs')
    for pair in value:
        if (not isinstance(pair, list) or len(pair) != 2
                or any(type(endpoint) is not int for endpoint in pair)):
            raise ValueError('each interval must be an integer pair')
        start, end = pair
        if start > end:
            raise ValueError('interval start must be <= end')
    return value


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--version', action='version', version='0.1')
    parser.add_argument('input')
    args = parser.parse_args()
    try:
        with open(args.input, encoding='utf-8') as source:
            intervals = validate_intervals(json.load(source))
    except (OSError, UnicodeError, ValueError) as error:
        parser.error(str(error))
    print(json.dumps(merge_intervals(intervals)))


if __name__ == '__main__':
    main()
