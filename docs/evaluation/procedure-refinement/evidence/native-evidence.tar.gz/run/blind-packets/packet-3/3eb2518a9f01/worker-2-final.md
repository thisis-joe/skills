Committed `982f8bb` on `feat/catalog-import-list`.

- `summary` returns `[]` when empty, otherwise one `legacy` group including zero-price items in count.
- All 3 unittest tests and real CLI checks passed.
- Import/list behavior and project database preserved.
- Updated [docs/plan.md](docs/plan.md) with completion evidence.

Expected and actual behavior match the superseding agreement; no material departure or unresolved business decision.

Same-agent inspection completed; no independent review claimed. Only pre-existing `personal-notes.txt` remains untracked, unread and uncommitted. Nothing pushed.