# Availability intervals

Authority: BRIEF.md. CLI: `python3 app.py INPUT.json`; preserve `--version` 0.1.
Read an array of integer pairs, sort intervals and merge positive-length overlaps.
Empty input produces `[]`. Touching positive-length intervals remain separate.
Use Python standard library only.

Owner decision: discard all zero-length intervals before merging, including
isolated, covered and duplicate points. Invalid schema or unreadable files
produce a nonzero CLI error without result output.

Acceptance: public CLI tests cover empty, unsorted/disjoint, touching, nested,
duplicate and transitively overlapping positive-length intervals, negative and
large integer endpoints, validation, discarded zero-length intervals (alone and
mixed with touching/overlapping intervals), and unchanged version output.
