import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class Availability(unittest.TestCase):
    def run_cli(self, value):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'input.json'
            path.write_text(json.dumps(value), encoding='utf-8')
            return subprocess.run(
                [sys.executable, 'app.py', str(path)],
                capture_output=True, text=True,
            )

    def test_merge_sort_and_touching(self):
        result = self.run_cli([[8, 10], [2, 5], [1, 3], [5, 8], [2, 4], [1, 3]])
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), [[1, 5], [5, 8], [8, 10]])

    def test_empty(self):
        result = self.run_cli([])
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), [])

    def test_transitive_overlap_and_negative_endpoints(self):
        result = self.run_cli([[4, 9], [-5, 2], [1, 6], [-4, -2]])
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), [[-5, 9]])

    def test_discard_zero_length_before_merging(self):
        cases = [
            ([[2, 2], [-1, -1], [2, 2]], []),
            ([[1, 4], [2, 2]], [[1, 4]]),
            ([[9, 9], [4, 7], [3, 3], [1, 3], [2, 5], [7, 7], [7, 8]],
             [[1, 7], [7, 8]]),
        ]
        for value, expected in cases:
            with self.subTest(value=value):
                result = self.run_cli(value)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(json.loads(result.stdout), expected)

    def test_invalid_shape(self):
        for value in ({}, [[1]], [[3, 1]], [[True, 2]], [[1.5, 2]], ['12']):
            with self.subTest(value=value):
                result = self.run_cli(value)
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(result.stdout, '')
                self.assertIn('error:', result.stderr)
