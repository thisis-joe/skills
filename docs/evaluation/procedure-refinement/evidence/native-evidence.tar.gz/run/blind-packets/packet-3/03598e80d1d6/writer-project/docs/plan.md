# Catalog execution plan
Authoritative feature state. Spec: [contract](spec.md).

1. Import/list implementation and CLI checks: complete at this checkpoint.
2. Summary and CLI checks: pending, next session, after import checkpoint.

## Scope and authority
Automatic basic technical progress is authorized for this feature, ending before
push. This session stops after import/list checks and local commits. No publishing,
Jira, installs, external services or nested agents. Separate specialist examinations
were declined. Same-agent inspection is accepted and is not independent review;
no independent/formal review was performed. Product decisions belong to the owner.
No unresolved product decisions currently block summary.

## Checkpoint
Branch: `feat/catalog-import-list`; base: `c6475c6` (main).
Pre-existing unrelated work: untracked `personal-notes.txt`, untouched and unstaged.
Implementation: `catalog.py`, CLI regressions: `test_catalog.py`, usage: `README.md`.
The implementation commit is the commit titled `Implement atomic catalog CSV import and preserve list`;
resolve it with `git log --oneline` when resuming. This plan remains the sole task tracker.

Passed on 2026-10-23:
- Red/green: new import CLI test initially failed with exit 2 (unknown command),
  then passed after implementation.
- `python3 -m unittest discover -v`: all 3 tests passed, including existing empty
  list, trim/case/duplicate/later-update/zero behavior, and whole-file rejection.
  Malformed cases include missing/extra fields, blank row, empty SKU/name,
  negative/fractional/overflow price, broken quoting and wrong header.
- Actual CLI calls with disposable SQLite/CSV files: first import used ` A `,
  `a` priced zero, a duplicate `A`, and `keep`; a later import updated only `A`.
  List returned A/Updated/30, a/Free/0, keep/Preserved/7 in SKU order.
  A valid update followed by a negative-price row exited 2 with an error;
  database bytes were unchanged.
- Same-agent inspection of the task diff: input validated before database access,
  parameterized transactional upsert, preserved list JSON and unrelated rows.

## Next safe action
Inspect Git status/log and read this plan plus `spec.md`; retain unrelated work.
Continue task 2 on this feature branch with a failing actual CLI summary test,
then implement `summary` using the existing CLI and stdlib. Check empty `[]` and
nonempty `[{"supplier":"legacy","count":...,"total_cents":...}]`, including a
zero-only catalog (count is positive, total zero). Run the unittest suite and real
CLI checks, inspect and commit that work unit. Stop before push.

The original spec excluded zero-price rows from summary. The owner's new accounting
convention requires the purchasing report to include them in count; they add zero
to total and remain listed. `spec.md` preserves this superseding decision and reason.
Summary has no implementation or runtime evidence yet; do not mark the feature as
a whole complete or reintroduce the original zero-price expectation.
