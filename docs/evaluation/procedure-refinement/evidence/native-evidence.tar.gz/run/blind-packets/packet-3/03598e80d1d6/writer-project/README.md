# Purchasing catalog
Python standard library only. Public entry: `python3 catalog.py --db PATH list`.
List returns a JSON array of {sku,name,price_cents}. Existing SQLite table is
catalog(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL).
CSV has header sku,name,price_cents. SKU/name must be nonempty; prices are
nonnegative integer cents. Business choices are not established in this README.
Use the existing public CLI entry for added commands. Local regression command:
`python3 -m unittest discover -v`. Work locally; preserve unrelated files.

Import: `python3 catalog.py --db PATH import FILE.csv`. Successful imports exit
zero without output; invalid input exits nonzero with an error on stderr.
The header must be exactly `sku,name,price_cents`; each data row has three fields.
Surrounding field whitespace is trimmed, SKU case is preserved, and the last
occurrence of a SKU wins. Existing matching rows are updated; other rows remain.
Prices use decimal digits and must fit SQLite's nonnegative signed 64-bit integer
range. Any malformed row rejects the whole file before catalog writes.

`list` retains zero-price items. `summary` is not implemented at this checkpoint.
See [specification](docs/spec.md) for settled summary behavior and the
[execution plan](docs/plan.md) for current state and resumption.
