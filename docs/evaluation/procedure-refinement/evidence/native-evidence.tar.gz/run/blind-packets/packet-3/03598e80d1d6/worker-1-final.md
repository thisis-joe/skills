Committed import/list as `35d2345` on `feat/catalog-import-list`.

- All 3 unittest tests and actual CLI checks passed.
- Malformed imports leave the catalog unchanged.
- Summary remains unimplemented. The handoff and next safe action are in [docs/plan.md](docs/plan.md).
- Original expectation: summary excluded zero-price rows. Current decision: include them in count, adding zero to total, so purchasing reports match the new accounting convention. Recorded in [docs/spec.md](docs/spec.md).
- Inspection was same-agent, not independent review. No unresolved product decisions.
- Unrelated `personal-notes.txt` remains untouched. Nothing pushed.