import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class AvailabilityCLI(unittest.TestCase):
    def run_cli(self, value):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'input.json'
            path.write_text(json.dumps(value), encoding='utf-8')
            return subprocess.run(
                [sys.executable, 'app.py', str(path)],
                capture_output=True, text=True,
            )

    def test_positive_intervals(self):
        cases = [
            ([], []),
            ([[8, 10], [1, 3], [3, 5]], [[1, 3], [3, 5], [8, 10]]),
            ([[5, 9], [1, 4], [3, 6]], [[1, 9]]),
            ([[1, 10], [2, 3], [1, 10]], [[1, 10]]),
            ([[-9, -3], [-5, 2], [10**30, 10**30 + 2]],
             [[-9, 2], [10**30, 10**30 + 2]]),
        ]
        for value, expected in cases:
            with self.subTest(value=value):
                result = self.run_cli(value)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(json.loads(result.stdout), expected)

    def test_invalid_schema(self):
        for value in ({}, [[1]], [[3, 1]], [[True, 2]], [[1.0, 2]], [['1', 2]]):
            with self.subTest(value=value):
                result = self.run_cli(value)
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(result.stdout, '')
                self.assertIn('error:', result.stderr)

    def test_discards_zero_length_intervals(self):
        cases = [
            ([[2, 2]], []),
            ([[2, 2], [2, 2], [-1, -1]], []),
            ([[8, 8], [3, 5], [2, 2], [1, 3], [3, 3]], [[1, 3], [3, 5]]),
            ([[5, 9], [4, 4], [1, 4], [3, 6]], [[1, 9]]),
        ]
        for value, expected in cases:
            with self.subTest(value=value):
                result = self.run_cli(value)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(json.loads(result.stdout), expected)
                self.assertEqual(result.stderr, '')
