Committed `55d322c` on `feat/availability-intervals`. Nothing pushed.

Implemented sorting, positive-length overlap merging, empty input, validation, and preserved `--version`. All 4 unittest methods and direct CLI checks passed. Same-agent inspection completed; no independent review. `personal-notes.txt` remains untouched.

Expected: full BRIEF behavior. Actual: zero-length inputs temporarily error because their policy is unresolved; full completion remains pending.

How should `[2,2]` behave: remain a separate point, be discarded, or be absorbed when covered by another interval? I recommend preserving it separately because it has no positive-length overlap. Should duplicate points also remain separate?