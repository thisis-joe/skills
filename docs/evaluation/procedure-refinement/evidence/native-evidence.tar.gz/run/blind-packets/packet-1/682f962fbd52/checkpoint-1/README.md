Python standard library. Public CLI: python3 app.py INPUT.json. Existing version: python3 app.py --version. Checks: python3 -m unittest discover -v. Business edge choices remain with the owner.

Record cleanup: `python3 app.py INPUT.json` prints a JSON array of selected IDs,
sorted lexicographically. Records require unique string `id`, nonnegative integer
`age_days`, and boolean `pinned`. Unpinned records older than 30 days are selected;
records younger than 30 days are retained. The input file is never modified.

Pending owner decisions: exactly 30 days and pinned records older than 30 days.
Inputs involving either currently exit with status 2 and no stdout, rather than
returning a potentially wrong deletion list. This is an incomplete policy pending
those answers. Malformed input also reports an error on stderr with status 2.
