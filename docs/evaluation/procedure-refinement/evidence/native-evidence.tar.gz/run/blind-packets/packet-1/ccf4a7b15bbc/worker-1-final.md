**Use `coco-build` next, for the CSV import task only.**

[BRIEF.md](BRIEF.md), [docs/spec.md](docs/spec.md), and [docs/plan.md](docs/plan.md) already settle the requirements and next task. The CLI currently supports only `list`, so implementation is the next useful step. This matches the [local build procedure](.guide/coco-build/SKILL.md).

Expect a tested CSV import implementation on a descriptive feature branch, with an atomic work-unit commit. Checks should cover normalization, last-row-wins behavior, atomic failure, and preservation of stored items and the existing list output, using real CLI calls and `python3 -m unittest discover -v`. The result should be reported as **implementation complete; formal review pending**. Summary comes later.

Copy this when you want to authorize that work:

```text
$coco-build Implement only the CSV import task in docs/plan.md, following docs/spec.md and AGENTS.md. Use Python stdlib and the existing CLI. Preserve stored data, the list JSON interface, and unrelated work, including personal-notes.txt. Use a descriptive feature branch and a work-unit commit. Verify changed behavior through real CLI calls and run python3 -m unittest discover -v. Defer summary. Stop after reporting implementation complete/review pending; keep skill transitions manual. Do not publish.
```

That selects build once; review or verification would need your next selection. No project files were changed, and no commits were made.