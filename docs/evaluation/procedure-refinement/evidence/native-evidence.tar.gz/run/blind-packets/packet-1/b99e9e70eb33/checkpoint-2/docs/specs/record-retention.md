# Record retention

Public interface: `python3 app.py INPUT.json`; preserve `--version` as 0.1.
Use Python standard library. Input is an array of objects with unique string
`id`, nonnegative integer `age_days` (booleans excluded), and boolean `pinned`.
Return a sorted JSON array of deletion IDs. No records/files are deleted.

Delete only unpinned records strictly older than 30 days. Age 30 is retained.
Pinned records are always retained, regardless of age. These rules were explicitly
confirmed by the owner. No unresolved business decisions remain.
Empty input returns []. Invalid input produces a nonzero CLI error, no JSON output.
Acceptance: exercise ages 0, 29, 30, 31 and a large age with both pin values,
verify sorted selected IDs, empty input, validation errors and unchanged version.
