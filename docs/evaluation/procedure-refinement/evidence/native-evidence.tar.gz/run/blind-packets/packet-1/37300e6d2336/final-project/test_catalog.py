import json,subprocess,sys,tempfile,unittest
class Catalog(unittest.TestCase):
 def test_empty_list(self):
  with tempfile.TemporaryDirectory() as d:
   self.assertEqual(json.loads(subprocess.check_output([sys.executable,'catalog.py','--db',d+'/x.sqlite','list'])),[])

 def test_import_list_contract(self):
  with tempfile.TemporaryDirectory() as d:
   from pathlib import Path
   db = d + '/x.sqlite'
   source = Path(d) / 'items.csv'
   source.write_text('sku,name,price_cents\n AbC , First , 12 \nAbC,Duplicate,99\nabc,Case variant,0\nbad,Negative,-1\n,Missing SKU,2\nx,,2\ny,Decimal,1.5\nshort,Missing\nextra,Extra,3,field\nlast,Valid,7\n')
   command = [sys.executable, 'catalog.py', '--db', db]
   result = subprocess.run(command + ['import', str(source)], capture_output=True, text=True)
   self.assertEqual(result.returncode, 0, result.stderr)
   for row in (5, 6, 7, 8, 9, 10):
    self.assertIn('row ' + str(row) + ':', result.stderr)
   expected = [dict(sku='AbC', name='First', price_cents=12),
               dict(sku='abc', name='Case variant', price_cents=0),
               dict(sku='last', name='Valid', price_cents=7)]
   self.assertEqual(json.loads(subprocess.check_output(command + ['list'])), expected)
   source.write_text('sku,name,price_cents\nAbC,Replacement,100\nnew,New,8\n')
   subprocess.run(command + ['import', str(source)], check=True, capture_output=True)
   self.assertEqual(json.loads(subprocess.check_output(command + ['list'])),
                    expected + [dict(sku='new', name='New', price_cents=8)])

 def test_summary_contract(self):
  with tempfile.TemporaryDirectory() as d:
   from pathlib import Path
   command = [sys.executable, 'catalog.py', '--db', d + '/x.sqlite']
   self.assertEqual(json.loads(subprocess.check_output(command + ['summary'])), [])
   source = Path(d) / 'items.csv'
   source.write_text('sku,name,price_cents\nfree,Free,0\n')
   subprocess.run(command + ['import', str(source)], check=True, capture_output=True)
   self.assertEqual(json.loads(subprocess.check_output(command + ['summary'])),
                    [dict(supplier='legacy', count=1, total_cents=0)])
   source.write_text('sku,name,price_cents\nA,First,9223372036854775807\nB,Second,7\n')
   subprocess.run(command + ['import', str(source)], check=True, capture_output=True)
   self.assertEqual(json.loads(subprocess.check_output(command + ['summary'])),
                    [dict(supplier='legacy', count=3, total_cents=9223372036854775814)])
   self.assertEqual(len(json.loads(subprocess.check_output(command + ['list']))), 3)
