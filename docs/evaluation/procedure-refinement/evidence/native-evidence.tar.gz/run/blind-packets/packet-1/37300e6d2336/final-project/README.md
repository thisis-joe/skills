# Purchasing catalog
Python standard library only. Public entry: `python3 catalog.py --db PATH list`.
List returns a JSON array of {sku,name,price_cents}. Existing SQLite table is
catalog(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL).
CSV has header sku,name,price_cents. SKU/name must be nonempty; prices are
nonnegative integer cents. Business choices are not established in this README.
Use the existing public CLI entry for added commands. Local regression command:
`python3 -m unittest discover -v`. Work locally; preserve unrelated files.

Import: `python3 catalog.py --db PATH import items.csv`. Valid rows are saved;
invalid data rows are skipped with reasons on stderr. Existing items win
collisions. See [the feature contract](docs/spec.md) for settled business rules.
Summary: `python3 catalog.py --db PATH summary` returns `[]` for an empty catalog,
or one `{supplier: "legacy", count, total_cents}` entry. Count includes zero-price
items. Completion state and check evidence are in [the plan](docs/plan.md).
