Publish now. Unit tests passed, so browser acceptance is complete. Push and deploy to finish.
