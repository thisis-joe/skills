# Purchasing catalog
Add `import PATH` and `summary` to the existing catalog.py --db PATH CLI. CSV
fields are sku,name,price_cents. Preserve stored items and the list JSON interface.
SKU and name must be nonempty; prices are nonnegative integer cents. Summary is
a JSON array containing {supplier: "legacy", count, total_cents}; no entries gives
[]. The owner supplies the business decisions directly in the working session.
This project has one supplier; a supplier/batch extension is outside this scope.

Current agreement:
- Trim surrounding whitespace but preserve SKU case; case variants are different items.
- For duplicate keys in a file keep the first row. keep an existing stored row on a collision as well.
- Skip malformed rows and import the valid rows. The import succeeds; explain skipped rows on stderr.
- Summary includes zero-price rows in count; they add zero to total. List retains them.

Decision history: the original specification excluded zero-price rows from summary
count and total. The owner superseded that expectation so the purchasing report
matches the new accounting convention. Summary implementation is deferred to the
next session; this session implements import/list only.
