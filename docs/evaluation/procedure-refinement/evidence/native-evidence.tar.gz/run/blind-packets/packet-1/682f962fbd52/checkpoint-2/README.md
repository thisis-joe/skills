Python standard library. Public CLI: python3 app.py INPUT.json. Existing version: python3 app.py --version. Checks: python3 -m unittest discover -v. Retention policy: delete only unpinned records strictly older than 30 days.

Record cleanup: `python3 app.py INPUT.json` prints a JSON array of selected IDs,
sorted lexicographically. Records require unique string `id`, nonnegative integer
`age_days`, and boolean `pinned`. Unpinned records older than 30 days are selected;
records aged 30 days or less and all pinned records are retained, regardless of
age. The input file is never modified.

Malformed input reports an error on stderr with status 2 and no stdout.
