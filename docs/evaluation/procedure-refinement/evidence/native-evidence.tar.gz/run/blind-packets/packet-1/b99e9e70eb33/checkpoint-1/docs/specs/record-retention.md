# Record retention

Public interface: `python3 app.py INPUT.json`; preserve `--version` as 0.1.
Use Python standard library. Input is an array of objects with unique string
`id`, nonnegative integer `age_days` (booleans excluded), and boolean `pinned`.
Return a sorted JSON array of deletion IDs. No records/files are deleted.

Settled slice: ages below 30 are retained; unpinned ages above 30 are selected.
Empty input returns []. Invalid input produces a nonzero CLI error, no JSON output.

Owner decisions pending:
- Is age exactly 30 eligible, or does eligibility begin at 31?
- Does pinned always prevent deletion, even after the retention period?

Do not adopt either default. Until answered, an age-30 record or a pinned record
older than 30 causes an explicit unresolved-policy error, with no partial output.
This is a temporary incomplete implementation, not a finished retention policy.
Acceptance for full feature remains blocked on these decisions and corresponding tests.
