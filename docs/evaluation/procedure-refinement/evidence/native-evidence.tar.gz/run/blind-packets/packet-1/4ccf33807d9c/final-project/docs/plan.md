One ready task: implement CSV import with CLI regression checks, then commit. Summary follows later.
