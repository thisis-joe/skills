Committed import/list as `e2169f5` on `feature/catalog-import-list`. Nothing pushed.

- Both unittest tests and actual CLI checks passed.
- Same-agent inspection completed; no independent review performed.
- Summary remains unimplemented. [The execution plan](docs/plan.md) records the handoff and next safe action; no product decisions remain open.
- Unrelated `personal-notes.txt` remains untouched.

Original expectation: summary excluded zero-price rows. Actual decision: count them, contributing zero to total, so the purchasing report matches the new accounting convention. This changes summary counts; list retains zero-price rows.