import json,subprocess,sys,tempfile,unittest
class Catalog(unittest.TestCase):
 def test_empty_list(self):
  with tempfile.TemporaryDirectory() as d:
   self.assertEqual(json.loads(subprocess.check_output([sys.executable,'catalog.py','--db',d+'/x.sqlite','list'])),[])

 def test_import_list(self):
  with tempfile.TemporaryDirectory() as d:
   from pathlib import Path
   db=d+'/x.sqlite'
   source=Path(d)/'items.csv'
   def run(*args):
    return subprocess.run([sys.executable,'catalog.py','--db',db,*args],capture_output=True,text=True)
   source.write_text('sku,name,price_cents\n A , First , 12 \nA,Duplicate,99\na,Lower,0\n,Missing,2\nB,Bad,-1\nC,Bad,1.5\nD,Missing\nE,Extra,2,oops\nF,Overflow,9223372036854775808\nG,Good,7\n')
   result=run('import',str(source))
   self.assertEqual(result.returncode,0,result.stderr)
   for line in (5,6,7,8,9,10):
    self.assertIn('row '+str(line)+':',result.stderr)
   expected=[{'sku':'A','name':'First','price_cents':12},{'sku':'G','name':'Good','price_cents':7},{'sku':'a','name':'Lower','price_cents':0}]
   self.assertEqual(json.loads(run('list').stdout),expected)
   source.write_text('sku,name,price_cents\nA,Replacement,44\nH,New,3\n')
   self.assertEqual(run('import',str(source)).returncode,0)
   self.assertEqual(json.loads(run('list').stdout),expected[:2]+[{'sku':'H','name':'New','price_cents':3}]+expected[2:])

 def test_summary(self):
  with tempfile.TemporaryDirectory() as d:
   from pathlib import Path
   db=d+'/x.sqlite'
   def run(*args):
    result=subprocess.run([sys.executable,'catalog.py','--db',db,*args],capture_output=True,text=True)
    self.assertEqual(result.returncode,0,result.stderr)
    self.assertEqual(result.stderr,'')
    return result.stdout
   self.assertEqual(json.loads(run('summary')),[])
   source=Path(d)/'items.csv'
   source.write_text('sku,name,price_cents\nZ,Free,0\n')
   run('import',str(source))
   self.assertEqual(json.loads(run('summary')),[{'supplier':'legacy','count':1,'total_cents':0}])
   source.write_text('sku,name,price_cents\nA,Paid,12\nB,Other,7\n')
   run('import',str(source))
   before=run('list')
   self.assertEqual(json.loads(run('summary')),[{'supplier':'legacy','count':3,'total_cents':19}])
   self.assertEqual(run('list'),before)
