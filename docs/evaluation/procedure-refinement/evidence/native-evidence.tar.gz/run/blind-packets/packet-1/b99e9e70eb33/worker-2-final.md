Implemented and committed as `30d867d` on `feature/record-retention`.

The CLI selects only unpinned records older than 30 days. Age 30 and all pinned records are retained—exactly matching your rules, with no departure.

All six tests and real CLI checks pass; `--version` remains `0.1`. Same-agent inspection completed. Unrelated work is preserved, nothing was pushed, and no decisions remain unresolved.