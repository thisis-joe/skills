import argparse
import csv
import json
import sqlite3
import sys


def import_rows(connection, path):
    with open(path, newline='', encoding='utf-8') as source:
        reader = csv.reader(source)
        if next(reader, None) != ['sku', 'name', 'price_cents']:
            raise ValueError('expected CSV header sku,name,price_cents')
        while True:
            try:
                row = next(reader)
            except StopIteration:
                break
            except csv.Error as error:
                print(f'row {reader.line_num}: skipped: {error}', file=sys.stderr)
                continue
            if len(row) != 3:
                print(f'row {reader.line_num}: skipped: expected three fields', file=sys.stderr)
                continue
            sku, name, price = (field.strip() for field in row)
            # SQLite stores signed 64-bit integers; reject out-of-range input.
            if (not sku or not name or not price or
                    any(char not in '0123456789' for char in price) or
                    len(price.lstrip('0')) > 19):
                print(f'row {reader.line_num}: skipped: invalid SKU, name or price', file=sys.stderr)
                continue
            cents = int(price.lstrip('0') or '0')
            if cents > 9223372036854775807:
                print(f'row {reader.line_num}: skipped: price exceeds storage range', file=sys.stderr)
                continue
            connection.execute(
                'INSERT OR IGNORE INTO catalog (sku,name,price_cents) VALUES (?,?,?)',
                (sku, name, cents))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    args = parser.parse_args()
    connection = sqlite3.connect(args.db)
    try:
        with connection:
            connection.execute('CREATE TABLE IF NOT EXISTS catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
            if args.command == 'import':
                import_rows(connection, args.path)
            else:
                print(json.dumps([dict(sku=k, name=n, price_cents=v) for k, n, v in
                                  connection.execute('SELECT sku,name,price_cents FROM catalog ORDER BY sku')]))
    except (OSError, ValueError, csv.Error) as error:
        parser.exit(1, f'import failed: {error}\n')
    finally:
        connection.close()


if __name__ == '__main__':
    main()
