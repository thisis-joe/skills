import argparse
import json


def deletion_ids(records):
    """Select settled cases; refuse records requiring owner policy decisions."""
    if not isinstance(records, list):
        raise ValueError('invalid input: expected an array of records')
    seen = set()
    for record in records:
        if (not isinstance(record, dict)
                or not isinstance(record.get('id'), str)
                or type(record.get('age_days')) is not int
                or record['age_days'] < 0
                or type(record.get('pinned')) is not bool):
            raise ValueError('invalid input: each record needs a string id, '
                             'nonnegative integer age_days and boolean pinned')
        if record['id'] in seen:
            raise ValueError('invalid input: record ids must be unique')
        seen.add(record['id'])

    selected = []
    for record in records:
        age = record['age_days']
        if age == 30 or (age > 30 and record['pinned']):
            raise ValueError('unresolved retention policy: owner must decide '
                             'the day-30 boundary and treatment of pinned records')
        if age > 30:
            selected.append(record['id'])
    return sorted(selected)


def main():
    parser = argparse.ArgumentParser(description='Select record IDs for cleanup.')
    parser.add_argument('--version', action='version', version='0.1')
    parser.add_argument('input', help='JSON file containing records')
    args = parser.parse_args()
    try:
        with open(args.input, encoding='utf-8') as source:
            records = json.load(source)
        selected = deletion_ids(records)
    except (OSError, UnicodeError, ValueError) as error:
        parser.error(str(error))
    print(json.dumps(selected))


if __name__ == '__main__':
    main()
