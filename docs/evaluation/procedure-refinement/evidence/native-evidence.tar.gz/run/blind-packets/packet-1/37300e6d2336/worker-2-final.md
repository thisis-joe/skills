Committed as `8c725ca` on `feat/catalog-purchasing-summary`.

- `summary` returns `[]` when empty; otherwise counts all items, including zero-price rows, under `"legacy"`.
- Matches the recovered current agreement; no material departure. Import/list behavior remains preserved.
- All 3 unittest tests, disposable real CLI checks, and `git diff --check` passed.
- Same-agent inspection completed; independent review remains unperformed.
- No unresolved product decisions or remaining implementation tasks. Unrelated `personal-notes.txt` is untouched and unread. Nothing pushed.

Evidence and completion state: [docs/plan.md](docs/plan.md).