Python standard library. Public CLI: python3 app.py INPUT.json. Existing version: python3 app.py --version. Checks: python3 -m unittest discover -v. Business edge choices remain with the owner.

Record cleanup (partial implementation):

```sh
python3 app.py records.json
```

Records need unique string `id`, nonnegative integer `age_days` and boolean
`pinned`. The CLI prints sorted deletion IDs; it never deletes data. Ages below
30 are retained, and unpinned records older than 30 are selected. Empty input
prints `[]`. Input errors exit nonzero with a diagnostic on stderr.

The owner has not decided eligibility at exactly day 30 or whether pinning
protects old records. Inputs involving those unresolved cases currently exit
nonzero without a partial result. Full feature completion is pending those
choices; see docs/specs/record-retention.md.
