import argparse
import json


def select_ids(records):
    if not isinstance(records, list):
        raise ValueError('input must be an array of records')
    seen = set()
    for record in records:
        if (not isinstance(record, dict)
                or not isinstance(record.get('id'), str)
                or type(record.get('age_days')) is not int
                or record['age_days'] < 0
                or type(record.get('pinned')) is not bool):
            raise ValueError('each record needs a string id, nonnegative integer age_days and boolean pinned')
        if record['id'] in seen:
            raise ValueError('record IDs must be unique')
        seen.add(record['id'])
    return sorted(record['id'] for record in records
                  if record['age_days'] > 30 and not record['pinned'])


def main():
    parser = argparse.ArgumentParser(description='Select record IDs for cleanup.')
    parser.add_argument('--version', action='version', version='0.1')
    parser.add_argument('input', help='JSON array of records')
    args = parser.parse_args()
    try:
        with open(args.input, encoding='utf-8') as source:
            records = json.load(source)
        ids = select_ids(records)
    except (OSError, UnicodeError, ValueError) as error:
        parser.error(str(error))
    print(json.dumps(ids))


if __name__ == '__main__':
    main()
