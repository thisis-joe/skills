import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class RetentionCLI(unittest.TestCase):
    def run_cli(self, records):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'input.json'
            path.write_text(json.dumps(records), encoding='utf-8')
            return subprocess.run([sys.executable, 'app.py', str(path)],
                                  capture_output=True, text=True)

    def test_determinate_selection(self):
        result = self.run_cli([
            {'id': 'z', 'age_days': 31, 'pinned': False},
            {'id': 'keep', 'age_days': 29, 'pinned': True},
            {'id': 'a', 'age_days': 90, 'pinned': False},
            {'id': 'new', 'age_days': 0, 'pinned': False},
        ])
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), ['a', 'z'])

    def test_empty(self):
        result = self.run_cli([])
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), [])

    def test_boundary_and_pinned_records_are_retained(self):
        for age, pinned in [(29, False), (30, False), (30, True), (31, True), (10000, True)]:
            with self.subTest(age=age, pinned=pinned):
                result = self.run_cli([
                    {'id': 'eligible', 'age_days': 99, 'pinned': False},
                    {'id': 'retained', 'age_days': age, 'pinned': pinned},
                ])
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(json.loads(result.stdout), ['eligible'])

    def test_invalid_records(self):
        valid = {'id': 'x', 'age_days': 1, 'pinned': False}
        for records in [{}, [None], [{}], [valid, valid],
                        [dict(valid, age_days=True)],
                        [dict(valid, age_days=-1)],
                        [dict(valid, age_days=1.5)],
                        [dict(valid, pinned=0)], [dict(valid, id=1)]]:
            with self.subTest(records=records):
                result = self.run_cli(records)
                self.assertEqual(result.returncode, 2)
                self.assertEqual(result.stdout, '')

    def test_bad_json_and_missing_file(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'input.json'
            for content in ['{', None]:
                if content is not None:
                    path.write_text(content, encoding='utf-8')
                else:
                    path.unlink()
                result = subprocess.run([sys.executable, 'app.py', str(path)],
                                        capture_output=True, text=True)
                self.assertEqual(result.returncode, 2)
                self.assertEqual(result.stdout, '')
