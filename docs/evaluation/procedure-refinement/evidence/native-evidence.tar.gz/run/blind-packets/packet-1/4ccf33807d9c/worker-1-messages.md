I’ll read the project context and any local `.guide` procedures, then recommend a next step with a ready-to-use prompt. I’ll keep everything read-only and won’t open global skill files.

The project brief says CSV import is ready to implement, with summary deferred. I’ll use the local `coco-tellmeskill` and `coco-whattosay` procedures to explain the fit and give you a starting prompt; I won’t activate the implementation workflow.

You’re at the **implementation stage**. I recommend **`coco-build`** next: it turns an agreed task into tested implementation commits. [The local workflow](.guide/_coco-shared/workflow.md) calls for this focused recommendation after the introductory map.

The fit is clear: [the brief](BRIEF.md) says requirements are settled, [the plan](docs/plan.md) identifies CSV import as the one ready task, and `catalog.py` currently supports only `list`.

Expect CSV import with atomic updates, trimmed lowercase SKU keys, last-row-wins behavior, and preserved stored items/list JSON. Completion should include real CLI checks, the existing unittest suite, and a task commit on a descriptive feature branch, with **formal review pending**. Summary remains deferred.

Use this starting request when you want execution:

```text
$coco-build Implement only the CSV import task in docs/plan.md,
following docs/spec.md and AGENTS.md. Preserve stored data, the list
JSON interface, and unrelated personal-notes.txt. Use Python stdlib,
verify through real CLI calls, run python3 -m unittest discover -v,
and commit the task on a descriptive feature branch. Defer summary.
Keep skill transitions manual; stop with formal review pending.
Do not publish.
```

Your manual boundary remains intact: this is a recommendation, not activation. You can request **this skill once** using the prompt above; automatic basic steps for this spec would require a separate explicit choice. I made no file changes or commits.