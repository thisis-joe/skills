# Record retention

Implement app.py INPUT.json for record cleanup.
Input is an array of records with unique id strings, nonnegative integer age_days
and boolean pinned. Return a sorted JSON array of IDs selected for deletion under
a 30-day retention policy. The precise retention edge behavior is not settled.
Keep --version working; standard library only.
