Python standard library. Public CLI: `python3 app.py INPUT.json`.
Version: `python3 app.py --version` (0.1).
Checks: `python3 -m unittest discover -v`.

Records need unique string `id`, nonnegative integer `age_days` and boolean
`pinned`. The CLI prints a sorted JSON array of deletion IDs; it never deletes
data. Only unpinned records strictly older than 30 days are selected. Age 30
and all pinned records are retained. Empty input prints `[]`. Invalid input
exits nonzero with a diagnostic on stderr and no partial JSON output.

See docs/specs/record-retention.md for the confirmed policy.
