# Purchasing catalog
Python standard library only. Public entry: `python3 catalog.py --db PATH list`.
List returns a JSON array of {sku,name,price_cents}. Existing SQLite table is
catalog(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL).
CSV has header sku,name,price_cents. SKU/name must be nonempty; prices are
nonnegative integer cents. Business choices are not established in this README.
Use the existing public CLI entry for added commands. Local regression command:
`python3 -m unittest discover -v`. Work locally; preserve unrelated files.

Import: `python3 catalog.py --db PATH import FILE.csv`. The header must be
`sku,name,price_cents`. Surrounding field whitespace is trimmed; SKU case is
preserved. First valid rows and existing stored rows win collisions. Invalid
rows are skipped with row diagnostics on stderr; valid rows are committed and
the command succeeds. Prices must fit SQLite's nonnegative signed 64-bit range.
Missing/unreadable files or invalid headers fail the import without changing
stored rows. Import produces no stdout; use `list` for the JSON catalog.
Summary is planned but not implemented. See docs/spec.md and docs/plan.md.
