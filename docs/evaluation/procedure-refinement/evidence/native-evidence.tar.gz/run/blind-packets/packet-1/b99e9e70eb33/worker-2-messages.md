I’ll apply those rules using the local build procedure, update the boundary tests, exercise the CLI, and commit the completed policy on the existing feature branch.


The policy tests now pass for both pin values at ages 0, 29, 30, 31, and 1,000,000. The full six-test suite passes, and a real CLI run returned `["a", "z"]`, retaining the day-30 and old pinned records. I’m recording the checks and committing the change.


Implemented and committed as `30d867d` on `feature/record-retention`.

The CLI selects only unpinned records older than 30 days. Age 30 and all pinned records are retained—exactly matching your rules, with no departure.

All six tests and real CLI checks pass; `--version` remains `0.1`. Same-agent inspection completed. Unrelated work is preserved, nothing was pushed, and no decisions remain unresolved.