import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class RetentionCLI(unittest.TestCase):
    def run_cli(self, records):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'records.json'
            path.write_text(json.dumps(records), encoding='utf-8')
            return subprocess.run([sys.executable, 'app.py', str(path)],
                                  capture_output=True, text=True)

    def test_settled_selection_sorted(self):
        result = self.run_cli([
            {'id': 'z', 'age_days': 31, 'pinned': False},
            {'id': 'young', 'age_days': 29, 'pinned': True},
            {'id': 'a', 'age_days': 100, 'pinned': False},
        ])
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), ['a', 'z'])

    def test_empty(self):
        result = self.run_cli([])
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), [])

    def test_pending_decisions_never_emit_partial_selection(self):
        for age, pinned in [(30, False), (30, True), (31, True)]:
            with self.subTest(age=age, pinned=pinned):
                result = self.run_cli([
                    {'id': 'eligible', 'age_days': 40, 'pinned': False},
                    {'id': 'pending', 'age_days': age, 'pinned': pinned},
                ])
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(result.stdout, '')
                self.assertIn('unresolved retention policy', result.stderr)

    def test_invalid_schema(self):
        valid = {'id': 'a', 'age_days': 31, 'pinned': False}
        for records in [{}, [None], [{}], [dict(valid, id=1)],
                        [dict(valid, age_days=True)], [dict(valid, age_days=-1)],
                        [dict(valid, age_days=1.5)], [dict(valid, pinned=1)],
                        [valid, valid]]:
            with self.subTest(records=records):
                result = self.run_cli(records)
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(result.stdout, '')
                self.assertIn('invalid input', result.stderr)

    def test_unreadable_or_malformed_input(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'records.json'
            for content in [None, '{', '\xff']:
                with self.subTest(content=content):
                    if content is not None:
                        path.write_bytes(content.encode('latin-1'))
                    result = subprocess.run(
                        [sys.executable, 'app.py', str(path)],
                        capture_output=True, text=True)
                    self.assertNotEqual(result.returncode, 0)
                    self.assertEqual(result.stdout, '')
                    self.assertIn('error:', result.stderr)
                    self.assertNotIn('Traceback', result.stderr)
