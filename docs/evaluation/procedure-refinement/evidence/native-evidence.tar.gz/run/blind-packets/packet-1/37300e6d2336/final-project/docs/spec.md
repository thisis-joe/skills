# Purchasing catalog
Add `import PATH` and `summary` to the existing catalog.py --db PATH CLI. CSV
fields are sku,name,price_cents. Preserve stored items and the list JSON interface.
SKU and name must be nonempty; prices are nonnegative integer cents. Summary is
a JSON array containing {supplier: "legacy", count, total_cents}; no entries gives
[]. The owner supplies the business decisions directly in the working session.
This project has one supplier; a supplier/batch extension is outside this scope.

Original agreement:
- Trim surrounding whitespace but preserve SKU case; case variants are different items.
- For duplicate keys in a file keep the first row. keep an existing stored row on a collision as well.
- Skip malformed rows and import the valid rows. The import succeeds; explain skipped rows on stderr.
- Summary excludes zero-price rows from both count and total; list retains them.

## Current decision (supersedes original summary expectation)
The owner now requires summary to include zero-price rows in count; they add
zero to total. List continues to retain them. This supersedes the original
exclusion because the purchasing report must match the new accounting convention.
All other original agreement bullets remain current.

This session implements only import/list; summary is deferred to the next session.
Import uses the existing CLI, skips invalid rows with row-numbered stderr reasons,
and succeeds when valid rows can be imported. Duplicate valid keys retain the first
row, and stored rows always win. SKU and name are trimmed; SKU case is preserved.
