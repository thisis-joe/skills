# Ready implementation

The accepted specification and one-task plan are saved in docs/. The next task is to add CSV import to catalog.py. Public inputs, errors and acceptance are settled; nothing has been implemented yet.
