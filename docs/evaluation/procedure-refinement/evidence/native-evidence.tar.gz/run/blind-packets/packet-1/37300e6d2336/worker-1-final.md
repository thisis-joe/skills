Implemented and committed import/list on `feat/catalog-import-list`.

- `0f1a765`: implementation, tests and records.
- `3d80c0b`: handoff commit receipt.
- Both unittest tests and disposable real CLI checks passed.
- Summary remains unimplemented. Next steps are saved in [docs/plan.md](docs/plan.md).
- Inspection was same-agent, not independent review.

Original expectation: summary excluded zero-price rows. Current decision: include them in count, adding zero to total, so purchasing reports match the new accounting convention. Both history and rationale survive in [docs/spec.md](docs/spec.md).

No unresolved product decisions. Existing data and unrelated work were preserved. Nothing was pushed.