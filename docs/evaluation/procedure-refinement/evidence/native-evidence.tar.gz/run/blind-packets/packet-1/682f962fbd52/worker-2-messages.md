I’ll apply those rules, update the tests and documentation, then run the CLI and unittest suite before committing.


Implemented and committed as `010fe34` on `feat/record-retention`.

Behavior matches your rules: only unpinned records older than 30 days are selected. Age 30 and all pinned records are retained. No material departure or unresolved decisions.

All six tests and real CLI checks passed; `--version` works. Same-agent inspection completed. Unrelated work preserved; nothing pushed.