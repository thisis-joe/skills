import unittest
from pathlib import Path
class Details(unittest.TestCase):
 def test_markup(self):
  page=Path('index.html').read_text();self.assertIn('aria-expanded="false"',page);self.assertIn("addEventListener('click'",page)
