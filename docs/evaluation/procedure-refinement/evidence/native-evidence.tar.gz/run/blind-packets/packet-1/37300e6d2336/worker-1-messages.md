I’ll read the project code and local procedures, implement and check import/list, then commit that slice with a handoff for the summary work.


I’m using the local build and context procedures. The plan already separates import/list from summary, and the spec still records the original zero-price rule. I’ll preserve that history, record your superseding decision, and leave summary unimplemented.


The CLI regression now passes after first failing because `import` did not exist. It checks trimming, case-sensitive SKUs, first-row and stored-row precedence, malformed-row diagnostics, and zero-price retention in list. I’ll check the CLI once more with a disposable database, inspect the diff, and commit the checkpoint; summary remains untouched.


Implemented and committed import/list on `feat/catalog-import-list`.

- `0f1a765`: implementation, tests and records.
- `3d80c0b`: handoff commit receipt.
- Both unittest tests and disposable real CLI checks passed.
- Summary remains unimplemented. Next steps are saved in [docs/plan.md](docs/plan.md).
- Inspection was same-agent, not independent review.

Original expectation: summary excluded zero-price rows. Current decision: include them in count, adding zero to total, so purchasing reports match the new accounting convention. Both history and rationale survive in [docs/spec.md](docs/spec.md).

No unresolved product decisions. Existing data and unrelated work were preserved. Nothing was pushed.