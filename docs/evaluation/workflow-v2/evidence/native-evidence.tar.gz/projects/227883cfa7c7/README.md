# Purchasing catalog

Python standard library only. Public commands:

```sh
python3 catalog.py --db PATH import INPUT.csv
python3 catalog.py --db PATH list
python3 -m unittest discover -v
```

Import reads UTF-8 CSV with the exact header `sku,name,price_cents`.
Surrounding field whitespace is trimmed; SKU keys are lowercased. SKU and name
must be nonempty. Prices are nonnegative decimal integer cents within SQLite's
signed 64-bit range. Each data row must have exactly three fields. The last row
for a normalized SKU wins; later imports replace stored rows for that SKU,
including existing case/whitespace variants. Other stored rows are preserved.
An invalid file is rejected before database access; valid imports write in one
transaction. Success exits 0 with no output; errors exit nonzero on stderr.

List returns the existing JSON array of `{sku,name,price_cents}`, sorted by stored
SKU, including zero-price rows. Existing SQLite table remains
`catalog(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)`.

Summary is deferred. See `HANDOFF.md` for settled requirements and the next step.
