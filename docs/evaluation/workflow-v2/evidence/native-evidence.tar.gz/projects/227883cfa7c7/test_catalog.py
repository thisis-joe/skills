import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest


class Catalog(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.db = self.root / 'catalog.sqlite'

    def cli(self, *args):
        return subprocess.run(
            [sys.executable, 'catalog.py', '--db', str(self.db), *args],
            text=True, capture_output=True,
        )

    def rows(self):
        result = self.cli('list')
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def load(self, text):
        path = self.root / 'input.csv'
        path.write_text(text, encoding='utf-8')
        return self.cli('import', str(path))

    def test_empty_list(self):
        self.assertEqual(self.rows(), [])

    def test_import_normalizes_duplicates_updates_and_retains_zero(self):
        self.assertEqual(self.load('sku,name,price_cents\n B , First ,10\nb,Last,0\na,Other,25\n').returncode, 0)
        self.assertEqual(self.rows(), [
            {'sku': 'a', 'name': 'Other', 'price_cents': 25},
            {'sku': 'b', 'name': 'Last', 'price_cents': 0},
        ])
        self.assertEqual(self.load('sku,name,price_cents\n B ,Updated,30\n').returncode, 0)
        self.assertEqual(self.rows()[1], {'sku': 'b', 'name': 'Updated', 'price_cents': 30})
        self.assertEqual(len(self.rows()), 2)

    def test_invalid_import_leaves_catalog_unchanged(self):
        self.assertEqual(self.load('sku,name,price_cents\nkeep,Original,7\n').returncode, 0)
        before = self.rows()
        for bad in ['x,,1', ',Name,1', 'x,Name,-1', 'x,Name,1.5',
                    'x,Name,9223372036854775808', 'x,Name', 'x,Name,1,extra',
                    'x,"unterminated,1']:
            with self.subTest(bad=bad):
                result = self.load('sku,name,price_cents\nkeep,Changed,9\n' + bad + '\n')
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(self.rows(), before)
        self.assertNotEqual(self.load('name,sku,price_cents\nName,x,1\n').returncode, 0)
        self.assertEqual(self.rows(), before)

    def test_preserves_unrelated_existing_rows(self):
        self.rows()
        with sqlite3.connect(self.db) as conn:
            conn.execute('INSERT INTO catalog VALUES (?, ?, ?)', ('Legacy', 'Stored', 12))
        self.assertEqual(self.load('sku,name,price_cents\nnew,New,3\n').returncode, 0)
        self.assertIn({'sku': 'Legacy', 'name': 'Stored', 'price_cents': 12}, self.rows())
        self.assertEqual(self.load('sku,name,price_cents\n LEGACY ,Updated,8\n').returncode, 0)
        self.assertEqual(self.rows()[0], {'sku': 'legacy', 'name': 'Updated', 'price_cents': 8})
