import argparse
import csv
import json
import sqlite3


def read_import(path):
    items = {}
    with open(path, newline='', encoding='utf-8') as source:
        rows = csv.reader(source, strict=True)
        if next(rows, None) != ['sku', 'name', 'price_cents']:
            raise ValueError('expected CSV header sku,name,price_cents')
        for row in rows:
            if len(row) != 3:
                raise ValueError(f'line {rows.line_num}: expected three fields')
            sku, name, price = (value.strip() for value in row)
            sku = sku.lower()
            if not sku or not name or not price or any(c not in '0123456789' for c in price):
                raise ValueError(f'line {rows.line_num}: invalid SKU, name or price')
            cents = int(price)
            if cents > 9223372036854775807:
                raise ValueError(f'line {rows.line_num}: price exceeds SQLite integer range')
            items[sku] = (name, cents)
    return items


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    args = parser.parse_args()
    try:
        # Validate the entire file before opening or modifying the database.
        items = read_import(args.path) if args.command == 'import' else None
        conn = sqlite3.connect(args.db)
        try:
            with conn:
                conn.execute('CREATE TABLE IF NOT EXISTS catalog '
                             '(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
                if items is not None:
                    # Python normalization also covers Unicode SKU case variants.
                    for (stored_sku,) in conn.execute('SELECT sku FROM catalog').fetchall():
                        if stored_sku.strip().lower() in items:
                            conn.execute('DELETE FROM catalog WHERE sku = ?', (stored_sku,))
                    conn.executemany('INSERT INTO catalog VALUES (?, ?, ?)',
                                     [(sku, name, cents) for sku, (name, cents) in items.items()])
                else:
                    print(json.dumps([
                        dict(sku=sku, name=name, price_cents=cents)
                        for sku, name, cents in conn.execute(
                            'SELECT sku,name,price_cents FROM catalog ORDER BY sku')
                    ]))
        finally:
            conn.close()
    except (OSError, UnicodeError, ValueError, csv.Error, sqlite3.Error) as error:
        parser.exit(1, f'catalog: {error}\n')


if __name__ == '__main__':
    main()
