import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class Catalog(unittest.TestCase):
    def cli(self, db, *args):
        return subprocess.run(
            [sys.executable, 'catalog.py', '--db', str(db), *args],
            text=True, capture_output=True,
        )

    def test_empty_list(self):
        with tempfile.TemporaryDirectory() as d:
            result = self.cli(Path(d) / 'x.sqlite', 'list')
            self.assertEqual(result.returncode, 0)
            self.assertEqual(json.loads(result.stdout), [])

    def test_summary(self):
        cases = [
            ('', []),
            ('A,Apple,125\nB,Banana,75\n',
             [{'supplier': 'legacy', 'count': 2, 'total_cents': 200}]),
            ('A,Free,0\nB,Paid,75\n',
             [{'supplier': 'legacy', 'count': 2, 'total_cents': 75}]),
            ('A,Free,0\n',
             [{'supplier': 'legacy', 'count': 1, 'total_cents': 0}]),
            ('A,Large,9223372036854775807\nB,Extra,1\n',
             [{'supplier': 'legacy', 'count': 2,
               'total_cents': 9223372036854775808}]),
        ]
        for rows, expected in cases:
            with self.subTest(rows=rows), tempfile.TemporaryDirectory() as d:
                db = Path(d) / 'x.sqlite'
                source = Path(d) / 'items.csv'
                source.write_text('sku,name,price_cents\n' + rows, encoding='utf-8')
                imported = self.cli(db, 'import', str(source))
                self.assertEqual(imported.returncode, 0, imported.stderr)
                before = self.cli(db, 'list')
                result = self.cli(db, 'summary')
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(result.stderr, '')
                self.assertEqual(json.loads(result.stdout), expected)
                after = self.cli(db, 'list')
                self.assertEqual(after.returncode, 0, after.stderr)
                self.assertEqual(after.stdout, before.stdout)

    def test_import_preserves_case_first_rows_and_zero_price(self):
        with tempfile.TemporaryDirectory() as d:
            db = Path(d) / 'x.sqlite'
            source = Path(d) / 'items.csv'
            source.write_text('sku,name,price_cents\n A , First , 10 \nA,Duplicate,99\na,Lowercase,0\n', encoding='utf-8')
            result = self.cli(db, 'import', str(source))
            self.assertEqual(result.returncode, 0, result.stderr)
            source.write_text('sku,name,price_cents\nA,Replacement,100\nB,New,25\n', encoding='utf-8')
            result = self.cli(db, 'import', str(source))
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(self.cli(db, 'list').stdout), [
                {'sku': 'A', 'name': 'First', 'price_cents': 10},
                {'sku': 'B', 'name': 'New', 'price_cents': 25},
                {'sku': 'a', 'name': 'Lowercase', 'price_cents': 0},
            ])

    def test_malformed_rows_are_explained_and_valid_rows_imported(self):
        with tempfile.TemporaryDirectory() as d:
            db = Path(d) / 'x.sqlite'
            source = Path(d) / 'items.csv'
            source.write_text('sku,name,price_cents\n,Missing,1\nX, ,1\nX,Negative,-1\nX,Fraction,1.5\nX,Missing\nX,Extra,1,oops\nX,Huge,999999999999999999999999\nX,Valid,2\n', encoding='utf-8')
            result = self.cli(db, 'import', str(source))
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stderr.count('Skipping row'), 7)
            self.assertEqual(json.loads(self.cli(db, 'list').stdout), [
                {'sku': 'X', 'name': 'Valid', 'price_cents': 2},
            ])

    def test_bad_header_does_not_replace_stored_data(self):
        with tempfile.TemporaryDirectory() as d:
            db = Path(d) / 'x.sqlite'
            source = Path(d) / 'items.csv'
            source.write_text('sku,name,price_cents\nOLD,Legacy,75\n', encoding='utf-8')
            self.assertEqual(self.cli(db, 'import', str(source)).returncode, 0)
            source.write_text('wrong,header\nA,Name\n', encoding='utf-8')
            result = self.cli(db, 'import', str(source))
            self.assertNotEqual(result.returncode, 0)
            self.assertIn('header', result.stderr)
            self.assertEqual(json.loads(self.cli(db, 'list').stdout), [
                {'sku': 'OLD', 'name': 'Legacy', 'price_cents': 75},
            ])
