import argparse
import csv
import json
import sqlite3
import sys


def import_items(connection, path):
    with open(path, newline='', encoding='utf-8') as source:
        rows = csv.reader(source)
        if next(rows, None) != ['sku', 'name', 'price_cents']:
            raise ValueError('CSV header must be sku,name,price_cents')
        for row in rows:
            try:
                if len(row) != 3:
                    raise ValueError('expected three fields')
                sku, name, price = (field.strip() for field in row)
                if not sku or not name:
                    raise ValueError('SKU and name must be nonempty')
                if not price or any(char not in '0123456789' for char in price):
                    raise ValueError('price_cents must be a nonnegative integer')
                price_cents = int(price)
                if price_cents > 9223372036854775807:
                    raise ValueError('price_cents exceeds SQLite integer range')
            except ValueError as error:
                print(f'Skipping row ending at line {rows.line_num}: {error}', file=sys.stderr)
                continue
            connection.execute(
                'INSERT OR IGNORE INTO catalog (sku, name, price_cents) VALUES (?, ?, ?)',
                (sku, name, price_cents),
            )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    commands.add_parser('summary')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    args = parser.parse_args()
    connection = sqlite3.connect(args.db)
    try:
        with connection:
            connection.execute(
                'CREATE TABLE IF NOT EXISTS catalog '
                '(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)'
            )
            if args.command == 'import':
                import_items(connection, args.path)
            elif args.command == 'summary':
                count = 0
                total_cents = 0
                for (price,) in connection.execute('SELECT price_cents FROM catalog'):
                    count += 1
                    total_cents += price
                print(json.dumps([
                    dict(supplier='legacy', count=count, total_cents=total_cents)
                ] if count else []))
            else:
                print(json.dumps([
                    dict(sku=sku, name=name, price_cents=price)
                    for sku, name, price in connection.execute(
                        'SELECT sku,name,price_cents FROM catalog ORDER BY sku'
                    )
                ]))
    except (OSError, UnicodeError, csv.Error, ValueError, sqlite3.Error) as error:
        parser.exit(1, f'catalog: {error}\n')
    finally:
        connection.close()


if __name__ == '__main__':
    main()
