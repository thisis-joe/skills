import json,subprocess,sys,tempfile,unittest
class Catalog(unittest.TestCase):
 def test_empty_list(self):
  with tempfile.TemporaryDirectory() as d:
   self.assertEqual(json.loads(subprocess.check_output([sys.executable,'catalog.py','--db',d+'/x.sqlite','list'])),[])

class ImportCatalog(unittest.TestCase):
 def test_cli_import_and_atomic_rejection(self):
  from pathlib import Path
  with tempfile.TemporaryDirectory() as d:
   source = Path(d) / 'items.csv'
   command = [sys.executable, 'catalog.py', '--db', d + '/catalog.sqlite']
   def run(*args):
    return subprocess.run(command + list(args), text=True, capture_output=True)
   def listing():
    result = run('list')
    self.assertEqual(result.returncode, 0, result.stderr)
    return json.loads(result.stdout)
   source.write_text('sku,name,price_cents\n B , First ,10\nb,Last,0\na,Other,25\n')
   self.assertEqual(run('import', str(source)).returncode, 0)
   self.assertEqual(listing(), [dict(sku='a',name='Other',price_cents=25), dict(sku='b',name='Last',price_cents=0)])
   source.write_text('sku,name,price_cents\n B ,Updated,40\n')
   self.assertEqual(run('import', str(source)).returncode, 0)
   before = listing()
   self.assertEqual(before[1], dict(sku='b',name='Updated',price_cents=40))
   for invalid in ['x,,2', ',Name,2', 'x,Name,-1', 'x,Name,1.5', 'x,Name,2,extra', 'x,Name', 'x,Name,9223372036854775808', '"unterminated', '']:
    source.write_text('sku,name,price_cents\nb,Changed,99\n' + invalid + '\n')
    result = run('import', str(source))
    self.assertNotEqual(result.returncode, 0, invalid)
    self.assertIn('error:', result.stderr)
    self.assertEqual(listing(), before)
   source.write_text('sku,name,bad\nx,Name,2\n')
   self.assertNotEqual(run('import', str(source)).returncode, 0)
   self.assertEqual(listing(), before)
   source.write_text('sku,name,price_cents\n')
   self.assertEqual(run('import', str(source)).returncode, 0)
   self.assertEqual(listing(), before)

class SummaryCatalog(unittest.TestCase):
 def test_summary_through_cli(self):
  from pathlib import Path
  with tempfile.TemporaryDirectory() as d:
   source = Path(d) / 'items.csv'
   command = [sys.executable, 'catalog.py', '--db', d + '/catalog.sqlite']
   def run(*args):
    result = subprocess.run(command + list(args), text=True, capture_output=True)
    self.assertEqual(result.returncode, 0, result.stderr)
    return result.stdout
   def summary():
    return json.loads(run('summary'))
   def import_rows(rows):
    source.write_text('sku,name,price_cents\n' + rows, encoding='utf-8')
    self.assertEqual(run('import', str(source)), '')
   self.assertEqual(summary(), [])
   import_rows('a,Free,0\n')
   self.assertEqual(summary(), [])
   import_rows('b,Paid,25\nc,Other,40\n')
   before = run('list')
   self.assertEqual(summary(), [dict(supplier='legacy', count=2, total_cents=65)])
   self.assertEqual(run('list'), before)
   self.assertEqual(len(json.loads(before)), 3)
   import_rows(' B ,Now free,0\nc,Updated,7\n')
   self.assertEqual(summary(), [dict(supplier='legacy', count=1, total_cents=7)])
   import_rows('c,Free too,0\n')
   self.assertEqual(summary(), [])
   import_rows('x,Large,9223372036854775807\ny,Large too,9223372036854775807\n')
   self.assertEqual(summary(), [dict(supplier='legacy', count=2, total_cents=18446744073709551614)])
