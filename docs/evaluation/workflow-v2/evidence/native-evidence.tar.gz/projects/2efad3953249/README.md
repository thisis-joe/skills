# Purchasing catalog
Python standard library only. Public entry: `python3 catalog.py --db PATH list`.
List returns a JSON array of {sku,name,price_cents}. Existing SQLite table is
catalog(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL).
CSV has header sku,name,price_cents. SKU/name must be nonempty; prices are
nonnegative integer cents. Business choices are not established in this README.
Use the existing public CLI entry for added commands. Local regression command:
`python3 -m unittest discover -v`. Work locally; preserve unrelated files.

Import with `python3 catalog.py --db PATH import FILE.csv`. Success exits 0
without output; invalid input exits nonzero with an error on stderr. The header
must contain exactly sku,name,price_cents (any order). Empty files are invalid;
header-only files are a no-op. Blank data rows are invalid.

Import trims surrounding whitespace, lowercases SKU keys, and trims names and
prices. Prices use decimal digits and must fit SQLite's signed integer range.
The last row for a normalized SKU wins; subsequent imports update that SKU.
Existing case/whitespace variants of an imported SKU are replaced by its
canonical row. Unmentioned stored rows are preserved. Validation finishes before
any database write, and all imported changes commit in one transaction.
`list` keeps its sorted JSON array interface and includes zero-price rows.

Run `python3 catalog.py --db PATH summary` for a JSON array containing
`{"supplier": "legacy", "count": N, "total_cents": T}`. Count and total include
only positive-price rows. An empty or all-zero catalog returns `[]`. Summary
reflects the current stored rows, including updates from subsequent imports.
