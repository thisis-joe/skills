import argparse
import csv
import json
import sqlite3


def read_import(path):
    """Validate the whole file before changing the catalog."""
    items = {}
    with open(path, encoding='utf-8', newline='') as source:
        rows = csv.reader(source, strict=True)
        header = next(rows, None)
        if header is None or len(header) != 3 or set(header) != {'sku', 'name', 'price_cents'}:
            raise ValueError('CSV header must contain sku,name,price_cents')
        for row in rows:
            if len(row) != 3:
                raise ValueError(f'line {rows.line_num}: expected three fields')
            values = dict(zip(header, row))
            sku = values['sku'].strip().lower()
            name = values['name'].strip()
            price = values['price_cents'].strip()
            if not sku or not name or not price or any(c not in '0123456789' for c in price):
                raise ValueError(f'line {rows.line_num}: invalid SKU, name, or price')
            cents = int(price)
            if cents > 9223372036854775807:
                raise ValueError(f'line {rows.line_num}: price exceeds SQLite integer range')
            items[sku] = (sku, name, cents)
    return list(items.values())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    commands.add_parser('summary')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    args = parser.parse_args()
    try:
        items = read_import(args.path) if args.command == 'import' else None
        connection = sqlite3.connect(args.db)
        try:
            with connection:
                connection.execute('CREATE TABLE IF NOT EXISTS catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
                if items is not None:
                    imported_keys = {item[0] for item in items}
                    legacy_keys = [
                        (sku,) for (sku,) in connection.execute('SELECT sku FROM catalog')
                        if sku.strip().lower() in imported_keys and sku != sku.strip().lower()
                    ]
                    connection.executemany('DELETE FROM catalog WHERE sku=?', legacy_keys)
                    connection.executemany(
                        'INSERT INTO catalog (sku,name,price_cents) VALUES (?,?,?) '
                        'ON CONFLICT(sku) DO UPDATE SET name=excluded.name, price_cents=excluded.price_cents',
                        items,
                    )
                elif args.command == 'summary':
                    count = total = 0
                    for (price,) in connection.execute(
                        'SELECT price_cents FROM catalog WHERE price_cents > 0'
                    ):
                        count += 1
                        total += price
                    print(json.dumps([
                        dict(supplier='legacy', count=count, total_cents=total)
                    ] if count else []))
                else:
                    print(json.dumps([
                        dict(sku=sku, name=name, price_cents=price)
                        for sku, name, price in connection.execute(
                            'SELECT sku,name,price_cents FROM catalog ORDER BY sku'
                        )
                    ]))
        finally:
            connection.close()
    except (OSError, UnicodeError, csv.Error, ValueError, sqlite3.Error) as error:
        parser.exit(1, f'error: {error}\n')


if __name__ == '__main__':
    main()
