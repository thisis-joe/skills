# Execution plan

1. Implement import/list with public CLI regression tests: normalization,
   last-row wins, later updates, preservation, zero-price listing, atomic rejection.
2. Run real CLI checks and unittest discovery, inspect own diff, commit the slice.
3. Record evidence and a resumable checkpoint; stop without summary or publishing.

At the original handoff, a colleague's next task was summary, starting with a failing CLI test against the
saved specification. No summary code belonged in that completed import work unit.

## Resumed summary work

4. Add a failing public CLI summary regression, implement the saved summary
   contract, and check empty, zero-only, mixed and updated catalogs.
5. Run unittest discovery and a disposable real CLI journey; inspect the owned
   diff, update the checkpoint and commit locally. Stop before push.
