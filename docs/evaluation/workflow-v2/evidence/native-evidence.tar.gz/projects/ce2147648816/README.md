# Purchasing catalog
Python standard library only. Public entry: `python3 catalog.py --db PATH list`.
List returns a JSON array of {sku,name,price_cents}. Existing SQLite table is
catalog(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL).
CSV has header sku,name,price_cents. SKU/name must be nonempty; prices are
nonnegative integer cents. Values are trimmed; SKU case is preserved. Duplicate SKUs keep the first valid
CSV row, and stored rows always win collisions. Malformed rows are skipped with
row diagnostics on stderr; valid rows are committed and import exits successfully.
Zero-price items remain in list results.
Use the existing public CLI entry for added commands. Local regression command:
`python3 -m unittest discover -v`. Work locally; preserve unrelated files.

Import: `python3 catalog.py --db PATH import items.csv` (no stdout on success).
Use UTF-8 CSV with the exact header above; prices use decimal digits and must
fit SQLite's signed 64-bit integer storage. Missing/unreadable files and invalid
headers fail the command. Diagnostics identify CSV physical line numbers (the
ending line for multiline records). CSV parser errors are skipped when parsing
can continue; an unterminated quoted record can consume the rest of the file.

Summary: `python3 catalog.py --db PATH summary`. Returns `[]` for an empty
catalog; otherwise returns `[{"supplier":"legacy","count":N,"total_cents":T}]`.
Count includes every stored row, including zero-price items. Totals use exact
integer cents, including sums beyond SQLite's per-item integer range.
See `HANDOFF.md` for the work checkpoint.
