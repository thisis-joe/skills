import argparse
import csv
import json
import sqlite3
import sys


def import_items(connection, path):
    with open(path, newline='', encoding='utf-8') as source:
        reader = csv.reader(source, strict=True)
        if next(reader, None) != ['sku', 'name', 'price_cents']:
            raise ValueError('CSV header must be sku,name,price_cents')
        with connection:
            while True:
                try:
                    row = next(reader)
                except StopIteration:
                    break
                except csv.Error as error:
                    print(f'Skipping row {reader.line_num}: {error}', file=sys.stderr)
                    continue
                reason = None
                if len(row) != 3:
                    reason = 'expected three fields'
                else:
                    sku, name, raw_price = (value.strip() for value in row)
                    if not sku or not name:
                        reason = 'SKU and name must be nonempty'
                    elif not raw_price or any(c not in '0123456789' for c in raw_price):
                        reason = 'price_cents must be a nonnegative integer'
                    else:
                        try:
                            price = int(raw_price)
                            if price > 9223372036854775807:
                                reason = 'price_cents exceeds SQLite integer range'
                        except ValueError:
                            reason = 'price_cents exceeds integer conversion limit'
                if reason:
                    print(f'Skipping row {reader.line_num}: {reason}', file=sys.stderr)
                    continue
                connection.execute(
                    'INSERT INTO catalog (sku,name,price_cents) VALUES (?,?,?) '
                    'ON CONFLICT(sku) DO NOTHING', (sku, name, price))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    commands.add_parser('summary')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    args = parser.parse_args()
    connection = sqlite3.connect(args.db)
    try:
        connection.execute('CREATE TABLE IF NOT EXISTS catalog '
                           '(sku TEXT PRIMARY KEY, name TEXT NOT NULL, '
                           'price_cents INTEGER NOT NULL)')
        if args.command == 'import':
            try:
                import_items(connection, args.path)
            except (OSError, UnicodeError, ValueError, csv.Error) as error:
                parser.error(str(error))
        elif args.command == 'summary':
            count = 0
            total = 0
            for price, in connection.execute('SELECT price_cents FROM catalog'):
                count += 1
                total += price
            print(json.dumps([dict(supplier='legacy', count=count, total_cents=total)]
                             if count else []))
        else:
            print(json.dumps([dict(sku=sku, name=name, price_cents=price)
                              for sku, name, price in connection.execute(
                                  'SELECT sku,name,price_cents FROM catalog ORDER BY sku')]))
    finally:
        connection.close()


if __name__ == '__main__':
    main()
