import json,subprocess,sys,tempfile,unittest
class Catalog(unittest.TestCase):
 def test_empty_list(self):
  with tempfile.TemporaryDirectory() as d:
   self.assertEqual(json.loads(subprocess.check_output([sys.executable,'catalog.py','--db',d+'/x.sqlite','list'])),[])

class CatalogImport(unittest.TestCase):
 def test_import_preserves_rows_and_skips_invalid(self):
  from pathlib import Path
  with tempfile.TemporaryDirectory() as d:
   db = d + '/x.sqlite'
   path = Path(d) / 'items.csv'
   def run(*args):
    return subprocess.run([sys.executable, 'catalog.py', '--db', db, *args],
                          text=True, capture_output=True)
   path.write_text('sku,name,price_cents\n A , First , 100 \nA,Duplicate,200\na,Case variant,0\n,Empty,10\nB,,20\nC,Negative,-1\nD,Fraction,1.5\nE,Missing\nF,Extra,10,oops\nG,Valid,30\n')
   result = run('import', str(path))
   self.assertEqual(result.returncode, 0, result.stderr)
   for line in (5, 6, 7, 8, 9, 10):
    self.assertIn('row ' + str(line), result.stderr)
   expected = [dict(sku='A', name='First', price_cents=100),
               dict(sku='G', name='Valid', price_cents=30),
               dict(sku='a', name='Case variant', price_cents=0)]
   self.assertEqual(json.loads(run('list').stdout), expected)
   path.write_text('sku,name,price_cents\nA,Overwrite,999\nZ,New,2\n')
   self.assertEqual(run('import', str(path)).returncode, 0)
   self.assertEqual(json.loads(run('list').stdout),
                    expected[:2] + [dict(sku='Z', name='New', price_cents=2)] + expected[2:])


class CatalogSummary(unittest.TestCase):
 def test_summary_empty_zero_and_mixed_catalog(self):
  from pathlib import Path
  with tempfile.TemporaryDirectory() as d:
   db = d + '/x.sqlite'
   path = Path(d) / 'items.csv'
   def run(*args):
    result = subprocess.run([sys.executable, 'catalog.py', '--db', db, *args],
                            text=True, capture_output=True)
    self.assertEqual(result.returncode, 0, result.stderr)
    self.assertEqual(result.stderr, '')
    return result.stdout
   self.assertEqual(json.loads(run('summary')), [])
   path.write_text('sku,name,price_cents\nFree,Free item,0\n')
   run('import', str(path))
   self.assertEqual(json.loads(run('summary')),
                    [dict(supplier='legacy', count=1, total_cents=0)])
   path.write_text('sku,name,price_cents\nA,First,10\nB,Second,3\n')
   run('import', str(path))
   before = run('list')
   self.assertEqual(json.loads(run('summary')),
                    [dict(supplier='legacy', count=3, total_cents=13)])
   self.assertEqual(run('list'), before)
   path.write_text('sku,name,price_cents\nMax,Maximum,9223372036854775807\n')
   run('import', str(path))
   self.assertEqual(json.loads(run('summary')),
                    [dict(supplier='legacy', count=4, total_cents=9223372036854775820)])
