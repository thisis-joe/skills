# Plan

1. On a descriptive feature branch, add failing CLI regression coverage for
   import/list, then implement CSV validation and transactional insert preserving
   existing data. Run focused checks, full unittest discovery and actual CLI
   fixtures; inspect the diff in this same agent and commit the tested work unit.
2. Save a project handoff with decisions, actual evidence and implementation
   commit, then commit that record. Stop at this checkpoint before summary/push.
3. Summary continuation (completed; evidence in HANDOFF.md): reconcile handoff
   with Git, implement summary with CLI tests
   for empty, zero-only and mixed catalogs, inspect and commit under owner scope.

Basic technical progress for this spec is automatic through checks and commits,
stopping before push. Separate specialist examinations are declined. Same-agent
inspection is accepted and must not be called independent review. No new product
choices are delegated. HANDOFF.md owns checkpoint status.
