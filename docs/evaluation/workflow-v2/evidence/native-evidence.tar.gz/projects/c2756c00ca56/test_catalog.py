import json
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


class Catalog(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.db = self.root / 'catalog.sqlite'

    def cli(self, *args):
        return subprocess.run([sys.executable, 'catalog.py', '--db', str(self.db), *args],
                              capture_output=True, text=True)

    def load(self, text):
        path = self.root / 'items.csv'
        path.write_text(text)
        return self.cli('import', str(path))

    def items(self):
        result = self.cli('list')
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def summary(self):
        result = self.cli('summary')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stderr, '')
        return json.loads(result.stdout)

    def test_summary_empty_and_zero_only(self):
        self.assertEqual(self.summary(), [])
        self.assertEqual(self.load('sku,name,price_cents\nz,Free,0\n').returncode, 0)
        self.assertEqual(self.summary(), [])
        self.assertEqual(self.items(), [dict(sku='z', name='Free', price_cents=0)])

    def test_summary_mixed_import_and_preserved_legacy(self):
        self.items()
        with sqlite3.connect(self.db) as conn:
            conn.execute('INSERT INTO catalog VALUES (?, ?, ?)', (' Legacy ', 'Old', 9))
        self.assertEqual(self.load('sku,name,price_cents\na,Apple,125\nb,Banana,26\nz,Free,0\n').returncode, 0)
        before = self.items()
        self.assertEqual(self.summary(), [dict(supplier='legacy', count=3, total_cents=160)])
        self.assertEqual(self.items(), before)

    def test_summary_total_can_exceed_sqlite_integer_range(self):
        self.assertEqual(self.load('sku,name,price_cents\na,Large,9223372036854775807\nb,One,1\n').returncode, 0)
        self.assertEqual(self.summary(), [dict(supplier='legacy', count=2,
                                              total_cents=9223372036854775808)])

    def test_empty_list(self):
        self.assertEqual(self.items(), [])

    def test_import_normalizes_and_skips_invalid_rows(self):
        result = self.load('sku,name,price_cents\n A , Apple ,10\nz,Zero,0\nb,Bad,-1\n,Empty,2\nc,,3\nd,Decimal,1.2\ne,Extra,2,x\nf,Missing\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [dict(sku='a', name='Apple', price_cents=10),
                                        dict(sku='z', name='Zero', price_cents=0)])
        for row in range(4, 10):
            self.assertIn(f'row {row}:', result.stderr)

    def test_duplicate_rejects_whole_file(self):
        for rows in ('A,One,1\na,Two,2\n', 'a,One,1\na,One,1\n',
                     'a,,bad\n A,Valid,1\n'):
            result = self.load('sku,name,price_cents\nx,New,5\n' + rows)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn('duplicate', result.stderr)
            self.assertEqual(self.items(), [])

    def test_stored_collision_preserves_legacy(self):
        self.items()
        with sqlite3.connect(self.db) as conn:
            conn.execute('INSERT INTO catalog VALUES (?, ?, ?)', (' Legacy ', 'Old', 9))
        result = self.load('sku,name,price_cents\nx,New,1\nLEGACY,Replacement,2\n')
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(self.items(), [dict(sku=' Legacy ', name='Old', price_cents=9)])

    def test_success_preserves_existing_and_rejects_bad_header(self):
        self.assertEqual(self.load('sku,name,price_cents\na,One,1\n').returncode, 0)
        self.assertEqual(self.load('sku,name,price_cents\nb,Two,2\n').returncode, 0)
        result = self.load('sku,name\nc,Three\n')
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(len(self.items()), 2)

    def test_unreadable_file_is_error(self):
        self.assertNotEqual(self.cli('import', str(self.root / 'missing')).returncode, 0)

    def test_malformed_csv_and_oversized_price_are_skipped(self):
        result = self.load('sku,name,price_cents\na,"broken"oops,1\nb,Good,2\nc,Huge,9223372036854775808\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('row 2:', result.stderr)
        self.assertIn('row 4:', result.stderr)
        self.assertEqual(self.items(), [dict(sku='b', name='Good', price_cents=2)])
