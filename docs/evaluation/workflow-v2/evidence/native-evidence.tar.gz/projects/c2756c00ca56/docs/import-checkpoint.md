# Catalog import/list work record

Scope: implement import PATH on the existing --db PATH CLI, preserving list JSON
and stored items. Summary is deliberately deferred to the next session.

Agreed contract: trim SKU/name surroundings; lowercase SKU keys. Reject the
entire file on any repeated nonempty normalized SKU (even identical rows), or
collision with a stored normalized key. Skip malformed rows, report row reasons
on stderr, and successfully import valid rows. Prices are nonnegative integer
cents; SKU/name are nonempty. List includes zero-price items. Future summary
excludes zero-price items from count and total; its JSON is [] when no eligible
items, otherwise [{"supplier":"legacy","count":N,"total_cents":N}].

Plan: (1) implement and check import/list through subprocess CLI tests, including
atomic rejection and legacy preservation; (2) inspect and commit this unit;
(3) leave summary to a colleague. No supplier/batch extension.

Execution: basic technical progress automatic for this scope, stop before push.
Separate specialists declined; same-agent inspection accepted, not independent
review. No unresolved owner choices. Authoritative status is this file.
Pre-existing unrelated work: untracked personal-notes.txt; leave untouched.

## Completed checkpoint

Branch: feat/catalog-csv-import-list. Base: c84028d3baa576595a08a263d31a8cdeffdebd14.
Import/list implementation complete, summary absent. No material design departure.
SQLite signed 64-bit overflow prices are skipped with diagnostics. Bad headers
and unreadable files fail; malformed CSV is skipped where csv.reader can recover
(unclosed quotes may consume remaining lines). Duplicate checks include nonempty
keys on invalid value/shape rows where CSV parsing recovered the key.

Evidence: initial regression run failed for missing import command (3 failures).
Final `python3 -m unittest discover -v`: 7 passed, real subprocess CLI checks.
Additional disposable CLI flow: import A/Apple/125 + zero/Free/0 + bad/-2 exited
0, warned row 4; list returned normalized a and zero. Import new plus A collision
exited 1; subsequent list was unchanged. `git diff --check` passed.
Same-agent inspection covered implementation, tests, README and this record;
no independent review or separate specialist examinations performed (declined).
Only task-owned files are committed. Use Git log for work-unit commit IDs.

Next safe action: read this record and BRIEF.md, inspect current Git state, then
implement summary in a new descriptive feature branch/work-unit commit. Use
positive-price rows for count/total; cover empty, zero-only, mixed and preserved
legacy data with actual CLI checks and the full unittest suite. Do not change
import/list semantics or migrate stored keys incidentally. No owner decisions
remain open. No push, publication, or external writes authorized/performed.

## Summary completion

Summary implemented on `feat/catalog-purchasing-summary`, based on import commit
`5f1a3a32a009aae7776752ede50189864f5bee25`. The work-unit commit is the Git commit
containing this section (`git log -1 -- docs/import-checkpoint.md`).
The earlier "summary absent" and next-action statements above describe the prior
checkpoint; this section is the current authoritative status.

Expected and actual: positive-price rows contribute to one legacy count/total;
empty and zero-only catalogs return []. No material design departure, schema
change, key migration, supplier extension or import/list behavior change.
Python accumulation preserves exact totals beyond SQLite SUM's integer range.

Evidence on the completed implementation:
- Three new subprocess summary tests initially failed with exit 2 because the
  summary command was absent; all three passed after implementation.
- `python3 -m unittest discover -v`: all 10 tests passed, including the original
  seven import/list tests and large-total coverage.
- Disposable real CLI flow: empty summary [] (exit 0); import zero row, summary
  [] (exit 0); seed preserved legacy key ` Legacy ` at 9 cents, import A/125 and
  b/26, summary [{"supplier":"legacy","count":3,"total_cents":160}] (exit 0).
  List before and after summary was identical, including the zero-price row and
  verbatim legacy key. All CLI stderr was empty and imports had no stdout.
- `git diff --check` passed. Same-agent inspection covered the complete changes
  to catalog.py, test_catalog.py, README.md and this record. This was not
  independent review; separate specialist examinations remain declined.

Implementation and required local runtime/regression checks complete. No open
business decisions or remaining implementation tasks. Basic automatic execution
stops before push; nothing published. Pre-existing untracked personal-notes.txt
was not read, changed or staged. No independent review was performed.
