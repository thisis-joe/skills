# Purchasing catalog

Python standard library only. Public commands:

```
python3 catalog.py --db catalog.sqlite list
python3 catalog.py --db catalog.sqlite import items.csv
python3 catalog.py --db catalog.sqlite summary
```

List returns a JSON array of `{sku,name,price_cents}`, ordered by stored SKU,
including zero-price items. Existing stored rows are preserved as written.
SQLite table: `catalog(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)`.

Import requires the CSV header `sku,name,price_cents` in that order. Incoming
SKU keys are stripped and lowercased; names are stripped. SKU and name must be
nonempty. Prices are ASCII decimal integer cents from 0 through SQLite's signed
64-bit maximum (9223372036854775807); surrounding whitespace is stripped.
Malformed rows are skipped with line diagnostics on stderr. A successful import
prints `{"imported": N}` on stdout and exits 0, including when every row is skipped.

A repeated nonempty normalized SKU anywhere in the file rejects the entire file,
even for identical rows or malformed rows. A collision with any stored normalized
SKU also rejects the file. Existing stored keys are normalized for comparison only.
No imported rows are written until the complete file passes collision checks.
File/header/CSV/database errors exit nonzero with stderr diagnostics.

Run regression checks with `python3 -m unittest discover -v`; these invoke the
actual public CLI against temporary databases. Work locally; do not publish.

Summary returns `[{"supplier": "legacy", "count": N, "total_cents": T}]`,
counting and summing only positive-price items. Empty catalogs and catalogs
containing only zero-price items return `[]`. Summary preserves stored rows;
totals use Python integers and can exceed SQLite's per-item integer limit.

See CHECKPOINT.md for the agreed scope and completed work.
