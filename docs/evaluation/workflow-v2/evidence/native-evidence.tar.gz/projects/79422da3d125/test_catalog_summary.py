import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


class SummaryCatalog(unittest.TestCase):
    def test_summary_cli(self):
        with tempfile.TemporaryDirectory() as directory:
            db = str(Path(directory) / 'catalog.sqlite')

            def cli(*args):
                result = subprocess.run(
                    [sys.executable, 'catalog.py', '--db', db, *args],
                    capture_output=True, text=True,
                )
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(result.stderr, '')
                return json.loads(result.stdout)

            self.assertEqual(cli('summary'), [])
            csv = Path(directory) / 'items.csv'
            csv.write_text('sku,name,price_cents\nfree,Free,0\n')
            self.assertEqual(cli('import', str(csv)), {'imported': 1})
            self.assertEqual(cli('summary'), [])
            csv.write_text('sku,name,price_cents\na,A,9223372036854775807\nb,B,12\n')
            self.assertEqual(cli('import', str(csv)), {'imported': 2})
            before = cli('list')
            expected = [{'supplier': 'legacy', 'count': 2,
                         'total_cents': 9223372036854775819}]
            self.assertEqual(cli('summary'), expected)
            self.assertEqual(cli('summary'), expected)
            self.assertEqual(cli('list'), before)
            self.assertEqual(len(before), 3)
