import json
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


class ImportCatalog(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.db = str(Path(self.temp.name) / 'catalog.sqlite')
        self.csv = Path(self.temp.name) / 'items.csv'

    def cli(self, *args):
        return subprocess.run([sys.executable, 'catalog.py', '--db', self.db, *args], capture_output=True, text=True)

    def load(self, rows):
        self.csv.write_text('sku,name,price_cents\n' + rows)
        return self.cli('import', str(self.csv))

    def items(self):
        result = self.cli('list')
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def test_normalize_skip_and_keep_zero(self):
        result = self.load(' AbC , Widget , 12 \nfree,Free,0\nbad,,2\nnegative,No,-1\nfraction,No,1.5\nextra,No,3,unexpected\nshort,No\nhuge,No,9223372036854775808\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {'imported': 2})
        self.assertEqual(result.stderr.count('skipped'), 6)
        self.assertEqual(self.items(), [{'sku': 'abc', 'name': 'Widget', 'price_cents': 12}, {'sku': 'free', 'name': 'Free', 'price_cents': 0}])

    def test_duplicate_rejects_entire_file(self):
        for rows in ['a,A,1\na,A,1\n', ' A ,A,1\na,B,2\n', 'a,,1\na,A,1\n']:
            result = self.load(rows)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn('repeated SKU', result.stderr)
            self.assertEqual(self.items(), [])

    def test_stored_collision_preserves_legacy(self):
        self.items()
        with sqlite3.connect(self.db) as connection:
            connection.execute('INSERT INTO catalog VALUES (?, ?, ?)', (' AbC ', 'Legacy', 9))
        result = self.load('new,New,1\nabc,Replacement,2\n')
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('stored SKU', result.stderr)
        self.assertEqual(self.items(), [{'sku': ' AbC ', 'name': 'Legacy', 'price_cents': 9}])

    def test_bad_header_and_missing_file(self):
        self.csv.write_text('wrong,header\na,b\n')
        self.assertNotEqual(self.cli('import', str(self.csv)).returncode, 0)
        self.assertNotEqual(self.cli('import', str(self.csv) + '.missing').returncode, 0)
        self.assertEqual(self.items(), [])

    def test_all_malformed_succeeds(self):
        result = self.load(',Missing,1\na,A,no\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {'imported': 0})
        self.assertEqual(self.items(), [])
