import argparse
import csv
import json
import sqlite3
import sys


def sku_key(value):
    return value.strip().lower()


def import_catalog(connection, path):
    rows = []
    seen = set()
    stored = {sku_key(row[0]) for row in connection.execute('SELECT sku FROM catalog')}
    with open(path, newline='', encoding='utf-8') as source:
        reader = csv.DictReader(source)
        if reader.fieldnames != ['sku', 'name', 'price_cents']:
            raise ValueError('CSV header must be sku,name,price_cents')
        for row in reader:
            line = reader.line_num
            key = sku_key(row.get('sku') or '')
            if key:
                if key in seen:
                    raise ValueError(f'line {line}: repeated SKU {key!r}; file rejected')
                if key in stored:
                    raise ValueError(f'line {line}: stored SKU {key!r}; file rejected')
                seen.add(key)
            name = (row.get('name') or '').strip()
            price = (row.get('price_cents') or '').strip()
            if None in row or not key or not name or not price.isascii() or not price.isdecimal():
                print(f'line {line}: skipped malformed row', file=sys.stderr)
                continue
            price = price.lstrip('0') or '0'
            # SQLite integers are signed 64-bit values.
            if len(price.lstrip('0')) > 19 or int(price) > 9223372036854775807:
                print(f'line {line}: skipped price outside SQLite integer range', file=sys.stderr)
                continue
            rows.append((key, name, int(price)))
    with connection:
        connection.executemany('INSERT INTO catalog VALUES (?, ?, ?)', rows)
    return len(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    commands.add_parser('summary')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    args = parser.parse_args()
    connection = sqlite3.connect(args.db)
    try:
        connection.execute('CREATE TABLE IF NOT EXISTS catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
        if args.command == 'import':
            print(json.dumps({'imported': import_catalog(connection, args.path)}))
        elif args.command == 'summary':
            count = 0
            total = 0
            for (price,) in connection.execute('SELECT price_cents FROM catalog WHERE price_cents > 0'):
                count += 1
                total += price
            print(json.dumps([dict(supplier='legacy', count=count, total_cents=total)] if count else []))
        else:
            print(json.dumps([dict(sku=k, name=n, price_cents=v) for k, n, v in connection.execute('SELECT sku,name,price_cents FROM catalog ORDER BY sku')]))
    except (OSError, ValueError, csv.Error, sqlite3.Error) as error:
        print(f'error: {error}', file=sys.stderr)
        return 1
    finally:
        connection.close()
    return 0


if __name__ == '__main__':
    sys.exit(main())
