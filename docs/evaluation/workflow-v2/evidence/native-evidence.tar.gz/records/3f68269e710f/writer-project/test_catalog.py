import json,subprocess,sys,tempfile,unittest
class Catalog(unittest.TestCase):
 def test_empty_list(self):
  with tempfile.TemporaryDirectory() as d:
   self.assertEqual(json.loads(subprocess.check_output([sys.executable,'catalog.py','--db',d+'/x.sqlite','list'])),[])

class ImportCatalog(unittest.TestCase):
 def setUp(self):
  self.directory = tempfile.TemporaryDirectory()
  self.addCleanup(self.directory.cleanup)
  self.db = self.directory.name + '/catalog.sqlite'
  self.csv = self.directory.name + '/items.csv'

 def cli(self, *args):
  return subprocess.run([sys.executable, 'catalog.py', '--db', self.db, *args],
                        text=True, capture_output=True)

 def import_text(self, content):
  with open(self.csv, 'w', encoding='utf-8', newline='') as source:
   source.write(content)
  return self.cli('import', self.csv)

 def items(self):
  result = self.cli('list')
  self.assertEqual(result.returncode, 0, result.stderr)
  return json.loads(result.stdout)

 def test_import_trim_case_duplicates_existing_and_zero(self):
  self.assertEqual(self.import_text('sku,name,price_cents\nOLD,Stored,9\n').returncode, 0)
  result = self.import_text('sku,name,price_cents\n A , First , 0 \nA,Second,2\na,Lower,3\nOLD,Replacement,4\n')
  self.assertEqual(result.returncode, 0, result.stderr)
  self.assertEqual(result.stdout, '')
  self.assertIn('line 3: skipped duplicate', result.stderr)
  self.assertIn('line 5: skipped existing', result.stderr)
  expected = [dict(sku='A', name='First', price_cents=0),
              dict(sku='OLD', name='Stored', price_cents=9),
              dict(sku='a', name='Lower', price_cents=3)]
  self.assertEqual(self.items(), expected)
  self.assertEqual(self.cli('import', self.csv).returncode, 0)
  self.assertEqual(self.items(), expected)

 def test_malformed_rows_are_reported_and_valid_rows_survive(self):
  result = self.import_text('sku,name,price_cents\n,Empty,2\nB, ,2\nC,Negative,-1\nD,Fraction,1.5\nE,Missing\nF,Extra,1,extra\nG,Overflow,9223372036854775808\nH,"broken"tail,2\nGOOD,"Quoted, name",7\n')
  self.assertEqual(result.returncode, 0, result.stderr)
  for line in range(2, 10):
   self.assertIn(f'line {line}: skipped', result.stderr)
  self.assertEqual(self.items(), [dict(sku='GOOD', name='Quoted, name', price_cents=7)])

 def test_bad_header_and_missing_file_preserve_data(self):
  self.import_text('sku,name,price_cents\nA,Stored,8\n')
  result = self.import_text('sku,name,wrong\nB,Ignored,3\n')
  self.assertEqual(result.returncode, 1)
  self.assertIn('CSV requires header', result.stderr)
  self.assertEqual(self.cli('import', self.csv + '.missing').returncode, 1)
  self.assertEqual(self.items(), [dict(sku='A', name='Stored', price_cents=8)])

 def test_reordered_header_and_integer_boundary(self):
  result = self.import_text('\ufeffname,price_cents,sku\nMaximum,9223372036854775807,MAX\nFree,0000,ZERO\n')
  self.assertEqual(result.returncode, 0, result.stderr)
  self.assertEqual(self.items(), [dict(sku='MAX', name='Maximum', price_cents=9223372036854775807),
                                 dict(sku='ZERO', name='Free', price_cents=0)])
