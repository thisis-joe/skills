# Purchasing catalog

Python standard library only. Public commands:

```sh
python3 catalog.py --db catalog.sqlite import items.csv
python3 catalog.py --db catalog.sqlite list
python3 -m unittest discover -v
```

`list` returns a JSON array of `{sku,name,price_cents}`, ordered by SKU,
including zero-price items. The SQLite table remains
`catalog(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)`.

CSV requires the three header fields `sku,name,price_cents` (column order may
vary). UTF-8, an optional BOM, and quoted CSV fields are supported. Surrounding
whitespace is trimmed from values. SKU case is preserved: `A` and `a` are
different items. SKU/name must be nonempty; price is decimal digits representing
nonnegative integer cents, within SQLite's signed 64-bit integer range.

Import keeps the first valid row for each trimmed SKU and keeps existing stored
rows on collisions. Invalid rows and collisions are skipped with line-numbered
explanations on stderr. Valid rows are committed, and row skips do not cause a
failure exit. Successful import writes nothing to stdout. Missing/unreadable
files, invalid UTF-8, and invalid/missing headers fail with exit status 1;
file decoding failure rolls back rows from that import. CSV diagnostics refer
to the starting physical line of the record. An unterminated quoted record can
consume the rest of the file as one malformed record.

`summary` is reserved for the next session; see [HANDOFF.md](HANDOFF.md).
Work locally; preserve unrelated files. Do not publish.
