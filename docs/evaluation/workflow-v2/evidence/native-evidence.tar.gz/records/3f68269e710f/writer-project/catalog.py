import argparse
import csv
import json
import sqlite3
import sys


def import_csv(connection, path):
    with open(path, newline='', encoding='utf-8-sig') as source:
        reader = csv.reader(source, strict=True)
        try:
            header = next(reader)
        except (StopIteration, csv.Error) as error:
            raise ValueError('CSV requires header sku,name,price_cents') from error
        if sorted(header) != ['name', 'price_cents', 'sku']:
            raise ValueError('CSV requires header sku,name,price_cents')

        seen = set()
        with connection:
            while True:
                start_line = reader.line_num + 1
                try:
                    values = next(reader)
                except StopIteration:
                    break
                except csv.Error as error:
                    print(f'line {start_line}: skipped malformed CSV: {error}', file=sys.stderr)
                    continue
                if len(values) != len(header):
                    print(f'line {start_line}: skipped: expected 3 fields', file=sys.stderr)
                    continue
                row = dict(zip(header, (value.strip() for value in values)))
                sku, name, price = row['sku'], row['name'], row['price_cents']
                if not sku or not name or not price.isascii() or not price.isdecimal():
                    print(f'line {start_line}: skipped: SKU/name must be nonempty and '
                          'price_cents must be a nonnegative integer', file=sys.stderr)
                    continue
                # SQLite INTEGER values are signed 64-bit integers.
                significant_price = price.lstrip('0') or '0'
                if (len(significant_price) > 19 or
                        (len(significant_price) == 19 and significant_price > '9223372036854775807')):
                    print(f'line {start_line}: skipped: price_cents exceeds SQLite integer range',
                          file=sys.stderr)
                    continue
                if sku in seen:
                    print(f'line {start_line}: skipped duplicate SKU {sku!r}', file=sys.stderr)
                    continue
                seen.add(sku)
                cursor = connection.execute(
                    'INSERT INTO catalog (sku,name,price_cents) VALUES (?,?,?) '
                    'ON CONFLICT(sku) DO NOTHING', (sku, name, int(significant_price)))
                if cursor.rowcount == 0:
                    print(f'line {start_line}: skipped existing SKU {sku!r}', file=sys.stderr)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    args = parser.parse_args()
    connection = sqlite3.connect(args.db)
    try:
        connection.execute('CREATE TABLE IF NOT EXISTS catalog '
                           '(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
        if args.command == 'import':
            try:
                import_csv(connection, args.path)
            except (OSError, UnicodeError, ValueError) as error:
                parser.exit(1, f'import failed: {error}\n')
        else:
            print(json.dumps([dict(sku=sku, name=name, price_cents=price)
                              for sku, name, price in connection.execute(
                                  'SELECT sku,name,price_cents FROM catalog ORDER BY sku')]))
    finally:
        connection.close()


if __name__ == '__main__':
    main()
