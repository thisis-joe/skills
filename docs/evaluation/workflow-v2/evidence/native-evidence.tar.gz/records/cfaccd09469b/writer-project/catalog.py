import argparse
import csv
import json
import re
import sqlite3


def read_import(path):
    items = {}
    with open(path, newline='', encoding='utf-8') as source:
        rows = csv.reader(source, strict=True)
        if next(rows, None) != ['sku', 'name', 'price_cents']:
            raise ValueError('expected CSV header sku,name,price_cents')
        for row in rows:
            if len(row) != 3:
                raise ValueError(f'line {rows.line_num}: expected three fields')
            sku, name, price = (value.strip() for value in row)
            if not sku or not name or not re.fullmatch(r'[0-9]+', price):
                raise ValueError(f'line {rows.line_num}: nonempty SKU/name and nonnegative integer price required')
            cents = int(price)
            if cents > 9223372036854775807:
                raise ValueError(f'line {rows.line_num}: price exceeds SQLite integer range')
            items.setdefault(sku.lower(), (name, cents))
    return items


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    args = parser.parse_args()
    try:
        # Validate even duplicate rows before opening or changing the catalog.
        items = read_import(args.path) if args.command == 'import' else None
        connection = sqlite3.connect(args.db)
        try:
            with connection:
                connection.execute('CREATE TABLE IF NOT EXISTS catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
                if items is not None:
                    connection.execute('BEGIN IMMEDIATE')
                    existing = {sku.strip().lower() for (sku,) in connection.execute('SELECT sku FROM catalog')}
                    connection.executemany(
                        'INSERT INTO catalog (sku, name, price_cents) VALUES (?, ?, ?)',
                        [(sku, name, cents) for sku, (name, cents) in items.items() if sku not in existing],
                    )
                else:
                    print(json.dumps([
                        dict(sku=sku, name=name, price_cents=cents)
                        for sku, name, cents in connection.execute('SELECT sku,name,price_cents FROM catalog ORDER BY sku')
                    ]))
        finally:
            connection.close()
    except (OSError, UnicodeError, csv.Error, ValueError, sqlite3.Error) as error:
        parser.exit(1, f'catalog: {error}\n')


if __name__ == '__main__':
    main()
