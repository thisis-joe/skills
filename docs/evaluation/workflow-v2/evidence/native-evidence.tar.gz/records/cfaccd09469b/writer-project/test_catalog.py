import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class Catalog(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.db = self.root / 'catalog.sqlite'

    def cli(self, *args):
        return subprocess.run(
            [sys.executable, 'catalog.py', '--db', str(self.db), *args],
            capture_output=True, text=True,
        )

    def items(self):
        result = self.cli('list')
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def csv(self, content):
        path = self.root / 'items.csv'
        path.write_text(content, encoding='utf-8')
        return str(path)

    def test_empty_list(self):
        self.assertEqual(self.items(), [])

    def test_import_normalizes_and_keeps_first_and_stored_rows(self):
        path = self.csv('sku,name,price_cents\n B , First ,0\nb,Duplicate,9\na,Other,25\n')
        result = self.cli('import', path)
        self.assertEqual(result.returncode, 0, result.stderr)
        expected = [dict(sku='a', name='Other', price_cents=25),
                    dict(sku='b', name='First', price_cents=0)]
        self.assertEqual(self.items(), expected)
        self.assertEqual(self.cli('import', self.csv('sku,name,price_cents\n B ,Replacement,99\n')).returncode, 0)
        self.assertEqual(self.items(), expected)

    def test_malformed_import_leaves_catalog_unchanged(self):
        self.assertEqual(self.cli('import', self.csv('sku,name,price_cents\nold,Stored,4\n')).returncode, 0)
        expected = self.items()
        for row in ['bad,Name,-1', 'bad,Name,1.5', ',Name,2', 'bad, ,2',
                    'bad,Name', 'bad,Name,2,extra', 'bad,Name,9223372036854775808',
                    'old,Duplicate,invalid', 'bad,"unterminated,2']:
            with self.subTest(row=row):
                result = self.cli('import', self.csv('sku,name,price_cents\nnew,Valid,1\n' + row + '\n'))
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(self.items(), expected)

    def test_bad_header_and_missing_file(self):
        for content in ['sku,name,cost\nx,X,2\n', '', 'sku,name,price_cents,extra\n']:
            self.assertNotEqual(self.cli('import', self.csv(content)).returncode, 0)
        self.assertNotEqual(self.cli('import', str(self.root / 'missing.csv')).returncode, 0)
        self.assertEqual(self.items(), [])

    def test_existing_case_variant_is_preserved(self):
        import sqlite3
        self.items()
        with sqlite3.connect(self.db) as connection:
            connection.execute('INSERT INTO catalog VALUES (?, ?, ?)', (' AbC ', 'Legacy', 7))
        result = self.cli('import', self.csv('sku,name,price_cents\nabc,New,8\n'))
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [dict(sku=' AbC ', name='Legacy', price_cents=7)])
