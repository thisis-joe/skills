# Purchasing catalog
Python standard library only. Public entry: `python3 catalog.py --db PATH list`.
List returns a JSON array of {sku,name,price_cents}. Existing SQLite table is
catalog(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL).
CSV has header sku,name,price_cents. SKU/name must be nonempty; prices are
nonnegative integer cents. Business choices are not established in this README.
Use the existing public CLI entry for added commands. Local regression command:
`python3 -m unittest discover -v`. Work locally; preserve unrelated files.

Import: `python3 catalog.py --db PATH import FILE.csv` (success exits 0 with
no stdout; invalid input exits 1 with a diagnostic on stderr). UTF-8 CSV must
have the exact header above and three fields per row. Surrounding field
whitespace is trimmed; imported SKU keys are lowercase. First duplicate wins;
stored rows win collisions, including normalized legacy SKU variants. Legacy
rows are preserved verbatim. Every row is validated, including duplicates,
before any catalog write. Prices use decimal digits and fit SQLite signed
64-bit integers. Zero-price items remain in list output. List stays sorted by
stored SKU and keeps its existing JSON shape.

Summary is deferred. See HANDOFF.md for the agreed behavior and checkpoint.
