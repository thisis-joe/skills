# Catalog checkpoint

Scope: runnable import/list slice only; stop before push. Work stays local,
Python stdlib only. No Jira or separate specialist examination. This record
is the authoritative checkpoint for this session.

Branch: feat/catalog-import-list. Base: c3bac8f (Record project context).
Pre-existing untracked personal-notes.txt and ignored store.sqlite were left
untouched. Do not stage, overwrite or use them as disposable test data.

## Settled behavior

- Trim surrounding whitespace and lowercase SKU keys; case variants identify
  the same item. Imported name/price whitespace is trimmed too.
- First row wins duplicate normalized keys in a file; existing stored rows win
  collisions. Existing rows are preserved verbatim, with normalized keys used
  only for collision comparison.
- Any malformed row rejects the entire import, including malformed duplicates.
- List retains zero-price rows.
- Future summary is a JSON array with one {"supplier":"legacy","count":N,
  "total_cents":T} for a nonempty catalog; empty catalog gives []. Count includes
  zero-price rows; they contribute zero to total. Supplier/batch extensions
  are outside scope.

## Done and evidence

Implementation and CLI regression tests are in catalog.py and test_catalog.py.
CSV validation completes before connecting to the DB; inserts use a transaction
and take a write lock before reading stored keys. See README for input details.

Before implementation, the focused import test failed because argparse rejected
`import`. After implementation `python3 -m unittest discover -v` passed all five
tests. These launch actual CLI subprocesses against temporary databases and cover
normalization, ordering, zero prices, first/stored wins, legacy preservation,
malformed fields/CSV/header, missing files, and rejection with no partial inserts.

A separate actual CLI smoke check imported A/Free/0, duplicate a/Ignored/9 and
b/Paid/125: list returned a/Free/0 and b/Paid/125. Importing c/Valid/3 followed
by d/Invalid/-1 exited 1; list stayed identical. `summary` still exits 2 as an
unknown command, deliberately. `git diff --check` passed. Inspection was by the
implementing agent over the full task diff; it was not independent review.

## Remaining / next safe action

Summary has no implementation or regression tests yet. No unresolved product
choices are known for this scoped feature. In the colleague's next authorized
session, inspect Git state and this record, run the existing suite, then add a
failing public-CLI summary test (empty, zero-only, mixed prices), implement the
agreed aggregation, and run real CLI checks plus the suite. Preserve list/import
and unrelated data. Use a descriptive feature branch and work-unit commits;
publication is not authorized by this checkpoint.

Commit identity for the implementation is recorded below after its creation.

Implementation commit: a6b1329 (`Add validated atomic CSV import and preserve
list behavior`). This handoff is a separate documentation work unit; find its
commit with `git log -1 -- HANDOFF.md`. Both units are local and unpushed.
