# Execution plan

1. Implement import/list with public CLI regression tests: normalization,
   last-row wins, later updates, preservation, zero-price listing, atomic rejection.
2. Run real CLI checks and unittest discovery, inspect own diff, commit the slice.
3. Record evidence and a resumable checkpoint; stop without summary or publishing.

A colleague's next task is summary, starting with a failing CLI test against the
saved specification. No summary code belongs in this work unit.
