import argparse
import csv
import json
import re
import sqlite3


def read_import(path):
    items = {}
    with open(path, encoding='utf-8', newline='') as source:
        rows = csv.reader(source, strict=True)
        if next(rows, None) != ['sku', 'name', 'price_cents']:
            raise ValueError('expected CSV header sku,name,price_cents')
        for row in rows:
            if len(row) != 3:
                raise ValueError(f'line {rows.line_num}: expected three fields')
            sku, name, price = (field.strip() for field in row)
            if not sku or not name or not re.fullmatch(r'[0-9]+', price):
                raise ValueError(f'line {rows.line_num}: invalid SKU, name or price')
            cents = int(price)
            if cents > 9223372036854775807:
                raise ValueError(f'line {rows.line_num}: price exceeds SQLite integer range')
            sku = sku.lower()
            items[sku] = (sku, name, cents)
    return list(items.values())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    args = parser.parse_args()
    try:
        # Finish validation before even opening the database.
        items = read_import(args.path) if args.command == 'import' else None
        connection = sqlite3.connect(args.db)
        try:
            with connection:
                connection.execute(
                    'CREATE TABLE IF NOT EXISTS catalog '
                    '(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)'
                )
                if args.command == 'import':
                    # Lock before matching legacy spellings so replacement is atomic.
                    connection.execute('BEGIN IMMEDIATE')
                    incoming = {item[0] for item in items}
                    aliases = [
                        (sku,) for (sku,) in connection.execute('SELECT sku FROM catalog')
                        if sku.strip().lower() in incoming and sku != sku.strip().lower()
                    ]
                    connection.executemany('DELETE FROM catalog WHERE sku=?', aliases)
                    connection.executemany(
                        'INSERT INTO catalog (sku,name,price_cents) VALUES (?,?,?) '
                        'ON CONFLICT(sku) DO UPDATE SET '
                        'name=excluded.name, price_cents=excluded.price_cents', items
                    )
                else:
                    print(json.dumps([
                        dict(sku=sku, name=name, price_cents=price)
                        for sku, name, price in connection.execute(
                            'SELECT sku,name,price_cents FROM catalog ORDER BY sku'
                        )
                    ]))
        finally:
            connection.close()
    except (OSError, UnicodeError, csv.Error, ValueError, sqlite3.Error) as error:
        parser.exit(1, f'catalog: {error}\n')


if __name__ == '__main__':
    main()
