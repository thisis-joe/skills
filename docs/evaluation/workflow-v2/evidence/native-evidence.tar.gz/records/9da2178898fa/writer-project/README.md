# Purchasing catalog
Python standard library only. Public entry: `python3 catalog.py --db PATH list`.
List returns a JSON array of {sku,name,price_cents}. Existing SQLite table is
catalog(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL).
CSV has header sku,name,price_cents. SKU/name must be nonempty; prices are
nonnegative integer cents. Settled business choices are recorded below and in the feature contract.
Use the existing public CLI entry for added commands. Local regression command:
`python3 -m unittest discover -v`. Work locally; preserve unrelated files.

Import a CSV with `python3 catalog.py --db PATH import items.csv` (silent success;
nonzero exit with a diagnostic on invalid input). Fields are trimmed, SKU keys
are lowercase, and the last duplicate wins. Later imports replace matching items,
including legacy case/whitespace spellings, while retaining unrelated items.
The entire file is validated before transactional updates. Zero-price items stay
in list output. Prices use unsigned decimal digits within SQLite's integer range.

Summary is deferred. See [the agreed contract](docs/specs/catalog-import.md) and
[the checkpoint](docs/CHECKPOINT.md) before continuing.
