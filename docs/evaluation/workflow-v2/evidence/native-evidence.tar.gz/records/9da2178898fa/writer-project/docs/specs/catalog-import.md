# Catalog import and summary contract

Use the existing Python stdlib CLI and SQLite catalog schema. Preserve list's
JSON array of {sku,name,price_cents}, ordered by SKU, including zero-price rows.
`import PATH` reads CSV header sku,name,price_cents. Trim surrounding field
whitespace; lowercase SKU keys. SKU/name must be nonempty; price must be
nonnegative integer cents within SQLite's integer range. Reject malformed CSV,
headers, row shapes or values with nonzero exit and leave stored catalog unchanged.
Validate the whole file before writing; apply valid rows in one transaction.
Last normalized key in a file wins; subsequent imports update existing keys.
Preserve unrelated stored rows. Import succeeds silently.

Only import/list is authorized for this checkpoint. Summary remains unimplemented.
Next session: summary returns [{"supplier":"legacy","count":N,"total_cents":T}],
excluding zero-price rows from both count and total; no contributing rows gives [].
No supplier/batch extension. No material product decisions remain open.
