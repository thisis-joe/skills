import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest


class Catalog(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.db = self.root / 'catalog.sqlite'

    def cli(self, *args):
        return subprocess.run(
            [sys.executable, 'catalog.py', '--db', str(self.db), *args],
            text=True, capture_output=True,
        )

    def items(self):
        result = self.cli('list')
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def load(self, content):
        path = self.root / 'input.csv'
        path.write_text(content, encoding='utf-8')
        return self.cli('import', str(path))

    def test_empty_list(self):
        self.assertEqual(self.items(), [])

    def test_import_normalizes_duplicates_and_updates(self):
        result = self.load('sku,name,price_cents\n A , First ,12\na,Last,0\nb,Keep,8\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [
            dict(sku='a', name='Last', price_cents=0),
            dict(sku='b', name='Keep', price_cents=8),
        ])
        result = self.load('sku,name,price_cents\n A , Updated , 20 \n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [
            dict(sku='a', name='Updated', price_cents=20),
            dict(sku='b', name='Keep', price_cents=8),
        ])

    def test_import_matches_legacy_stored_key(self):
        self.items()
        with sqlite3.connect(self.db) as connection:
            connection.execute('INSERT INTO catalog VALUES (?,?,?)', (' A ', 'Legacy', 4))
        result = self.load('sku,name,price_cents\na,Replacement,5\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [dict(sku='a', name='Replacement', price_cents=5)])

    def test_invalid_import_is_atomic(self):
        self.assertEqual(self.load('sku,name,price_cents\na,Original,7\n').returncode, 0)
        for bad in ('b,B,-1', 'b,B,1.5', ',B,2', 'b, ,2',
                    'b,B', 'b,B,2,extra', 'b,B,9223372036854775808',
                    'b,"unterminated,2'):
            with self.subTest(bad=bad):
                result = self.load('sku,name,price_cents\na,Changed,10\n' + bad + '\n')
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(self.items(), [dict(sku='a', name='Original', price_cents=7)])
        for header in ('', 'sku,name,cost\n', 'sku,name,price_cents,extra\n'):
            with self.subTest(header=header):
                self.assertNotEqual(self.load(header).returncode, 0)
                self.assertEqual(self.items(), [dict(sku='a', name='Original', price_cents=7)])


if __name__ == '__main__':
    unittest.main()
