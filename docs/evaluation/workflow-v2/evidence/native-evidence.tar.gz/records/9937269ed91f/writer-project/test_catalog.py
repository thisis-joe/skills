import json,subprocess,sys,tempfile,unittest
class Catalog(unittest.TestCase):
 def test_empty_list(self):
  with tempfile.TemporaryDirectory() as d:
   self.assertEqual(json.loads(subprocess.check_output([sys.executable,'catalog.py','--db',d+'/x.sqlite','list'])),[])

class ImportCatalog(unittest.TestCase):
 def test_import_updates_and_lists(self):
  with tempfile.TemporaryDirectory() as d:
   from pathlib import Path
   db=d+'/x.sqlite'
   source=Path(d)/'items.csv'
   def run(*args):
    return subprocess.run([sys.executable,'catalog.py','--db',db,*args],capture_output=True,text=True)
   source.write_text('sku,name,price_cents\n KEEP , Old ,7\n A , First ,10\nA, Last ,0\na,Lower,2\n')
   result=run('import',str(source))
   self.assertEqual(result.returncode,0,result.stderr)
   self.assertEqual(json.loads(run('list').stdout),[
    {'sku':'A','name':'Last','price_cents':0},
    {'sku':'KEEP','name':'Old','price_cents':7},
    {'sku':'a','name':'Lower','price_cents':2}])
   source.write_text('sku,name,price_cents\nA,Updated,12\n')
   self.assertEqual(run('import',str(source)).returncode,0)
   self.assertEqual(json.loads(run('list').stdout)[0],{'sku':'A','name':'Updated','price_cents':12})
   self.assertEqual(len(json.loads(run('list').stdout)),3)

 def test_rejects_entire_malformed_import(self):
  with tempfile.TemporaryDirectory() as d:
   from pathlib import Path
   db=d+'/x.sqlite'
   source=Path(d)/'items.csv'
   def run(*args):
    return subprocess.run([sys.executable,'catalog.py','--db',db,*args],capture_output=True,text=True)
   source.write_text('sku,name,price_cents\nKEEP,Original,7\n')
   self.assertEqual(run('import',str(source)).returncode,0)
   before=run('list').stdout
   bad_rows=[' ,Name,1','A, ,1','A,Name,-1','A,Name,1.5',
             'A,Name,abc','A,Name,9223372036854775808',
             'A,Name','A,Name,1,extra','', 'A,"unterminated,1']
   for bad in bad_rows:
    with self.subTest(row=bad):
     source.write_text('sku,name,price_cents\nKEEP,Changed,9\n'+bad+'\n')
     result=run('import',str(source))
     self.assertNotEqual(result.returncode,0)
     self.assertTrue(result.stderr)
     self.assertEqual(run('list').stdout,before)
   for header in ['', 'name,sku,price_cents\n', 'sku,name,price_cents,extra\n']:
    source.write_text(header)
    self.assertNotEqual(run('import',str(source)).returncode,0)
    self.assertEqual(run('list').stdout,before)
   source.write_bytes(b'sku,name,price_cents\nA,\xff,1\n')
   self.assertNotEqual(run('import',str(source)).returncode,0)
   self.assertNotEqual(run('import',d+'/missing.csv').returncode,0)
   self.assertEqual(run('list').stdout,before)
   source.write_text('sku,name,price_cents\n')
   self.assertEqual(run('import',str(source)).returncode,0)
   self.assertEqual(run('list').stdout,before)
