# Purchasing catalog
Python standard library only. Public entry: `python3 catalog.py --db PATH list`.
List returns a JSON array of {sku,name,price_cents}. Existing SQLite table is
catalog(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL).
CSV has header sku,name,price_cents. SKU/name must be nonempty; prices are
nonnegative integer cents. Settled behavior and scope are recorded in docs/specs/catalog-import.md.
Use the existing public CLI entry for added commands. Local regression command:
`python3 -m unittest discover -v`. Work locally; preserve unrelated files.

Import: `python3 catalog.py --db PATH import items.csv`. Success is silent (exit 0);
invalid input reports an error on stderr (exit 2) without changing catalog rows.
Use a UTF-8 CSV with exact header `sku,name,price_cents`. Field whitespace is
trimmed, SKU case is preserved, and the last duplicate wins; later imports update
existing items. Prices use decimal digits in SQLite INTEGER range (0 through
9223372036854775807). Header-only input is a no-op; malformed/blank data rows fail.
Zero-price items remain in list. Summary is not implemented yet.

Resume from [docs/HANDOFF.md](docs/HANDOFF.md) for evidence and the next task.
