# Catalog CSV feature
Owner decisions: strip surrounding field whitespace, preserve SKU case (case variants
are distinct); last duplicate row wins, including updates on later imports. Validate
every row before writing; any malformed row rejects the whole file without changing
catalog data. SKU/name are nonempty; price is nonnegative integer cents fitting the
existing SQLite INTEGER. CSV header is sku,name,price_cents. Keep list's sorted JSON
array of {sku,name,price_cents}, including zero prices, and preserve unrelated rows.

Current scope: runnable `python3 catalog.py --db PATH import PATH` and existing list.
Import success exits zero; invalid input exits nonzero with a diagnostic on stderr.
Summary is deliberately deferred: future `summary` returns [] for no rows, otherwise
[{"supplier":"legacy","count":N,"total_cents":T}]. Count includes zero prices.
One supplier only; supplier/batch extensions are excluded.

Acceptance: real CLI import/list with whitespace, case variants, duplicates, later
updates, zero prices and preserved rows; invalid rows leave prior data unchanged;
existing unittest suite passes. No push/publication.
