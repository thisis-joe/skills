# Plan
1. Import/list: write public CLI regression, observe failure, implement CSV validation
   and transactional upsert, check real CLI and unittest suite, inspect and commit.
2. Save checkpoint with evidence and next safe summary task; commit records and stop.
3. Next session only: implement summary against agreed spec with CLI regression tests.

Authoritative progress/authorization record: docs/HANDOFF.md (created at checkpoint).
Basic technical progression is automatic for this feature through checks and commits;
stop before push. Separate specialist examinations declined; same-agent inspection
accepted and must not be represented as independent review. Product decisions belong
to owner. Current session stops after import/list; summary is not authorized here.
