import argparse
import csv
import json
import re
import sqlite3


def read_items(path):
    items = {}
    with open(path, encoding='utf-8', newline='') as source:
        reader = csv.reader(source, strict=True)
        if next(reader, None) != ['sku', 'name', 'price_cents']:
            raise ValueError('expected CSV header sku,name,price_cents')
        for row in reader:
            if len(row) != 3:
                raise ValueError(f'line {reader.line_num}: expected three fields')
            sku, name, price = (field.strip() for field in row)
            if not sku or not name or not re.fullmatch(r'[0-9]+', price):
                raise ValueError(f'line {reader.line_num}: invalid SKU, name or price')
            cents = int(price)
            if cents > 9223372036854775807:
                raise ValueError(f'line {reader.line_num}: price exceeds SQLite INTEGER range')
            items[sku] = (sku, name, cents)
    return list(items.values())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    args = parser.parse_args()
    try:
        # Validate the entire input before opening or changing the database.
        items = read_items(args.path) if args.command == 'import' else None
        connection = sqlite3.connect(args.db)
        try:
            with connection:
                connection.execute('CREATE TABLE IF NOT EXISTS catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
                if args.command == 'import':
                    connection.executemany(
                        'INSERT INTO catalog(sku,name,price_cents) VALUES(?,?,?) '
                        'ON CONFLICT(sku) DO UPDATE SET name=excluded.name, price_cents=excluded.price_cents',
                        items,
                    )
                else:
                    print(json.dumps([
                        dict(sku=sku, name=name, price_cents=price)
                        for sku, name, price in connection.execute(
                            'SELECT sku,name,price_cents FROM catalog ORDER BY sku'
                        )
                    ]))
        finally:
            connection.close()
    except (OSError, UnicodeError, csv.Error, ValueError, sqlite3.Error) as error:
        parser.error(str(error))


if __name__ == '__main__':
    main()
