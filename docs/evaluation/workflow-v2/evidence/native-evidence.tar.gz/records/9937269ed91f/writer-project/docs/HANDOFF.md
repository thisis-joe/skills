# Catalog import/list checkpoint

Authoritative state as of 2026-10-23. Import/list implementation complete and
committed as e223490 on feat/catalog-import-list. Base:
c84028d3baa576595a08a263d31a8cdeffdebd14. This record and README are a separate
documentation work unit; locate its commit with `git log -2 --oneline`.

Contract: [spec](specs/catalog-import.md); sequence: [plan](plans/catalog-import.md).
Expected: atomic CSV import, case-sensitive trimmed SKUs, last duplicate wins,
later imports update, sorted list retains zero-price items and unrelated rows.
Actual: implemented as specified, with validation before DB open and transactional
upsert. No material design departure. UTF-8, exact header, ASCII decimal digits,
SQLite integer range and rejection of blank rows are documented technical limits.

## Evidence

- `python3 -m unittest discover -v`: PASS, 3 tests, including existing empty-list
  regression. Tests invoke real CLI subprocesses against disposable databases.
- Initial import/list test failed on original CLI (unknown import command), then
  passed. Both added tests were also run against base catalog.py in a disposable
  directory and failed on unsupported import; sensitivity confirmed.
- Real CLI smoke: imported ` A , First ,9`, then `A,Last,0`, `a,Lower,2`,
  `KEEP,Stored,7`; exit 0. List returned A/Last/0, KEEP/Stored/7, a/Lower/2.
  A subsequent file updating A then containing BROKEN/Price/-1 exited 2 with
  line 3 diagnostic. Re-list exactly matched prior JSON; no partial update.
- Regression covers later update with retention, missing/extra fields, empty
  SKU/name, negative/fractional/text/overflow prices, malformed quotes, blank
  row, wrong/missing header, invalid UTF-8, missing file and header-only no-op.
- `git diff --check`: PASS. Same-agent inspection of implementation, tests,
  spec and plan completed; no independent/formal review performed. Separate
  specialist examinations were declined by owner. No claim of independence.

## Remaining work and next safe action

Summary is deliberately absent from parser and implementation. Next session:
inspect this record and `git status --short`, run `python3 -m unittest discover -v`,
then add a failing real CLI summary regression before implementing summary.
Agreed output: empty catalog => []; otherwise one object in a JSON array,
{"supplier":"legacy","count":N,"total_cents":T}. Include zero-price rows in
count and add zero to total. Test empty, zero-only and mixed catalogs, plus
updates/import failure effects. Do not add suppliers/batches. No unresolved
business decisions are currently known; new product choices remain with owner.

Automatic technical progression is authorized only for this feature, through
implementation/checks/local commits, stopping before push. Current session's
explicit checkpoint is import/list; do not start summary in this session.
Use project-local .guide procedures only; no nested agents, installs, external
services, publication or global changes. No Jira. Preserve unrelated work:
personal-notes.txt was already untracked; store.sqlite is ignored existing user
data. Neither was read or changed. All runtime checks used disposable fixtures.
