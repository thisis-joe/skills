# Purchasing catalog

Python standard library only. Public CLI:

```
python3 catalog.py --db PATH import items.csv
python3 catalog.py --db PATH list
python3 -m unittest discover -v
```

Import expects the exact CSV header `sku,name,price_cents`. SKU and name are
trimmed; SKU keys are lowercase. Both must be nonempty. Prices are nonnegative
integer cents, bounded by SQLite's signed 64-bit integer storage. Import succeeds
silently. Errors go to stderr with a nonzero exit code.

The first row for each normalized SKU wins within a file. Existing stored rows
win collisions, including legacy SKU case/whitespace variants; their stored data
is preserved. Every row is validated, including duplicates. Any malformed row
rejects the entire import before catalog writes. Zero-price rows are retained.

List returns a JSON array of {sku,name,price_cents}, ordered by stored SKU.
The existing table remains catalog(sku TEXT PRIMARY KEY, name TEXT NOT NULL,
price_cents INTEGER NOT NULL). Work locally; do not publish.
