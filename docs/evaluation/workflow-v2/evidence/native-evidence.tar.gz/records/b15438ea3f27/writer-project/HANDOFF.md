# Import/list checkpoint

Owner-approved scope: implement and commit import/list now; leave summary for the
next session. No Jira, external services, publishing, or independent specialist
review. Work branch: feature/catalog-import-list. Untracked personal-notes.txt is
unrelated and was not read or changed.

## Settled product decisions

- Trim surrounding whitespace and lowercase SKU keys; variants identify one item.
- First row wins within a file; an existing stored row wins a collision.
- Any malformed row rejects the entire import, leaving catalog contents unchanged.
- Summary counts zero-price rows; they contribute zero to total. List retains them.

## Completed

The public CLI supports import PATH and the existing list JSON interface.
Validation happens before opening the database; insertion uses one transaction.
Legacy rows are compared using normalized keys without rewriting their data.
Names are trimmed. The exact CSV header is required. Prices use ASCII integer
syntax and SQLite's signed 64-bit range. No schema migration was needed.

Five unittest cases pass via real subprocess CLI calls, covering empty list,
normalization, duplicate precedence, zero-price retention, legacy preservation,
malformed-row atomicity (including invalid duplicates), bad headers and missing
files. An additional real CLI scenario imported free/paid rows, rejected a later
negative-price file, and confirmed list output was unchanged. git diff --check
passed. Inspection was by the implementing agent, not independent review.

## Remaining and next safe action

Summary is deliberately unimplemented. No product decision remains unresolved
for this slice. The agreed summary contract in BRIEF.md is a JSON array containing
{supplier: "legacy", count, total_cents}, or [] for no entries. There is one supplier;
supplier/batch extensions are outside scope.

Next session: inspect the committed CLI and tests, create a descriptive summary
feature branch, implement summary using all stored rows (including zero prices),
and verify empty and mixed-price catalogs through actual CLI calls plus the full
unittest suite. Preserve import/list behavior and unrelated work; commit locally
and stop before push unless the owner changes authorization.
