import argparse
import csv
import json
import re
import sqlite3


def read_import(path):
    """Validate every row before permitting any catalog writes."""
    rows = {}
    with open(path, newline='', encoding='utf-8') as source:
        reader = csv.DictReader(source, strict=True)
        if reader.fieldnames != ['sku', 'name', 'price_cents']:
            raise ValueError('CSV header must be sku,name,price_cents')
        for row in reader:
            if None in row or any(value is None for value in row.values()):
                raise ValueError(f'line {reader.line_num}: expected three fields')
            sku = row['sku'].strip().lower()
            name = row['name'].strip()
            price = row['price_cents'].strip()
            if not sku or not name or not re.fullmatch(r'[0-9]+', price):
                raise ValueError(f'line {reader.line_num}: invalid SKU, name or price')
            price = int(price)
            if price > 9223372036854775807:
                raise ValueError(f'line {reader.line_num}: price exceeds SQLite integer range')
            rows.setdefault(sku, (sku, name, price))
    return rows.values()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    args = parser.parse_args()
    try:
        rows = read_import(args.path) if args.command == 'import' else None
        connection = sqlite3.connect(args.db)
        try:
            with connection:
                connection.execute('CREATE TABLE IF NOT EXISTS catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
                if rows is not None:
                    connection.execute('BEGIN IMMEDIATE')
                    existing = {sku.strip().lower() for (sku,) in connection.execute('SELECT sku FROM catalog')}
                    connection.executemany(
                        'INSERT INTO catalog (sku,name,price_cents) VALUES (?,?,?)',
                        (row for row in rows if row[0] not in existing),
                    )
                else:
                    print(json.dumps([
                        dict(sku=sku, name=name, price_cents=price)
                        for sku, name, price in connection.execute(
                            'SELECT sku,name,price_cents FROM catalog ORDER BY sku'
                        )
                    ]))
        finally:
            connection.close()
    except (OSError, ValueError, csv.Error, sqlite3.Error) as error:
        parser.exit(1, f'error: {error}\n')


if __name__ == '__main__':
    main()
