import json
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


class Catalog(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.db = Path(self.temp.name) / 'catalog.sqlite'
        self.csv = Path(self.temp.name) / 'items.csv'

    def cli(self, *args):
        return subprocess.run(
            [sys.executable, 'catalog.py', '--db', str(self.db), *args],
            text=True, capture_output=True,
        )

    def items(self):
        result = self.cli('list')
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def load(self, body):
        self.csv.write_text('sku,name,price_cents\n' + body, encoding='utf-8')
        return self.cli('import', str(self.csv))

    def test_empty_list(self):
        self.assertEqual(self.items(), [])

    def test_normalized_first_wins_and_zero_retained(self):
        result = self.load(' B , First ,0\nb,Second,90\na,Other,12\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [
            {'sku': 'a', 'name': 'Other', 'price_cents': 12},
            {'sku': 'b', 'name': 'First', 'price_cents': 0},
        ])
        self.assertEqual(self.load('B,Replacement,10\n').returncode, 0)
        self.assertEqual(self.items()[1]['name'], 'First')

    def test_legacy_collision_preserves_stored_row(self):
        self.items()
        with sqlite3.connect(self.db) as connection:
            connection.execute('INSERT INTO catalog VALUES (?,?,?)', (' Old ', 'Legacy', 7))
        self.assertEqual(self.load('old,New,20\n').returncode, 0)
        self.assertEqual(self.items(), [{'sku': ' Old ', 'name': 'Legacy', 'price_cents': 7}])

    def test_invalid_import_is_atomic_including_duplicate_rows(self):
        self.assertEqual(self.load('saved,Original,9\n').returncode, 0)
        before = self.items()
        for bad in ['x,,3', ',Name,3', 'x,Name,-1', 'x,Name,1.5',
                    'x,Name', 'x,Name,1,extra', 'x,Name,9223372036854775808',
                    'new,Duplicate,invalid', 'x,"unterminated,3']:
            with self.subTest(bad=bad):
                result = self.load('new,Valid,1\n' + bad + '\n')
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(self.items(), before)

    def test_bad_header_and_missing_file(self):
        self.csv.write_text('name,sku,price_cents\nName,x,1\n')
        self.assertNotEqual(self.cli('import', str(self.csv)).returncode, 0)
        self.assertNotEqual(self.cli('import', str(self.csv) + '.missing').returncode, 0)
        self.assertFalse(self.db.exists())


if __name__ == '__main__':
    unittest.main()
