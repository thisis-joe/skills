# Purchasing catalog
Python standard library only. Public entry: `python3 catalog.py --db PATH list`.
List returns a JSON array of {sku,name,price_cents}. Existing SQLite table is
catalog(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL).
CSV has header sku,name,price_cents. SKU/name must be nonempty; prices are
nonnegative integer cents. Business choices are not established in this README.
Use the existing public CLI entry for added commands. Local regression command:
`python3 -m unittest discover -v`. Work locally; preserve unrelated files.

Import with `python3 catalog.py --db PATH import items.csv`. SKU keys are trimmed
and lowercased; names are trimmed. Duplicate keys within the file or against
stored keys reject the entire import (exit 1). Malformed rows are skipped with
stderr diagnostics; valid rows are committed together (exit 0). Successful
imports produce no stdout. Prices must fit SQLite's nonnegative signed 64-bit
integer range. Missing/unreadable files and incorrect headers are errors.
Malformed CSV records are skipped where the CSV reader can recover; an unclosed
quoted field can consume the rest of a file as one malformed record.

List keeps its sorted JSON interface and includes zero-price rows. Existing
stored keys are preserved verbatim, but collision checks normalize them.
Summary is not implemented yet. See docs/import-checkpoint.md for the handoff.
