# Catalog import/list work record

Scope: implement import PATH on the existing --db PATH CLI, preserving list JSON
and stored items. Summary is deliberately deferred to the next session.

Agreed contract: trim SKU/name surroundings; lowercase SKU keys. Reject the
entire file on any repeated nonempty normalized SKU (even identical rows), or
collision with a stored normalized key. Skip malformed rows, report row reasons
on stderr, and successfully import valid rows. Prices are nonnegative integer
cents; SKU/name are nonempty. List includes zero-price items. Future summary
excludes zero-price items from count and total; its JSON is [] when no eligible
items, otherwise [{"supplier":"legacy","count":N,"total_cents":N}].

Plan: (1) implement and check import/list through subprocess CLI tests, including
atomic rejection and legacy preservation; (2) inspect and commit this unit;
(3) leave summary to a colleague. No supplier/batch extension.

Execution: basic technical progress automatic for this scope, stop before push.
Separate specialists declined; same-agent inspection accepted, not independent
review. No unresolved owner choices. Authoritative status is this file.
Pre-existing unrelated work: untracked personal-notes.txt; leave untouched.

## Completed checkpoint

Branch: feat/catalog-csv-import-list. Base: c84028d3baa576595a08a263d31a8cdeffdebd14.
Import/list implementation complete, summary absent. No material design departure.
SQLite signed 64-bit overflow prices are skipped with diagnostics. Bad headers
and unreadable files fail; malformed CSV is skipped where csv.reader can recover
(unclosed quotes may consume remaining lines). Duplicate checks include nonempty
keys on invalid value/shape rows where CSV parsing recovered the key.

Evidence: initial regression run failed for missing import command (3 failures).
Final `python3 -m unittest discover -v`: 7 passed, real subprocess CLI checks.
Additional disposable CLI flow: import A/Apple/125 + zero/Free/0 + bad/-2 exited
0, warned row 4; list returned normalized a and zero. Import new plus A collision
exited 1; subsequent list was unchanged. `git diff --check` passed.
Same-agent inspection covered implementation, tests, README and this record;
no independent review or separate specialist examinations performed (declined).
Only task-owned files are committed. Use Git log for work-unit commit IDs.

Next safe action: read this record and BRIEF.md, inspect current Git state, then
implement summary in a new descriptive feature branch/work-unit commit. Use
positive-price rows for count/total; cover empty, zero-only, mixed and preserved
legacy data with actual CLI checks and the full unittest suite. Do not change
import/list semantics or migrate stored keys incidentally. No owner decisions
remain open. No push, publication, or external writes authorized/performed.
