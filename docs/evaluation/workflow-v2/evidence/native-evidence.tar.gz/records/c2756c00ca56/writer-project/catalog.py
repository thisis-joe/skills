import argparse
import csv
import json
import re
import sqlite3
import sys


def import_csv(connection, path):
    rows = []
    seen = set()
    with open(path, newline='', encoding='utf-8') as source:
        reader = csv.reader(source, strict=True)
        if next(reader, None) != ['sku', 'name', 'price_cents']:
            raise ValueError('expected CSV header sku,name,price_cents')
        while True:
            try:
                row = next(reader)
            except StopIteration:
                break
            except csv.Error as error:
                print(f'row {reader.line_num}: skipped malformed CSV ({error})', file=sys.stderr)
                continue
            line = reader.line_num
            sku = row[0].strip().lower() if row else ''
            if sku:
                if sku in seen:
                    raise ValueError(f'row {line}: duplicate SKU {sku!r}')
                seen.add(sku)
            if (len(row) != 3 or not sku or not row[1].strip()
                    or re.fullmatch(r'[0-9]+', row[2].strip()) is None):
                print(f'row {line}: skipped malformed row (requires SKU, name, and nonnegative integer cents)',
                      file=sys.stderr)
                continue
            try:
                price = int(row[2].strip())
            except ValueError:
                price = -1
            if not 0 <= price <= 9223372036854775807:
                print(f'row {line}: skipped price outside SQLite integer range', file=sys.stderr)
                continue
            rows.append((sku, row[1].strip(), price))
    with connection:
        # Lock before checking collisions so another writer cannot race the check.
        connection.execute('BEGIN IMMEDIATE')
        stored = {sku.strip().lower() for (sku,) in connection.execute('SELECT sku FROM catalog')}
        collisions = stored & seen
        if collisions:
            raise ValueError(f'duplicate stored SKU {min(collisions)!r}')
        connection.executemany('INSERT INTO catalog VALUES (?, ?, ?)', rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    args = parser.parse_args()
    try:
        with sqlite3.connect(args.db) as connection:
            connection.execute('CREATE TABLE IF NOT EXISTS catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
            if args.command == 'import':
                import_csv(connection, args.path)
            else:
                print(json.dumps([dict(sku=k, name=n, price_cents=v) for k, n, v in
                                  connection.execute('SELECT sku,name,price_cents FROM catalog ORDER BY sku')]))
    except (OSError, UnicodeError, csv.Error, ValueError, sqlite3.Error) as error:
        print(f'catalog: {error}', file=sys.stderr)
        return 1
    finally:
        if 'connection' in locals():
            connection.close()
    return 0


if __name__ == '__main__':
    sys.exit(main())
