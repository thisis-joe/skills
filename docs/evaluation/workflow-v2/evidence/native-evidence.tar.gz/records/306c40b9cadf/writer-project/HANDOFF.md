# Catalog checkpoint

## Authority and state

Owner authorized automatic local implementation, CLI checks and commits for
**import/list only**, stopping before push. No Jira, external services, installs,
subagents or separate specialist examinations. Local `.guide` build, verify and
context procedures were used with those explicit overrides. Inspection was by
the implementing agent and is not independent review.

Branch: `feat/catalog-import-list`. Base: `c84028d`.
Implementation/tests commit: `604df70` (see Git history if rebased).
Pre-existing untracked `personal-notes.txt` was not read, changed or committed.
No user database was used; checks used disposable temporary databases.

## Settled owner decisions

- Trim surrounding whitespace; lowercase SKU keys; case variants are one item.
- Repeated keys reject the file, including identical duplicates. Stored-key
  collision also rejects the entire file without inserting other rows.
- Skip malformed rows, import valid rows successfully, explain skips on stderr.
- List retains zero-price rows.
- Future summary excludes zero-price rows from both count and total.

## Completed and evidence

`catalog.py --db PATH import PATH` is runnable through the existing CLI. List's
JSON shape/order and existing table are preserved. README describes validation,
exit status, collision handling and CSV parsing limitations.

Initial regression run: existing empty-list check passed; four new import checks
failed because import was absent. Final `python3 -m unittest discover -v`: all six
checks passed, exercising actual CLI subprocesses, including malformed CSV,
normalized and identical duplicates, malformed values, zero price, stored legacy
key collision, unchanged database bytes on rejection, bad header and missing file.
`git diff --check` passed.

Additional actual CLI smoke calls on a temporary database: mixed valid/invalid
CSV returned 0 and a skip diagnostic; list returned `abc` at 125 cents and `free`
at zero; stored `ABC` collision and repeated `x`/` X ` each returned 1 and left
list output unchanged. Same-agent diff inspection covered catalog.py and
test_catalog.py; documentation was inspected separately before its commit.

## Remaining work and next safe action

Summary has **no implementation or CLI parser yet**. No unresolved owner product
choice is known. BRIEF.md requires a JSON array containing
`{"supplier":"legacy","count":N,"total_cents":T}`; no qualifying entries gives
`[]`. Apply the settled exclusion of zero-price rows to both count and total.
One supplier only; supplier/batch extensions are outside scope.

Next session: inspect `git status --short`, current branch/history and this
handoff; preserve unrelated work. Begin a separate descriptive feature branch
for summary from this checkpoint. Add real CLI acceptance tests for empty,
zero-only and mixed-price catalogs, implement summary without changing import or
list, run the full unittest suite and actual summary CLI checks, inspect and
commit that work unit. Do not push without authorization. This session stops
here; the summary plan is a handoff, not completed work.
