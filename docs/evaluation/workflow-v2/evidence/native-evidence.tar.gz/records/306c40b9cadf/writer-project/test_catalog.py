import json
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


class Catalog(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.db = Path(self.temp.name) / "catalog.sqlite"
        self.csv = Path(self.temp.name) / "items.csv"

    def cli(self, *args):
        return subprocess.run(
            [sys.executable, "catalog.py", "--db", str(self.db), *args],
            text=True, capture_output=True,
        )

    def import_rows(self, rows):
        self.csv.write_text("sku,name,price_cents\n" + rows)
        return self.cli("import", str(self.csv))

    def items(self):
        result = self.cli("list")
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def test_empty_list(self):
        self.assertEqual(self.items(), [])

    def test_import_normalizes_skips_invalid_and_lists_zero(self):
        result = self.import_rows(
            " B , Beta ,12\na,Free,0\n,Missing,1\nx,,2\ny,Negative,-1\n"
            "z,Fraction,1.2\nw,Missing\nv,Extra,1,extra\n"
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stderr.count("Skipping row"), 6)
        self.assertEqual(self.items(), [
            {"sku": "a", "name": "Free", "price_cents": 0},
            {"sku": "b", "name": "Beta", "price_cents": 12},
        ])

    def test_duplicate_file_is_atomic_even_for_identical_rows(self):
        for rows in ("A,One,1\na,Two,2\n", "a,One,1\na,One,1\n",
                     "a,Bad,-1\n A ,Good,1\n"):
            result = self.import_rows("new,New,3\n" + rows)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("Duplicate SKU", result.stderr)
            self.assertEqual(self.items(), [])

    def test_stored_collision_preserves_legacy_data(self):
        self.items()
        with sqlite3.connect(self.db) as connection:
            connection.execute("INSERT INTO catalog VALUES (?, ?, ?)", (" A ", "Original", 7))
        before = self.db.read_bytes()
        result = self.import_rows("new,New,3\na,Replacement,9\n")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("stored SKU", result.stderr)
        self.assertEqual(self.db.read_bytes(), before)
        self.assertEqual(self.items(), [{"sku": " A ", "name": "Original", "price_cents": 7}])

    def test_malformed_csv_record_is_skipped(self):
        result = self.import_rows('a,Good,1\n"broken"oops,Bad,2\nb,Free,0\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("Skipping row 3", result.stderr)
        self.assertEqual([item["sku"] for item in self.items()], ["a", "b"])

    def test_bad_header_and_missing_file_fail_cleanly(self):
        self.csv.write_text("wrong,header\na,A\n")
        result = self.cli("import", str(self.csv))
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("header", result.stderr)
        result = self.cli("import", str(self.csv) + ".missing")
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn("Traceback", result.stderr)
