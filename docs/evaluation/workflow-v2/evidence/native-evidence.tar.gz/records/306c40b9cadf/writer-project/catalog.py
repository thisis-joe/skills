import argparse
import csv
import json
import re
import sqlite3
import sys


def read_import(path):
    items = []
    seen = set()
    with open(path, newline='', encoding='utf-8') as source:
        rows = csv.reader(source, strict=True)
        if next(rows, None) != ['sku', 'name', 'price_cents']:
            raise ValueError('CSV header must be sku,name,price_cents')
        while True:
            try:
                row = next(rows)
            except StopIteration:
                break
            except csv.Error as error:
                print(f'Skipping row {rows.line_num}: {error}', file=sys.stderr)
                continue
            sku = row[0].strip().lower() if row else ''
            if sku:
                if sku in seen:
                    raise ValueError(f'Duplicate SKU {sku!r} at row {rows.line_num}')
                seen.add(sku)
            if len(row) != 3:
                print(f'Skipping row {rows.line_num}: expected three fields', file=sys.stderr)
                continue
            name, price = row[1].strip(), row[2].strip()
            if not sku or not name or not re.fullmatch(r'[0-9]+', price):
                print(f'Skipping row {rows.line_num}: nonempty SKU/name and nonnegative integer price required', file=sys.stderr)
                continue
            try:
                cents = int(price)
                if cents > 9223372036854775807:
                    raise ValueError('price exceeds SQLite integer range')
            except ValueError:
                print(f'Skipping row {rows.line_num}: price exceeds SQLite integer range', file=sys.stderr)
                continue
            items.append((sku, name, cents))
    return items, seen


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    args = parser.parse_args()
    try:
        # Validate the complete file before changing the catalog.
        if args.command == 'import':
            items, keys = read_import(args.path)
        connection = sqlite3.connect(args.db)
        try:
            with connection:
                connection.execute('CREATE TABLE IF NOT EXISTS catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
                if args.command == 'import':
                    connection.execute('BEGIN IMMEDIATE')
                    stored = {sku.strip().lower() for (sku,) in connection.execute('SELECT sku FROM catalog')}
                    collisions = keys & stored
                    if collisions:
                        raise ValueError(f'Import collides with stored SKU {min(collisions)!r}')
                    connection.executemany('INSERT INTO catalog VALUES (?, ?, ?)', items)
                else:
                    print(json.dumps([
                        dict(sku=sku, name=name, price_cents=price)
                        for sku, name, price in connection.execute(
                            'SELECT sku,name,price_cents FROM catalog ORDER BY sku'
                        )
                    ]))
        finally:
            connection.close()
    except (OSError, UnicodeError, csv.Error, ValueError, sqlite3.Error) as error:
        print(f'catalog: {error}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
