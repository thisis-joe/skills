# Purchasing catalog

Python standard library only. Public commands:

```sh
python3 catalog.py --db PATH import items.csv
python3 catalog.py --db PATH list
python3 -m unittest discover -v
```

CSV must have the exact header `sku,name,price_cents` and UTF-8 encoding.
Imported SKUs are trimmed and lowercased; names are trimmed. SKU/name must be
nonempty. Prices are nonnegative integer cents within SQLite's signed 64-bit
integer range. Zero-price items remain in list output.

Malformed records are skipped with row diagnostics on stderr; valid records
are imported with exit status 0. Repeated normalized keys (even identical rows)
or collisions with stored normalized keys reject the whole import with status
1. Parseable nonempty keys participate in collision detection even when their
other fields are invalid. Existing rows are preserved, including their original
spelling. Invalid headers, unreadable files and database failures return status 1.
Successful import writes no stdout.

List returns a JSON array of `{sku,name,price_cents}`, ordered by stored SKU.
Existing SQLite table remains
`catalog(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)`.
CSV diagnostics use the ending physical line number of the record. CSV quoting
can span lines; an unterminated quoted record may consume the remaining input,
which is skipped as one malformed record.

`summary` is intentionally deferred. See `HANDOFF.md` for the next work unit.
Work locally; preserve unrelated files. Do not publish.
