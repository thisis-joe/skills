# Purchasing catalog
Python standard library only. Public entry: `python3 catalog.py --db PATH list`.
List returns a JSON array of {sku,name,price_cents}. Existing SQLite table is
catalog(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL).
CSV has header sku,name,price_cents. SKU/name must be nonempty; prices are
nonnegative integer cents. Business choices are not established in this README.
Use the existing public CLI entry for added commands. Local regression command:
`python3 -m unittest discover -v`. Work locally; preserve unrelated files.

Import: `python3 catalog.py --db PATH import items.csv` (silent on success;
nonzero exit and stderr on invalid input). Imports validate the entire CSV
before writing. Keys are trimmed/lowercase; first file row and existing stored
rows win collisions. List keeps zero-price items. See
[the saved contract](docs/specs/catalog-import-list.md) and
[work checkpoint](docs/plans/catalog-import-list.md) for decisions and deferred summary work.
