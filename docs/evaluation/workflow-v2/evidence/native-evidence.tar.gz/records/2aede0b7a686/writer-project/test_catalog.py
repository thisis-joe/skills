import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest


class Catalog(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db = str(Path(self.tmp.name) / 'catalog.sqlite')

    def cli(self, *args):
        return subprocess.run([sys.executable, 'catalog.py', '--db', self.db, *args],
                              text=True, capture_output=True)

    def rows(self):
        result = self.cli('list')
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def csv(self, content):
        path = Path(self.tmp.name) / 'items.csv'
        path.write_text(content, encoding='utf-8')
        return str(path)

    def test_empty_list(self):
        self.assertEqual(self.rows(), [])

    def test_import_normalization_duplicates_zero_and_existing(self):
        path = self.csv('sku,name,price_cents\n B , First ,0\nb,Second,99\na,Other,20\n')
        result = self.cli('import', path)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.rows(), [dict(sku='a', name='Other', price_cents=20),
                                       dict(sku='b', name='First', price_cents=0)])
        self.assertEqual(self.cli('import', path).returncode, 0)
        self.assertEqual(len(self.rows()), 2)
        with sqlite3.connect(self.db) as conn:
            conn.execute("INSERT INTO catalog VALUES (' LEGACY ', 'Stored', 7)")
        self.assertEqual(self.cli('import', self.csv(
            'sku,name,price_cents\nlegacy,Replacement,8\n')).returncode, 0)
        self.assertIn(dict(sku=' LEGACY ', name='Stored', price_cents=7), self.rows())
        self.assertEqual(len(self.rows()), 3)

    def test_invalid_import_is_atomic(self):
        self.assertEqual(self.cli('import', self.csv(
            'sku,name,price_cents\nkept,Stored,12\n')).returncode, 0)
        before = self.rows()
        for bad in ['x,,1', ',Name,1', 'x,Name,-1', 'x,Name,1.5',
                    'x,Name,9223372036854775808', 'x,Name,1,extra',
                    'x,Name', 'kept,Duplicate,bad', 'x,"unterminated,1']:
            with self.subTest(bad=bad):
                result = self.cli('import', self.csv(
                    'sku,name,price_cents\nnew,Valid,5\n' + bad + '\n'))
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(self.rows(), before)
        result = self.cli('import', self.csv('wrong,name,price_cents\nx,Name,1\n'))
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(self.rows(), before)
