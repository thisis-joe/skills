# Catalog import/list
Use the existing Python stdlib CLI: `python3 catalog.py --db DB import CSV`.
CSV header is exactly sku,name,price_cents. Trim fields; SKU keys use lowercase.
SKU/name must be nonempty, prices decimal nonnegative integer cents within
SQLite's signed 64-bit range. Reject malformed CSV, headers, field counts or
rows before writing any catalog data, including malformed duplicate rows.
Keep the first normalized key in the file; existing stored rows win collisions,
including stored keys with surrounding whitespace or uppercase. Do not rewrite
existing rows. List remains a SKU-sorted JSON array and retains zero prices.

Summary is deferred: JSON array [{supplier: "legacy", count, total_cents}],
empty catalog -> []; count includes zero-price rows, which add zero to total.
No supplier/batch extension. No publication or independent review this session.
