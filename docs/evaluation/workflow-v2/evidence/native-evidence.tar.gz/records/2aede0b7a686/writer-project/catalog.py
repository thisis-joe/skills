import argparse
import csv
import json
import re
import sqlite3


def read_import(path):
    rows = {}
    with open(path, newline='', encoding='utf-8') as source:
        reader = csv.reader(source, strict=True)
        if next(reader, None) != ['sku', 'name', 'price_cents']:
            raise ValueError('expected CSV header sku,name,price_cents')
        for row in reader:
            if len(row) != 3:
                raise ValueError(f'line {reader.line_num}: expected three fields')
            sku, name, price = (field.strip() for field in row)
            sku = sku.lower()
            if not sku or not name or not re.fullmatch(r'[0-9]+', price):
                raise ValueError(f'line {reader.line_num}: invalid SKU, name or price')
            price = int(price)
            if price > 9223372036854775807:
                raise ValueError(f'line {reader.line_num}: price exceeds SQLite integer range')
            rows.setdefault(sku, (sku, name, price))
    return list(rows.values())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    args = parser.parse_args()
    try:
        # Validate the entire file before opening or changing the catalog.
        rows = read_import(args.path) if args.command == 'import' else None
        with sqlite3.connect(args.db) as conn:
            if rows is not None:
                conn.execute('BEGIN IMMEDIATE')
            conn.execute('CREATE TABLE IF NOT EXISTS catalog '
                         '(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
            if rows is not None:
                existing = {sku.strip().lower() for (sku,) in
                            conn.execute('SELECT sku FROM catalog')}
                conn.executemany('INSERT INTO catalog VALUES (?, ?, ?)',
                                 [row for row in rows if row[0] not in existing])
            else:
                print(json.dumps([dict(sku=k, name=n, price_cents=v) for k, n, v in
                                  conn.execute('SELECT sku,name,price_cents FROM catalog ORDER BY sku')]))
    except (OSError, UnicodeError, csv.Error, ValueError, sqlite3.Error) as error:
        parser.exit(1, f'error: {error}\n')
    finally:
        if 'conn' in locals():
            conn.close()


if __name__ == '__main__':
    main()
