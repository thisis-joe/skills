# Purchasing catalog

Python standard library only. Commands:

```sh
python3 catalog.py --db PATH import items.csv
python3 catalog.py --db PATH list
python3 -m unittest discover -v
```

Import accepts UTF-8 CSV with the exact header `sku,name,price_cents`.
Surrounding field whitespace is trimmed. SKU and name must be nonempty;
SKU case is preserved and case variants are separate items. Prices must be
ASCII nonnegative integer cents within SQLite's signed 64-bit integer range.
Every data row must have exactly three fields. A header-only file is a no-op.
The last row for a SKU wins, including when updating a stored item. Other
stored items are preserved. The whole file is validated before writes, and
updates run in one transaction. Invalid input exits nonzero with an error on
stderr and leaves the catalog unchanged. Successful import exits zero silently.

List returns a JSON array of `{sku,name,price_cents}` ordered by SKU, including
zero-price items. The SQLite table remains
`catalog(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)`.

Summary is deferred; see [HANDOFF.md](HANDOFF.md). Work locally; do not publish.
