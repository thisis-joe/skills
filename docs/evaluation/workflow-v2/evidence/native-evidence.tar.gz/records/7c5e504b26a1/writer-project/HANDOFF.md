# Import/list checkpoint

Scope: implement only runnable import/list now. Summary belongs to a colleague's
next session. No external services, installs, publishing or global changes.
Use Python stdlib, existing CLI, descriptive feature branches and work-unit
commits. Product choices remain with the owner.

Branch: `feat/catalog-import-list`.
Base: `c84028d3baa576595a08a263d31a8cdeffdebd14`.
Implementation commit: `3ff18cc` (`feat: import catalog CSV atomically through existing CLI`).
This handoff is a separate documentation work-unit commit; find its ID with
`git log -2 --oneline` rather than treating this file as a live HEAD pointer.

## Agreed behavior

- Trim surrounding field whitespace, preserve SKU case; case variants differ.
- Last duplicate SKU in a file wins; subsequent imports update stored rows.
- Reject the entire import if any row is malformed, preserving the catalog.
- List retains zero-price rows. Future summary counts them and adds zero to total.
- Per BRIEF.md, summary is a JSON array with one object for supplier `legacy`,
  `count`, and `total_cents`; an empty catalog yields `[]`.
- One supplier only; supplier/batch extensions are outside scope.

## Done and evidence

`catalog.py` validates the complete CSV before connecting, then performs a
transactional upsert. List keeps its JSON fields and SKU ordering. README.md
records CSV format, errors, output, header-only behavior and SQLite price bounds.
No summary parser or implementation was added.

Baseline unittest: 1 passed. New behavior tests first failed because `import`
was unavailable. After implementation, `python3 -m unittest discover -v` passed
all 4 tests (CLI subprocesses with isolated temporary databases). Coverage:
trimming, case variants, duplicate rows, stored updates, retained zero prices,
missing files, invalid headers, wrong field counts, empty fields, bad/negative/
fractional/overflow prices, malformed quoting and atomic rejection.

A separate actual CLI smoke check imported spaced `SKU` and lowercase `sku`,
with duplicate `SKU`: list returned `SKU/Last/12` and `sku/Free/0`. A subsequent
file updating SKU followed by a negative-price row exited 1, and list was
byte-for-byte unchanged. All databases used for checks were temporary.
`git diff --check` passed. Same-agent inspection covered the complete code/test
and documentation diff; no blocking findings. This was not independent review.

## Preserved state and next safe action

Pre-existing untracked `personal-notes.txt` was neither read nor changed nor
staged. Existing ignored `store.sqlite` was not opened or changed. No push.
No unresolved business decisions for the agreed slice or summary contract.

Next session: inspect `git status --short` and `git log -2 --oneline`, read
BRIEF.md, README.md and this file, and run `python3 -m unittest discover -v`.
Then begin the separately authorized summary slice on a descriptive branch:
add real CLI tests for empty catalog, mixed zero/nonzero rows, and totals after
updates; implement `summary` without changing import/list or the schema; run
CLI acceptance checks and the full suite, inspect changes and commit locally.
Do not resume summary implementation merely from this handoff in this session.
