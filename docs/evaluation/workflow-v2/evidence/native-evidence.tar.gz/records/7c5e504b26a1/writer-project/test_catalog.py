import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class Catalog(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.db = self.root / 'catalog.sqlite'

    def cli(self, *args):
        return subprocess.run(
            [sys.executable, 'catalog.py', '--db', str(self.db), *args],
            capture_output=True, text=True)

    def rows(self):
        result = self.cli('list')
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def load(self, text):
        path = self.root / 'items.csv'
        path.write_text(text, encoding='utf-8')
        return self.cli('import', str(path))

    def test_empty_list(self):
        self.assertEqual(self.rows(), [])

    def test_import_updates_duplicates_preserves_case_and_zero(self):
        result = self.load('sku,name,price_cents\n A , First , 10 \na,Lower,0\nA,Last,20\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.rows(), [
            dict(sku='A', name='Last', price_cents=20),
            dict(sku='a', name='Lower', price_cents=0)])
        result = self.load('sku,name,price_cents\nA,Updated,30\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.rows(), [
            dict(sku='A', name='Updated', price_cents=30),
            dict(sku='a', name='Lower', price_cents=0)])

    def test_malformed_import_is_atomic(self):
        self.assertEqual(self.load('sku,name,price_cents\nkeep,Original,7\n').returncode, 0)
        for bad in ['x,,1', ',Name,1', 'x,Name,-1', 'x,Name,1.5',
                    'x,Name,abc', 'x,Name', 'x,Name,1,extra',
                    'x,Name,9223372036854775808', '"unterminated,Name,1']:
            with self.subTest(bad=bad):
                result = self.load('sku,name,price_cents\nkeep,Changed,9\n' + bad + '\n')
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(self.rows(), [dict(sku='keep', name='Original', price_cents=7)])

    def test_header_and_missing_file(self):
        for contents in ['', 'sku,name\nx,Name\n', 'name,sku,price_cents\nName,x,1\n']:
            self.assertNotEqual(self.load(contents).returncode, 0)
        self.assertNotEqual(self.cli('import', str(self.root / 'missing')).returncode, 0)
        self.assertEqual(self.rows(), [])
