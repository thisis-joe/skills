# Catalog checkpoint

Owner authorized only the runnable import/list slice for this session. Summary
is deliberately unimplemented; no supplier/batch extension is in scope.

## Settled owner decisions

- Trim surrounding whitespace and lowercase SKU keys; case variants are one item.
- Last duplicate row wins within a file; later imports update stored rows.
- Any malformed row rejects the entire import without changing the catalog.
- Summary excludes zero-price rows from both count and total; list retains them.

## Completed

Branch: feature/catalog-import-list. Implementation commit: a3f774b.
The existing CLI now accepts `python3 catalog.py --db PATH import FILE` and
continues to support `list` with the original JSON row interface. README records
input validation and error behavior. Only imported keys replace matching legacy
case/whitespace variants; other stored items remain untouched.

Verification: `python3 -m unittest discover -v` passed both tests. Subprocess CLI
regression covers duplicates, normalization, updates, zero prices, malformed
rows, bad headers, integer overflow, header-only input, and atomic rejection.
An additional actual CLI check seeded a legacy mixed/whitespace key and unrelated
row, verified canonical replacement and preservation, then verified that a
malformed import left the list unchanged. `git diff --check` passed.
Same-agent code inspection only; this was not independent specialist review.

## Next safe action

Read this file, BRIEF.md, README.md, catalog.py and test_catalog.py; inspect Git
status to preserve unrelated work. On a new descriptive summary feature branch,
implement `summary` through the existing CLI. Return a JSON array with
`{"supplier":"legacy","count":N,"total_cents":T}` for positive-price rows;
return `[]` when no rows qualify (including an all-zero catalog). Add actual CLI
checks for empty, all-zero, mixed prices, and updates after import, then run the
existing unittest suite. Do not publish without owner authorization.

No product decision remains unresolved for this slice or the agreed summary
rules. Summary implementation and its verification remain outstanding.
`personal-notes.txt` was already untracked and was neither read nor changed.
