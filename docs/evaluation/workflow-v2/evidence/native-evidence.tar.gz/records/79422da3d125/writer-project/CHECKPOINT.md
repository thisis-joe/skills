# Import/list checkpoint

Owner scope: implement and commit only runnable import/list now. Summary belongs
to a colleague's next session. No Jira, publishing, external services or agents.

## Settled business decisions

- Trim surrounding SKU whitespace and use lowercase keys; case variants are one item.
- Repeated keys reject the whole file, including identical duplicate rows.
- A stored-key collision rejects the whole file, preserving stored items.
- Skip malformed rows, import valid rows successfully, and explain skips on stderr.
- List retains zero-price rows.
- Future summary excludes zero-price rows from both count and total.

## Completed

`catalog.py import PATH` uses the existing `--db PATH` CLI and SQLite table.
List's JSON interface is preserved. README documents concrete import output,
validation, error handling, and duplicate detection, including malformed rows
with nonempty keys. Existing stored keys are normalized only for comparison;
legacy records are never rewritten. No supplier/batch extension was added.

Verification: all six tests passed using `python3 -m unittest discover -v`.
The tests call the real CLI with temporary CSV files and databases, covering
normalization, zero price, malformed rows, duplicate rejection, stored collisions,
legacy preservation, bad headers and missing files. Same-agent source inspection
was performed; this is not independent review.

## Remaining and next safe action

Summary is deliberately not registered or implemented. Start by reading BRIEF.md,
README.md, this checkpoint, and the current CLI/tests. Implement `summary` as the
brief's JSON array of `{supplier: "legacy", count, total_cents}` using only rows
with positive prices. Empty qualifying data returns `[]`, including a catalog
containing only zero-price rows. Preserve import/list behavior; add actual CLI
checks for empty, only-zero, and mixed-price cases; run the full unittest suite.
Use a descriptive feature branch and work-unit commits, and stop before push.

There are no unresolved owner product decisions for this scoped slice or the
stated summary rules. Import's precise technical conventions are in README.md.
The pre-existing untracked personal-notes.txt was left unread and untouched.
