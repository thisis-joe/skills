# Purchasing catalog

Python standard library only. Run from this project:

```sh
python3 catalog.py --db catalog.sqlite import items.csv
python3 catalog.py --db catalog.sqlite list
python3 -m unittest discover -v
```

CSV uses UTF-8 and the header `sku,name,price_cents`. Surrounding whitespace
in values is trimmed. SKU case is preserved: `A` and `a` are different items.
SKU/name must be nonempty; prices must be nonnegative decimal integer cents
within SQLite's signed 64-bit integer range. Malformed data rows are skipped
with line numbers and reasons on stderr; valid rows are imported and the command
succeeds. The first valid row for a SKU wins; existing stored rows always win.
Import writes no stdout. An invalid/missing header or unreadable input fails
without committing imported items.

List returns a JSON array of `{sku,name,price_cents}`, ordered by SKU, including
zero-price rows. The existing SQLite table remains
`catalog(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)`.

`summary` is not implemented in this checkpoint. See [HANDOFF.md](HANDOFF.md)
for agreed behavior and the next task. Work locally; preserve unrelated files.
