# Catalog CSV import and summary

Use the existing Python stdlib CLI and SQLite catalog schema. Preserve stored
rows and the list JSON array interface, sorted by SKU.

CSV header: sku,name,price_cents. Trim surrounding whitespace from values;
SKU case is preserved and case variants are distinct. SKU/name must be nonempty;
price must be nonnegative integer cents. Keep the first valid row per SKU in a
file and keep existing stored rows on collisions. Skip malformed rows, explain
each skip on stderr, and successfully import valid rows. List retains zero prices.

This session implements only `import PATH` and compatible `list`. Summary is
explicitly deferred. Its agreed eventual output is a JSON array containing
{supplier: "legacy", count, total_cents}, or [] for no items. Zero-price rows
contribute to count and zero to total. Supplier/batch extensions are out of scope.

Acceptance: real CLI import/list checks cover trimming, case distinctions,
file/stored collisions, invalid rows, zero prices, persistence and list shape;
run the existing unittest suite. No publishing.
