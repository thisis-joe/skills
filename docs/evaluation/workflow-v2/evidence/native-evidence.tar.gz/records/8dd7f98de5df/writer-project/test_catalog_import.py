import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class CatalogImport(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.db = self.root / 'catalog.sqlite'

    def cli(self, *args):
        return subprocess.run(
            [sys.executable, str(Path(__file__).with_name('catalog.py')),
             '--db', str(self.db), *args], capture_output=True, text=True)

    def load(self, content):
        path = self.root / 'items.csv'
        path.write_text(content, encoding='utf-8')
        return self.cli('import', str(path))

    def listing(self):
        result = self.cli('list')
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def test_duplicates_case_zero_and_later_update(self):
        result = self.load('sku,name,price_cents\n A , First , 10 \nA,Last,0\na,Lower,20\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.listing(), [
            dict(sku='A', name='Last', price_cents=0),
            dict(sku='a', name='Lower', price_cents=20)])
        result = self.load('sku,name,price_cents\nA,Updated,30\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.listing(), [
            dict(sku='A', name='Updated', price_cents=30),
            dict(sku='a', name='Lower', price_cents=20)])

    def test_invalid_import_preserves_catalog(self):
        self.assertEqual(self.load('sku,name,price_cents\nA,Original,5\n').returncode, 0)
        original = self.listing()
        for bad in ['B,New,-1', 'B,New,1.5', 'B,New,+1', 'B,New,',
                    ',New,1', 'B, ,1', 'B,New,1,extra', 'B,New',
                    'B,New,9223372036854775808', '"unterminated',
                    'A,Invalid,-1\nA,Valid,1']:
            with self.subTest(row=bad):
                result = self.load('sku,name,price_cents\nA,Changed,9\n' + bad + '\n')
                self.assertNotEqual(result.returncode, 0)
                self.assertTrue(result.stderr)
                self.assertEqual(self.listing(), original)

    def test_bad_header_and_header_only(self):
        self.assertNotEqual(self.load('sku,name,price\nA,Name,1\n').returncode, 0)
        self.assertFalse(self.db.exists())
        self.assertEqual(self.load('sku,name,price_cents\n').returncode, 0)
        self.assertEqual(self.listing(), [])
