# Purchasing catalog

Python standard library only. Run:

```sh
python3 catalog.py --db catalog.sqlite import items.csv
python3 catalog.py --db catalog.sqlite list
python3 -m unittest discover -v
```

Import accepts UTF-8 CSV with the exact header `sku,name,price_cents` and
three fields per record. Surrounding field whitespace is trimmed. SKU and name
must be nonempty; SKU case is preserved and case variants are distinct items.
Prices use decimal digits for nonnegative integer cents, within SQLite's signed
64-bit integer range. Zero is valid. Header-only imports are successful no-ops.
Successful import exits zero without output; errors exit nonzero with stderr.

Every row must be valid, even a duplicate that a later row replaces. Any malformed
row rejects the whole import before database writes. The last row for each SKU
wins, and subsequent imports update existing SKUs. Other stored items survive.
Updates are transactional.

List returns a JSON array of `{sku,name,price_cents}`, sorted by SKU, including
zero-price items. The SQLite schema remains
`catalog(sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)`.

Summary is deferred; see [HANDOFF.md](HANDOFF.md) for the next work checkpoint.
