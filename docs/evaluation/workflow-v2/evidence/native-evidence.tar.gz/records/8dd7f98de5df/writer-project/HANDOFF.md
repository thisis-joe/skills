# Checkpoint: import/list complete; summary next

The owner authorized this session to implement, verify and commit only the
runnable import/list slice, stopping before push. No publishing occurred.
There is no Jira and no local .guide directory. Work is on
`feature/catalog-import-list`. Untracked `personal-notes.txt` predates this work
and was neither read nor changed. Preserve it.

## Settled business choices

- Trim surrounding whitespace; preserve SKU case. Case variants are different items.
- Last duplicate key in a file wins; later imports update existing stored rows.
- Reject the entire import if any row is malformed; preserve the catalog.
- Summary counts zero-price rows; they contribute zero cents. List retains them.

## Completed and verified

Import uses the existing CLI, validates all CSV records before opening the DB,
and applies updates in one transaction. List keeps its existing JSON interface.
README documents the concrete CSV/error behavior and SQLite integer limit.

`python3 -m unittest discover -v` passed all four tests, including subprocess CLI
coverage of duplicates, trimming, case, zero price, later updates, malformed rows,
atomic rejection, bad headers and header-only input. Separate direct CLI checks
used a pre-existing legacy-schema database: existing rows survived import, the
expected list was returned, and a malformed late row left database bytes unchanged.
`git diff --check` passed. Inspection and checks were performed by the same agent;
this was not independent review. No specialist examination was performed.

## Remaining / next safe action

Implement `python3 catalog.py --db PATH summary` on a new descriptive feature
branch, preserving import/list. The agreed result is a JSON array with one object
`{"supplier":"legacy","count":N,"total_cents":T}` when rows exist, otherwise
`[]`. Count all stored rows, including zero-price ones; total their price_cents.
Supplier/batch extensions are outside scope. Summary is currently rejected by
argparse and has no implementation.

Add real CLI checks for empty data, mixed zero/nonzero prices, and summary after
updates and rejected imports; rerun the existing unittest suite. Use work-unit
commits and stop before push unless the owner changes authorization. There are
no outstanding business decisions for this agreed slice or summary. Any new
product choices remain with the owner.
