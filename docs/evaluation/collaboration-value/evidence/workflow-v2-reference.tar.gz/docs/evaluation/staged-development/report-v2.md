# COCO workflow and collaboration evaluation — v2

## What this evaluation establishes

**Current COCO made the agreed procedure understandable and consistent in all
five observed handoffs; a fresh worker recovered the agreement and completed the
remaining work in all five. All five beginner advice cases supplied an appropriate,
usable next step.** These are operational workflow outcomes, rather than a claim
that COCO raises the model's underlying coding ability.

Procedure clarity, common completion boundaries, usable decision records and a
shared way to ask for help are valid team requirements. Meeting those requirements
is useful even when another approach can also meet them. This report evaluates
that behavior directly; it does not make faster implementation a prerequisite
for workflow value.

Against published 0.2.0, the observed differences were one additional-input handoff
and one advice response with an extra Jira prerequisite. Against no provided skill
bodies, the requested workflow outcomes were tied in these scenarios. COCO supplied
its explicit four-stage vocabulary and procedure map; the ordinary agent also
produced usable records when directly asked to prepare a handoff. **The evidence
supports COCO as a working, shared procedure package; it does not establish that
these tasks require it or that real humans learn it faster.**

The [original report](report.md) remains unchanged. Its function/cost comparison
answers a different question and is not reinterpreted as a test of team usability.

## Scope, conditions and evidence

The [frozen v2 protocol](../workflow-v2/protocol.md) and
[specification](../../specs/workflow-value-v2.md) define the four requested axes.
Candidate: active skill files at `622975e`. Baseline: the actual published npm
`@thisis-joe/coco-skills@0.2.0`, gitHead
`256c88073a1bfa858c6221197959d6ad1d7d8a5c`, with its SHA-512 verified before use.
The third condition had no provided `.guide` bodies. All conditions had the same
project instructions, source seed, task, local capabilities and permissions.

There were **30 actual temporary projects and 45 distinct fresh native contexts**:
five matched handoffs per condition, each with a writer and a new successor, plus
five matched advice contexts per condition. Native CLI:
`codex-cli 0.163.0-alpha.11.2`, identical `--ignore-user-config` invocation and native
defaults, no model override. Model identity was not pinned/reported by the retained
events. The five policy profiles vary SKU identity, duplicate handling, malformed
rows and zero-price summary inclusion. Advice cases vary the development situation;
they are not repeated identical samples or observations of a human learning curve.

The [per-case table](../workflow-v2/case-table.md),
[structured results and grades](../workflow-v2/evidence/results.json), and
[complete native evidence](../workflow-v2/evidence/native-evidence.tar.gz) retain
the actual artifacts, prompts/actions, writer checkpoints, Git bundles, public
CLI/SQLite outcomes, source audits, blind packets and judgments. Evidence archive
SHA-256: `a814bef46256e5da838e4b9c8bea21eeb51ffc9925328de484703cea86548a0a`.
Frozen actor driver: `fc972745e44fce01a12440963026e5206a6ab05a`.
No active skill policy changed during this evaluation.

## How the scenarios tested the procedure

**Handoff:** the writer received the settled business choices in its conversation,
implemented and committed only import/list, and chose records for a colleague.
The experimenter did not insert those policy values into the seed files or write
a memory packet. After the writer ended, the successor received only the surviving
repository and a generic continuation request, in a new native thread. It had to
recover decisions, identify completed/pending work, implement summary and preserve
the completed import behavior. Actual CLI processes and persistent SQLite data
tested independent values and required error boundaries. Observers ran on copies
and left the successor's original files unchanged.

**Selection:** a newcomer asked what help/action to use next, why, and what result
to expect. The contexts were unsettled requirements, a ready specification/plan,
an unexpected CLI failure, committed work awaiting review, and browser acceptance
blocked by missing runtime. Advice had to remain read-only. An equivalent concrete
action in the no-body condition could receive full credit without COCO names.

All implementation handoffs had the same explicit automatic technical authority,
no-Jira convention, accepted same-agent inspection limitation, and publication
boundary. The successor received that technical authority again; this does **not**
test cross-chat consent persistence. Selection was a separate first-use advice
profile, not an automatic implementation run. Manual switching, specialist
preferences, open-ended grilling and real release execution were outside v2.

## Results on the requested criteria

Each applicable subitem was graded 0–2 using the frozen observable rubric. A full
case requires every applicable subitem on that axis to be 2. Counts below are
observations out of five, not estimated population success rates. No combined
cross-axis quality score is used.

| Criterion | Current COCO | Published 0.2.0 | No provided skill bodies |
| --- | --- | --- | --- |
| Clear agreement, completed/pending work and next safe action | 5/5 | 5/5 | 5/5 |
| Decisions, work checkpoint and truthful authority/completion remain consistent | 5/5 | 5/5 | 5/5 |
| Correct agreement recovery with usable source references | 5/5 | 5/5 | 5/5 |
| Independent pickup completes summary and preserves import | 5/5 | 4/5; one safe block | 5/5 |
| Suitable, understandable, usable advice without an added prerequisite | 5/5 | 4/5; one extra setup condition | 5/5 |
| Advice-only files/authority preserved | 5/5 | 5/5 | 5/5 |

All 15 writers stopped at the requested import-only checkpoint with working
import and without implementing summary early. All 15 successors preserved the
observed import/data boundaries. No successor was given owner rescue facts.

### Procedure clarity and consistency

The current procedure produced records from which the successor could recover
the agreement, completed slice, remaining summary and next permitted action in
every sample. The saved checkpoint was usable: the successor acted on it and the
result passed independent public probes. This goes beyond merely counting files.

All five current replies named the four-stage requirements → implementation →
review/verification → release framework. Four displayed the ten-skill overview
table; the ready-task reply recommended build directly and summarized the stages
in one sentence. That verifies the intended shared vocabulary and route are being
communicated. The other conditions also communicated correct immediate
work state and boundaries; named stages were not required for their full credit.

### Pickup and the safe blocked case

Published case `227883cfa7c7` preserved all four known business choices, commits,
verification history and a new open question: should a nonempty all-zero catalog
produce `[]` or one zero-count summary object? Its successor cited those records
and asked that same question before implementation. Summary remained absent, so
the no-intervention completion criterion was unmet.

**This is not lost context or dishonest completion.** Recovery, scope, preservation
and truth received full credit. The difference concerns an additional business
edge decision and the degree of autonomous interpretation; the original brief
did not explicitly settle the all-zero output shape. Current and bare workers
selected `[]`. Do not turn this one safe block into a general claim that the old
handoff mechanism is inferior or that asking a material question is undesirable.

### Is selection sufficiently simple?

Every current answer put an appropriate next step first and supplied a usable
request or action. The recommended routes were clarify, build, debug, review then
verification, and verification/pending-runtime handling. No user had to execute
the entire catalog to take that first step.

There is a real presentation tradeoff. Four current answers also displayed the
ten-skill stage overview; the ready-task answer referenced one procedure. Published
answers referenced 1–2 registered procedures; bare answers described a usable
action with or without a known name. The current final replies contained
181–271 whitespace-separated words (median 218), versus 159–203 (median 175) for
0.2.0 and 140–187 (median 155) for no bodies. Ten overview names are not ten equally
required alternatives, but they are more visible information.

Therefore **the next choice was actionable; a reduction in visible information
was not demonstrated**. A concrete follow-up would keep the next recommendation
and copyable request prominent and make the broader map optional after initial
orientation. This is a proposal for later usability testing, not a policy change
made during the experiment or a reason to hide the expert catalog.

Published advice case `cc0486d14776` chose the correct build procedure but asked
for Jira metadata or another branch-naming exception before proceeding, although
the context already supplied a descriptive-branch project convention. The starting
path was accordingly partial, rather than an incorrect feature recommendation.
The judge also mentioned absolute links in the relocated packet; that is not
treated as a product defect because the original project paths were valid.

## Separate comparative assessments

**Current versus 0.2.0:** clarity and consistent decision/scope/truth handling were
equally successful. Current COCO communicated its explicit stage framework and
avoided the old ready-task Jira preparation step. Independent pickup completed
5 versus 4 cases, with the old difference being an honestly preserved open edge
decision. These are specific observed differences, not blanket superiority.
The current overview was more expansive, so simpler presentation cannot be inferred
from having fewer introductory categories alone.

**Current versus no provided bodies:** all four requested operational criteria
were met equally in these samples. The bare writer was also explicitly asked
to prepare a colleague's continuation, and it made useful handoff records. COCO
delivers a predefined shared procedure and vocabulary rather than requiring the
team to rediscover or restate its full method; this experiment verified the tested
implementation, handoff and advice paths, but did not measure how much recurring
human instruction it saves. Files-read and reconstruction effort were not
separately quantified; their raw actions are retained. No effort or ease advantage
is established, nor a unique ability to collaborate.

These results support choosing COCO when the team wants its explicit common
workflow. They do not support telling a team that equivalent outcomes are impossible
without it, or that more paperwork is automatically better collaboration.

## Costs and boundaries of the conclusion

| Activity, five samples | Current median seconds [min,max] | 0.2.0 | No bodies |
| --- | --- | --- | --- |
| Writer plus successor | 253.684 [218.500,307.147] | 211.132 [199.714,282.626] | 206.042 [166.152,250.538] |
| Advice response | 43.171 [33.836,61.524] | 34.977 [31.920,47.644] | 26.837 [23.007,28.077] |

These are descriptive native process elapsed times, not measured human effort or
causal speed estimates. Other separately frozen local experiments shared the host.
The old handoff cost includes one blocked successor, so it cannot be interpreted
as equivalent completed-work speed. Commands, per-worker usage, cached tokens and
all case values remain in the structured evidence. Additional effort can buy a
desired team deliverable; time alone does not decide its value.

The no-body condition remains catalog-aware: runtime metadata/prior model knowledge
was not removed. Two no-body advice responses named `coco-build` or `coco-debug`
without reading a skill body. Thus the comparison isolates provided procedural
bodies in this environment, not a completely unexposed human or model. All 30
recorded-action audits found only permitted project/guide reads, no external
conversation retrieval, source/control access or publication/global changes;
all provided guide hashes remained unchanged. There were no excluded or unresolved
trials. One old advice context corrected a shell-quoting error within its retained
native turn; no actor was rerun.

The second worker is a fresh model context, **not an actual human teammate**.
Real comprehension, satisfaction, learning time, long-term maintenance and novice
retention were not measured. Five handoffs in one stdlib domain and five distinct
advice contexts support a bounded operational check, not all-project guarantees.
Technical authority was explicit; its persistence and specialist consent were not
inferred from these results. Existing two-arm collaboration experiments were left
unchanged and are not pooled into this v2 three-condition comparison.

## Verification and review receipts

The independent [design review](../workflow-v2/design-review.md) repaired fixture,
freeze, observer-isolation and grading-support gaps before their dependent phases.
Rubric and actor inputs were frozen before primary execution. Later analysis-helper
repairs implemented that rubric without changing actor inputs or replacing adverse
outcomes. Five fresh native judgment contexts received condition-label-blinded
packets, including actual historical Git content. Style can reveal process; blinding
was imperfect. Their supplied artifacts remained byte/mode-identical afterward.

All 32 structured grades passed ID/axis/subitem validation. Both unlabeled controls
were rejected with concrete evidence: a constant/wrong summary coupled to false
completion, and a recommendation to publish based on unit tests despite required
browser acceptance being unavailable. [Control reconciliation](../workflow-v2/evidence/control-review.json)
and [per-ID source eligibility](../workflow-v2/evidence/source-audit.json) are retained.
The native record archive preserves the exact judgments and their action records.

`python3 scripts/validate.py` passed; all **156 tests** passed, including real
observer mutation/restoration, no observer effects on the writer, probe-timeout
recording and selection-fixture execution. See [the required test log](../workflow-v2/evidence/required-tests.log).
The independent [final claim review](../workflow-v2/final-review.md) checked the
report against retained evidence. Closure and branch receipts are recorded in the
[task plan](../../plans/workflow-value-v2.md).
