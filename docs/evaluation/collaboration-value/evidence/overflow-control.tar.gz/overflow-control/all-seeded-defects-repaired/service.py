import storage


class Billing:
    def __init__(self, connection):
        self.connection = connection
        self.cache = {}

    def invoice(self, tenant, invoice_id):
        row = storage.invoice(self.connection, invoice_id)
        if row is None or row['tenant'] != tenant:
            raise ValueError('not found')
        if invoice_id in self.cache:
            return dict(self.cache[invoice_id])
        self.cache[invoice_id] = row
        return dict(row)

    def list(self, tenant, order='id'):
        return storage.invoices(self.connection, tenant, order)

    def refund(self, tenant, invoice_id, amount, request_key):
        if type(amount) is not int or amount <= 0:
            raise ValueError('amount must be a positive integer')
        if not isinstance(request_key, str) or not request_key:
            raise ValueError('request_key is required')
        previous = self.connection.execute(
            'SELECT * FROM refund_requests WHERE tenant = ? AND request_key = ?',
            (tenant, request_key)).fetchone()
        if previous:
            if previous['invoice'] != invoice_id or previous['amount'] != amount:
                raise ValueError('request key conflicts with previous payload')
            return dict(previous)
        row = self.invoice(tenant, invoice_id)
        updated = row['refunded'] + amount
        if updated > row['amount']:
            raise ValueError('refund exceeds remaining amount')
        receipt = {'tenant': tenant, 'request_key': request_key,
                   'invoice': invoice_id, 'amount': amount}
        with self.connection:
            self.connection.execute(
                'UPDATE invoices SET refunded = ? WHERE id = ?',
                (updated, invoice_id))
            self.connection.execute(
                'INSERT INTO refund_requests VALUES (?, ?, ?, ?)',
                (tenant, request_key, invoice_id, amount))
        self.cache.pop(invoice_id, None)
        return receipt
