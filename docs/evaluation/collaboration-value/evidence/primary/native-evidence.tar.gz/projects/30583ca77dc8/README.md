# Purchasing catalog
Python standard library only. Public entry: `python3 catalog.py --db PATH list`.
List returns a JSON array of {supplier,sku,name,price_cents}, sorted by supplier
then SKU. Existing databases are migrated automatically: their items belong to
supplier `legacy`, preserving their SKU, name, and price.

Import a daily file:
`python3 catalog.py --db PATH import FILE.csv [--supplier NAME] [--batch-id ID]`.
Supplier defaults to `legacy`. Without a batch ID, every invocation applies the
file. Identity is supplier plus case-sensitive SKU. A later import updates the
name and price of an existing item within that supplier; other items remain.

CSV has the exact header `sku,name,price_cents`. Surrounding whitespace is trimmed
from imported fields before validation and collision checks. SKU case is
preserved: case variants are different items. SKU/name must be nonempty. Prices
use decimal digits, must be nonnegative integer cents, and must fit SQLite's
signed 64-bit integer range. Zero prices are accepted.

The first occurrence of a SKU in a file takes precedence, even if that row is
invalid. Invalid rows and within-file duplicates are skipped with line-numbered
explanations on stderr; importing valid rows still succeeds (exit status 0).
Successful imports produce no stdout.

Batch IDs are scoped to their supplier. A successful keyed import records a
SHA-256 digest of the exact source bytes. Repeating those bytes with the same
supplier/batch ID succeeds without applying them again, even after newer imports.
Different bytes with that key fail without changing items or successful-batch
records. Unreadable files and invalid headers fail. Fatal read/database errors
roll back the transaction, including migration, item changes, and batch records.

Local regression command: `python3 -m unittest discover -v`.
Work locally; preserve unrelated files. Do not publish.
Run `python3 catalog.py --db PATH summary` for a JSON array containing one
{supplier,count,total_cents} object per nonempty supplier group, sorted by
supplier, or [] when there are no groups. Count includes zero-priced items;
total_cents is the exact sum of current item prices, even when the group total
exceeds SQLite's signed 64-bit integer range.
