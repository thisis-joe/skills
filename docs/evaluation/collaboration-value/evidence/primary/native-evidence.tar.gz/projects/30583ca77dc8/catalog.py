import argparse
import csv
import json
import hashlib
import io
import re
import sqlite3
import sys


def initialize(connection):
    columns = [row[1] for row in connection.execute('PRAGMA table_info(catalog)')]
    if columns and 'supplier' not in columns:
        connection.execute('ALTER TABLE catalog RENAME TO catalog_legacy')
    connection.execute(
        'CREATE TABLE IF NOT EXISTS catalog '
        '(supplier TEXT NOT NULL, sku TEXT NOT NULL, name TEXT NOT NULL, '
        'price_cents INTEGER NOT NULL CHECK(price_cents >= 0), '
        'PRIMARY KEY (supplier, sku))'
    )
    if columns and 'supplier' not in columns:
        connection.execute(
            "INSERT INTO catalog SELECT 'legacy', sku, name, price_cents FROM catalog_legacy"
        )
        connection.execute('DROP TABLE catalog_legacy')
    connection.execute(
        'CREATE TABLE IF NOT EXISTS successful_batches '
        '(supplier TEXT NOT NULL, batch_id TEXT NOT NULL, source_hash TEXT NOT NULL, '
        'PRIMARY KEY (supplier, batch_id))'
    )


def import_csv(connection, path, supplier, batch_id):
    seen = set()
    with open(path, 'rb') as source_file:
        source_bytes = source_file.read()
    source_hash = hashlib.sha256(source_bytes).hexdigest()
    if batch_id is not None:
        previous = connection.execute(
            'SELECT source_hash FROM successful_batches WHERE supplier = ? AND batch_id = ?',
            (supplier, batch_id),
        ).fetchone()
        if previous:
            if previous[0] != source_hash:
                raise ValueError('batch-id already used with different source bytes')
            return
    with io.StringIO(source_bytes.decode('utf-8'), newline='') as source:
        reader = csv.reader(source, strict=True)
        if next(reader, None) != ['sku', 'name', 'price_cents']:
            raise ValueError('expected CSV header sku,name,price_cents')
        while True:
            line = reader.line_num + 1
            try:
                row = next(reader)
            except StopIteration:
                break
            except csv.Error as error:
                print(f'line {line}: skipped malformed CSV: {error}', file=sys.stderr)
                continue
            row = [field.strip() for field in row]
            reason = None
            sku = row[0] if row else ''
            if sku in seen:
                reason = f'duplicate SKU {sku!r}; first row kept'
            else:
                if sku:
                    seen.add(sku)
                if len(row) != 3:
                    reason = 'expected three fields'
                elif not sku.strip() or not row[1].strip():
                    reason = 'SKU and name must be nonempty'
                elif not re.fullmatch(r'[0-9]+', row[2]):
                    reason = 'price_cents must be a nonnegative integer'
                else:
                    # SQLite INTEGER storage is a signed 64-bit value.
                    digits = row[2].lstrip('0') or '0'
                    if len(digits) > 19 or (len(digits) == 19 and digits > '9223372036854775807'):
                        reason = 'price_cents exceeds SQLite integer range'
                    else:
                        connection.execute(
                            'INSERT INTO catalog (supplier, sku, name, price_cents) '
                            'VALUES (?, ?, ?, ?) ON CONFLICT(supplier, sku) DO UPDATE SET '
                            'name = excluded.name, price_cents = excluded.price_cents',
                            (supplier, sku, row[1], int(digits)),
                        )
            if reason:
                print(f'line {line}: skipped: {reason}', file=sys.stderr)

    if batch_id is not None:
        connection.execute(
            'INSERT INTO successful_batches VALUES (?, ?, ?)',
            (supplier, batch_id, source_hash),
        )


def purchasing_summary(connection):
    groups = []
    # Accumulate in Python: valid individual prices can overflow SQLite SUM.
    for supplier, price in connection.execute(
        'SELECT supplier,price_cents FROM catalog ORDER BY supplier,sku'
    ):
        if not groups or groups[-1]['supplier'] != supplier:
            groups.append(dict(supplier=supplier, count=0, total_cents=0))
        groups[-1]['count'] += 1
        groups[-1]['total_cents'] += price
    return groups


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    commands.add_parser('summary')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    importer.add_argument('--supplier', default='legacy')
    importer.add_argument('--batch-id')
    args = parser.parse_args()
    connection = sqlite3.connect(args.db)
    try:
        with connection:
            connection.execute('BEGIN IMMEDIATE')
            initialize(connection)
            if args.command == 'import':
                import_csv(connection, args.path, args.supplier, args.batch_id)
            elif args.command == 'summary':
                print(json.dumps(purchasing_summary(connection)))
            else:
                print(json.dumps([
                    dict(supplier=supplier, sku=sku, name=name, price_cents=price)
                    for supplier, sku, name, price in connection.execute(
                        'SELECT supplier,sku,name,price_cents FROM catalog ORDER BY supplier,sku'
                    )
                ]))
    except (OSError, UnicodeError, ValueError, csv.Error, sqlite3.Error) as error:
        parser.exit(1, f'error: {error}\n')
    finally:
        connection.close()


if __name__ == '__main__':
    main()
