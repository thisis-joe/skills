import json,subprocess,sys,tempfile,unittest
class Catalog(unittest.TestCase):
 def test_empty_list(self):
  with tempfile.TemporaryDirectory() as d:
   self.assertEqual(json.loads(subprocess.check_output([sys.executable,'catalog.py','--db',d+'/x.sqlite','list'])),[])

class ImportCatalog(unittest.TestCase):
 def test_import_preserves_first_updates_stored_rows_and_skips_invalid(self):
  with tempfile.TemporaryDirectory() as d:
   from pathlib import Path
   import sqlite3
   db = d + '/catalog.sqlite'
   with sqlite3.connect(db) as connection:
    connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
    connection.execute("INSERT INTO catalog VALUES ('old', 'Original', 50)")
   source = Path(d) / 'daily.csv'
   source.write_text('sku,name,price_cents\nold,Replacement,99\na,First,10\na,Second,20\nb,Bad,no\nb,Later,30\nc,Zero,0\nd,Negative,-1\ne,Huge,9223372036854775808\nf,Missing\ng,,10\nh,"Quoted, name",15\n', encoding='utf-8')
   result = subprocess.run([sys.executable, 'catalog.py', '--db', db, 'import', str(source)], capture_output=True, text=True)
   self.assertEqual(result.returncode, 0, result.stderr)
   self.assertEqual(result.stdout, '')
   self.assertEqual(len(result.stderr.splitlines()), 7)
   rows = json.loads(subprocess.check_output([sys.executable, 'catalog.py', '--db', db, 'list']))
   self.assertEqual(rows, [dict(supplier='legacy', sku='a', name='First', price_cents=10), dict(supplier='legacy', sku='c', name='Zero', price_cents=0), dict(supplier='legacy', sku='h', name='Quoted, name', price_cents=15), dict(supplier='legacy', sku='old', name='Replacement', price_cents=99)])
   repeated = subprocess.run([sys.executable, 'catalog.py', '--db', db, 'import', str(source)], capture_output=True)
   self.assertEqual(repeated.returncode, 0)
   self.assertEqual(json.loads(subprocess.check_output([sys.executable, 'catalog.py', '--db', db, 'list'])), rows)

 def test_invalid_header_fails_without_importing_rows(self):
  with tempfile.TemporaryDirectory() as d:
   from pathlib import Path
   source = Path(d) / 'bad.csv'
   source.write_text('wrong,header\na,Name,10\n', encoding='utf-8')
   db = d + '/catalog.sqlite'
   result = subprocess.run([sys.executable, 'catalog.py', '--db', db, 'import', str(source)], capture_output=True, text=True)
   self.assertNotEqual(result.returncode, 0)
   self.assertIn('expected CSV header', result.stderr)
   self.assertEqual(json.loads(subprocess.check_output([sys.executable, 'catalog.py', '--db', db, 'list'])), [])

 def test_trimmed_identity_file_and_stored_collisions_preserve_case(self):
  with tempfile.TemporaryDirectory() as d:
   from pathlib import Path
   import sqlite3
   db = d + '/catalog.sqlite'
   with sqlite3.connect(db) as connection:
    connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
    connection.execute("INSERT INTO catalog VALUES ('Stored', ' Original ', 50)")
   source = Path(d) / 'daily.csv'
   source.write_text('sku,name,price_cents\n SKU , First name , 10 \nSKU,Second,20\nsku,Lowercase,30\n Stored ,Replacement,99\nstored,Distinct,40\n bad ,Invalid,no\nbad,Later,60\n', encoding='utf-8')
   result = subprocess.run([sys.executable, 'catalog.py', '--db', db, 'import', str(source)], capture_output=True, text=True)
   self.assertEqual(result.returncode, 0, result.stderr)
   self.assertEqual(result.stdout, '')
   self.assertIn("line 3: skipped: duplicate SKU 'SKU'", result.stderr)
   self.assertIn("line 8: skipped: duplicate SKU 'bad'", result.stderr)
   rows = json.loads(subprocess.check_output([sys.executable, 'catalog.py', '--db', db, 'list']))
   self.assertEqual(rows, [dict(supplier='legacy', sku='SKU', name='First name', price_cents=10), dict(supplier='legacy', sku='Stored', name='Replacement', price_cents=99), dict(supplier='legacy', sku='sku', name='Lowercase', price_cents=30), dict(supplier='legacy', sku='stored', name='Distinct', price_cents=40)])

 def test_supplier_migration_and_replay_are_atomic_and_scoped(self):
  with tempfile.TemporaryDirectory() as d:
   from pathlib import Path
   import sqlite3
   db = d + '/catalog.sqlite'
   with sqlite3.connect(db) as connection:
    connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
    connection.execute("INSERT INTO catalog VALUES ('Old', ' Original ', 5)")
   def run_file(contents, *options):
    source = Path(d) / 'daily.csv'
    source.write_bytes(contents)
    return subprocess.run([sys.executable, 'catalog.py', '--db', db, 'import', str(source), *options], capture_output=True, text=True)
   def listing():
    return json.loads(subprocess.check_output([sys.executable, 'catalog.py', '--db', db, 'list']))
   self.assertEqual(listing(), [dict(supplier='legacy', sku='Old', name=' Original ', price_cents=5)])
   first = b'sku,name,price_cents\n X , First , 10 \nX,Duplicate,20\nx,Lower,0\nbad,Bad,-1\n'
   newer = b'sku,name,price_cents\nX,Newer,30\n'
   self.assertEqual(run_file(first, '--supplier', 'alpha', '--batch-id', '1').returncode, 0)
   self.assertEqual(run_file(newer, '--supplier', 'alpha', '--batch-id', '2').returncode, 0)
   before = listing()
   self.assertEqual(run_file(first, '--supplier', 'alpha', '--batch-id', '1').returncode, 0)
   self.assertEqual(listing(), before)
   with sqlite3.connect(db) as connection:
    batches = connection.execute('SELECT * FROM successful_batches ORDER BY supplier,batch_id').fetchall()
   failed = run_file(first + b'Y,Extra,7\n', '--supplier', 'alpha', '--batch-id', '1')
   self.assertNotEqual(failed.returncode, 0)
   self.assertIn('different source bytes', failed.stderr)
   self.assertEqual(listing(), before)
   with sqlite3.connect(db) as connection:
    self.assertEqual(connection.execute('SELECT * FROM successful_batches ORDER BY supplier,batch_id').fetchall(), batches)
   self.assertEqual(run_file(newer, '--supplier', 'beta', '--batch-id', '1').returncode, 0)
   self.assertEqual(run_file(b'sku,name,price_cents\nOld,Updated,0\n').returncode, 0)
   self.assertEqual(listing(), [dict(supplier='alpha', sku='X', name='Newer', price_cents=30), dict(supplier='alpha', sku='x', name='Lower', price_cents=0), dict(supplier='beta', sku='X', name='Newer', price_cents=30), dict(supplier='legacy', sku='Old', name='Updated', price_cents=0)])
   self.assertEqual(run_file(b'bad header\n', '--supplier', 'alpha', '--batch-id', 'failed').returncode, 1)
   self.assertEqual(run_file(newer, '--supplier', 'alpha', '--batch-id', 'failed').returncode, 0)

 def test_database_failure_rolls_back_items_and_batch_key(self):
  with tempfile.TemporaryDirectory() as d:
   from pathlib import Path
   import sqlite3
   db = d + '/catalog.sqlite'
   subprocess.check_call([sys.executable, 'catalog.py', '--db', db, 'list'], stdout=subprocess.DEVNULL)
   with sqlite3.connect(db) as connection:
    connection.execute("CREATE TRIGGER reject_item BEFORE INSERT ON catalog WHEN NEW.sku = 'fail' BEGIN SELECT RAISE(ABORT, 'forced failure'); END")
   source = Path(d) / 'daily.csv'
   source.write_text('sku,name,price_cents\nok,Valid,1\nfail,Rejected,2\n')
   result = subprocess.run([sys.executable, 'catalog.py', '--db', db, 'import', str(source), '--batch-id', 'retry'], capture_output=True)
   self.assertNotEqual(result.returncode, 0)
   self.assertEqual(json.loads(subprocess.check_output([sys.executable, 'catalog.py', '--db', db, 'list'])), [])
   with sqlite3.connect(db) as connection:
    self.assertEqual(connection.execute('SELECT * FROM successful_batches').fetchall(), [])

class SummaryCatalog(unittest.TestCase):
 def test_empty_summary(self):
  with tempfile.TemporaryDirectory() as d:
   result = subprocess.run([sys.executable, 'catalog.py', '--db', d + '/catalog.sqlite', 'summary'], capture_output=True, text=True)
   self.assertEqual(result.returncode, 0, result.stderr)
   self.assertEqual(result.stderr, '')
   self.assertEqual(json.loads(result.stdout), [])

 def test_summary_migrates_groups_and_tracks_current_prices(self):
  from pathlib import Path
  import sqlite3
  with tempfile.TemporaryDirectory() as d:
   db = d + '/catalog.sqlite'
   def run(*args):
    result = subprocess.run([sys.executable, 'catalog.py', '--db', db, *args], capture_output=True, text=True)
    self.assertEqual(result.returncode, 0, result.stderr)
    self.assertEqual(result.stderr, '')
    return result.stdout
   with sqlite3.connect(db) as connection:
    connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
    connection.execute("INSERT INTO catalog VALUES ('old', 'Original', 7)")
   self.assertEqual(json.loads(run('summary')), [dict(supplier='legacy', count=1, total_cents=7)])
   before = json.loads(run('list'))
   source = Path(d) / 'daily.csv'
   source.write_text('sku,name,price_cents\na,Maximum,9223372036854775807\nb,Another,9223372036854775807\nz,Zero,0\n', encoding='utf-8')
   run('import', str(source), '--supplier', 'zeta', '--batch-id', 'first')
   source.write_text('sku,name,price_cents\na,Initial,12\n', encoding='utf-8')
   run('import', str(source), '--supplier', 'alpha')
   source.write_text('sku,name,price_cents\na,Replacement,3\n', encoding='utf-8')
   run('import', str(source), '--supplier', 'alpha')
   listing = run('list')
   with sqlite3.connect(db) as connection:
    batches = connection.execute('SELECT * FROM successful_batches').fetchall()
   expected = [dict(supplier='alpha', count=1, total_cents=3), dict(supplier='legacy', count=1, total_cents=7), dict(supplier='zeta', count=3, total_cents=18446744073709551614)]
   self.assertEqual(json.loads(run('summary')), expected)
   self.assertEqual(json.loads(run('summary')), expected)
   self.assertEqual(run('list'), listing)
   self.assertIn(before[0], json.loads(listing))
   with sqlite3.connect(db) as connection:
    self.assertEqual(connection.execute('SELECT * FROM successful_batches').fetchall(), batches)
