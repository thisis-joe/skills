import argparse
import csv
import io
import json
from pathlib import Path
import sqlite3
import uuid


def sku_key(value):
    return value.strip().lower()


def read_import(source_bytes):
    items = []
    seen = set()
    with io.StringIO(source_bytes.decode('utf-8'), newline='') as source:
        reader = csv.DictReader(source, strict=True)
        if reader.fieldnames != ['sku', 'name', 'price_cents']:
            raise ValueError('CSV header must be sku,name,price_cents')
        for row in reader:
            line = reader.line_num
            if None in row or any(value is None for value in row.values()):
                raise ValueError(f'line {line}: expected three fields')
            sku = sku_key(row['sku'])
            name, price = row['name'].strip(), row['price_cents'].strip()
            if not sku.strip() or not name.strip():
                raise ValueError(f'line {line}: SKU and name must be nonempty')
            if not price or any(char not in '0123456789' for char in price):
                raise ValueError(f'line {line}: price must be nonnegative integer cents')
            cents = int(price)
            if cents > 9223372036854775807:
                raise ValueError(f'line {line}: price exceeds SQLite integer range')
            if sku in seen:
                continue
            seen.add(sku)
            items.append((sku, name, cents))
    return items


def prepare_storage(connection):
    columns = connection.execute('PRAGMA table_info(catalog)').fetchall()
    old_table = None
    if columns and 'supplier' not in {column[1] for column in columns}:
        old_table = 'catalog_legacy_' + uuid.uuid4().hex
        connection.execute(f'ALTER TABLE catalog RENAME TO "{old_table}"')
    connection.execute(
        'CREATE TABLE IF NOT EXISTS catalog ('
        'supplier TEXT NOT NULL, sku TEXT NOT NULL, name TEXT NOT NULL, '
        'price_cents INTEGER NOT NULL CHECK(price_cents >= 0), '
        'PRIMARY KEY (supplier, sku))'
    )
    if old_table is not None:
        connection.execute(
            f'INSERT INTO catalog (supplier, sku, name, price_cents) '
            f'SELECT ?, sku, name, price_cents FROM "{old_table}"', ('legacy',)
        )
        connection.execute(f'DROP TABLE "{old_table}"')
    connection.execute(
        'CREATE TABLE IF NOT EXISTS successful_batches ('
        'supplier TEXT NOT NULL, batch_id TEXT NOT NULL, source_bytes BLOB NOT NULL, '
        'PRIMARY KEY (supplier, batch_id))'
    )


def apply_import(connection, supplier, batch_id, source_bytes, items):
    if batch_id is not None:
        previous = connection.execute(
            'SELECT source_bytes FROM successful_batches WHERE supplier = ? AND batch_id = ?',
            (supplier, batch_id)
        ).fetchone()
        if previous is not None:
            if previous[0] != source_bytes:
                raise ValueError('batch ID already used with different source bytes for this supplier')
            return 0
    existing = {}
    for (stored_sku,) in connection.execute('SELECT sku FROM catalog WHERE supplier = ?', (supplier,)):
        existing.setdefault(sku_key(stored_sku), []).append(stored_sku)
    imported = 0
    for sku, name, cents in items:
        matches = existing.get(sku, [])
        if len(matches) > 1:
            raise ValueError(f'ambiguous existing SKU {sku!r}; no items imported')
        if matches:
            connection.execute(
                'UPDATE catalog SET name = ?, price_cents = ? WHERE supplier = ? AND sku = ?',
                (name, cents, supplier, matches[0])
            )
        else:
            connection.execute(
                'INSERT INTO catalog (supplier, sku, name, price_cents) VALUES (?, ?, ?, ?)',
                (supplier, sku, name, cents)
            )
            imported += 1
    if batch_id is not None:
        connection.execute(
            'INSERT INTO successful_batches (supplier, batch_id, source_bytes) VALUES (?, ?, ?)',
            (supplier, batch_id, source_bytes)
        )
    return imported


def purchasing_summary(connection):
    groups = {}
    # Python integers keep exact totals even beyond SQLite's integer SUM range.
    for supplier, cents in connection.execute(
        'SELECT supplier,price_cents FROM catalog ORDER BY supplier'
    ):
        group = groups.setdefault(supplier, dict(supplier=supplier, count=0, total_cents=0))
        group['count'] += 1
        group['total_cents'] += cents
    return list(groups.values())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    commands.add_parser('summary')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    importer.add_argument('--supplier', default='legacy')
    importer.add_argument('--batch-id')
    args = parser.parse_args()
    connection = None
    try:
        if args.command == 'import':
            if not args.supplier.strip():
                raise ValueError('supplier must be nonempty')
            source_bytes = Path(args.path).read_bytes()
            items = read_import(source_bytes)
        connection = sqlite3.connect(args.db)
        with connection:
            connection.execute('BEGIN IMMEDIATE')
            prepare_storage(connection)
            if args.command == 'import':
                imported = apply_import(connection, args.supplier, args.batch_id, source_bytes, items)
                result = {'imported': imported}
            elif args.command == 'summary':
                result = purchasing_summary(connection)
            else:
                result = [
                    dict(supplier=supplier, sku=sku, name=name, price_cents=cents)
                    for supplier, sku, name, cents in connection.execute(
                        'SELECT supplier,sku,name,price_cents FROM catalog ORDER BY supplier,sku'
                    )
                ]
        print(json.dumps(result))
    except (OSError, UnicodeError, csv.Error, ValueError, sqlite3.Error) as error:
        parser.exit(1, f'error: {error}\n')
    finally:
        if connection is not None:
            connection.close()


if __name__ == '__main__':
    main()
