import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest


class Catalog(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.db = self.root / 'catalog.sqlite'
        self.source = self.root / 'daily.csv'

    def call(self, *args):
        return subprocess.run(
            [sys.executable, 'catalog.py', '--db', str(self.db), *args],
            text=True, capture_output=True,
        )

    def write(self, rows):
        self.source.write_text('sku,name,price_cents\n' + rows, encoding='utf-8')

    def run_import(self, *options, imported=None):
        result = self.call('import', str(self.source), *options)
        self.assertEqual(result.returncode, 0, result.stderr)
        if imported is not None:
            self.assertEqual(json.loads(result.stdout), {'imported': imported})
        return result

    def listing(self):
        result = self.call('list')
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def batches(self):
        with sqlite3.connect(self.db) as connection:
            return connection.execute(
                'SELECT supplier,batch_id,source_bytes FROM successful_batches ORDER BY supplier,batch_id'
            ).fetchall()

    def seed_old_storage(self, rows):
        with sqlite3.connect(self.db) as connection:
            connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
            connection.executemany('INSERT INTO catalog VALUES (?, ?, ?)', rows)
            connection.execute('CREATE TABLE unrelated (value TEXT)')
            connection.execute("INSERT INTO unrelated VALUES ('keep')")

    def test_empty_list(self):
        self.assertEqual(self.listing(), [])

    def summary(self):
        result = self.call('summary')
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def test_empty_summary(self):
        self.assertEqual(self.summary(), [])

    def test_summary_groups_suppliers_counts_zero_and_preserves_storage(self):
        self.write('a,Paid,12\nb,Free,0\n')
        self.run_import('--supplier', 'zeta', '--batch-id', 'daily', imported=2)
        self.write('a,Free,0\n')
        self.run_import('--supplier', 'alpha', imported=1)
        self.write('a,Maximum,9223372036854775807\nb,Extra,1\n')
        self.run_import(imported=2)
        baseline, batches = self.listing(), self.batches()
        expected = [
            dict(supplier='alpha', count=1, total_cents=0),
            dict(supplier='legacy', count=2, total_cents=9223372036854775808),
            dict(supplier='zeta', count=2, total_cents=12),
        ]
        self.assertEqual(self.summary(), expected)
        self.assertEqual(self.summary(), expected)
        self.assertEqual(self.listing(), baseline)
        self.assertEqual(self.batches(), batches)

    def test_summary_migrates_legacy_rows_without_merging_normalized_keys(self):
        self.seed_old_storage([('A', 'Paid', 9), (' a ', 'Free', 0)])
        self.assertEqual(self.summary(), [dict(supplier='legacy', count=2, total_cents=9)])
        self.assertEqual(len(self.listing()), 2)
        with sqlite3.connect(self.db) as connection:
            self.assertEqual(connection.execute('SELECT * FROM unrelated').fetchall(), [('keep',)])

    def test_default_import_normalizes_and_updates_first_row_only(self):
        self.write(' OLD , Original , 100 \n')
        self.run_import(imported=1)
        self.write(' NEW , First , 200 \nnew,Second,300\nOLD,Replacement,900\nold,Third,800\n')
        self.run_import(imported=1)
        self.assertEqual(self.listing(), [
            dict(supplier='legacy', sku='new', name='First', price_cents=200),
            dict(supplier='legacy', sku='old', name='Replacement', price_cents=900),
        ])
        self.run_import(imported=0)
        self.assertEqual(self.batches(), [])
        self.write('old,Newest,0\n')
        self.run_import(imported=0)
        self.assertEqual(self.listing()[1]['price_cents'], 0)
        self.assertEqual(self.listing()[1]['name'], 'Newest')

    def test_malformed_rows_leave_catalog_and_batches_unchanged(self):
        self.write('old,Original,100\n')
        self.run_import('--batch-id', 'initial', imported=1)
        baseline, batches = self.listing(), self.batches()
        for rows in (
            'new,New,200\n NEW ,Duplicate,broken\n',
            'new,New,200\n OLD ,Replacement,broken\n',
            'old,Changed,200\nbad,Bad,1.5\n',
            'bad,Bad,-1\n',
            'bad,Bad,9223372036854775808\n',
            'bad,Bad,\n',
            ',Missing SKU,1\n',
            'bad, ,1\n',
            'bad,Bad\n',
            'bad,Bad,1,extra\n',
            'bad,"Unclosed,1\n',
        ):
            with self.subTest(rows=rows):
                self.write(rows)
                result = self.call('import', str(self.source), '--batch-id', 'retry')
                self.assertEqual(result.returncode, 1)
                self.assertEqual(result.stdout, '')
                self.assertIn('error:', result.stderr)
                self.assertEqual(self.listing(), baseline)
                self.assertEqual(self.batches(), batches)
        # A rejected attempt must not reserve the batch key.
        self.write('a,"Name, quoted",0\n')
        self.run_import('--batch-id', 'retry', imported=1)
        self.assertEqual(self.listing()[0], dict(supplier='legacy', sku='a', name='Name, quoted', price_cents=0))

    def test_bad_header_missing_file_and_invalid_encoding(self):
        for content in (None, b'', b'name,sku,price_cents\n', b'sku,name,price_cents\nx,\xff,1\n'):
            with self.subTest(content=content):
                if content is not None:
                    self.source.write_bytes(content)
                result = self.call('import', str(self.source))
                self.assertEqual(result.returncode, 1)
                self.assertNotIn('Traceback', result.stderr)
                self.assertFalse(self.db.exists())

    def test_migration_preserves_rows_and_unrelated_table(self):
        old_rows = [(' Old ', ' Original ', 100), ('zero', 'Free', 0)]
        self.seed_old_storage(old_rows)
        expected = [dict(supplier='legacy', sku=k, name=n, price_cents=p) for k, n, p in old_rows]
        self.assertEqual(self.listing(), expected)
        self.assertEqual(self.listing(), expected)
        self.write('OLD,Updated,200\n')
        self.run_import(imported=0)
        self.assertEqual(self.listing()[0], dict(supplier='legacy', sku=' Old ', name='Updated', price_cents=200))
        with sqlite3.connect(self.db) as connection:
            self.assertEqual(connection.execute('SELECT * FROM unrelated').fetchall(), [('keep',)])
        self.write('old,Other supplier,300\n')
        self.run_import('--supplier', 'other', imported=1)
        self.assertEqual(len(self.listing()), 3)

    def test_import_migrates_directly_and_list_sorts_by_supplier_then_sku(self):
        self.seed_old_storage([('b', 'Legacy B', 50)])
        self.write(' B ,Supplier B,2\na,Supplier A,1\n')
        self.run_import('--supplier', 'alpha', imported=2)
        self.write('b,Legacy updated,60\n')
        self.run_import(imported=0)
        self.assertEqual(self.listing(), [
            dict(supplier='alpha', sku='a', name='Supplier A', price_cents=1),
            dict(supplier='alpha', sku='b', name='Supplier B', price_cents=2),
            dict(supplier='legacy', sku='b', name='Legacy updated', price_cents=60),
        ])

    def test_batch_replay_survives_newer_updates_and_is_supplier_scoped(self):
        self.write('A,First,10\na,Ignored,20\n')
        original_bytes = self.source.read_bytes()
        self.run_import('--supplier', 'alpha', '--batch-id', 'daily', imported=1)
        self.write('a,Newer,30\n')
        self.run_import('--supplier', 'alpha', '--batch-id', 'newer', imported=0)
        baseline, batches = self.listing(), self.batches()
        # Replay matches source bytes, independently of file path or current items.
        self.source = self.root / 'copied.csv'
        self.source.write_bytes(original_bytes)
        self.run_import('--supplier', 'alpha', '--batch-id', 'daily', imported=0)
        self.assertEqual(self.listing(), baseline)
        self.assertEqual(self.batches(), batches)
        # Even semantically equivalent CSV with changed bytes conflicts.
        self.source.write_bytes(original_bytes.replace(b'\n', b'\r\n'))
        result = self.call('import', str(self.source), '--supplier', 'alpha', '--batch-id', 'daily')
        self.assertEqual(result.returncode, 1)
        self.assertIn('different source bytes', result.stderr)
        self.assertEqual(self.listing(), baseline)
        self.assertEqual(self.batches(), batches)
        self.write('a,Independent,40\n')
        self.run_import('--supplier', 'beta', '--batch-id', 'daily', imported=1)
        self.assertEqual([row['price_cents'] for row in self.listing()], [30, 40])
        # Unkeyed batches always apply, and old replay still cannot revert them.
        self.write('a,Ordinary,50\n')
        self.run_import('--supplier', 'alpha', imported=0)
        self.source.write_bytes(original_bytes)
        self.run_import('--supplier', 'alpha', '--batch-id', 'daily', imported=0)
        self.assertEqual(self.listing()[0]['price_cents'], 50)

    def test_database_failure_rolls_back_items_and_batch_record(self):
        self.listing()
        self.write('a,Original,1\n')
        self.run_import('--batch-id', 'original', imported=1)
        baseline, batches = self.listing(), self.batches()
        with sqlite3.connect(self.db) as connection:
            connection.execute("CREATE TRIGGER reject_bad BEFORE INSERT ON catalog WHEN NEW.sku = 'bad' BEGIN SELECT RAISE(ABORT, 'test failure'); END")
        self.write('a,Changed,2\nbad,Fail,3\n')
        result = self.call('import', str(self.source), '--batch-id', 'failed')
        self.assertEqual(result.returncode, 1)
        self.assertEqual(self.listing(), baseline)
        self.assertEqual(self.batches(), batches)

    def test_batch_record_failure_rolls_back_item_updates(self):
        self.write('a,Original,1\n')
        self.run_import('--batch-id', 'original', imported=1)
        baseline, batches = self.listing(), self.batches()
        with sqlite3.connect(self.db) as connection:
            connection.execute("CREATE TRIGGER reject_batch BEFORE INSERT ON successful_batches BEGIN SELECT RAISE(ABORT, 'test batch failure'); END")
        self.write('a,Changed,2\nnew,New,3\n')
        result = self.call('import', str(self.source), '--batch-id', 'failed')
        self.assertEqual(result.returncode, 1)
        self.assertEqual(self.listing(), baseline)
        self.assertEqual(self.batches(), batches)

    def test_malformed_import_leaves_old_schema_and_data_untouched(self):
        self.seed_old_storage([('a', 'Original', 1)])
        with sqlite3.connect(self.db) as connection:
            before = '\n'.join(connection.iterdump())
        self.write('a,Changed,2\nbad,Bad,-1\n')
        result = self.call('import', str(self.source), '--batch-id', 'failed')
        self.assertEqual(result.returncode, 1)
        with sqlite3.connect(self.db) as connection:
            self.assertEqual('\n'.join(connection.iterdump()), before)

    def test_ambiguous_legacy_keys_are_preserved_and_not_overwritten(self):
        self.seed_old_storage([('A', 'First', 1), (' a ', 'Second', 2)])
        baseline = self.listing()
        self.assertEqual(len(baseline), 2)
        self.write('new,New,3\na,Ambiguous,4\n')
        result = self.call('import', str(self.source), '--batch-id', 'ambiguous')
        self.assertEqual(result.returncode, 1)
        self.assertIn('ambiguous', result.stderr)
        self.assertEqual(self.listing(), baseline)
        self.assertEqual(self.batches(), [])


if __name__ == '__main__':
    unittest.main()
