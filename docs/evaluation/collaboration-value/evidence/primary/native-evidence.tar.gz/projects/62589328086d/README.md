# Purchasing catalog

Python standard library only. Public CLI:

```
python3 catalog.py --db catalog.sqlite import daily.csv
python3 catalog.py --db catalog.sqlite import daily.csv --supplier acme --batch-id 2026-10-23
python3 catalog.py --db catalog.sqlite list
python3 catalog.py --db catalog.sqlite summary
```

Import CSV has the exact header `sku,name,price_cents`. Surrounding whitespace
is trimmed from fields, and SKU keys are lowercase. SKU/name must be nonempty;
prices must use ASCII digits and represent nonnegative integer cents within
SQLite's signed 64-bit integer range. Zero prices are valid. The first row for
each normalized SKU in a file wins. Every row is validated, including later
duplicates; any malformed row rejects the entire file without changing catalog
items or successful-batch records. Errors exit 1 with a diagnostic on stderr.

Item identity is supplier plus normalized SKU. `--supplier` defaults to `legacy`;
supplier names are nonempty, case-sensitive strings used exactly as supplied.
An ordinary import inserts new items and updates the name and price of matching
items for that supplier. Other suppliers' items are unaffected. Success prints
`{"imported": N}`, retaining the count of newly inserted items only; updates and
replays do not increase this count.

`--batch-id` is optional; without it every valid import applies normally.
Batch IDs are scoped to their supplier. The first successful keyed import stores
its exact source bytes in SQLite in the same transaction as the item changes.
A replay of those bytes with the same supplier and batch ID succeeds with
`{"imported": 0}` and applies no changes, even after newer imports. Different
bytes with that key fail without changing items or successful-batch records.
The same batch ID can be used independently by different suppliers. File paths
do not affect replay identity. Failed imports do not reserve batch IDs.

`list` returns a JSON array of `{supplier,sku,name,price_cents}` objects sorted
by supplier, then stored SKU. An empty catalog returns `[]`.

Existing three-column catalog databases migrate transactionally on the next
successful command. All existing rows become supplier `legacy`, preserving their
stored SKU spelling, names, and prices. Future imports match these rows using
normalized SKU keys. If multiple old rows share a normalized key, an import
that touches that identity fails atomically rather than choosing or discarding
a stored row. Unrelated tables are preserved. The supplier-aware catalog has a
composite `(supplier, sku)` primary key; replay records live in
`successful_batches(supplier, batch_id, source_bytes)`.

Regression command: `python3 -m unittest discover -v`. Tests exercise the real CLI
using temporary databases. Work locally; preserve unrelated files. Do not publish.

`summary` returns one `{supplier,count,total_cents}` object per nonempty supplier
group, sorted by supplier, or `[]` for an empty catalog. Zero-price items count
and add zero to the total; suppliers with only zero-price items are included.
Totals are exact integer cents, including totals beyond SQLite's signed 64-bit
integer range. Summary preserves stored items and successful-batch records.
