# Purchasing catalog
Python standard library only. Public entry: `python3 catalog.py --db PATH list`.
List returns a JSON array of {supplier,sku,name,price_cents}, sorted by supplier
then SKU. Old catalog rows migrate transactionally to supplier `legacy`, with
their values preserved. Item identity is now supplier plus SKU.
CSV has header sku,name,price_cents. SKU/name must be nonempty; prices are
nonnegative integer cents. Business choices are not established in this README.
Use the existing public CLI entry for added commands. Local regression command:
`python3 -m unittest discover -v`. Work locally; preserve unrelated files.

Import a daily supplier file with:

```sh
python3 catalog.py --db PATH import supplier.csv
python3 catalog.py --db PATH list
```

The exact CSV header is `sku,name,price_cents`. Fields may use CSV quoting.
Surrounding whitespace is trimmed from every data field before validation and
duplicate handling. SKU/name must then be nonempty. SKU case is preserved:
`ABC` and `abc` are different items, while ` ABC ` and `ABC` share a key. Prices
must contain only ASCII digits and fit SQLite's signed 64-bit integer range.
The last row for a SKU wins; imports update existing items and keep other items.
Every row is validated, even an earlier duplicate. Any invalid row rejects the
whole file without changing the catalog; errors go to stderr with a nonzero exit.
Successful imports are silent. A header-only file makes no item changes.

Show purchasing totals with `python3 catalog.py --db PATH summary`.
The result is a JSON array of `{supplier,count,total_cents}` groups sorted by
supplier, or `[]` for an empty catalog. Every stored item counts, including
zero-price items; those add zero to totals and remain in list output. Suppliers
with only zero-price items appear. Totals use exact integer cents, even when a
supplier total exceeds SQLite's signed 64-bit range. Existing databases migrate
on summary as on list.

Optional supplier and replay key:

```sh
python3 catalog.py --db PATH import supplier.csv --supplier north --batch-id daily-001
```

Without options, supplier is `legacy` and there is no replay key. Supplier names
and batch IDs are used as supplied. A later ordinary import updates items only
for its supplier. Batch IDs are scoped to a supplier: identical source bytes for
an already successful key succeed without applying old data again, even after
newer imports. Different bytes with that key fail without changing items or
successful-batch records. Failed imports do not reserve keys. Exact source bytes
are retained in SQLite for successful keyed imports. Migration, item updates and
batch recording share one transaction. Existing databases migrate on list or a
valid import; malformed input is rejected before the database is opened.
