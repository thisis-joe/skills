import argparse
import csv
import io
import json
from pathlib import Path
import sqlite3


def read_import(source_bytes):
    items = {}
    with io.StringIO(source_bytes.decode('utf-8'), newline='') as source:
        reader = csv.reader(source, strict=True)
        if next(reader, None) != ['sku', 'name', 'price_cents']:
            raise ValueError('expected CSV header sku,name,price_cents')
        for row in reader:
            location = f'CSV line {reader.line_num}'
            if len(row) != 3:
                raise ValueError(f'{location}: expected three fields')
            sku, name, price = (field.strip() for field in row)
            if not sku or not name:
                raise ValueError(f'{location}: sku and name must be nonempty')
            # Check the lexical form and range before converting untrusted text.
            digits = price.lstrip('0') or '0'
            if (not price or not price.isascii() or not price.isdecimal()
                    or len(digits) > 19
                    or (len(digits) == 19 and digits > '9223372036854775807')):
                raise ValueError(f'{location}: price_cents must be nonnegative integer cents within SQLite range')
            items[sku] = (sku, name, int(digits))
    return list(items.values())


def prepare_storage(connection):
    columns = connection.execute('PRAGMA table_info(catalog)').fetchall()
    schema = ('(supplier TEXT NOT NULL, sku TEXT NOT NULL, name TEXT NOT NULL, '
              'price_cents INTEGER NOT NULL CHECK(price_cents >= 0), '
              'PRIMARY KEY(supplier,sku))')
    if not columns:
        connection.execute('CREATE TABLE catalog ' + schema)
    elif 'supplier' not in [column[1] for column in columns]:
        connection.execute('CREATE TABLE catalog_supplier_migration ' + schema)
        connection.execute(
            "INSERT INTO catalog_supplier_migration SELECT 'legacy',sku,name,price_cents FROM catalog")
        connection.execute('DROP TABLE catalog')
        connection.execute('ALTER TABLE catalog_supplier_migration RENAME TO catalog')
    connection.execute(
        'CREATE TABLE IF NOT EXISTS successful_batches ('
        'supplier TEXT NOT NULL, batch_id TEXT NOT NULL, source_bytes BLOB NOT NULL, '
        'PRIMARY KEY(supplier,batch_id))')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    commands.add_parser('summary')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    importer.add_argument('--supplier', default='legacy')
    importer.add_argument('--batch-id')
    args = parser.parse_args()

    connection = None
    try:
        # Use one immutable snapshot for both parsing and exact-byte replay checks.
        source_bytes = Path(args.path).read_bytes() if args.command == 'import' else None
        items = read_import(source_bytes) if source_bytes is not None else None
        connection = sqlite3.connect(args.db)
        with connection:
            # Serialize replay decisions and include schema migration in rollback.
            connection.execute('BEGIN IMMEDIATE')
            prepare_storage(connection)
            if args.command == 'import':
                if args.batch_id is not None:
                    previous = connection.execute(
                        'SELECT source_bytes FROM successful_batches WHERE supplier=? AND batch_id=?',
                        (args.supplier, args.batch_id),
                    ).fetchone()
                    if previous is not None:
                        if previous[0] != source_bytes:
                            raise ValueError('batch-id already used with different source bytes for this supplier')
                        return
                connection.executemany(
                    'INSERT INTO catalog (supplier,sku,name,price_cents) VALUES (?,?,?,?) '
                    'ON CONFLICT(supplier,sku) DO UPDATE SET name=excluded.name, price_cents=excluded.price_cents',
                    [(args.supplier, *item) for item in items],
                )
                if args.batch_id is not None:
                    connection.execute(
                        'INSERT INTO successful_batches VALUES (?,?,?)',
                        (args.supplier, args.batch_id, source_bytes),
                    )
            elif args.command == 'summary':
                groups = {}
                # Python integers preserve exact totals beyond SQLite's SUM range.
                for supplier, price in connection.execute(
                    'SELECT supplier,price_cents FROM catalog ORDER BY supplier'
                ):
                    group = groups.setdefault(
                        supplier, dict(supplier=supplier, count=0, total_cents=0))
                    group['count'] += 1
                    group['total_cents'] += price
                print(json.dumps(list(groups.values())))
            else:
                print(json.dumps([
                    dict(supplier=supplier, sku=sku, name=name, price_cents=price)
                    for supplier, sku, name, price in connection.execute(
                        'SELECT supplier,sku,name,price_cents FROM catalog ORDER BY supplier,sku'
                    )
                ]))
    except (OSError, UnicodeError, csv.Error, ValueError, sqlite3.Error) as error:
        parser.exit(1, f'catalog: {error}\n')
    finally:
        if connection is not None:
            connection.close()


if __name__ == '__main__':
    main()
