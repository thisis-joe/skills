import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest


class Catalog(unittest.TestCase):
    def run_cli(self, db, *args):
        return subprocess.run(
            [sys.executable, 'catalog.py', '--db', str(db), *args],
            text=True, capture_output=True,
        )

    def test_empty_list(self):
        with tempfile.TemporaryDirectory() as d:
            result = self.run_cli(Path(d) / 'x.sqlite', 'list')
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stdout), [])

    def test_import_updates_and_last_duplicate_wins(self):
        with tempfile.TemporaryDirectory() as d:
            db, csv = Path(d) / 'x.sqlite', Path(d) / 'items.csv'
            for contents in (
                'sku,name,price_cents\nz,Keep,10\na,Old,20\n',
                'sku,name,price_cents\na,First,30\nb,Zero,0\na,Last,40\n',
            ):
                csv.write_text(contents, encoding='utf-8')
                result = self.run_cli(db, 'import', str(csv))
                self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(self.run_cli(db, 'list').stdout), [
                {'supplier': 'legacy', 'sku': 'a', 'name': 'Last', 'price_cents': 40},
                {'supplier': 'legacy', 'sku': 'b', 'name': 'Zero', 'price_cents': 0},
                {'supplier': 'legacy', 'sku': 'z', 'name': 'Keep', 'price_cents': 10},
            ])

    def test_invalid_import_leaves_catalog_unchanged(self):
        with tempfile.TemporaryDirectory() as d:
            db, csv = Path(d) / 'x.sqlite', Path(d) / 'items.csv'
            csv.write_text('sku,name,price_cents\na,Original,5\n')
            result = self.run_cli(db, 'import', str(csv))
            self.assertEqual(result.returncode, 0, result.stderr)
            before = self.run_cli(db, 'list').stdout
            bad_rows = [
                'a,Bad,-1', 'a,Bad,1.5', 'a,Bad,NaN',
                'a,Bad,9223372036854775808', ',Empty,1', 'a,  ,1',
                'a,Missing', 'a,Extra,1,extra', '', 'a,"Unclosed,1',
            ]
            for row in bad_rows:
                with self.subTest(row=row):
                    csv.write_text('sku,name,price_cents\nz,New,9\n' + row + '\na,Valid,7\n')
                    result = self.run_cli(db, 'import', str(csv))
                    self.assertNotEqual(result.returncode, 0)
                    self.assertTrue(result.stderr)
                    self.assertEqual(self.run_cli(db, 'list').stdout, before)
            for contents in (b'wrong,header\n', b'', b'sku,name,price_cents\na,\xff,1\n'):
                csv.write_bytes(contents)
                self.assertNotEqual(self.run_cli(db, 'import', str(csv)).returncode, 0)
                self.assertEqual(self.run_cli(db, 'list').stdout, before)
            self.assertNotEqual(self.run_cli(db, 'import', str(csv) + '.missing').returncode, 0)
            self.assertEqual(self.run_cli(db, 'list').stdout, before)

    def test_quoted_fields_and_header_only(self):
        with tempfile.TemporaryDirectory() as d:
            db, csv = Path(d) / 'x.sqlite', Path(d) / 'items.csv'
            csv.write_text('sku,name,price_cents\na,"Part, large",9223372036854775807\n')
            self.assertEqual(self.run_cli(db, 'import', str(csv)).returncode, 0)
            before = self.run_cli(db, 'list').stdout
            self.assertEqual(json.loads(before)[0]['name'], 'Part, large')
            csv.write_text('sku,name,price_cents\n')
            self.assertEqual(self.run_cli(db, 'import', str(csv)).returncode, 0)
            self.assertEqual(self.run_cli(db, 'list').stdout, before)

    def test_trimmed_identity_collisions_and_case_sensitive_updates(self):
        with tempfile.TemporaryDirectory() as d:
            db, csv = Path(d) / 'x.sqlite', Path(d) / 'items.csv'
            csv.write_text('sku,name,price_cents\nABC,Original,5\nkeep,Unrelated,8\n')
            self.assertEqual(self.run_cli(db, 'import', str(csv)).returncode, 0)
            csv.write_text('sku,name,price_cents\n ABC , First ,10\nABC, Last ,20\nabc, Lower ,30\n')
            result = self.run_cli(db, 'import', str(csv))
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(self.run_cli(db, 'list').stdout), [
                {'supplier': 'legacy', 'sku': 'ABC', 'name': 'Last', 'price_cents': 20},
                {'supplier': 'legacy', 'sku': 'abc', 'name': 'Lower', 'price_cents': 30},
                {'supplier': 'legacy', 'sku': 'keep', 'name': 'Unrelated', 'price_cents': 8},
            ])
            csv.write_text('sku,name,price_cents\n ABC , Updated , 40 \n')
            result = self.run_cli(db, 'import', str(csv))
            self.assertEqual(result.returncode, 0, result.stderr)
            before = self.run_cli(db, 'list').stdout
            self.assertEqual(json.loads(before)[0],
                             {'supplier': 'legacy', 'sku': 'ABC', 'name': 'Updated', 'price_cents': 40})
            csv.write_text('sku,name,price_cents\n ABC ,Bad,nope\nABC,Valid,50\n')
            self.assertNotEqual(self.run_cli(db, 'import', str(csv)).returncode, 0)
            self.assertEqual(self.run_cli(db, 'list').stdout, before)

    def test_supplier_migration_and_batch_replay(self):
        with tempfile.TemporaryDirectory() as d:
            db, source = Path(d) / 'x.sqlite', Path(d) / 'items.csv'
            with sqlite3.connect(db) as connection:
                connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
                connection.execute("INSERT INTO catalog VALUES ('old', 'Preserved', 7)")
            self.assertEqual(json.loads(self.run_cli(db, 'list').stdout), [
                dict(supplier='legacy', sku='old', name='Preserved', price_cents=7)])
            original = b'sku,name,price_cents\n A ,First,0\nA,Last,10\n'
            source.write_bytes(original)
            def apply(supplier, batch=None):
                args = ['import', str(source), '--supplier', supplier]
                if batch is not None:
                    args += ['--batch-id', batch]
                return self.run_cli(db, *args)
            self.assertEqual(apply('north', 'one').returncode, 0)
            self.assertEqual(apply('south', 'one').returncode, 0)
            source.write_text('sku,name,price_cents\nA,Newer,20\n')
            self.assertEqual(apply('north', 'two').returncode, 0)
            before = self.run_cli(db, 'list').stdout
            source.write_bytes(original)
            self.assertEqual(apply('north', 'one').returncode, 0)
            self.assertEqual(self.run_cli(db, 'list').stdout, before)
            source.write_bytes(original.replace(b'10', b'11'))
            self.assertNotEqual(apply('north', 'one').returncode, 0)
            self.assertEqual(self.run_cli(db, 'list').stdout, before)
            source.write_text('sku,name,price_cents\nA,Bad,-1\n')
            self.assertNotEqual(apply('north', 'retry').returncode, 0)
            source.write_text('sku,name,price_cents\nA,Retry,30\n')
            self.assertEqual(apply('north', 'retry').returncode, 0)
            self.assertEqual(json.loads(self.run_cli(db, 'list').stdout), [
                dict(supplier='legacy', sku='old', name='Preserved', price_cents=7),
                dict(supplier='north', sku='A', name='Retry', price_cents=30),
                dict(supplier='south', sku='A', name='Last', price_cents=10)])

    def test_storage_failure_rolls_back_items_and_batch_key(self):
        with tempfile.TemporaryDirectory() as d:
            db, source = Path(d) / 'x.sqlite', Path(d) / 'items.csv'
            self.assertEqual(self.run_cli(db, 'list').returncode, 0)
            with sqlite3.connect(db) as connection:
                connection.execute("CREATE TRIGGER reject_item BEFORE INSERT ON catalog WHEN NEW.sku='bad' BEGIN SELECT RAISE(ABORT, 'blocked'); END")
            source.write_text('sku,name,price_cents\na,Valid,1\nbad,Blocked,2\n')
            args = ['import', str(source), '--batch-id', 'retry']
            self.assertNotEqual(self.run_cli(db, *args).returncode, 0)
            self.assertEqual(json.loads(self.run_cli(db, 'list').stdout), [])
            with sqlite3.connect(db) as connection:
                self.assertEqual(connection.execute('SELECT * FROM successful_batches').fetchall(), [])
                connection.execute('DROP TRIGGER reject_item')
            self.assertEqual(self.run_cli(db, *args).returncode, 0)

    def test_summary_supplier_counts_totals_and_empty(self):
        with tempfile.TemporaryDirectory() as d:
            db, source = Path(d) / 'x.sqlite', Path(d) / 'items.csv'
            empty = self.run_cli(db, 'summary')
            self.assertEqual(empty.returncode, 0, empty.stderr)
            self.assertEqual(json.loads(empty.stdout), [])
            for supplier, rows in (
                ('south', 'a,Free,0\n'),
                ('legacy', 'a,Free,0\nb,Paid,12\n'),
                ('north', 'a,Large,9223372036854775807\nb,Extra,1\n'),
            ):
                source.write_text('sku,name,price_cents\n' + rows)
                result = self.run_cli(db, 'import', str(source), '--supplier', supplier)
                self.assertEqual(result.returncode, 0, result.stderr)
            before = self.run_cli(db, 'list').stdout
            result = self.run_cli(db, 'summary')
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stdout), [
                dict(supplier='legacy', count=2, total_cents=12),
                dict(supplier='north', count=2, total_cents=9223372036854775808),
                dict(supplier='south', count=1, total_cents=0),
            ])
            self.assertEqual(self.run_cli(db, 'list').stdout, before)
            self.assertEqual(len(json.loads(before)), 5)

    def test_summary_migrates_legacy_rows(self):
        with tempfile.TemporaryDirectory() as d:
            db = Path(d) / 'x.sqlite'
            with sqlite3.connect(db) as connection:
                connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
                connection.executemany('INSERT INTO catalog VALUES (?,?,?)',
                                       [('a', 'Free', 0), ('b', 'Paid', 7)])
            result = self.run_cli(db, 'summary')
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stdout), [
                dict(supplier='legacy', count=2, total_cents=7)])
            self.assertEqual(len(json.loads(self.run_cli(db, 'list').stdout)), 2)
