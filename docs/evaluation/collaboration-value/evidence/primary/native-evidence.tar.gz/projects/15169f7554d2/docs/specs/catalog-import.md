# Catalog CSV import

Add `python3 catalog.py --db PATH import CSV_PATH`; preserve sorted JSON `list`
and existing schema/data. CSV header is sku,name,price_cents. SKU and name must
be nonempty after surrounding whitespace is trimmed from all data fields.
Trim before validation and duplicate handling; preserve SKU case, so `ABC` and
`abc` are distinct while ` ABC ` and `ABC` collide. Prices are ASCII
digits representing nonnegative integer cents within SQLite's signed 64-bit range.
Require the exact header and three fields per row; reject blank/malformed rows,
invalid UTF-8, missing files and invalid prices with a nonzero exit and stderr.
Validate every row, including overwritten duplicates, before any database write.
Last row per SKU wins; later imports update stored name and price. Apply all rows
in one transaction; a rejected file leaves the catalog unchanged. Success emits
no output. A header-only file succeeds without changing items.

Summary is deferred until the user trials this committed import/list slice.
Automatic basic implementation/checking/local commits authorized; same-agent
inspection accepted; no specialists, services, publication or push.

## Supplier storage and replay revision

Imports accept optional --supplier (default legacy) and --batch-id (default none).
Identity is (supplier, trimmed case-sensitive SKU). Existing rows migrate exactly
as stored into legacy. List adds supplier and sorts by supplier then SKU.
Store successful keyed imports' exact source bytes under (supplier,batch_id).
An identical replay is a no-op, including after newer updates; differing bytes
under the same key fail. Validation, migration, item updates and batch recording
must be atomic; rejected imports change neither items nor successful-batch state.
Supplier and batch identifiers are used exactly as provided. No automatic rewrite
of existing keys. Summary is explicitly excluded from this work unit.

## Purchasing summary

`summary` returns a JSON array of nonempty supplier groups sorted by supplier,
with supplier, count and total_cents; an empty catalog returns []. All stored
items count, including zero-price rows, which add zero to totals. List retains
those rows. Sum integer cents exactly, including totals beyond SQLite's integer
range. Summary supports existing legacy database migration like list. Import
and replay behavior remain unchanged. This supersedes summary deferral above.
