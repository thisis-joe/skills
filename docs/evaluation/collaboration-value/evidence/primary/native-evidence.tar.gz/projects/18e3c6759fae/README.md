# Purchasing catalog
Python standard library only. Public entry: `python3 catalog.py --db PATH list`.
List returns a JSON array of {supplier,sku,name,price_cents}, sorted by supplier
then SKU. Storage uses a composite (supplier,sku) primary key. Existing catalogs
are migrated transactionally to supplier legacy, preserving all stored rows.
CSV has header sku,name,price_cents. SKU/name must be nonempty; prices are
nonnegative integer cents. Import rules are documented below.
Use the existing public CLI entry for added commands. Local regression command:
`python3 -m unittest discover -v`. Work locally; preserve unrelated files.

Import supplier files with `python3 catalog.py --db PATH import SUPPLIER.csv`.
Successful imports exit with status 0 and no output; use `list` to inspect items.
The last row for each SKU wins within a file, and imports update existing items
for the same supplier and normalized SKU.
Items absent from the file remain stored. Every row is validated, including rows
superseded by later duplicates. Any malformed row rejects the entire file without
changing stored items; errors go to stderr with a nonzero exit status.

Files use UTF-8 (an optional BOM is accepted) and the exact header
`sku,name,price_cents`. Each row must have three fields, SKU/name must contain
non-whitespace text, and price must contain ASCII digits only, within SQLite's
signed 64-bit integer range. Surrounding field whitespace is trimmed; SKU keys
are lowercased before duplicate resolution and storage. Case/whitespace variants
are the same item. Importing that identity replaces matching legacy spellings
with one lowercase key; unrelated stored rows remain untouched. A header-only
file makes no changes. Database write failures roll back the import as well.

Use `import SUPPLIER.csv --supplier NAME --batch-id ID` for supplier-scoped
imports with replay protection. Both options are optional: supplier defaults to
`legacy`; omitting `--batch-id` applies an ordinary import each time. Supplier
names and batch IDs are used exactly as supplied. Different suppliers have
independent items and may reuse the same batch ID.

For a given supplier/batch ID, replaying the exact original source bytes succeeds
without applying them again, even after newer imports update those items. Reusing
that key with different bytes fails. Source bytes are stored in SQLite alongside
the successful key. Catalog changes and the successful-batch record commit in one
transaction; failures leave both unchanged and do not reserve a new key. Source
bytes are read once for validation and replay comparison.

Run `python3 catalog.py --db PATH summary` for a JSON array of
`{supplier,count,total_cents}` objects sorted by supplier. Only positive-price
rows contribute to count and total; suppliers with no positive-price rows are
omitted. No qualifying rows yields `[]`. Totals are exact integer cents, including
when a supplier's total exceeds SQLite's signed 64-bit integer range.
Summary preserves all stored items; `list` continues to include zero-price rows.
