import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest


class Catalog(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.db = str(Path(self.temp.name) / 'catalog.sqlite')
        self.csv = Path(self.temp.name) / 'items.csv'

    def cli(self, *args):
        return subprocess.run(
            [sys.executable, 'catalog.py', '--db', self.db, *args],
            capture_output=True, text=True,
        )

    def listing(self):
        result = self.cli('list')
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def import_text(self, text, *options):
        self.csv.write_text(text, encoding='utf-8')
        return self.cli('import', str(self.csv), *options)

    def test_empty_list(self):
        self.assertEqual(self.listing(), [])

    def test_duplicates_updates_and_preserves_existing_items(self):
        with sqlite3.connect(self.db) as connection:
            connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
            connection.executemany('INSERT INTO catalog VALUES (?,?,?)', [
                ('A', 'Original', 10), ('z', 'Keep', 99),
            ])
        result = self.import_text('sku,name,price_cents\nA,First,20\nB,"Item, B",0\nA,Last,30\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.listing(), [
            dict(supplier='legacy', sku='a', name='Last', price_cents=30),
            dict(supplier='legacy', sku='b', name='Item, B', price_cents=0),
            dict(supplier='legacy', sku='z', name='Keep', price_cents=99),
        ])
        result = self.import_text('sku,name,price_cents\nA,Later,40\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.listing()[0], dict(supplier='legacy', sku='a', name='Later', price_cents=40))

    def test_normalized_identity_collisions_and_later_update(self):
        with sqlite3.connect(self.db) as connection:
            connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
            connection.executemany('INSERT INTO catalog VALUES (?,?,?)', [
                (' Widget ', 'Legacy one', 10), ('WIDGET', 'Legacy two', 20),
                ('widget', 'Legacy three', 30), (' UNRELATED ', 'Keep exactly', 99),
            ])
        result = self.import_text('sku,name,price_cents\n WIDGET , First , 40 \nwidget, Last , 50 \n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.listing(), [
            dict(supplier='legacy', sku=' UNRELATED ', name='Keep exactly', price_cents=99),
            dict(supplier='legacy', sku='widget', name='Last', price_cents=50),
        ])
        result = self.import_text('sku,name,price_cents\n WiDgEt , Later , 60 \n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.listing()[1], dict(supplier='legacy', sku='widget', name='Later', price_cents=60))
        before = self.listing()
        result = self.import_text('sku,name,price_cents\n WIDGET ,Bad,no\nwidget,Good,70\n')
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(self.listing(), before)

    def test_malformed_file_leaves_catalog_unchanged(self):
        self.assertEqual(self.import_text('sku,name,price_cents\nA,Original,10\n').returncode, 0)
        before = self.listing()
        invalid_rows = [
            'B,Bad,-1\n', 'B,Bad,1.5\n', 'B,Bad,no\n', 'B,Bad,\n',
            ',Bad,1\n', 'B,   ,1\n', 'B,Bad\n', 'B,Bad,1,extra\n',
            'B,Bad,9223372036854775808\n', 'B,"unclosed,1\n',
            'A,Bad,no\nA,Valid later,2\n',
        ]
        for row in invalid_rows:
            with self.subTest(row=row):
                result = self.import_text('sku,name,price_cents\nA,Changed,20\nC,New,30\n' + row)
                self.assertNotEqual(result.returncode, 0)
                self.assertIn('error:', result.stderr)
                self.assertEqual(self.listing(), before)
        for text in ['', 'sku,name,wrong\nA,Changed,20\n']:
            self.assertNotEqual(self.import_text(text).returncode, 0)
            self.assertEqual(self.listing(), before)
        self.csv.write_bytes(b'sku,name,price_cents\nA,Changed,20\nB,\xff,1\n')
        self.assertNotEqual(self.cli('import', str(self.csv)).returncode, 0)
        self.assertEqual(self.listing(), before)
        self.assertNotEqual(self.cli('import', str(self.csv) + '.missing').returncode, 0)
        self.assertEqual(self.listing(), before)

    def test_database_failure_rolls_back_all_updates(self):
        self.import_text('sku,name,price_cents\nA,Original,10\n')
        with sqlite3.connect(self.db) as connection:
            connection.execute("CREATE TRIGGER reject_b BEFORE INSERT ON catalog WHEN NEW.sku = 'b' BEGIN SELECT RAISE(ABORT, 'blocked'); END")
        with sqlite3.connect(self.db) as connection:
            connection.execute("UPDATE catalog SET sku=' A ' WHERE sku='a'")
        result = self.import_text('sku,name,price_cents\nA,Changed,20\nB,Blocked,30\n')
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(self.listing(), [dict(supplier='legacy', sku=' A ', name='Original', price_cents=10)])

    def batch_state(self):
        with sqlite3.connect(self.db) as connection:
            return connection.execute(
                'SELECT supplier,batch_id,source_bytes FROM successful_batches ORDER BY supplier,batch_id'
            ).fetchall()

    def test_supplier_scoped_updates_and_replay(self):
        old = 'sku,name,price_cents\n X ,First,10\nx,Last,20\n'
        newer = 'sku,name,price_cents\nx,Newer,30\n'
        for supplier in ['zeta', 'alpha']:
            result = self.import_text(old, '--supplier', supplier, '--batch-id', 'daily')
            self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.import_text(newer, '--supplier', 'alpha').returncode, 0)
        self.assertEqual(self.import_text(newer, '--supplier', 'zeta', '--batch-id', 'next').returncode, 0)
        before = self.listing()
        batches = self.batch_state()
        self.assertEqual(before, [
            dict(supplier='alpha', sku='x', name='Newer', price_cents=30),
            dict(supplier='zeta', sku='x', name='Newer', price_cents=30),
        ])
        for supplier in ['alpha', 'zeta']:
            self.assertEqual(self.import_text(old, '--supplier', supplier, '--batch-id', 'daily').returncode, 0)
            self.assertEqual(self.listing(), before)
            self.assertEqual(self.batch_state(), batches)
        # Semantically equivalent CSV still has different source bytes.
        result = self.import_text(old.replace('\n', '\r\n'), '--supplier', 'alpha', '--batch-id', 'daily')
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(self.listing(), before)
        self.assertEqual(self.batch_state(), batches)

    def test_failed_batch_does_not_reserve_key(self):
        self.listing()
        before = self.listing()
        batches = self.batch_state()
        bad = 'sku,name,price_cents\nx,Valid,10\ny,Bad,-1\n'
        self.assertNotEqual(self.import_text(bad, '--batch-id', 'retry').returncode, 0)
        self.assertEqual(self.listing(), before)
        self.assertEqual(self.batch_state(), batches)
        good = 'sku,name,price_cents\nx,Fixed,0\n'
        self.assertEqual(self.import_text(good, '--batch-id', 'retry').returncode, 0)
        self.assertEqual(self.batch_state(), [('legacy', 'retry', good.encode())])
        self.assertEqual(self.listing(), [dict(supplier='legacy', sku='x', name='Fixed', price_cents=0)])

    def test_failed_write_rolls_back_successful_batch_state(self):
        self.listing()
        with sqlite3.connect(self.db) as connection:
            connection.execute("CREATE TRIGGER reject_y BEFORE INSERT ON catalog WHEN NEW.sku='y' BEGIN SELECT RAISE(ABORT, 'blocked'); END")
        text = 'sku,name,price_cents\nx,Valid,10\ny,Blocked,20\n'
        self.assertNotEqual(self.import_text(text, '--batch-id', 'retry').returncode, 0)
        self.assertEqual(self.listing(), [])
        self.assertEqual(self.batch_state(), [])
        with sqlite3.connect(self.db) as connection:
            connection.execute('DROP TRIGGER reject_y')
        self.assertEqual(self.import_text(text, '--batch-id', 'retry').returncode, 0)
        self.assertEqual(len(self.batch_state()), 1)

    def test_migration_preserves_all_legacy_rows(self):
        rows = [(' A ', 'Original', 10), ('a', 'Other', 0), ('Z', 'Keep', 99)]
        with sqlite3.connect(self.db) as connection:
            connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
            connection.executemany('INSERT INTO catalog VALUES (?,?,?)', rows)
        expected = [dict(supplier='legacy', sku=k, name=n, price_cents=v) for k, n, v in sorted(rows)]
        self.assertEqual(self.listing(), expected)
        self.assertEqual(self.listing(), expected)
        self.assertEqual(self.batch_state(), [])
        result = self.import_text('sku,name,price_cents\nA,Supplier item,50\n', '--supplier', 'other')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.listing()[:3], expected)

    def summary(self):
        result = self.cli('summary')
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def test_summary_filters_zero_prices_and_sorts_suppliers(self):
        self.assertEqual(self.summary(), [])
        for supplier, rows in [
            ('zeta', 'a,First,10\nb,Second,20\nfree,Free,0\n'),
            ('alpha', 'a,Other,7\n'),
            ('zero', 'free,Free,0\n'),
        ]:
            result = self.import_text('sku,name,price_cents\n' + rows, '--supplier', supplier)
            self.assertEqual(result.returncode, 0, result.stderr)
        before = self.listing()
        self.assertEqual(self.summary(), [
            dict(supplier='alpha', count=1, total_cents=7),
            dict(supplier='zeta', count=2, total_cents=30),
        ])
        self.assertEqual(self.listing(), before)
        self.assertEqual(len(before), 5)
        self.assertEqual(self.import_text('sku,name,price_cents\na,Now free,0\n', '--supplier', 'alpha').returncode, 0)
        self.assertEqual(self.summary(), [dict(supplier='zeta', count=2, total_cents=30)])

    def test_summary_zero_only_and_large_exact_totals(self):
        self.assertEqual(self.import_text('sku,name,price_cents\nfree,Free,0\n').returncode, 0)
        self.assertEqual(self.summary(), [])
        maximum = 9223372036854775807
        result = self.import_text(f'sku,name,price_cents\na,A,{maximum}\nb,B,{maximum}\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.summary(), [dict(supplier='legacy', count=2, total_cents=maximum * 2)])
        self.assertEqual(len(self.listing()), 3)

    def test_summary_migrates_legacy_storage_without_losing_zero_rows(self):
        with sqlite3.connect(self.db) as connection:
            connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
            connection.executemany('INSERT INTO catalog VALUES (?,?,?)', [('A', 'Paid', 12), ('B', 'Free', 0)])
        self.assertEqual(self.summary(), [dict(supplier='legacy', count=1, total_cents=12)])
        self.assertEqual(self.listing(), [
            dict(supplier='legacy', sku='A', name='Paid', price_cents=12),
            dict(supplier='legacy', sku='B', name='Free', price_cents=0),
        ])

    def test_header_only_import_preserves_items(self):
        self.import_text('sku,name,price_cents\nA,Original,10\n')
        before = self.listing()
        self.assertEqual(self.import_text('sku,name,price_cents\n').returncode, 0)
        self.assertEqual(self.listing(), before)


if __name__ == '__main__':
    unittest.main()
