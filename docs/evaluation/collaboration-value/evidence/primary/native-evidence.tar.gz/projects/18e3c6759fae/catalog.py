import argparse
import csv
import io
import json
from pathlib import Path
import sqlite3


def read_import(source_bytes):
    """Validate the complete file before changing any stored items."""
    items = {}
    with io.StringIO(source_bytes.decode('utf-8-sig'), newline='') as source:
        rows = csv.reader(source, strict=True)
        if next(rows, None) != ['sku', 'name', 'price_cents']:
            raise ValueError('expected CSV header sku,name,price_cents')
        for row in rows:
            if len(row) != 3:
                raise ValueError(f'line {rows.line_num}: expected three fields')
            sku, name, price = (field.strip() for field in row)
            sku = sku.lower()
            if not sku.strip() or not name.strip():
                raise ValueError(f'line {rows.line_num}: SKU and name must be nonempty')
            if not price or any(char not in '0123456789' for char in price):
                raise ValueError(f'line {rows.line_num}: price must be nonnegative integer cents')
            cents = int(price)
            if cents > 9223372036854775807:
                raise ValueError(f'line {rows.line_num}: price exceeds SQLite integer range')
            items[sku] = (sku, name, cents)
    return list(items.values())


def initialize_storage(connection):
    columns = {row[1] for row in connection.execute('PRAGMA table_info(catalog)')}
    if columns and 'supplier' not in columns:
        connection.execute(
            'CREATE TABLE catalog_supplier_migration '
            '(supplier TEXT NOT NULL, sku TEXT NOT NULL, name TEXT NOT NULL, '
            'price_cents INTEGER NOT NULL CHECK(price_cents >= 0), '
            'PRIMARY KEY (supplier,sku))'
        )
        connection.execute(
            "INSERT INTO catalog_supplier_migration SELECT 'legacy',sku,name,price_cents FROM catalog"
        )
        connection.execute('DROP TABLE catalog')
        connection.execute('ALTER TABLE catalog_supplier_migration RENAME TO catalog')
    else:
        connection.execute(
            'CREATE TABLE IF NOT EXISTS catalog '
            '(supplier TEXT NOT NULL, sku TEXT NOT NULL, name TEXT NOT NULL, '
            'price_cents INTEGER NOT NULL CHECK(price_cents >= 0), '
            'PRIMARY KEY (supplier,sku))'
        )
    connection.execute(
        'CREATE TABLE IF NOT EXISTS successful_batches '
        '(supplier TEXT NOT NULL, batch_id TEXT NOT NULL, source_bytes BLOB NOT NULL, '
        'PRIMARY KEY (supplier,batch_id))'
    )


def apply_import(connection, supplier, batch_id, source_bytes, items):
    if batch_id is not None:
        previous = connection.execute(
            'SELECT source_bytes FROM successful_batches WHERE supplier=? AND batch_id=?',
            (supplier, batch_id),
        ).fetchone()
        if previous is not None:
            if previous[0] != source_bytes:
                raise ValueError('batch ID already used with different source bytes for this supplier')
            return
    incoming = {sku for sku, _, _ in items}
    aliases = [
        (supplier, sku) for (sku,) in connection.execute(
            'SELECT sku FROM catalog WHERE supplier=?', (supplier,)
        )
        if sku.strip().lower() in incoming and sku != sku.strip().lower()
    ]
    connection.executemany('DELETE FROM catalog WHERE supplier=? AND sku=?', aliases)
    connection.executemany(
        'INSERT INTO catalog (supplier,sku,name,price_cents) VALUES (?,?,?,?) '
        'ON CONFLICT(supplier,sku) DO UPDATE SET '
        'name=excluded.name, price_cents=excluded.price_cents',
        [(supplier, sku, name, cents) for sku, name, cents in items],
    )
    if batch_id is not None:
        connection.execute(
            'INSERT INTO successful_batches VALUES (?,?,?)',
            (supplier, batch_id, source_bytes),
        )


def purchasing_summary(connection):
    groups = {}
    for supplier, price in connection.execute(
        'SELECT supplier,price_cents FROM catalog WHERE price_cents > 0 ORDER BY supplier'
    ):
        group = groups.setdefault(supplier, dict(supplier=supplier, count=0, total_cents=0))
        group['count'] += 1
        # Python integers preserve exact totals beyond SQLite's integer range.
        group['total_cents'] += price
    return list(groups.values())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    commands.add_parser('summary')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    importer.add_argument('--supplier', default='legacy')
    importer.add_argument('--batch-id')
    args = parser.parse_args()
    try:
        source_bytes = Path(args.path).read_bytes() if args.command == 'import' else None
        items = read_import(source_bytes) if source_bytes is not None else None
        connection = sqlite3.connect(args.db)
        try:
            with connection:
                # Serialize replay checks and writes, including transactional migration.
                connection.execute('BEGIN IMMEDIATE')
                initialize_storage(connection)
                if items is not None:
                    apply_import(connection, args.supplier, args.batch_id, source_bytes, items)
                elif args.command == 'summary':
                    print(json.dumps(purchasing_summary(connection)))
                else:
                    print(json.dumps([
                        dict(supplier=supplier, sku=sku, name=name, price_cents=price)
                        for supplier, sku, name, price in connection.execute(
                            'SELECT supplier,sku,name,price_cents FROM catalog ORDER BY supplier,sku'
                        )
                    ]))
        finally:
            connection.close()
    except (OSError, UnicodeError, csv.Error, ValueError, sqlite3.Error) as error:
        parser.exit(1, f'error: {error}\n')


if __name__ == '__main__':
    main()
