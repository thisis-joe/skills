# Purchasing catalog

Python standard library only. Public entry:
`python3 catalog.py --db PATH list`.
List returns a JSON array of `{supplier,sku,name,price_cents}`, sorted by supplier
then SKU. Existing single-supplier databases migrate automatically: all rows
become supplier `legacy`, with their stored values preserved.

Import with:

```
python3 catalog.py --db PATH import daily.csv --supplier NAME --batch-id ID
```

Both options are optional. Supplier defaults to `legacy`; omitting `--batch-id`
imports normally without a replay key. Supplier names and batch IDs are used
exactly as passed. Item identity is supplier plus trimmed, case-sensitive SKU.
An ordinary later import updates name/price for existing items; absent items
remain unchanged. Within a file, only the first occurrence of a SKU is used,
even if that first row is malformed.

CSV header is exactly `sku,name,price_cents`. Incoming fields are trimmed;
SKU/name must be nonempty. Prices are ASCII digits from 0 through
9223372036854775807 cents. Malformed rows and duplicate rows are skipped with
row-numbered stderr explanations; these skips still succeed. Import has no
stdout output. File/header/encoding/CSV syntax errors fail without partial writes.

A successful batch key belongs to its supplier. Repeating the exact source bytes
with that key succeeds without reapplying, even after newer updates. Different
bytes with the same key fail without changing catalog or successful-batch state.
SHA-256 fingerprints track source bytes. Item writes and key recording commit
atomically. Failed imports do not reserve their batch key.

Regression command: `python3 -m unittest discover -v`.
Work locally; preserve unrelated files. Nothing is published.

Run `python3 catalog.py --db PATH summary` for a JSON array of
`{supplier,count,total_cents}` objects, one per nonempty supplier group sorted by
supplier. An empty catalog returns `[]`. Count includes zero-price rows, which
add zero to the total and remain in list. All-zero supplier groups appear.
Totals are exact integer cents, even above SQLite's per-item integer limit.
