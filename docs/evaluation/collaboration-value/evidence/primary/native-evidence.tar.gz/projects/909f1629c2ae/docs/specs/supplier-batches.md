# Supplier and batch import storage

Import accepts optional --supplier NAME (default legacy) and --batch-id ID
(default no replay key). Identity is supplier plus trimmed case-sensitive SKU.
Incoming CSV fields are trimmed. First occurrence of each SKU wins, including
invalid first rows; malformed rows are skipped with stderr explanations and
successful exit. Later ordinary imports update names/prices for existing keys.
Items absent from an import are preserved. Prices remain nonnegative integer
cents within SQLite's integer range; zero remains valid.

Migrate old catalog rows unchanged to supplier legacy. List adds supplier and
sorts by supplier then SKU. No edits to unrelated data or files.

Successful keys are scoped to supplier and record a SHA-256 digest of the exact
source bytes. An identical keyed replay succeeds without applying rows, even
after newer imports. Different bytes with the same key fail with no catalog or
successful-key changes. Import data, migration and successful-key writes share
one transaction; file-level errors roll back. Supplier and batch identifiers
are used exactly as passed, with no normalization.

Summary is excluded from this slice. Next session: sorted nonempty supplier
groups with supplier,count,total_cents, [] when empty. Clarify the referenced
zero-price summary rule if it is not otherwise available before implementation.
