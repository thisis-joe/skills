import argparse
import csv
import hashlib
import io
import json
import re
import sqlite3
import sys
from pathlib import Path


def prepare_storage(connection):
    columns = {row[1] for row in connection.execute('PRAGMA table_info(catalog)')}
    if columns and 'supplier' not in columns:
        connection.execute('ALTER TABLE catalog RENAME TO catalog_before_suppliers')
    connection.execute(
        'CREATE TABLE IF NOT EXISTS catalog ('
        'supplier TEXT NOT NULL, sku TEXT NOT NULL, name TEXT NOT NULL, '
        'price_cents INTEGER NOT NULL, PRIMARY KEY (supplier,sku))')
    if columns and 'supplier' not in columns:
        connection.execute(
            "INSERT INTO catalog SELECT 'legacy',sku,name,price_cents FROM catalog_before_suppliers")
        connection.execute('DROP TABLE catalog_before_suppliers')
    connection.execute(
        'CREATE TABLE IF NOT EXISTS successful_batches ('
        'supplier TEXT NOT NULL, batch_id TEXT NOT NULL, source_sha256 TEXT NOT NULL, '
        'PRIMARY KEY (supplier,batch_id))')


def import_csv(connection, path, supplier, batch_id):
    source_bytes = Path(path).read_bytes()
    digest = hashlib.sha256(source_bytes).hexdigest()
    if batch_id is not None:
        previous = connection.execute(
            'SELECT source_sha256 FROM successful_batches WHERE supplier=? AND batch_id=?',
            (supplier, batch_id)).fetchone()
        if previous is not None:
            if previous[0] != digest:
                raise ValueError('batch key already used with different source bytes')
            return
    seen = set()
    with io.StringIO(source_bytes.decode('utf-8'), newline='') as source:
        reader = csv.reader(source, strict=True)
        if next(reader, None) != ['sku', 'name', 'price_cents']:
            raise ValueError('expected CSV header sku,name,price_cents')
        for row in reader:
            row = [field.strip() for field in row]
            reason = None
            sku = row[0] if row else ''
            if sku.strip():
                if sku in seen:
                    reason = 'duplicate SKU; keeping first row'
                else:
                    seen.add(sku)
            if reason is None:
                if len(row) != 3 or not sku.strip() or not row[1].strip():
                    reason = 'expected nonempty sku/name and three fields'
                elif not re.fullmatch(r'[0-9]+', row[2]):
                    reason = 'price_cents must be nonnegative integer cents'
                else:
                    digits = row[2].lstrip('0') or '0'
                    if len(digits) > 19 or (len(digits) == 19 and digits > '9223372036854775807'):
                        reason = 'price_cents exceeds SQLite integer range'
                    else:
                        connection.execute(
                            'INSERT INTO catalog (supplier,sku,name,price_cents) VALUES (?,?,?,?) '
                            'ON CONFLICT(supplier,sku) DO UPDATE SET '
                            'name=excluded.name, price_cents=excluded.price_cents',
                            (supplier, sku, row[1], int(digits)),
                        )
            if reason:
                print(f'row {reader.line_num}: skipped: {reason}', file=sys.stderr)

    if batch_id is not None:
        connection.execute(
            'INSERT INTO successful_batches VALUES (?,?,?)', (supplier, batch_id, digest))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    commands.add_parser('summary')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    importer.add_argument('--supplier', default='legacy')
    importer.add_argument('--batch-id')
    args = parser.parse_args()
    connection = None
    try:
        connection = sqlite3.connect(args.db)
        # Serialize key checks and writes, including migration, in one transaction.
        with connection:
            connection.execute('BEGIN IMMEDIATE')
            prepare_storage(connection)
            if args.command == 'import':
                import_csv(connection, args.path, args.supplier, args.batch_id)
            elif args.command == 'summary':
                groups = []
                # Python integer totals stay exact beyond SQLite's SUM range.
                for supplier, price in connection.execute(
                        'SELECT supplier,price_cents FROM catalog ORDER BY supplier,sku'):
                    if not groups or groups[-1]['supplier'] != supplier:
                        groups.append(dict(supplier=supplier, count=0, total_cents=0))
                    groups[-1]['count'] += 1
                    groups[-1]['total_cents'] += price
                print(json.dumps(groups))
            else:
                print(json.dumps([dict(supplier=s, sku=k, name=n, price_cents=v)
                    for s, k, n, v in connection.execute(
                        'SELECT supplier,sku,name,price_cents FROM catalog ORDER BY supplier,sku')]))
    except (OSError, UnicodeError, csv.Error, ValueError, sqlite3.Error) as error:
        print(f'catalog: {error}', file=sys.stderr)
        return 1
    finally:
        if connection is not None:
            connection.close()
    return 0


if __name__ == '__main__':
    sys.exit(main())
