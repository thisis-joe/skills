Historical first-slice record. Supplier/update/replay requirements are now
authoritative in supplier-batches.md.

# Catalog CSV import checkpoint

Add `python3 catalog.py --db PATH import CSV_PATH`; preserve sorted JSON `list`
and the existing SQLite schema. CSV header is sku,name,price_cents. SKU/name
must contain non-whitespace text; prices are ASCII nonnegative integer cents
within SQLite's signed 64-bit range. Trim surrounding whitespace from incoming field values before validation,
identity comparison and storage. Preserve SKU case: AbC and abc are distinct.
Do not rewrite existing stored data.

Keep the first occurrence of a nonempty SKU in a file, even if that row is
malformed; preserve existing stored rows on collision. Skip malformed rows and
collisions, explain each on stderr, and succeed for a readable, correctly headed
CSV. Invalid headers, unreadable files, invalid encoding or broken CSV syntax
fail with a diagnostic and no partial import. Import has no stdout output.

Acceptance: real CLI checks for import/list, duplicates, stored collisions,
malformed rows, repeat import, and file errors; existing unittest suite passes.
Summary is deferred until the user trials this committed slice.
