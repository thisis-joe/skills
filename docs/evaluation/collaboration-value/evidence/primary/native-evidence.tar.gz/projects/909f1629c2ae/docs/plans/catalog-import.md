Historical first-slice record. Supplier/update/replay requirements are now
authoritative in ../specs/supplier-batches.md.

# Import/list work record

Base: 82945e58fa484f66fc4a525ca9586047011befce
Branch: feat/catalog-csv-import
Unrelated untracked file: personal-notes.txt (leave untouched).

Authorized: automatic implementation, checks, disclosed same-agent inspection,
and local work-unit commits; no specialists, agents, publication or Jira.
Spec: ../specs/catalog-import.md

1. Add failing CLI regression checks, implement import, document usage.
2. Run unittest suite and disposable real CLI trials; inspect task diff.
3. Commit import/list slice and stop for user trial before summary.

Status: import/list implemented, verified and same-agent inspected; ready for
local commit and user trial. Summary is not implemented.

Evidence:
- Original import regression failed because the CLI rejected `import` (exit 2).
- `python3 -m unittest discover -v`: all 3 tests passed, including row validation,
  first occurrence retention, existing-item preservation, repeat import, header
  rejection and rollback after malformed CSV syntax.
- Disposable CLI trial: import and repeat import both exited 0, empty stdout,
  stderr explanations; list returned A/First/125 and C/Free/0, no bad B row.
- `git diff --check`: passed.
- Same-agent inspection of catalog.py, tests, README, spec and this record:
  checked transaction rollback, parameterized SQL, integer bounds, unchanged
  schema/list ordering, diagnostics and preservation of unrelated work. No
  unresolved findings. No independent reviewer or specialist examination used.
- Expected and actual: first-row-wins, preserve stored collisions, skip invalid
  rows with successful import and stderr diagnostics; no material departure.

Commit: the local work-unit commit containing this record (see Git history).
Next: stop for the user's import/list trial and next checkpoint before summary.


## Trial repair: chosen identity and file collision

User reported failed identity/file-collision trial on 4393d07. Incoming fields
must be trimmed; SKU comparison remains case-sensitive. Repair only import/list;
leave stored rows and unrelated files untouched.
Plan: reproduce via CLI regression, trim fields before validation/seen lookup,
rerun affected CLI scenarios and suite, inspect diff and locally commit.

Repair evidence and resulting state:
- Focused CLI regression failed before repair: padded Stored did not collide,
  and padded prices failed validation instead of importing the first row.
- Cause: raw CSV fields were used in the seen set and INSERT parameters.
- Fix: trim incoming fields before validation/identity/storage; no case folding
  and no updates to stored rows. This replaces the earlier no-trimming assumption
  with the user's clarified rule; actual behavior matches that expectation.
- `python3 -m unittest discover -v`: 4 tests passed.
- Disposable actual CLI trial and repeat import exited 0 with empty stdout and
  stderr skip explanations. Final list: New/First/20, SKU/Existing/100 and
  new/Case variant/40. Invalid Bad and subsequent duplicate were both skipped.
- Same-agent diff inspection completed: normalization occurs before seen lookup
  and INSERT; existing rows (including stored whitespace in names) are unchanged;
  case variants remain distinct. No unresolved findings; no independent review.
- `git diff --check`: passed. Temporary trial files cleaned automatically.
- Repair commit: the commit containing this update (see Git history).
Status: repair complete, waiting for user trial; summary remains deferred.
