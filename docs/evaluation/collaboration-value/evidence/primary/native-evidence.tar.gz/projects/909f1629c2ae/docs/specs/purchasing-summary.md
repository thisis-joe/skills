# Purchasing summary

`python3 catalog.py --db PATH summary` returns a JSON array of objects with
supplier,count,total_cents, one per nonempty supplier group sorted by supplier.
Empty catalog returns []. Count includes zero-price rows; they add zero to the
total. Suppliers containing only zero-price rows appear. List retains these rows.
Totals are exact integer cents, including totals above SQLite integer range.
Preserve existing import/update/replay rules, stored data and legacy migration.

Acceptance: real CLI tests for empty catalog, multiple sorted suppliers, mixed
and all-zero groups, large totals, legacy data and unchanged list/replay behavior;
run existing unittest suite and same-agent inspection; commit locally, no push.
