import json,subprocess,sys,tempfile,unittest
class Catalog(unittest.TestCase):
 def test_empty_list(self):
  with tempfile.TemporaryDirectory() as d:
   self.assertEqual(json.loads(subprocess.check_output([sys.executable,'catalog.py','--db',d+'/x.sqlite','list'])),[])

class ImportCatalog(unittest.TestCase):
 def run_cli(self, db, *args):
  return subprocess.run([sys.executable, 'catalog.py', '--db', str(db), *map(str,args)], capture_output=True, text=True)

 def test_import_updates_existing_preserves_first_and_skips_bad_rows(self):
  from pathlib import Path
  with tempfile.TemporaryDirectory() as d:
   db=Path(d)/'catalog.sqlite'; csv=Path(d)/'daily.csv'
   csv.write_text('sku,name,price_cents\nold,Stored,50\n', encoding='utf-8')
   self.assertEqual(self.run_cli(db,'import',csv).returncode,0)
   csv.write_text('sku,name,price_cents\nold,Replacement,99\na,First,20\na,Second,30\nb,Bad,no\nb,Later,40\nc,Good,0\n,Missing,2\nd,,3\ne,Negative,-1\nf,Huge,9223372036854775808\ng,Extra,1,x\nh,Missing\ni,"Comma, name",7\n', encoding='utf-8')
   result=self.run_cli(db,'import',csv)
   self.assertEqual(result.returncode,0,result.stderr)
   self.assertEqual(result.stdout,'')
   for line in range(2,15):
    if line not in (2,3,7,14):
     self.assertIn(f'row {line}:',result.stderr)
   expected=[{'sku':'a','name':'First','price_cents':20},{'sku':'c','name':'Good','price_cents':0},{'sku':'i','name':'Comma, name','price_cents':7},{'sku':'old','name':'Replacement','price_cents':99}]
   self.assertEqual(json.loads(self.run_cli(db,'list').stdout),[dict(supplier='legacy', **row) for row in expected])
   self.assertEqual(self.run_cli(db,'import',csv).returncode,0)
   self.assertEqual(json.loads(self.run_cli(db,'list').stdout),[dict(supplier='legacy', **row) for row in expected])

 def test_file_errors_do_not_partially_import(self):
  from pathlib import Path
  with tempfile.TemporaryDirectory() as d:
   db=Path(d)/'catalog.sqlite'; csv=Path(d)/'daily.csv'
   for content in ('wrong,name,price_cents\na,A,1\n','sku,name,price_cents\na,A,1\nb,"unfinished,2\n'):
    csv.write_text(content,encoding='utf-8')
    result=self.run_cli(db,'import',csv)
    self.assertNotEqual(result.returncode,0)
    self.assertTrue(result.stderr)
    self.assertNotIn('invalid choice', result.stderr)
    self.assertIn('catalog:', result.stderr)
    self.assertEqual(json.loads(self.run_cli(db,'list').stdout),[])
   self.assertNotEqual(self.run_cli(db,'import',Path(d)/'missing.csv').returncode,0)

 def test_trimmed_identity_is_case_sensitive_and_first_wins(self):
  import sqlite3
  from pathlib import Path
  with tempfile.TemporaryDirectory() as d:
   db=Path(d)/'catalog.sqlite'; csv=Path(d)/'daily.csv'
   with sqlite3.connect(db) as connection:
    connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
    connection.executemany('INSERT INTO catalog VALUES (?,?,?)', [('Stored','Original',50),('untouched',' Unchanged ',8)])
   csv.write_text('sku,name,price_cents\n Stored ,Replacement,99\n AbC , First , 20 \nAbC,Second,30\nabc, Lowercase ,40\n Bad ,Invalid,no\nBad,Later,6\n', encoding='utf-8')
   result=self.run_cli(db,'import',csv)
   self.assertEqual(result.returncode,0,result.stderr)
   self.assertEqual(result.stdout,'')
   for line in (4,6,7):
    self.assertIn(f'row {line}:',result.stderr)
   expected=[{'sku':'AbC','name':'First','price_cents':20},{'sku':'Stored','name':'Replacement','price_cents':99},{'sku':'abc','name':'Lowercase','price_cents':40},{'sku':'untouched','name':' Unchanged ','price_cents':8}]
   self.assertEqual(json.loads(self.run_cli(db,'list').stdout),[dict(supplier='legacy', **row) for row in expected])
   self.assertEqual(self.run_cli(db,'import',csv).returncode,0)
   self.assertEqual(json.loads(self.run_cli(db,'list').stdout),[dict(supplier='legacy', **row) for row in expected])

 def test_supplier_batches_replay_conflicts_and_migration(self):
  import sqlite3
  from pathlib import Path
  with tempfile.TemporaryDirectory() as d:
   db=Path(d)/'catalog.sqlite'; csv=Path(d)/'daily.csv'
   with sqlite3.connect(db) as c:
    c.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
    c.execute('INSERT INTO catalog VALUES (?,?,?)', ('Old',' Original ',7))
   self.assertEqual(json.loads(self.run_cli(db,'list').stdout),[dict(supplier='legacy',sku='Old',name=' Original ',price_cents=7)])
   first=b'sku,name,price_cents\n X , First , 0 \nX,Duplicate,90\nx,Lower,3\n'
   csv.write_bytes(first)
   r=self.run_cli(db,'import',csv,'--supplier','alpha','--batch-id','one')
   self.assertEqual(r.returncode,0,r.stderr)
   self.assertIn('duplicate',r.stderr)
   csv.write_text('sku,name,price_cents\nX,Newer,22\n')
   self.assertEqual(self.run_cli(db,'import',csv,'--supplier','alpha','--batch-id','two').returncode,0)
   before=self.run_cli(db,'list').stdout
   with sqlite3.connect(db) as c:
    ledger=c.execute('SELECT * FROM successful_batches ORDER BY supplier,batch_id').fetchall()
   r=self.run_cli(db,'import',csv,'--supplier','alpha','--batch-id','one')
   self.assertNotEqual(r.returncode,0)
   self.assertEqual(self.run_cli(db,'list').stdout,before)
   with sqlite3.connect(db) as c:
    self.assertEqual(c.execute('SELECT * FROM successful_batches ORDER BY supplier,batch_id').fetchall(),ledger)
   csv.write_bytes(first.replace(b'\n', b'\r\n'))
   self.assertNotEqual(self.run_cli(db,'import',csv,'--supplier','alpha','--batch-id','one').returncode,0)
   self.assertEqual(self.run_cli(db,'list').stdout,before)
   csv.write_bytes(first)
   self.assertEqual(self.run_cli(db,'import',csv,'--supplier','alpha','--batch-id','one').returncode,0)
   self.assertEqual(self.run_cli(db,'list').stdout,before)
   self.assertEqual(self.run_cli(db,'import',csv,'--supplier','beta','--batch-id','one').returncode,0)
   rows=json.loads(self.run_cli(db,'list').stdout)
   self.assertEqual(rows,[dict(supplier='alpha',sku='X',name='Newer',price_cents=22),dict(supplier='alpha',sku='x',name='Lower',price_cents=3),dict(supplier='beta',sku='X',name='First',price_cents=0),dict(supplier='beta',sku='x',name='Lower',price_cents=3),dict(supplier='legacy',sku='Old',name=' Original ',price_cents=7)])
   csv.write_text('sku,name,price_cents\nX,Partial,9\nY,"broken\n')
   self.assertNotEqual(self.run_cli(db,'import',csv,'--supplier','alpha','--batch-id','failed').returncode,0)
   self.assertEqual(json.loads(self.run_cli(db,'list').stdout),rows)
   csv.write_text('sku,name,price_cents\nX,Recovered,8\n')
   self.assertEqual(self.run_cli(db,'import',csv,'--supplier','alpha','--batch-id','failed').returncode,0)

 def test_failed_import_rolls_back_migration_and_preserves_unrelated_data(self):
  import sqlite3
  from pathlib import Path
  with tempfile.TemporaryDirectory() as d:
   db=Path(d)/'catalog.sqlite'; csv=Path(d)/'daily.csv'
   with sqlite3.connect(db) as c:
    c.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
    c.execute("INSERT INTO catalog VALUES ('old',' Original ',5)")
    c.execute('CREATE TABLE user_notes (note TEXT)')
    c.execute("INSERT INTO user_notes VALUES ('keep me')")
   csv.write_text('sku,name,price_cents\nold,Changed,9\nx,"broken\n')
   self.assertNotEqual(self.run_cli(db,'import',csv,'--batch-id','one').returncode,0)
   with sqlite3.connect(db) as c:
    self.assertEqual([r[1] for r in c.execute('PRAGMA table_info(catalog)')],['sku','name','price_cents'])
    self.assertEqual(c.execute('SELECT * FROM catalog').fetchall(),[('old',' Original ',5)])
    self.assertEqual(c.execute('SELECT * FROM user_notes').fetchall(),[('keep me',)])
    self.assertEqual(c.execute("SELECT name FROM sqlite_master WHERE name='successful_batches'").fetchall(),[])
   self.assertEqual(self.run_cli(db,'list').returncode,0)
   with sqlite3.connect(db) as c:
    self.assertEqual(c.execute('SELECT * FROM catalog').fetchall(),[('legacy','old',' Original ',5)])
    self.assertEqual(c.execute('SELECT * FROM user_notes').fetchall(),[('keep me',)])


class SummaryCatalog(unittest.TestCase):
 run_cli = ImportCatalog.run_cli
 def test_summary_empty_and_grouped_exact_totals(self):
  from pathlib import Path
  with tempfile.TemporaryDirectory() as d:
   db=Path(d)/'catalog.sqlite'; csv=Path(d)/'daily.csv'
   result=self.run_cli(db,'summary')
   self.assertEqual(result.returncode,0,result.stderr)
   self.assertEqual(json.loads(result.stdout),[])
   for supplier, content in [('zeta','a,Free,0\n'),('alpha','a,Free,0\nb,Maximum,9223372036854775807\nc,Extra,5\n'),('legacy','a,Paid,9\n')]:
    csv.write_text('sku,name,price_cents\n'+content,encoding='utf-8')
    result=self.run_cli(db,'import',csv,'--supplier',supplier,'--batch-id','one')
    self.assertEqual(result.returncode,0,result.stderr)
   before=self.run_cli(db,'list').stdout
   result=self.run_cli(db,'summary')
   self.assertEqual(result.returncode,0,result.stderr)
   self.assertEqual(result.stderr,'')
   self.assertEqual(json.loads(result.stdout),[
    dict(supplier='alpha',count=3,total_cents=9223372036854775812),
    dict(supplier='legacy',count=1,total_cents=9),
    dict(supplier='zeta',count=1,total_cents=0)])
   self.assertEqual(self.run_cli(db,'list').stdout,before)
   self.assertEqual(len([r for r in json.loads(before) if r['price_cents']==0]),2)
   self.assertEqual(self.run_cli(db,'import',csv,'--batch-id','one').returncode,0)
   self.assertEqual(self.run_cli(db,'list').stdout,before)

 def test_summary_migrates_legacy_without_changing_values(self):
  import sqlite3
  from pathlib import Path
  with tempfile.TemporaryDirectory() as d:
   db=Path(d)/'catalog.sqlite'
   with sqlite3.connect(db) as c:
    c.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
    c.executemany('INSERT INTO catalog VALUES (?,?,?)',[('free',' Original ',0),('paid','Paid',17)])
   result=self.run_cli(db,'summary')
   self.assertEqual(result.returncode,0,result.stderr)
   self.assertEqual(json.loads(result.stdout),[dict(supplier='legacy',count=2,total_cents=17)])
   self.assertEqual(json.loads(self.run_cli(db,'list').stdout),[
    dict(supplier='legacy',sku='free',name=' Original ',price_cents=0),
    dict(supplier='legacy',sku='paid',name='Paid',price_cents=17)])
