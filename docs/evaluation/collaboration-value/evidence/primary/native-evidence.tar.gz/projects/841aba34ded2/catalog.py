import argparse
import csv
import io
import json
from pathlib import Path
import re
import sqlite3


def sku_key(sku):
    return sku.strip().lower()


def read_items(source_bytes):
    items = {}
    with io.StringIO(source_bytes.decode('utf-8'), newline='') as source:
        reader = csv.reader(source, strict=True)
        if next(reader, None) != ['sku', 'name', 'price_cents']:
            raise ValueError('expected CSV header sku,name,price_cents')
        for row in reader:
            line = reader.line_num
            if len(row) != 3:
                raise ValueError(f'line {line}: expected three columns')
            sku, name, price = row
            sku = sku_key(sku)
            if not sku.strip() or not name.strip():
                raise ValueError(f'line {line}: SKU and name must be nonempty')
            if not re.fullmatch(r'[0-9]+', price):
                raise ValueError(f'line {line}: price must be nonnegative integer cents')
            # Compare normalized digits before conversion, even for very long input.
            digits = price.lstrip('0') or '0'
            if len(digits) > 19 or (len(digits) == 19 and digits > '9223372036854775807'):
                raise ValueError(f'line {line}: price exceeds SQLite integer range')
            items.setdefault(sku, (sku, name, int(digits)))
    return list(items.values())


def ensure_catalog(connection):
    columns = {row[1] for row in connection.execute('PRAGMA table_info(catalog)')}
    if columns == {'supplier', 'sku', 'sku_key', 'name', 'price_cents'}:
        return
    if columns and columns != {'sku', 'name', 'price_cents'}:
        raise ValueError('unsupported catalog schema; no changes applied')

    table = 'catalog_supplier_migration' if columns else 'catalog'
    connection.execute(f'''
        CREATE TABLE {table} (
            supplier TEXT NOT NULL,
            sku TEXT NOT NULL,
            sku_key TEXT NOT NULL,
            name TEXT NOT NULL,
            price_cents INTEGER NOT NULL
                CHECK (typeof(price_cents) = 'integer' AND price_cents >= 0),
            PRIMARY KEY (supplier, sku_key)
        )
    ''')
    if columns:
        try:
            connection.executemany(
                'INSERT INTO catalog_supplier_migration '
                '(supplier,sku,sku_key,name,price_cents) VALUES (?,?,?,?,?)',
                (('legacy', sku, sku_key(sku), name, price)
                 for sku, name, price in connection.execute(
                     'SELECT sku,name,price_cents FROM catalog')))
        except sqlite3.IntegrityError as error:
            raise ValueError(
                'legacy catalog has conflicting SKU identities or invalid prices; '
                'migration cancelled without data loss') from error
        connection.execute('DROP TABLE catalog')
        connection.execute('ALTER TABLE catalog_supplier_migration RENAME TO catalog')


def import_items(connection, supplier, batch_id, source_bytes, items):
    if batch_id is not None:
        previous = connection.execute(
            'SELECT source_bytes FROM successful_batches '
            'WHERE supplier=? AND batch_id=?', (supplier, batch_id)).fetchone()
        if previous is not None:
            if previous[0] != source_bytes:
                raise ValueError('batch ID already used for different source bytes '
                                 'within this supplier')
            return

    connection.executemany(
        'INSERT INTO catalog (supplier,sku,sku_key,name,price_cents) '
        'VALUES (?,?,?,?,?) ON CONFLICT(supplier,sku_key) DO UPDATE '
        'SET name=excluded.name, price_cents=excluded.price_cents',
        ((supplier, sku, sku, name, price) for sku, name, price in items))
    if batch_id is not None:
        connection.execute(
            'INSERT INTO successful_batches (supplier,batch_id,source_bytes) '
            'VALUES (?,?,?)', (supplier, batch_id, source_bytes))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    commands.add_parser('summary')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    importer.add_argument('--supplier', default='legacy')
    importer.add_argument('--batch-id')
    args = parser.parse_args()
    try:
        # Validate the entire source before opening or modifying the database.
        if args.command == 'import':
            source_bytes = Path(args.path).read_bytes()
            items = read_items(source_bytes)
        connection = sqlite3.connect(args.db)
        try:
            with connection:
                # Migration and item changes are one atomic operation.
                connection.execute('BEGIN IMMEDIATE')
                ensure_catalog(connection)
                connection.execute('''
                    CREATE TABLE IF NOT EXISTS successful_batches (
                        supplier TEXT NOT NULL,
                        batch_id TEXT NOT NULL,
                        source_bytes BLOB NOT NULL,
                        PRIMARY KEY (supplier, batch_id)
                    )
                ''')
                if args.command == 'import':
                    import_items(connection, args.supplier, args.batch_id,
                                 source_bytes, items)
                elif args.command == 'summary':
                    groups = {}
                    # Python integers keep totals exact beyond SQLite's SUM range.
                    for supplier, price in connection.execute(
                            'SELECT supplier,price_cents FROM catalog ORDER BY supplier'):
                        group = groups.setdefault(supplier, dict(
                            supplier=supplier, count=0, total_cents=0))
                        group['count'] += 1
                        group['total_cents'] += price
                    print(json.dumps(list(groups.values())))
                else:
                    print(json.dumps([
                        dict(supplier=supplier, sku=sku, name=name, price_cents=price)
                        for supplier, sku, name, price in connection.execute(
                            'SELECT supplier,sku,name,price_cents FROM catalog '
                            'ORDER BY supplier,sku')]))
        finally:
            connection.close()
    except (OSError, UnicodeError, csv.Error, ValueError, sqlite3.Error) as error:
        parser.exit(1, f'catalog: {error}\n')


if __name__ == '__main__':
    main()
