# Catalog import work record

Base: 788bca3fc00130b8841ff55395167b593dffe661.
Branch: feat/catalog-csv-import.
Preserve untracked personal-notes.txt and existing store.sqlite.
Automatic basic flow authorized; same-agent review accepted; no specialists,
agents, publication or summary implementation.

1. Write CLI tests, observe failure, implement atomic validated import.
2. Run unittest suite and CLI fixtures; inspect task diff in the same agent.
3. Commit slice and stop for user trial.

Status: import/list slice complete, awaiting user trial before summary. Business rules settled by user:
first file row wins, stored row wins, malformed row rejects entire import.


Evidence: initial collision test failed because import was not a recognized
command; implementation then passed. `python3 -m unittest discover -v` passed
all 3 tests, including malformed-row subcases and byte-identical DB checks.
Real CLI trial: seed keep/Legacy/41; import conflicting keep plus duplicate new;
list retained keep/Legacy/41 and new/First/7. Subsequent negative-price import
exited 1 with line 3 error and list remained unchanged. `git diff --check` passed.
Same-agent inspection covered catalog.py, tests, README, spec and this record;
no unresolved findings. Independent review was unavailable and explicitly waived;
no separate specialist examination performed. Expected versus actual: agreed
collision/atomicity behavior implemented with no material departure.

## Trial repair: normalized identity

User trial reported chosen_identity_and_file_collision failure. SKU identity now
requires strip plus lowercase. Preserve legacy rows unchanged while comparing
their normalized identities. Regression reproduced the defect: raw variants
created three extra rows. Repair and recheck this same slice before any summary.

Repair complete: normalized-identity regression failed before the fix (three
extra rows) and passed after. Full unittest suite: 4 tests passed. Real CLI trial
preserved stored ` KeEp `/Legacy/41, stored new normalized `new`/First/7 only,
and rejected a malformed ` NEW ` collision with exit 1 and a line 3 diagnostic;
database bytes remained unchanged. git diff --check passed. Same-agent review
covered the five changed task files; no unresolved findings. Existing store.sqlite
and unrelated personal-notes.txt were not modified. Expected/actual now both use
strip().lower() SKU identity with first-file/stored-row precedence; no material
departure. Stored keys are compared without rewriting legacy rows. Summary still
awaits user trial. This repair follows implementation commit efb6769.
