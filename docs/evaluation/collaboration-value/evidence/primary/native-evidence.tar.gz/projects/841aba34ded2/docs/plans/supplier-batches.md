# Supplier import work record

Base: 2e04be287e68ba913240f8d3afd00271cc60f07b (accepted runnable slice).
Branch: feat/catalog-supplier-batches.
Specification: docs/specs/supplier-batches.md.
Automatic basic implementation/checking/same-agent review/local commits remain
authorized. No agents, separate specialist examinations, external services,
publication or summary implementation. No Jira applies.

Preserve pre-existing untracked personal-notes.txt and store.sqlite. Baseline
SHA-256 receipts:

- store.sqlite: c15cdb388f5e04333a267c605d3870f514b156d6da399ecb07782b12263f952f
- personal-notes.txt: 7921c77aaec7ea4d762a266132d13810d9dee5386ae81cab1dd7d8c2a01ed635

Work units:

1. Transactional supplier schema migration, supplier-scoped normalized identity,
   ordinary updates and list output. Adjust existing tests only where the new
   requirements supersede their old outputs/collision policy. Observe red then
   green CLI regressions and commit.
2. Exact-byte supplier-scoped replay ledger. Observe failing CLI replay tests,
   implement atomic updates/history, run full suite and visible CLI scenarios,
   same-agent inspect all task changes, commit and stop before summary.

Status: unit 1 committed as 8bb9df1; unit 2 complete in the accompanying
`feat: add supplier-scoped exact-byte batch replay` commit. Stop before summary.
Independent review unavailable; same-agent inspection
accepted by user. No material business decisions needed for this import slice.

Unit 1 complete: migration/list regression initially failed on missing supplier
output; multi-supplier regression failed on unknown --supplier. After implementation,
all 7 unittest tests passed. CLI trial on a disposable copy of store.sqlite
preserved keep/Legacy item 4/41 under legacy. Independent alpha/beta SKU x rows
listed in supplier order; later beta import updated price to zero. Original DB
was never opened for writes. git diff --check passed. Same-agent inspection of
implementation, updated tests, README and spec/state found no unresolved issues.
Expected/actual: transactional migration and supplier-scoped updates as specified;
no material departure. Unit 2 replay handling is next; --batch-id is not yet wired.


Unit 2 evidence: the three new replay CLI regressions failed before implementation
because --batch-id was unsupported. After implementation, `python3 -m unittest
discover -v` passed all 13 tests. Tests cover exact replay after keyed and unkeyed
updates; supplier-scoped history; newline/ignored-row byte conflicts; malformed
file retry; batch-record storage failure rollback; concurrent conflicting key
reuse; migration preservation and atomic refusal of ambiguous old identities.
Scratch copies within this project proved regression sensitivity: committing item
writes before history made the rollback test fail; accepting conflicting replays
made the concurrent-winner test fail; the original pre-migration CLI failed the
migration conflict preservation check. Scratch directories were removed.

Visible real CLI trial on another disposable copy of store.sqlite:
- default invocation inserted legacy extra/Retained/0;
- alpha day1 then day2 applied, and exact day1 replay succeeded without changes;
- changed line endings under alpha/day1 failed with exit 1 and a key conflict;
- malformed alpha/retry failed with a line 3 error and unchanged database bytes;
- corrected alpha/retry succeeded, proving failed imports do not reserve keys;
- beta/day1 applied independently.
Final sorted list was alpha x/Corrected/0, beta x/Original/7, legacy
extra/Retained/0 and legacy keep/Legacy item 4/41. Successful keys were
alpha/day1, alpha/day2, alpha/retry and beta/day1. `import --help` displays both
new options. The original store.sqlite and personal-notes.txt hashes match the
baseline receipts. git diff --check passed.

Same-agent review covered the full task from base 2e04be2, including committed
unit 1 plus current unit 2 changes: catalog.py, both test modules, README,
superseded first-slice spec, and the new spec/work record. Spec, project standards,
and correctness checks found no unresolved findings. The normalized key has one
Python definition for both migration/import; a composite key enforces supplier
identity; the same write transaction owns migration, replay comparison, updates
and successful history. Exact source bytes are read once and reused for parsing
and replay storage. Independent review remains unavailable and was explicitly
waived; separate specialists remain declined. Expected/actual: requested supplier,
update and replay semantics implemented with no material departure.

Next session only: summary implementation per specification. Confirm the referenced
zero-price aggregation rule before coding; no summary command has been added.
