import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest


class SupplierImports(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.root = Path(directory.name)
        self.db = self.root / 'catalog.sqlite'
        self.source = self.root / 'daily.csv'

    def cli(self, *arguments):
        return subprocess.run(
            [sys.executable, str(Path(__file__).with_name('catalog.py')),
             '--db', str(self.db), *arguments],
            capture_output=True, text=True)

    def load(self, source, *options):
        self.source.write_bytes(source)
        return self.cli('import', str(self.source), *options)

    def items(self):
        result = self.cli('list')
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def assert_success(self, result):
        self.assertEqual(result.returncode, 0, result.stderr)

    def seed_legacy(self):
        with sqlite3.connect(self.db) as connection:
            connection.execute(
                'CREATE TABLE catalog (sku TEXT PRIMARY KEY, '
                'name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
            connection.executemany('INSERT INTO catalog VALUES (?,?,?)', [
                (' KeEp ', 'Legacy name', 41), ('z', 'Zero', 0)])
            connection.execute('CREATE TABLE notes (body TEXT)')
            connection.execute("INSERT INTO notes VALUES ('unrelated')")

    def test_list_migrates_legacy_without_data_loss(self):
        self.seed_legacy()
        expected = [
            dict(supplier='legacy', sku=' KeEp ', name='Legacy name', price_cents=41),
            dict(supplier='legacy', sku='z', name='Zero', price_cents=0)]
        self.assertEqual(self.items(), expected)
        self.assertEqual(self.items(), expected)
        with sqlite3.connect(self.db) as connection:
            self.assertEqual(connection.execute('SELECT * FROM notes').fetchall(),
                             [('unrelated',)])

    def test_supplier_identity_updates_duplicates_and_order(self):
        self.seed_legacy()
        self.assert_success(self.load(
            b'sku,name,price_cents\n KEEP ,Updated legacy,0\n'))
        self.assert_success(self.load(
            b'sku,name,price_cents\n Z ,First,7\nz,Ignored,99\na,Alpha,1\n',
            '--supplier', 'beta'))
        self.assert_success(self.load(
            b'sku,name,price_cents\nz,Other supplier,2\n', '--supplier', 'alpha'))
        self.assert_success(self.load(
            b'sku,name,price_cents\n Z ,New price,3\nz,Still ignored,5\n',
            '--supplier', 'beta'))
        self.assertEqual(self.items(), [
            dict(supplier='alpha', sku='z', name='Other supplier', price_cents=2),
            dict(supplier='beta', sku='a', name='Alpha', price_cents=1),
            dict(supplier='beta', sku='z', name='New price', price_cents=3),
            dict(supplier='legacy', sku=' KeEp ', name='Updated legacy', price_cents=0),
            dict(supplier='legacy', sku='z', name='Zero', price_cents=0)])

    def test_malformed_source_does_not_migrate_or_change_legacy(self):
        self.seed_legacy()
        before = self.db.read_bytes()
        result = self.load(b'sku,name,price_cents\na,Valid,1\na,Invalid,-2\n')
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(self.db.read_bytes(), before)

    def test_replay_after_newer_updates_and_supplier_scoped_keys(self):
        original = b'sku,name,price_cents\n X ,Original,7\nx,Ignored,99\n'
        newer = b'sku,name,price_cents\nx,Newer,11\n'
        self.assert_success(self.load(original, '--supplier', 'alpha', '--batch-id', 'day1'))
        self.assert_success(self.load(newer, '--supplier', 'alpha', '--batch-id', 'day2'))
        before = self.db.read_bytes()
        self.assert_success(self.load(original, '--supplier', 'alpha', '--batch-id', 'day1'))
        self.assertEqual(self.db.read_bytes(), before)
        self.assertEqual(self.items(), [
            dict(supplier='alpha', sku='x', name='Newer', price_cents=11)])

        # Unkeyed imports always apply, even when the same source was keyed before.
        self.assert_success(self.load(original, '--supplier', 'alpha'))
        self.assert_success(self.load(newer, '--supplier', 'alpha'))
        before = self.db.read_bytes()
        self.assert_success(self.load(original, '--supplier', 'alpha', '--batch-id', 'day1'))
        self.assertEqual(self.db.read_bytes(), before)

        self.assert_success(self.load(newer, '--supplier', 'beta', '--batch-id', 'day1'))
        self.assert_success(self.load(original, '--batch-id', 'day1'))
        with sqlite3.connect(self.db) as connection:
            self.assertEqual(connection.execute(
                'SELECT supplier,batch_id,source_bytes FROM successful_batches '
                'ORDER BY supplier,batch_id').fetchall(), [
                    ('alpha', 'day1', original), ('alpha', 'day2', newer),
                    ('beta', 'day1', newer), ('legacy', 'day1', original)])

    def test_reused_key_requires_exact_bytes(self):
        original = b'sku,name,price_cents\nx,First,7\n X ,Ignored,9\n'
        self.assert_success(self.load(original, '--supplier', 'alpha', '--batch-id', 'one'))
        before = self.db.read_bytes()
        for different in [
                original.replace(b'\n', b'\r\n'),
                original.replace(b'Ignored,9', b'Ignored,10'),
                b'sku,name,price_cents\nx,Changed,8\n',
                b'sku,name,price_cents\nx,Malformed,-1\n']:
            with self.subTest(source=different):
                result = self.load(different, '--supplier', 'alpha', '--batch-id', 'one')
                self.assertNotEqual(result.returncode, 0)
                self.assertTrue(result.stderr)
                self.assertEqual(self.db.read_bytes(), before)
        self.assert_success(self.load(original, '--supplier', 'alpha', '--batch-id', 'one'))
        self.assertEqual(self.db.read_bytes(), before)

    def test_malformed_batch_does_not_reserve_key(self):
        self.assert_success(self.load(b'sku,name,price_cents\nx,Stored,7\n'))
        before = self.db.read_bytes()
        result = self.load(b'sku,name,price_cents\nx,Valid,8\n X ,Invalid,-1\n',
                           '--batch-id', 'retry')
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(self.db.read_bytes(), before)
        self.assert_success(self.load(b'sku,name,price_cents\nx,Corrected,0\n',
                                      '--batch-id', 'retry'))
        self.assertEqual(self.items(), [
            dict(supplier='legacy', sku='x', name='Corrected', price_cents=0)])

    def test_batch_record_failure_rolls_back_all_item_writes(self):
        self.assert_success(self.load(b'sku,name,price_cents\nx,Stored,7\n',
                                      '--batch-id', 'seed'))
        with sqlite3.connect(self.db) as connection:
            connection.execute('''
                CREATE TRIGGER reject_batch BEFORE INSERT ON successful_batches
                WHEN NEW.batch_id = 'retry'
                BEGIN SELECT RAISE(ABORT, 'fixture batch storage failure'); END
            ''')
        before = self.db.read_bytes()
        source = b'sku,name,price_cents\nx,Updated,8\ny,Inserted,9\n'
        result = self.load(source, '--batch-id', 'retry')
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('fixture batch storage failure', result.stderr)
        self.assertEqual(self.db.read_bytes(), before)
        self.assertEqual(self.items(), [
            dict(supplier='legacy', sku='x', name='Stored', price_cents=7)])
        with sqlite3.connect(self.db) as connection:
            self.assertEqual(connection.execute(
                'SELECT batch_id FROM successful_batches').fetchall(), [('seed',)])
            connection.execute('DROP TRIGGER reject_batch')
        self.assert_success(self.load(source, '--batch-id', 'retry'))
        self.assertEqual(self.items(), [
            dict(supplier='legacy', sku='x', name='Updated', price_cents=8),
            dict(supplier='legacy', sku='y', name='Inserted', price_cents=9)])

    def test_migration_conflict_rolls_back_without_discarding_legacy_rows(self):
        self.seed_legacy()
        with sqlite3.connect(self.db) as connection:
            connection.execute('INSERT INTO catalog VALUES (?,?,?)',
                               ('KEEP', 'Another legacy row', 8))
        before = self.db.read_bytes()
        result = self.cli('list')
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('migration cancelled without data loss', result.stderr)
        self.assertEqual(self.db.read_bytes(), before)
        with sqlite3.connect(self.db) as connection:
            self.assertEqual(connection.execute(
                "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
            ).fetchall(), [('catalog',), ('notes',)])

    def test_concurrent_key_reuse_has_one_atomic_winner(self):
        sources = [b'sku,name,price_cents\nx,First,1\n',
                   b'sku,name,price_cents\nx,Second,2\n']
        processes = []
        for index, source in enumerate(sources):
            path = self.root / f'batch{index}.csv'
            path.write_bytes(source)
            process = subprocess.Popen(
                [sys.executable, str(Path(__file__).with_name('catalog.py')),
                 '--db', str(self.db), 'import', str(path),
                 '--supplier', 'alpha', '--batch-id', 'shared'],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            self.addCleanup(lambda process=process: process.wait(timeout=10))
            processes.append(process)
        results = [process.communicate(timeout=10) for process in processes]
        self.assertEqual(sorted(process.returncode for process in processes), [0, 1], results)
        winner = next(i for i, process in enumerate(processes) if process.returncode == 0)
        self.assertEqual(self.items(), [dict(
            supplier='alpha', sku='x', name=['First', 'Second'][winner],
            price_cents=winner + 1)])
        with sqlite3.connect(self.db) as connection:
            self.assertEqual(connection.execute(
                'SELECT supplier,batch_id,source_bytes FROM successful_batches'
            ).fetchall(), [('alpha', 'shared', sources[winner])])
