# Supplier import and replay storage

This specification supersedes catalog-import.md for import/storage/list behavior.
Import/storage/list behavior remains unchanged by the subsequent summary slice.

`python3 catalog.py --db DB import PATH [--supplier NAME] [--batch-id ID]`
defaults to supplier `legacy` and no replay key. Supplier names and batch IDs
are exact strings; only SKU keys are normalized with `strip().lower()`.
The UTF-8 CSV header, price validation, first normalized SKU occurrence within
a file, and full-file rejection rules remain unchanged. Validate ignored
duplicate rows too. Later ordinary imports update name/price for the same
supplier and normalized SKU. Items absent from a source remain stored.

Automatically migrate the old catalog schema transactionally to supplier
`legacy`, preserving stored SKU spelling, names and prices. Keep the normalized
SKU identity in a separate internal column; new rows store normalized SKU
spelling. Updates preserve the existing stored spelling. An ambiguous old
catalog with multiple rows for one normalized identity must fail migration
atomically with an error instead of choosing a row or discarding data.
List adds supplier and sorts by supplier then stored SKU; an empty list is [].

Successful batch keys are unique within a supplier. Record the exact file bytes,
including encoding/newlines/ignored duplicate rows, alongside the key. An exact
replay succeeds without changing items, even after later imports. Different bytes
with the same key fail without modifying items or successful-batch records.
Suppliers can reuse each other's keys. Without a batch ID, every import applies.
Malformed or failed imports do not reserve a key. Migration, writes and key
recording commit together under a write lock; failed operations roll back.

Acceptance uses real CLI processes and SQLite fixtures: old-schema migration,
default invocation, multi-supplier ordering/identity, normalized file duplicates,
ordinary updates including zero prices, replay after newer updates, byte-exact
conflicts, supplier key isolation, and unchanged data/history on failure.

Summary contract: `python3 catalog.py --db DB summary` returns a JSON array with
one {supplier,count,total_cents} per nonempty supplier group, sorted by supplier;
[] for no groups. Count every stored item, including zero-price rows; those rows
add zero to the total and remain visible in list. Totals are exact integer cents,
including when the sum exceeds SQLite's individual-price integer range. Summary
uses the same automatic transactional legacy migration as list.
