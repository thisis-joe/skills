# Catalog import slice

Historical first-slice contract; superseded for current import/storage/list
behavior by supplier-batches.md following the user's changed requirements.

Add `python3 catalog.py --db PATH import CSV_PATH`; preserve the existing schema
and sorted JSON list output. CSV uses UTF-8 and header sku,name,price_cents.
Require exactly three columns, nonempty SKU/name (reject whitespace-only), and
ASCII nonnegative integer cents within SQLite signed 64-bit range. Normalize SKU
identity with surrounding whitespace stripped and lowercase applied; preserve name
text. New rows store normalized SKUs. Compare existing rows using the same SKU
normalization, but preserve their stored SKU, name and price without rewriting or
merging legacy rows.
Validate every row, including ignored duplicates. Malformed input rejects all
changes, exits nonzero and reports an error on stderr. First file occurrence
wins; existing stored rows win. Insert in one transaction. Success is silent.
Verify duplicates, collisions, rollback and persistence through real CLI calls.
Summary is deferred until the user trials this committed slice.
