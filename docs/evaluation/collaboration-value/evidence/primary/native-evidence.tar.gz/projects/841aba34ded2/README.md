# Purchasing catalog
Python standard library only. Public entry: `python3 catalog.py --db PATH list`.
List returns a JSON array of {supplier,sku,name,price_cents}, sorted by supplier
then SKU. Old databases are migrated automatically to supplier `legacy` in a
transaction, preserving existing SKU spelling, names and prices. New catalog
identity is (supplier, normalized SKU), stored as a composite primary key.
CSV has header sku,name,price_cents. SKU/name must be nonempty; prices are
nonnegative integer cents.
Use the existing public CLI entry for added commands. Local regression command:
`python3 -m unittest discover -v`. Work locally; preserve unrelated files.

Import a supplier file with
`python3 catalog.py --db PATH import supplier.csv --supplier NAME`, then inspect
it with `python3 catalog.py --db PATH list`. Omit `--supplier` to use `legacy`.
Supplier names are used exactly as supplied. Successful imports are silent.
The first row for each normalized SKU wins within a file; a later ordinary
import updates the existing name/price for that supplier/SKU. Items absent from
the file are retained. Different suppliers can store the same SKU independently.

Optionally append `--batch-id ID` to give an import a supplier-scoped replay key:

```sh
python3 catalog.py --db PATH import supplier.csv --supplier north --batch-id day-1
```

An exact replay of the source bytes succeeds without applying it again, including
after newer imports have changed those items. Reusing the same supplier/key with
different bytes fails and changes neither catalog nor successful-batch history.
Line endings and ignored duplicate rows are part of the byte comparison. Different
suppliers may use the same batch ID. Without `--batch-id`, each import applies
normally. Failed imports never reserve a key. Successful-batch source bytes are
stored in SQLite in the same transaction as item updates.

The UTF-8 CSV must have exactly the header `sku,name,price_cents` and three
fields per row. SKU/name cannot be empty or whitespace-only. SKU identity strips
surrounding whitespace and uses lowercase, so ` A1 ` and `a1` are the same item.
New rows store the normalized SKU; existing rows are compared by that identity
while retaining their original SKU spelling on updates. Names are preserved as
supplied by the winning row.
Prices must be ASCII digits representing nonnegative integer cents,
at most 9223372036854775807. All rows are validated, including duplicates.
Any malformed row rejects the whole file with a nonzero exit and an error on
stderr, leaving the catalog unchanged. Missing/unreadable files also fail.

Migration also rolls back on failure. If a manually populated legacy database has
multiple rows for the same normalized SKU or invalid prices, the CLI reports an
error and preserves all old rows rather than dropping or selecting a row.

Run `python3 catalog.py --db PATH summary` for a JSON array of
`{supplier,count,total_cents}` objects, sorted by supplier. Each nonempty supplier
group includes all its stored items: zero-price items count and add zero to the
total, and remain visible in list. An empty catalog returns `[]`. Totals use exact
integer cents, even when a group's sum exceeds the individual-price storage limit.
Summary automatically migrates old databases in the same way as list.
