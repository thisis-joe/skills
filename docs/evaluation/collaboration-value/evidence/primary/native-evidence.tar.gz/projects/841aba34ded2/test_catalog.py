import json,subprocess,sys,tempfile,unittest
class Catalog(unittest.TestCase):
 def test_normalized_identity_and_collisions(self):
  import sqlite3
  from pathlib import Path
  with tempfile.TemporaryDirectory() as d:
   db=Path(d)/'x.sqlite'
   with sqlite3.connect(db) as c:
    c.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
    c.execute('INSERT INTO catalog VALUES (?,?,?)',('  KeEp  ','Legacy',41))
   command=[sys.executable,'catalog.py','--db',str(db)]
   path=Path(d)/'input.csv'
   path.write_text('sku,name,price_cents\n KEEP ,Replacement,99\n New ,First,7\nnew,Second,9\nNEW,Third,11\n')
   result=subprocess.run(command+['import',str(path)],capture_output=True,text=True)
   self.assertEqual(result.returncode,0,result.stderr)
   self.assertEqual(json.loads(subprocess.check_output(command+['list'])),[
    dict(supplier='legacy',sku='  KeEp  ',name='Replacement',price_cents=99),
    dict(supplier='legacy',sku='new',name='First',price_cents=7)])
   before=db.read_bytes()
   path.write_text('sku,name,price_cents\nother,Valid,1\n NEW ,Ignored,nope\n')
   result=subprocess.run(command+['import',str(path)],capture_output=True,text=True)
   self.assertNotEqual(result.returncode,0)
   self.assertEqual(db.read_bytes(),before)
 def test_empty_list(self):
  with tempfile.TemporaryDirectory() as d:
   self.assertEqual(json.loads(subprocess.check_output([sys.executable,'catalog.py','--db',d+'/x.sqlite','list'])),[])
 def test_import_collisions(self):
  from pathlib import Path
  with tempfile.TemporaryDirectory() as d:
   path=Path(d)/'input.csv'
   command=[sys.executable,'catalog.py','--db',d+'/x.sqlite']
   for contents in ['sku,name,price_cents\nb,Stored,41\n', 'sku,name,price_cents\nb,Replacement,99\na,First,0\na,Second,7\n']:
    path.write_text(contents)
    result=subprocess.run(command+['import',str(path)],capture_output=True,text=True)
    self.assertEqual(result.returncode,0,result.stderr)
   self.assertEqual(json.loads(subprocess.check_output(command+['list'])),[
    dict(supplier='legacy',sku='a',name='First',price_cents=0),
    dict(supplier='legacy',sku='b',name='Replacement',price_cents=99)])
 def test_malformed_import_leaves_database_unchanged(self):
  from pathlib import Path
  with tempfile.TemporaryDirectory() as d:
   path=Path(d)/'input.csv'
   db=Path(d)/'x.sqlite'
   command=[sys.executable,'catalog.py','--db',str(db)]
   path.write_text('sku,name,price_cents\nkeep,Legacy,41\n')
   subprocess.run(command+['import',str(path)],check=True)
   before=db.read_bytes()
   bad_rows=['bad,Name,-1', 'bad,Name,1.5', 'bad,Name,nope',
             'bad,Name,9223372036854775808', ',Name,1', 'bad,,1',
             'bad,Name', 'bad,Name,1,extra', 'keep,Ignored,nope',
             'new,Duplicate,nope', '"unterminated,Name,1', 'bad,Name,١']
   for row in bad_rows:
    with self.subTest(row=row):
     path.write_text('sku,name,price_cents\nnew,Valid,7\n'+row+'\n')
     result=subprocess.run(command+['import',str(path)],capture_output=True,text=True)
     self.assertNotEqual(result.returncode,0)
     self.assertTrue(result.stderr)
     self.assertEqual(db.read_bytes(),before)
   for contents in ['', 'wrong,header,columns\na,A,1\n']:
    path.write_text(contents)
    self.assertNotEqual(subprocess.run(command+['import',str(path)],capture_output=True).returncode,0)
    self.assertEqual(db.read_bytes(),before)
   self.assertNotEqual(subprocess.run(command+['import',str(Path(d)/'missing.csv')],capture_output=True).returncode,0)
   self.assertEqual(db.read_bytes(),before)
