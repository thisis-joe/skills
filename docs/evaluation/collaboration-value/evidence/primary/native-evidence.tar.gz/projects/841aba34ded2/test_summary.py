import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest


class PurchasingSummary(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.root = Path(directory.name)
        self.db = self.root / 'catalog.sqlite'

    def cli(self, *arguments):
        result = subprocess.run(
            [sys.executable, str(Path(__file__).with_name('catalog.py')),
             '--db', str(self.db), *arguments], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        return result.stdout

    def test_empty_summary(self):
        self.assertEqual(json.loads(self.cli('summary')), [])

    def test_supplier_counts_zero_rows_updates_and_exact_totals(self):
        source = self.root / 'daily.csv'
        for supplier, contents in [
                ('beta', 'a,First,9223372036854775807\nb,Second,1\n'),
                ('alpha', 'z,Zero,0\nx,Paid,7\n X ,Ignored,99\n'),
                ('only-zero', 'z,Zero,0\n'),
                ('alpha', 'x,Updated,9\n')]:
            source.write_text('sku,name,price_cents\n' + contents)
            self.cli('import', str(source), '--supplier', supplier)
        before = self.db.read_bytes()
        self.assertEqual(json.loads(self.cli('summary')), [
            dict(supplier='alpha', count=2, total_cents=9),
            dict(supplier='beta', count=2, total_cents=9223372036854775808),
            dict(supplier='only-zero', count=1, total_cents=0)])
        self.assertEqual(self.db.read_bytes(), before)
        listed = json.loads(self.cli('list'))
        self.assertEqual(len(listed), 5)
        self.assertEqual(sum(item['price_cents'] == 0 for item in listed), 2)

    def test_summary_migrates_legacy_and_preserves_list(self):
        with sqlite3.connect(self.db) as connection:
            connection.execute('CREATE TABLE catalog '
                               '(sku TEXT PRIMARY KEY, name TEXT, price_cents INTEGER)')
            connection.executemany('INSERT INTO catalog VALUES (?,?,?)', [
                (' Keep ', 'Original', 41), ('z', 'Zero', 0)])
        self.assertEqual(json.loads(self.cli('summary')), [
            dict(supplier='legacy', count=2, total_cents=41)])
        self.assertEqual(json.loads(self.cli('list')), [
            dict(supplier='legacy', sku=' Keep ', name='Original', price_cents=41),
            dict(supplier='legacy', sku='z', name='Zero', price_cents=0)])
