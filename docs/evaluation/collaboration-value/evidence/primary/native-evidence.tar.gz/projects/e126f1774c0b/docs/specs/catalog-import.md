# Catalog import/list slice

Historical first-slice contract. Supplier storage and list shape are superseded
by [catalog-supplier-batches.md](catalog-supplier-batches.md).

Add `python3 catalog.py --db DB import PATH` for CSV with exactly the
sku,name,price_cents columns (column order may vary). SKU and name must contain
non-whitespace text. Trim surrounding SKU whitespace and lowercase SKU keys;
preserve name text. All case/whitespace variants share one identity. Imported
keys replace matching legacy stored variants atomically; unrelated stored keys
are preserved exactly. Price must contain ASCII decimal
digits representing nonnegative integer cents within SQLite's signed integer
range. Reject invalid headers, missing/extra fields, malformed CSV and invalid
rows with a nonzero exit and diagnostic. Validate every row before writing;
any failure leaves stored catalog items unchanged. Last row wins for duplicate
SKUs; later imports update stored rows. Preserve other stored items and the
existing sorted JSON list interface. Successful import exits zero without output.

Summary is deferred until the user tries this committed runnable slice and
provides the next checkpoint. No schema changes, external dependencies or push.
