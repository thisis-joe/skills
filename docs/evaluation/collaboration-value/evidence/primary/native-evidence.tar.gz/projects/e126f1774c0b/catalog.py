import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
import sqlite3


def read_import(path):
    """Validate the entire file before opening the catalog for writes."""
    items = {}
    source_bytes = Path(path).read_bytes()
    with io.StringIO(source_bytes.decode('utf-8'), newline='') as source:
        reader = csv.reader(source, strict=True)
        header = next(reader, None)
        if header is None or sorted(header) != ['name', 'price_cents', 'sku']:
            raise ValueError('CSV header must contain exactly sku,name,price_cents')
        for row in reader:
            line = reader.line_num
            if len(row) != 3:
                raise ValueError(f'line {line}: expected three fields')
            item = dict(zip(header, row))
            price = item['price_cents']
            if not item['sku'].strip() or not item['name'].strip():
                raise ValueError(f'line {line}: sku and name must be nonempty')
            # Compare normalized digits before conversion to handle huge input safely.
            if not price or any(c not in '0123456789' for c in price):
                raise ValueError(f'line {line}: price_cents must be nonnegative integer cents')
            digits = price.lstrip('0') or '0'
            if len(digits) > 19 or (len(digits) == 19 and digits > '9223372036854775807'):
                raise ValueError(f'line {line}: price_cents exceeds SQLite integer range')
            sku = item['sku'].strip().lower()
            items[sku] = (sku, item['name'], int(digits))
    return list(items.values()), hashlib.sha256(source_bytes).hexdigest()

def ensure_schema(connection):
    columns = [row[1] for row in connection.execute('PRAGMA table_info(catalog)')]
    if columns and 'supplier' not in columns:
        if columns != ['sku', 'name', 'price_cents']:
            raise ValueError('unsupported catalog schema')
        # Keep all old rows verbatim. Only subsequent imports consolidate aliases.
        schema_objects = [row[0] for row in connection.execute(
            "SELECT sql FROM sqlite_master WHERE tbl_name='catalog' "
            "AND type IN ('index','trigger') AND sql IS NOT NULL")]
        connection.execute(
            'CREATE TABLE catalog_supplier_migration ('
            'supplier TEXT NOT NULL, sku TEXT NOT NULL, name TEXT NOT NULL, '
            'price_cents INTEGER NOT NULL, PRIMARY KEY (supplier,sku))')
        connection.execute(
            "INSERT INTO catalog_supplier_migration (supplier,sku,name,price_cents) "
            "SELECT 'legacy',sku,name,price_cents FROM catalog")
        connection.execute('DROP TABLE catalog')
        connection.execute('ALTER TABLE catalog_supplier_migration RENAME TO catalog')
        for sql in schema_objects:
            connection.execute(sql)
    else:
        connection.execute(
            'CREATE TABLE IF NOT EXISTS catalog ('
            'supplier TEXT NOT NULL, sku TEXT NOT NULL, name TEXT NOT NULL, '
            'price_cents INTEGER NOT NULL, PRIMARY KEY (supplier,sku))')
    connection.execute(
        'CREATE TABLE IF NOT EXISTS successful_batches ('
        'supplier TEXT NOT NULL, batch_id TEXT NOT NULL, source_sha256 TEXT NOT NULL, '
        'PRIMARY KEY (supplier,batch_id))')


def apply_import(connection, supplier, batch_id, items, digest):
    if batch_id is not None:
        previous = connection.execute(
            'SELECT source_sha256 FROM successful_batches WHERE supplier=? AND batch_id=?',
            (supplier, batch_id)).fetchone()
        if previous is not None:
            if previous[0] != digest:
                raise ValueError('batch ID already used with different source bytes')
            return
    imported_keys = {item[0] for item in items}
    aliases = [
        (supplier, sku) for (sku,) in connection.execute(
            'SELECT sku FROM catalog WHERE supplier=?', (supplier,))
        if sku.strip().lower() in imported_keys and sku != sku.strip().lower()
    ]
    connection.executemany('DELETE FROM catalog WHERE supplier=? AND sku=?', aliases)
    connection.executemany(
        'INSERT INTO catalog (supplier,sku,name,price_cents) VALUES (?,?,?,?) '
        'ON CONFLICT(supplier,sku) DO UPDATE SET '
        'name=excluded.name, price_cents=excluded.price_cents',
        [(supplier, sku, name, price) for sku, name, price in items])
    if batch_id is not None:
        connection.execute(
            'INSERT INTO successful_batches (supplier,batch_id,source_sha256) VALUES (?,?,?)',
            (supplier, batch_id, digest))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    commands.add_parser('summary')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    importer.add_argument('--supplier', default='legacy')
    importer.add_argument('--batch-id')
    args = parser.parse_args()
    try:
        if args.command == 'import':
            items, digest = read_import(args.path)
        connection = sqlite3.connect(args.db)
        try:
            with connection:
                # Lock before schema checks and replay lookup so concurrent imports
                # cannot race migration or reserve the same supplier/batch key.
                connection.execute('BEGIN IMMEDIATE')
                ensure_schema(connection)
                if args.command == 'import':
                    apply_import(connection, args.supplier, args.batch_id, items, digest)
                elif args.command == 'summary':
                    groups = {}
                    # Python integers keep totals exact beyond SQLite SUM's range.
                    for supplier, price in connection.execute(
                            'SELECT supplier,price_cents FROM catalog '
                            'WHERE price_cents != 0 ORDER BY supplier'):
                        group = groups.setdefault(
                            supplier, dict(supplier=supplier, count=0, total_cents=0))
                        group['count'] += 1
                        group['total_cents'] += price
                    rows = list(groups.values())
                else:
                    rows = [
                        dict(supplier=supplier, sku=sku, name=name, price_cents=price)
                        for supplier, sku, name, price in connection.execute(
                            'SELECT supplier,sku,name,price_cents FROM catalog '
                            'ORDER BY supplier,sku')
                    ]
            if args.command in ('list', 'summary'):
                print(json.dumps(rows))
        finally:
            connection.close()
    except (OSError, UnicodeError, csv.Error, ValueError, sqlite3.Error) as error:
        parser.exit(1, f'catalog: {error}\n')


if __name__ == '__main__':
    main()
