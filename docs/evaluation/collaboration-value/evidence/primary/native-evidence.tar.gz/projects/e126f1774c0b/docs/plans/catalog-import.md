# Catalog import work record

- Scope: docs/specs/catalog-import.md; automatic basic technical progress authorized.
- Branch: feature/catalog-csv-import; base: d45f197.
- Preserve unrelated untracked personal-notes.txt and existing store.sqlite.
- One implementation unit: import validation, transactional upsert, CLI regression
  coverage and usage documentation. Run failing focused test before implementation,
  full unittest suite and real CLI checks using disposable databases.
- Review: same-agent inspection explicitly accepted; no separate specialist review.
- Current stage: implementation; stop after committed import/list for user trial.

## Import/list checkpoint

- Implementation commit: 2310e17.
- Expected/actual: last duplicate wins, later files update stored rows, invalid
  files leave all stored items unchanged; no material departure.
- Evidence: initial import CLI regression failed because import was not a valid
  command; after implementation `python3 -m unittest discover -v` passed all
  four tests. Coverage includes stored-row preservation, invalid duplicate rows,
  malformed CSV/header/prices, missing files and transactional write rollback.
- Separate real CLI trial on a temporary database: duplicate A yielded Last/20
  alongside B/5; subsequent invalid file exited 1 with line 3 diagnostic and
  list output remained identical. Existing project database was not opened.
- Same-agent review of d45f197..2310e17 and all five task paths: acceptance,
  project standards and correctness/risk passed, no findings. Independence is
  unavailable and was explicitly waived for this project. No specialist review.
- `git diff --check` passed. Only pre-existing personal-notes.txt is untracked.
- Current stage: import/list complete, awaiting user trial and next checkpoint.
  Summary unimplemented; nothing pushed or published.

## Trial repair: normalized SKU identity

- User trial exposed raw-key identity and file collisions. Updated contract:
  trim/lowercase imported SKUs before duplicate resolution and stored matching.
- Preserve unrelated stored keys exactly; consolidate only imported identities.
- Plan: reproduce collision through CLI, fix normalization and atomic legacy
  matching, rerun suite and real CLI trial, same-agent review and local commit.
- Current stage: repair implementation; summary remains deferred.

### Repair checkpoint

- Repair commit: 31276a1; cause was raw CSV SKU used for dictionary and SQL keys.
- Red signal: new normalized-identity CLI test returned five rows instead of two
  before repair. After repair full unittest discovery passed all five tests.
- Actual CLI trial (temporary DB): legacy ` ABC ` plus incoming ` ABC `/First/10
  and `abc`/Last/20 became `abc`/Last/20; subsequent ` AbC `/Later/30 updated
  that item. Unrelated `Keep ` remained exact. Invalid earlier duplicate exited
  1 with line 2 diagnostic and list output stayed identical.
- Rollback regression also confirms removed legacy aliases are restored if a
  later database write fails. Project store.sqlite was not opened or modified.
- Same-agent review of ea131a0..31276a1, five task paths: acceptance, standards,
  correctness/risk passed with no findings; no independent/specialist review.
  Explicit transaction covers alias deletion and upserts; validation still
  precedes all writes. Diff whitespace check passed.
- Expected/actual: normalized identity, last row wins, later update and atomic
  rejection match the clarified contract. No material departure.
- Current stage: repaired import/list ready for user trial; summary deferred.
  Nothing published; unrelated personal-notes.txt remains untracked.
