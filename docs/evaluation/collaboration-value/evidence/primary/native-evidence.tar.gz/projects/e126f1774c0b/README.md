# Purchasing catalog

Python standard library only. Public CLI:

```sh
python3 catalog.py --db PATH list
python3 catalog.py --db PATH summary
python3 catalog.py --db PATH import items.csv
python3 catalog.py --db PATH import items.csv --supplier acme --batch-id daily-001
```

`list` returns a JSON array of `{supplier,sku,name,price_cents}`, sorted by
supplier then SKU. An original three-column catalog is migrated automatically
and transactionally to supplier `legacy`, preserving stored rows and values.
The catalog now uses `(supplier, sku)` as its primary key.

Import accepts optional `--supplier NAME` (default `legacy`) and `--batch-id ID`
(default absent). Supplier names and batch IDs are literal identifiers; only SKU
keys are trimmed and lowercased. The CSV header must contain exactly
`sku,name,price_cents` in any column order. SKU/name must contain non-whitespace
text; name text is preserved. Prices use ASCII digits only, from 0 through
9223372036854775807 cents, including zero.

Item identity is supplier plus normalized SKU. Within a file the last duplicate
row wins; later ordinary imports update that supplier's stored items. Matching
legacy raw SKU variants consolidate when imported. Other suppliers and unrelated
items remain unchanged. Every row is validated, including overwritten duplicates.
Any malformed row or write failure rejects the whole import without partial
item changes. Errors go to stderr with a nonzero exit; success exits zero silently.

A batch ID records a successful import's exact source-byte fingerprint for that
supplier. Repeating those bytes with that supplier/batch ID succeeds without
reapplying them, even after newer imports. Different bytes with the same key fail
without changing catalog items or successful-batch records. Different suppliers
can use the same batch ID independently. Without a batch ID, imports always apply.
Migration, item changes and successful-batch recording commit together. Failed
imports do not reserve batch IDs. File paths are not part of the replay identity.

Local regression command: `python3 -m unittest discover -v`.
Work locally and preserve unrelated files.

`summary` returns a JSON array of `{supplier,count,total_cents}`, sorted by
supplier. Zero-price rows are excluded from both count and total; suppliers
with only zero-price rows are omitted. An empty summary is `[]`. `list` retains
zero-price rows. Totals are exact integer cents, including sums beyond SQLite's
per-item integer limit. See [the supplier spec](docs/specs/catalog-supplier-batches.md).
