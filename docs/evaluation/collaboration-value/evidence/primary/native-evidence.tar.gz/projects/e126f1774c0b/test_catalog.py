import json
from pathlib import Path
import subprocess
import sqlite3
import sys
import tempfile
import unittest


class Catalog(unittest.TestCase):
    def run_cli(self, db, *args):
        return subprocess.run(
            [sys.executable, 'catalog.py', '--db', str(db), *map(str, args)],
            capture_output=True, text=True,
        )

    def test_empty_list(self):
        with tempfile.TemporaryDirectory() as d:
            result = self.run_cli(Path(d) / 'x.sqlite', 'list')
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stdout), [])

    def test_import_last_row_updates_and_preserves_other_items(self):
        with tempfile.TemporaryDirectory() as d:
            db = Path(d) / 'x.sqlite'
            source = Path(d) / 'items.csv'
            source.write_text('sku,name,price_cents\nA,Old,10\nB,Keep,20\n')
            result = self.run_cli(db, 'import', source)
            self.assertEqual(result.returncode, 0, result.stderr)
            source.write_text('sku,name,price_cents\nA,First,30\nA,"Last, name",40\n')
            result = self.run_cli(db, 'import', source)
            self.assertEqual(result.returncode, 0, result.stderr)
            result = self.run_cli(db, 'list')
            self.assertEqual(json.loads(result.stdout), [
                {'supplier': 'legacy', 'sku': 'a', 'name': 'Last, name', 'price_cents': 40},
                {'supplier': 'legacy', 'sku': 'b', 'name': 'Keep', 'price_cents': 20},
            ])

    def test_invalid_file_preserves_catalog(self):
        invalid_files = [
            'sku,name,price_cents\nA,Changed,99\nB,Bad,-1\n',
            'sku,name,price_cents\nA,Bad,nope\nA,Valid,1\n',
            'sku,name,price_cents\nA,Bad,1.2\n',
            'sku,name,price_cents\nA,Bad,9223372036854775808\n',
            'sku,name,price_cents\nA,Bad,１２\n',
            'sku,name,price_cents\n ,Bad,1\n',
            'sku,name,price_cents\nA, ,1\n',
            'sku,name,price_cents\nA,Bad\n',
            'sku,name,price_cents\nA,Bad,1,extra\n',
            'sku,name,price_cents\nA,"unterminated,1\n',
            'sku,name,name\nA,Bad,1\n',
            '',
        ]
        with tempfile.TemporaryDirectory() as d:
            db = Path(d) / 'x.sqlite'
            source = Path(d) / 'items.csv'
            source.write_text('sku,name,price_cents\nA,Original,5\n')
            self.assertEqual(self.run_cli(db, 'import', source).returncode, 0)
            before = self.run_cli(db, 'list').stdout
            for content in invalid_files:
                with self.subTest(content=content):
                    source.write_text(content)
                    result = self.run_cli(db, 'import', source)
                    self.assertNotEqual(result.returncode, 0)
                    self.assertTrue(result.stderr)
                    self.assertEqual(self.run_cli(db, 'list').stdout, before)
            result = self.run_cli(db, 'import', Path(d) / 'missing.csv')
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(self.run_cli(db, 'list').stdout, before)

    def test_database_failure_rolls_back_updates(self):
        with tempfile.TemporaryDirectory() as d:
            db = Path(d) / 'x.sqlite'
            source = Path(d) / 'items.csv'
            source.write_text('sku,name,price_cents\nA,Original,5\n')
            self.assertEqual(self.run_cli(db, 'import', source).returncode, 0)
            with sqlite3.connect(db) as connection:
                connection.execute("INSERT INTO catalog (sku,name,price_cents,supplier) VALUES (?,?,?,'legacy')",
                                   (' A ', 'Legacy alias', 2))
                connection.execute("CREATE TRIGGER reject_b BEFORE INSERT ON catalog "
                                   "WHEN NEW.sku = 'b' BEGIN "
                                   "SELECT RAISE(ABORT, 'blocked'); END")
            source.write_text('sku,name,price_cents\nA,Changed,10\nB,Blocked,20\n')
            result = self.run_cli(db, 'import', source, '--batch-id', 'retry')
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(json.loads(self.run_cli(db, 'list').stdout), [
                {'supplier': 'legacy', 'sku': ' A ', 'name': 'Legacy alias', 'price_cents': 2},
                {'supplier': 'legacy', 'sku': 'a', 'name': 'Original', 'price_cents': 5},
            ])
            with sqlite3.connect(db) as connection:
                self.assertEqual(connection.execute('SELECT * FROM successful_batches').fetchall(), [])
                connection.execute('DROP TRIGGER reject_b')
            source.write_text('sku,name,price_cents\nA,Retry,0\n')
            result = self.run_cli(db, 'import', source, '--batch-id', 'retry')
            self.assertEqual(result.returncode, 0, result.stderr)

    def test_normalized_identity_collisions_and_later_import(self):
        with tempfile.TemporaryDirectory() as d:
            db = Path(d) / 'x.sqlite'
            source = Path(d) / 'items.csv'
            self.assertEqual(self.run_cli(db, 'list').returncode, 0)
            with sqlite3.connect(db) as connection:
                connection.executemany("INSERT INTO catalog (sku,name,price_cents,supplier) VALUES (?,?,?,'legacy')", [
                    (' AbC ', 'Legacy', 3), ('ABC', 'Alias', 4),
                    (' Unrelated ', 'Keep exactly', 7),
                ])
            source.write_text('sku,name,price_cents\n ABC ,First,10\nabc,Last,20\n')
            result = self.run_cli(db, 'import', source)
            self.assertEqual(result.returncode, 0, result.stderr)
            expected = [
                {'supplier': 'legacy', 'sku': ' Unrelated ', 'name': 'Keep exactly', 'price_cents': 7},
                {'supplier': 'legacy', 'sku': 'abc', 'name': 'Last', 'price_cents': 20},
            ]
            self.assertEqual(json.loads(self.run_cli(db, 'list').stdout), expected)
            source.write_text('sku,name,price_cents\n AbC ,Later,30\n')
            self.assertEqual(self.run_cli(db, 'import', source).returncode, 0)
            expected[1].update(name='Later', price_cents=30)
            self.assertEqual(json.loads(self.run_cli(db, 'list').stdout), expected)
            source.write_text('sku,name,price_cents\n ABC ,Bad,nope\nabc,Valid,1\n')
            self.assertNotEqual(self.run_cli(db, 'import', source).returncode, 0)
            self.assertEqual(json.loads(self.run_cli(db, 'list').stdout), expected)


    def test_migrate_original_rows_to_legacy_without_loss(self):
        with tempfile.TemporaryDirectory() as d:
            db = Path(d) / 'x.sqlite'
            with sqlite3.connect(db) as connection:
                connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, '
                                   'name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
                connection.executemany('INSERT INTO catalog VALUES (?,?,?)', [
                    ('a', 'Zero', 0), (' A ', 'Raw legacy', 9223372036854775807),
                ])
            result = self.run_cli(db, 'list')
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stdout), [
                {'supplier': 'legacy', 'sku': ' A ', 'name': 'Raw legacy',
                 'price_cents': 9223372036854775807},
                {'supplier': 'legacy', 'sku': 'a', 'name': 'Zero', 'price_cents': 0},
            ])
            self.assertEqual(self.run_cli(db, 'list').stdout, result.stdout)
            source = Path(d) / 'items.csv'
            source.write_text('sku,name,price_cents\n A ,Other supplier,6\n')
            imported = self.run_cli(db, 'import', source, '--supplier', 'other')
            self.assertEqual(imported.returncode, 0, imported.stderr)
            self.assertEqual(json.loads(self.run_cli(db, 'list').stdout),
                             json.loads(result.stdout) + [
                                 {'supplier': 'other', 'sku': 'a',
                                  'name': 'Other supplier', 'price_cents': 6},
                             ])
            with sqlite3.connect(db) as connection:
                self.assertEqual(connection.execute('SELECT * FROM successful_batches').fetchall(), [])

    def test_supplier_identity_and_replay_after_newer_import(self):
        with tempfile.TemporaryDirectory() as d:
            db = Path(d) / 'x.sqlite'
            source = Path(d) / 'items.csv'
            original = b'sku,name,price_cents\n A ,First,10\na,Last,20\n'
            source.write_bytes(original)
            for supplier in ('zeta', 'alpha'):
                result = self.run_cli(db, 'import', source, '--supplier', supplier,
                                      '--batch-id', 'daily')
                self.assertEqual(result.returncode, 0, result.stderr)
            source.write_text('sku,name,price_cents\nA,Newer,30\n')
            result = self.run_cli(db, 'import', source, '--supplier', 'alpha')
            self.assertEqual(result.returncode, 0, result.stderr)
            expected = [
                {'supplier': 'alpha', 'sku': 'a', 'name': 'Newer', 'price_cents': 30},
                {'supplier': 'zeta', 'sku': 'a', 'name': 'Last', 'price_cents': 20},
            ]
            source.write_bytes(original)
            result = self.run_cli(db, 'import', source, '--supplier', 'alpha',
                                  '--batch-id', 'daily')
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(self.run_cli(db, 'list').stdout), expected)
            # Semantically identical CSV with different bytes must conflict too.
            source.write_bytes(original.replace(b'\n', b'\r\n'))
            with sqlite3.connect(db) as connection:
                batches_before = connection.execute(
                    'SELECT * FROM successful_batches ORDER BY supplier,batch_id').fetchall()
            result = self.run_cli(db, 'import', source, '--supplier', 'alpha',
                                  '--batch-id', 'daily')
            self.assertNotEqual(result.returncode, 0)
            self.assertIn('batch', result.stderr.lower())
            self.assertEqual(json.loads(self.run_cli(db, 'list').stdout), expected)
            with sqlite3.connect(db) as connection:
                self.assertEqual(connection.execute(
                    'SELECT * FROM successful_batches ORDER BY supplier,batch_id').fetchall(),
                    batches_before)
            source.write_bytes(original)
            self.assertEqual(self.run_cli(db, 'import', source, '--supplier', 'alpha',
                                         '--batch-id', 'daily').returncode, 0)
            self.assertEqual(json.loads(self.run_cli(db, 'list').stdout), expected)

    def test_invalid_keyed_import_does_not_reserve_key(self):
        with tempfile.TemporaryDirectory() as d:
            db = Path(d) / 'x.sqlite'
            source = Path(d) / 'items.csv'
            source.write_text('sku,name,price_cents\nA,Bad,-1\n')
            result = self.run_cli(db, 'import', source, '--batch-id', 'retry')
            self.assertNotEqual(result.returncode, 0)
            source.write_text('sku,name,price_cents\nA,Valid,0\n')
            result = self.run_cli(db, 'import', source, '--batch-id', 'retry')
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(self.run_cli(db, 'list').stdout), [
                {'supplier': 'legacy', 'sku': 'a', 'name': 'Valid', 'price_cents': 0},
            ])

    def test_migration_and_batch_state_roll_back_on_write_failure(self):
        with tempfile.TemporaryDirectory() as d:
            db = Path(d) / 'x.sqlite'
            source = Path(d) / 'items.csv'
            with sqlite3.connect(db) as connection:
                connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, '
                                   'name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
                connection.execute("INSERT INTO catalog VALUES ('a','Original',5)")
                connection.execute('CREATE INDEX catalog_name ON catalog(name)')
                connection.execute("CREATE TRIGGER reject_b BEFORE INSERT ON catalog "
                                   "WHEN NEW.sku = 'b' BEGIN "
                                   "SELECT RAISE(ABORT, 'blocked'); END")
                before = connection.execute('SELECT type,name,sql FROM sqlite_master '
                                            'ORDER BY type,name').fetchall()
            source.write_text('sku,name,price_cents\nA,Changed,10\nB,Blocked,20\n')
            result = self.run_cli(db, 'import', source, '--supplier', 'new',
                                  '--batch-id', 'retry')
            self.assertNotEqual(result.returncode, 0)
            self.assertIn('blocked', result.stderr)
            with sqlite3.connect(db) as connection:
                self.assertEqual(connection.execute('SELECT * FROM catalog').fetchall(),
                                 [('a', 'Original', 5)])
                self.assertEqual(connection.execute('SELECT type,name,sql FROM sqlite_master '
                                                    'ORDER BY type,name').fetchall(), before)
                connection.execute('DROP TRIGGER reject_b')
            source.write_text('sku,name,price_cents\nA,Retry,0\n')
            result = self.run_cli(db, 'import', source, '--supplier', 'new',
                                  '--batch-id', 'retry')
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(self.run_cli(db, 'list').stdout), [
                {'supplier': 'legacy', 'sku': 'a', 'name': 'Original', 'price_cents': 5},
                {'supplier': 'new', 'sku': 'a', 'name': 'Retry', 'price_cents': 0},
            ])
            with sqlite3.connect(db) as connection:
                self.assertIsNotNone(connection.execute(
                    "SELECT name FROM sqlite_master WHERE name='catalog_name'").fetchone())


    def test_summary_filters_zero_rows_and_preserves_list(self):
        with tempfile.TemporaryDirectory() as d:
            db = Path(d) / 'x.sqlite'
            result = self.run_cli(db, 'summary')
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stdout), [])
            source = Path(d) / 'items.csv'
            for supplier, content in [
                ('zeta', 'a,One,7\nb,Two,3\nz,Zero,0\n'),
                ('zero-only', 'z,Zero,0\n'),
                ('alpha', 'a,Max,9223372036854775807\nb,Max,9223372036854775807\n'),
            ]:
                source.write_text('sku,name,price_cents\n' + content)
                imported = self.run_cli(db, 'import', source, '--supplier', supplier,
                                        '--batch-id', 'daily')
                self.assertEqual(imported.returncode, 0, imported.stderr)
            before = self.run_cli(db, 'list').stdout
            result = self.run_cli(db, 'summary')
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stdout), [
                {'supplier': 'alpha', 'count': 2, 'total_cents': 18446744073709551614},
                {'supplier': 'zeta', 'count': 2, 'total_cents': 10},
            ])
            self.assertEqual(self.run_cli(db, 'list').stdout, before)
            self.assertEqual(len(json.loads(before)), 6)
            source.write_text('sku,name,price_cents\nz,Zero,0\n')
            self.assertEqual(self.run_cli(db, 'import', source, '--supplier',
                                          'zero-only', '--batch-id', 'daily').returncode, 0)
            zero_db = Path(d) / 'zero.sqlite'
            self.assertEqual(self.run_cli(zero_db, 'import', source).returncode, 0)
            self.assertEqual(json.loads(self.run_cli(zero_db, 'summary').stdout), [])
            self.assertEqual(len(json.loads(self.run_cli(zero_db, 'list').stdout)), 1)

    def test_summary_migrates_original_catalog_preserving_rows(self):
        with tempfile.TemporaryDirectory() as d:
            db = Path(d) / 'x.sqlite'
            with sqlite3.connect(db) as connection:
                connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, '
                                   'name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
                connection.executemany('INSERT INTO catalog VALUES (?,?,?)', [
                    (' A ', 'Raw', 12), ('a', 'Other stored row', 8), ('z', 'Zero', 0),
                ])
            result = self.run_cli(db, 'summary')
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stdout), [
                {'supplier': 'legacy', 'count': 2, 'total_cents': 20},
            ])
            rows = json.loads(self.run_cli(db, 'list').stdout)
            self.assertEqual([(r['sku'], r['name'], r['price_cents']) for r in rows],
                             [(' A ', 'Raw', 12), ('a', 'Other stored row', 8), ('z', 'Zero', 0)])
