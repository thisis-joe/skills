# Supplier imports and batch replay

This extends the runnable import/list slice (catalog-import.md) and supersedes
its single-supplier schema and JSON shape. The summary continuation is authorized below.

- `import PATH` accepts optional `--supplier NAME` (default `legacy`) and
  `--batch-id ID` (default absent). Supplier and batch ID are literal identifiers;
  only SKU is normalized by stripping surrounding whitespace and lowercasing.
- Catalog identity is (supplier, normalized SKU). Last CSV row wins within that
  identity, but every row must validate. All previous price/name/CSV rules apply,
  including zero cents. An ordinary later import updates matching items only
  for that supplier. Matching legacy raw SKU aliases consolidate only when
  their identity is imported; unrelated rows remain exact.
- Migrate the original three-column catalog to supplier `legacy`, preserving
  every stored row and value. `list` adds supplier and sorts by supplier then SKU.
  Migration is transactional and repeatable, without modifying the project data
  during development checks.
- A successful keyed import records a SHA-256 fingerprint of the exact bytes
  parsed. Replay of that supplier/batch ID with identical bytes succeeds without
  touching items, even if newer imports have updated them. Different bytes fail
  and leave catalog and successful-batch records unchanged. Keys are independent
  between suppliers. Without a batch ID, each invocation applies normally.
- Migration, supplier item changes and successful-batch insertion commit together;
  failures never reserve a key. SQL values are parameterized. Existing public CLI,
  Python stdlib only, successful silent import and nonzero/stderr failures remain.

Summary contract (clarified 2026-10-23): `summary` returns a JSON array with
one {supplier,count,total_cents} per supplier having nonzero-price rows, sorted
by supplier; no qualifying groups returns []. Exclude zero-price rows from both
count and total, while retaining them in list and storage. Zero-only suppliers
therefore have no summary group. Totals use exact integer cents even when their
sum exceeds SQLite's per-value signed integer range. Preserve import/replay rules
and automatic transactional migration for original catalogs.
