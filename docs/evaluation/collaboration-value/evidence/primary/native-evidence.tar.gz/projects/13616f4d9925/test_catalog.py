import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest


class Catalog(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.db = self.root / 'catalog.sqlite'
        self.csv = self.root / 'supplier.csv'

    def cli(self, *args):
        return subprocess.run(
            [sys.executable, 'catalog.py', '--db', str(self.db), *args],
            text=True, capture_output=True,
        )

    def listing(self):
        result = self.cli('list')
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def import_text(self, content, *options):
        self.csv.write_text(content, encoding='utf-8')
        return self.cli('import', str(self.csv), *options)

    def summary(self):
        result = self.cli('summary')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stderr, '')
        return json.loads(result.stdout)

    def test_empty_summary(self):
        self.assertEqual(self.summary(), [])

    def test_summary_counts_zero_prices_and_sorts_supplier_groups(self):
        for supplier, rows in [
            ('zeta', 'same,Free,0\n'),
            ('alpha', 'same,Large,9223372036854775807\nb,Large too,9223372036854775807\nc,Free,0\n'),
        ]:
            result = self.import_text('sku,name,price_cents\n' + rows, '--supplier', supplier)
            self.assertEqual(result.returncode, 0, result.stderr)
        before = self.db.read_bytes()
        self.assertEqual(self.summary(), [
            {'supplier': 'alpha', 'count': 3, 'total_cents': 18446744073709551614},
            {'supplier': 'zeta', 'count': 1, 'total_cents': 0},
        ])
        self.assertEqual(self.db.read_bytes(), before)
        self.assertEqual(len(self.listing()), 4)
        self.assertEqual(sum(item['price_cents'] == 0 for item in self.listing()), 2)

    def test_summary_migrates_legacy_items(self):
        with sqlite3.connect(self.db) as connection:
            connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
            connection.executemany('INSERT INTO catalog VALUES (?, ?, ?)', [
                ('free', 'Free', 0), ('paid', 'Paid', 25),
            ])
        self.assertEqual(self.summary(), [
            {'supplier': 'legacy', 'count': 2, 'total_cents': 25},
        ])
        self.assertEqual(len(self.listing()), 2)

    def test_empty_list(self):
        self.assertEqual(self.listing(), [])

    def test_import_duplicates_updates_and_legacy_items(self):
        with sqlite3.connect(self.db) as connection:
            connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
            connection.executemany('INSERT INTO catalog VALUES (?, ?, ?)', [
                ('keep', 'Existing', 25), ('a', 'Old', 1),
            ])
        result = self.import_text('sku,name,price_cents\na,First,10\nb,"Name, quoted",0\na,Last,30\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.listing(), [
            {'supplier': 'legacy', 'sku': 'a', 'name': 'Last', 'price_cents': 30},
            {'supplier': 'legacy', 'sku': 'b', 'name': 'Name, quoted', 'price_cents': 0},
            {'supplier': 'legacy', 'sku': 'keep', 'name': 'Existing', 'price_cents': 25},
        ])
        result = self.import_text('sku,name,price_cents\na,Later,40\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.listing()[0]['price_cents'], 40)

    def test_trimmed_identity_collisions_and_case_sensitive_updates(self):
        result = self.import_text(
            'sku,name,price_cents\n'
            ' Part , First , 10 \n'
            'Part, Last , 20 \n'
            'part, Lowercase ,30\n'
            'keep, Unrelated ,40\n'
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.listing(), [
            {'supplier': 'legacy', 'sku': 'Part', 'name': 'Last', 'price_cents': 20},
            {'supplier': 'legacy', 'sku': 'keep', 'name': 'Unrelated', 'price_cents': 40},
            {'supplier': 'legacy', 'sku': 'part', 'name': 'Lowercase', 'price_cents': 30},
        ])
        result = self.import_text('sku,name,price_cents\n Part , Updated , 50 \n')
        self.assertEqual(result.returncode, 0, result.stderr)
        expected = self.listing()
        self.assertEqual(expected[0], {'supplier': 'legacy', 'sku': 'Part', 'name': 'Updated', 'price_cents': 50})
        self.assertEqual(expected[2], {'supplier': 'legacy', 'sku': 'part', 'name': 'Lowercase', 'price_cents': 30})
        result = self.import_text(
            'sku,name,price_cents\n Part , Invalid , nope \nPart,Valid,60\n'
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(self.listing(), expected)

    def test_malformed_imports_preserve_catalog(self):
        self.assertEqual(self.import_text('sku,name,price_cents\na,Original,7\n').returncode, 0)
        before = self.db.read_bytes()
        for row in ['a,Bad,-1', 'a,Bad,1.5', 'a,Bad,no', 'a,Bad,9223372036854775808',
                    ',Name,1', 'a, ,1', 'a,Name', 'a,Name,1,extra', '', 'a,"unclosed,1']:
            with self.subTest(row=row):
                result = self.import_text('sku,name,price_cents\na,Changed,10\n' + row + '\n')
                self.assertNotEqual(result.returncode, 0)
                self.assertIn('error:', result.stderr)
                self.assertEqual(self.db.read_bytes(), before)
        # An invalid earlier duplicate still invalidates the entire file.
        self.assertNotEqual(self.import_text('sku,name,price_cents\na,Bad,no\na,Good,1\n').returncode, 0)
        self.assertEqual(self.db.read_bytes(), before)

    def batch_state(self):
        with sqlite3.connect(self.db) as connection:
            return connection.execute(
                'SELECT * FROM successful_batches ORDER BY supplier,batch_id'
            ).fetchall()

    def test_migration_on_list_preserves_exact_legacy_values(self):
        with sqlite3.connect(self.db) as connection:
            connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
            connection.execute('INSERT INTO catalog VALUES (?, ?, ?)', (' X ', ' Old ', 0))
            connection.execute('CREATE TABLE unrelated (value TEXT)')
            connection.execute("INSERT INTO unrelated VALUES ('keep')")
        expected = [{'supplier': 'legacy', 'sku': ' X ', 'name': ' Old ', 'price_cents': 0}]
        self.assertEqual(self.listing(), expected)
        self.assertEqual(self.listing(), expected)
        self.assertEqual(self.batch_state(), [])
        with sqlite3.connect(self.db) as connection:
            self.assertEqual(connection.execute('SELECT * FROM unrelated').fetchall(), [('keep',)])

    def test_supplier_identity_sorting_and_batch_replay(self):
        original = 'sku,name,price_cents\n A , First , 1 \nA,Last,2\na,Lower,0\n'
        newer = 'sku,name,price_cents\nA,Newer,9\n'
        for supplier in ['zeta', 'alpha']:
            result = self.import_text(original, '--supplier', supplier, '--batch-id', 'daily')
            self.assertEqual(result.returncode, 0, result.stderr)
        result = self.import_text(newer, '--supplier', 'alpha', '--batch-id', 'next')
        self.assertEqual(result.returncode, 0, result.stderr)
        expected = [
            {'supplier': 'alpha', 'sku': 'A', 'name': 'Newer', 'price_cents': 9},
            {'supplier': 'alpha', 'sku': 'a', 'name': 'Lower', 'price_cents': 0},
            {'supplier': 'zeta', 'sku': 'A', 'name': 'Last', 'price_cents': 2},
            {'supplier': 'zeta', 'sku': 'a', 'name': 'Lower', 'price_cents': 0},
        ]
        self.assertEqual(self.listing(), expected)
        state = self.batch_state()
        self.assertEqual(len(state), 3)
        result = self.import_text(original, '--supplier', 'alpha', '--batch-id', 'daily')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.listing(), expected)
        self.assertEqual(self.batch_state(), state)
        # Same parsed content but different bytes still conflicts.
        result = self.import_text(original.replace('First', ' First '), '--supplier', 'alpha', '--batch-id', 'daily')
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(self.listing(), expected)
        self.assertEqual(self.batch_state(), state)
        result = self.import_text(newer, '--supplier', 'zeta')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.listing()[2]['price_cents'], 9)
        self.assertEqual(self.batch_state(), state)

    def test_failed_import_does_not_consume_key(self):
        self.assertEqual(self.listing(), [])
        result = self.import_text('sku,name,price_cents\nA,Good,1\nB,Bad,-1\n', '--batch-id', 'retry')
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(self.listing(), [])
        self.assertEqual(self.batch_state(), [])
        result = self.import_text('sku,name,price_cents\nA,Good,1\n', '--batch-id', 'retry')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(len(self.batch_state()), 1)

    def test_storage_failure_rolls_back_items_and_batch_record(self):
        self.assertEqual(self.import_text('sku,name,price_cents\nA,Original,1\n').returncode, 0)
        with sqlite3.connect(self.db) as connection:
            connection.execute("CREATE TRIGGER reject_b BEFORE INSERT ON catalog WHEN NEW.sku='B' BEGIN SELECT RAISE(ABORT, 'blocked'); END")
        before = self.listing()
        result = self.import_text('sku,name,price_cents\nA,Changed,2\nB,Blocked,3\n', '--batch-id', 'retry')
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(self.listing(), before)
        self.assertEqual(self.batch_state(), [])

    def test_invalid_input_does_not_create_database(self):
        for content in ['', 'name,sku,price_cents\n', 'sku,name,price_cents\na,Bad,no\n']:
            self.assertNotEqual(self.import_text(content).returncode, 0)
            self.assertFalse(self.db.exists())
        self.csv.unlink()
        self.assertNotEqual(self.cli('import', str(self.csv)).returncode, 0)
        self.assertFalse(self.db.exists())


if __name__ == '__main__':
    unittest.main()
