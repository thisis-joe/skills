import argparse
import csv
import json
import hashlib
import io
from pathlib import Path
import re
import sqlite3


def read_import(source_bytes):
    items = {}
    with io.StringIO(source_bytes.decode('utf-8'), newline='') as source:
        reader = csv.reader(source, strict=True)
        if next(reader, None) != ['sku', 'name', 'price_cents']:
            raise ValueError('CSV header must be sku,name,price_cents')
        for row in reader:
            if len(row) != 3:
                raise ValueError(f'line {reader.line_num}: expected three fields')
            sku, name, price = (field.strip() for field in row)
            if not sku or not name:
                raise ValueError(f'line {reader.line_num}: SKU and name must be nonempty')
            if not re.fullmatch(r'[0-9]+', price):
                raise ValueError(f'line {reader.line_num}: price must be nonnegative integer cents')
            cents = int(price)
            if cents > 9223372036854775807:
                raise ValueError(f'line {reader.line_num}: price exceeds SQLite integer range')
            items[sku] = (sku, name, cents)
    return list(items.values())


def prepare_storage(connection):
    columns = connection.execute('PRAGMA table_info(catalog)').fetchall()
    if columns and 'supplier' not in {column[1] for column in columns}:
        connection.execute('ALTER TABLE catalog RENAME TO catalog_legacy_migration')
    connection.execute(
        'CREATE TABLE IF NOT EXISTS catalog ('
        'supplier TEXT NOT NULL, sku TEXT NOT NULL, name TEXT NOT NULL, '
        'price_cents INTEGER NOT NULL CHECK(price_cents >= 0), '
        'PRIMARY KEY (supplier, sku))'
    )
    if columns and 'supplier' not in {column[1] for column in columns}:
        connection.execute(
            "INSERT INTO catalog SELECT 'legacy', sku, name, price_cents "
            'FROM catalog_legacy_migration'
        )
        connection.execute('DROP TABLE catalog_legacy_migration')
    connection.execute(
        'CREATE TABLE IF NOT EXISTS successful_batches ('
        'supplier TEXT NOT NULL, batch_id TEXT NOT NULL, source_sha256 TEXT NOT NULL, '
        'PRIMARY KEY (supplier, batch_id))'
    )


def apply_import(connection, supplier, batch_id, digest, items):
    if batch_id is not None:
        previous = connection.execute(
            'SELECT source_sha256 FROM successful_batches WHERE supplier=? AND batch_id=?',
            (supplier, batch_id),
        ).fetchone()
        if previous is not None:
            if previous[0] != digest:
                raise ValueError('batch ID already used with different source bytes')
            return
    connection.executemany(
        'INSERT INTO catalog (supplier, sku, name, price_cents) VALUES (?, ?, ?, ?) '
        'ON CONFLICT(supplier, sku) DO UPDATE SET '
        'name=excluded.name, price_cents=excluded.price_cents',
        [(supplier, sku, name, price) for sku, name, price in items],
    )
    if batch_id is not None:
        connection.execute(
            'INSERT INTO successful_batches VALUES (?, ?, ?)',
            (supplier, batch_id, digest),
        )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    commands.add_parser('summary')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    importer.add_argument('--supplier', default='legacy')
    importer.add_argument('--batch-id')
    args = parser.parse_args()
    try:
        # Parse and hash one snapshot, so replay identity matches the imported bytes.
        items = None
        if args.command == 'import':
            source_bytes = Path(args.path).read_bytes()
            items = read_import(source_bytes)
            digest = hashlib.sha256(source_bytes).hexdigest()
        connection = sqlite3.connect(args.db)
        try:
            with connection:
                # Serialize replay checks and writes; migration is in the same transaction.
                connection.execute('BEGIN IMMEDIATE')
                prepare_storage(connection)
                if items is not None:
                    apply_import(connection, args.supplier, args.batch_id, digest, items)
                elif args.command == 'summary':
                    groups = {}
                    # Python integers keep totals exact beyond SQLite's SUM range.
                    for supplier, price in connection.execute(
                        'SELECT supplier,price_cents FROM catalog ORDER BY supplier'
                    ):
                        group = groups.setdefault(
                            supplier, dict(supplier=supplier, count=0, total_cents=0)
                        )
                        group['count'] += 1
                        group['total_cents'] += price
                    print(json.dumps(list(groups.values())))
                else:
                    print(json.dumps([
                        dict(supplier=supplier, sku=sku, name=name, price_cents=price)
                        for supplier, sku, name, price in connection.execute(
                            'SELECT supplier,sku,name,price_cents FROM catalog '
                            'ORDER BY supplier,sku'
                        )
                    ]))
        finally:
            connection.close()
    except (OSError, UnicodeError, ValueError, csv.Error, sqlite3.Error) as error:
        parser.exit(1, f'error: {error}\n')


if __name__ == '__main__':
    main()
