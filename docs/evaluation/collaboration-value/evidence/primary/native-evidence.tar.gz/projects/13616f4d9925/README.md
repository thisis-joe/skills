# Purchasing catalog
Python standard library only. Public entry: `python3 catalog.py --db PATH list`.
List returns a JSON array of {supplier,sku,name,price_cents}, sorted by supplier
then SKU. Existing single-supplier databases migrate transactionally on first
use: all stored values are preserved exactly under supplier legacy. Item identity
is the pair (supplier, SKU).
CSV has header sku,name,price_cents. SKU/name must be nonempty; prices are
nonnegative integer cents.
Use the existing public CLI entry for added commands. Local regression command:
`python3 -m unittest discover -v`. Work locally; preserve unrelated files.

Import a supplier file with `python3 catalog.py --db PATH import FILE.csv`.
The header must be exactly `sku,name,price_cents`. Every row must have three
fields, a nonblank SKU and name, and a price containing only decimal digits
within SQLite's signed 64-bit integer range. Surrounding whitespace is trimmed
from SKU, name, and price before validation. SKU case is preserved: case
variants are different items. Duplicate matching uses the trimmed SKU.
The last row for a repeated SKU wins; imports also update existing SKUs and
preserve items absent from the file. All rows are validated before any writes;
any malformed row rejects the entire import, including an earlier duplicate.
Successful imports exit silently with status 0; failures print an error to stderr
and exit nonzero. A header-only file is valid and makes no item changes.

Optional import arguments are `--supplier NAME` (default `legacy`) and
`--batch-id ID` (default: no replay key). Supplier names and batch IDs are used
exactly as supplied. The same SKU can exist independently for different suppliers.
Without a batch ID, each successful import applies its updates normally.

A batch ID belongs to its supplier. Successful keyed imports record a SHA-256
fingerprint of the exact source bytes. Replaying those bytes with the same key
succeeds silently without applying updates again, even after newer imports.
Different bytes with an already successful key fail without changing items or
batch records. Different suppliers can use the same batch ID independently.
Item writes and batch records commit together; a failed import consumes no key.
Replay checks and updates run in one serialized SQLite write transaction.

Run `python3 catalog.py --db PATH summary` to return one
`{supplier,count,total_cents}` object per nonempty supplier group, sorted by
supplier, or `[]` when there are no groups. Every stored item counts, including
zero-price items, which add zero to the total and remain visible in `list`.
Totals are exact integer cents, including when a group's total exceeds SQLite's
signed 64-bit integer range.
