# Purchasing catalog

Python standard library only. Public CLI:

```sh
python3 catalog.py --db PATH list
python3 catalog.py --db PATH summary
python3 catalog.py --db PATH import FILE.csv [--supplier NAME] [--batch-id ID]
```

Import defaults to supplier `legacy` and no replay key. Supplier names and batch
IDs are compared exactly as supplied. Item identity is supplier plus SKU; SKU
keys are trimmed and lowercased before storage and duplicate checks. Names retain
their supplied whitespace. A later import updates an existing item's name and
price for the same supplier/SKU. Other suppliers and items remain unchanged.

The CSV header must be exactly `sku,name,price_cents`. Blank or whitespace-only
SKU/name, wrong field counts, and invalid prices are skipped with line diagnostics
on stderr. Prices use decimal digits only and must fit SQLite's nonnegative signed
64-bit integer range, including zero. Successful imports exit 0, including files
with skipped rows.

Any repeated nonempty normalized SKU within the file rejects the entire import,
even for identical rows or rows with other malformed fields. Invalid headers,
unreadable files, or CSV syntax errors also reject the file. Rejected imports exit
nonzero with an explanation on stderr and commit neither item updates nor a
successful-batch record.

Batch IDs are scoped to suppliers. An exact byte-for-byte replay of a successful
supplier/batch-id succeeds without applying items again, even after later updates.
Reusing that key with different source bytes fails without changing stored state.
Omit `--batch-id` to apply each import normally. Successful source bytes are stored
in SQLite to support exact replay comparison.

List returns a JSON array of `{supplier,sku,name,price_cents}`, sorted by supplier
then SKU. On first use, the old `catalog(sku,name,price_cents)` table is migrated
transactionally to supplier `legacy`, preserving names and prices and normalizing
SKU keys. If old keys collide after normalization, migration fails and leaves the
original database intact for resolution; no row is silently discarded.

Summary returns a JSON array of `{supplier,count,total_cents}`, sorted by supplier.
Zero-price items are excluded from both count and total; list still includes them.
Suppliers with no remaining items are omitted, and no groups returns `[]`.
Totals remain exact even when their sum exceeds the SQLite integer range.

Local regression command: `python3 -m unittest discover -v`.
Work locally; preserve unrelated files.
