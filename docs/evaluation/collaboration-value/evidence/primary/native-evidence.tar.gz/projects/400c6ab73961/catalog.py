import argparse
import csv
import json
import io
import re
import sqlite3
import sys


class ImportRejected(ValueError):
    pass


def initialize_storage(connection):
    columns = connection.execute('PRAGMA table_info(catalog)').fetchall()
    if columns and 'supplier' not in {column[1] for column in columns}:
        connection.execute('ALTER TABLE catalog RENAME TO catalog_before_suppliers')
    connection.execute('CREATE TABLE IF NOT EXISTS catalog ('
                       'supplier TEXT NOT NULL, sku TEXT NOT NULL, '
                       'name TEXT NOT NULL, price_cents INTEGER NOT NULL, '
                       'PRIMARY KEY (supplier, sku))')
    if columns and 'supplier' not in {column[1] for column in columns}:
        seen = set()
        for sku, name, price in connection.execute(
                'SELECT sku,name,price_cents FROM catalog_before_suppliers'):
            key = sku.strip().lower()
            if key in seen:
                raise ImportRejected('legacy SKU normalization collision; migration rolled back')
            seen.add(key)
            connection.execute('INSERT INTO catalog VALUES (?,?,?,?)',
                               ('legacy', key, name, price))
        connection.execute('DROP TABLE catalog_before_suppliers')
    connection.execute('CREATE TABLE IF NOT EXISTS successful_batches ('
                       'supplier TEXT NOT NULL, batch_id TEXT NOT NULL, '
                       'source_bytes BLOB NOT NULL, PRIMARY KEY (supplier,batch_id))')


def import_catalog(connection, path, supplier, batch_id):
    with open(path, 'rb') as source:
        source_bytes = source.read()
    if batch_id is not None:
        previous = connection.execute(
            'SELECT source_bytes FROM successful_batches WHERE supplier=? AND batch_id=?',
            (supplier, batch_id)).fetchone()
        if previous is not None:
            if previous[0] != source_bytes:
                raise ImportRejected('batch-id already used with different source bytes')
            return []
    rows = []
    seen = set()
    skipped = []
    with io.StringIO(source_bytes.decode('utf-8-sig'), newline='') as source:
        reader = csv.reader(source, strict=True)
        header = next(reader, None)
        if header != ['sku', 'name', 'price_cents']:
            raise ImportRejected('expected CSV header sku,name,price_cents')
        for row in reader:
            line = reader.line_num
            sku = row[0].strip().lower() if row else ''
            # Check keys even when another field makes the row malformed.
            if sku:
                if sku in seen:
                    raise ImportRejected(f'line {line}: repeated SKU {sku!r}')
                seen.add(sku)
            if len(row) != 3:
                skipped.append(f'line {line}: expected 3 fields')
                continue
            _, name, price = row
            if not sku.strip() or not name.strip():
                skipped.append(f'line {line}: SKU and name must be nonempty')
                continue
            # SQLite INTEGER stores signed 64-bit values. Compare text first so
            # arbitrarily long malformed prices cannot overflow int conversion.
            digits = price.lstrip('0') or '0'
            if (not re.fullmatch(r'[0-9]+', price)
                    or len(digits) > 19
                    or (len(digits) == 19 and digits > '9223372036854775807')):
                skipped.append(f'line {line}: price_cents must be a nonnegative SQLite integer')
                continue
            rows.append((supplier, sku, name, int(digits)))
    connection.executemany(
        'INSERT INTO catalog (supplier,sku,name,price_cents) VALUES (?,?,?,?) '
        'ON CONFLICT(supplier,sku) DO UPDATE SET name=excluded.name, '
        'price_cents=excluded.price_cents', rows)
    if batch_id is not None:
        connection.execute('INSERT INTO successful_batches VALUES (?,?,?)',
                           (supplier, batch_id, source_bytes))
    return skipped


def summarize_catalog(connection):
    groups = {}
    # Sum with Python integers so valid individual prices cannot overflow
    # SQLite's signed 64-bit SUM accumulator.
    for supplier, price in connection.execute(
            'SELECT supplier,price_cents FROM catalog WHERE price_cents != 0 '
            'ORDER BY supplier'):
        group = groups.setdefault(supplier, dict(supplier=supplier, count=0, total_cents=0))
        group['count'] += 1
        group['total_cents'] += price
    return list(groups.values())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    commands.add_parser('summary')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    importer.add_argument('--supplier', default='legacy')
    importer.add_argument('--batch-id')
    args = parser.parse_args()
    connection = None
    try:
        connection = sqlite3.connect(args.db)
        with connection:
            connection.execute('BEGIN IMMEDIATE')
            initialize_storage(connection)
            if args.command == 'import':
                skipped = import_catalog(connection, args.path, args.supplier, args.batch_id)
            elif args.command == 'summary':
                print(json.dumps(summarize_catalog(connection)))
            else:
                print(json.dumps([dict(supplier=s, sku=k, name=n, price_cents=v) for s, k, n, v in connection.execute('SELECT supplier,sku,name,price_cents FROM catalog ORDER BY supplier,sku')]))
        if args.command == 'import':
            for reason in skipped:
                print(f'Skipped {reason}', file=sys.stderr)
    except (ImportRejected, OSError, UnicodeError, csv.Error, sqlite3.Error) as error:
        print(f'catalog: {error}', file=sys.stderr)
        return 1
    finally:
        if connection is not None:
            connection.close()
    return 0


if __name__ == '__main__':
    sys.exit(main())
