import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest


class Catalog(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.db = self.root / 'catalog.sqlite'

    def cli(self, *args):
        return subprocess.run([sys.executable, 'catalog.py', '--db', str(self.db), *args],
                              capture_output=True, text=True)

    def load(self, contents, *options):
        path = self.root / 'supplier.csv'
        path.write_text(contents, encoding='utf-8')
        return self.cli('import', str(path), *options)

    def items(self):
        result = self.cli('list')
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def test_empty_list(self):
        self.assertEqual(self.items(), [])

    def summary(self):
        result = self.cli('summary')
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def test_summary_empty_and_zero_only(self):
        self.assertEqual(self.summary(), [])
        self.assertEqual(self.load('sku,name,price_cents\na,Free,0\n').returncode, 0)
        self.assertEqual(self.summary(), [])
        self.assertEqual(len(self.items()), 1)

    def test_summary_groups_sorts_excludes_zero_and_tracks_updates(self):
        for supplier, contents in (
                ('z', 'a,A,10\nb,B,25\nc,Free,0\n'),
                ('a', 'a,A,7\n'), ('zero', 'a,Free,0\n')):
            result = self.load('sku,name,price_cents\n' + contents, '--supplier', supplier)
            self.assertEqual(result.returncode, 0, result.stderr)
        before = self.items()
        self.assertEqual(self.summary(), [dict(supplier='a', count=1, total_cents=7),
                                          dict(supplier='z', count=2, total_cents=35)])
        self.assertEqual(self.items(), before)
        self.assertEqual(self.load('sku,name,price_cents\na,Now free,0\n',
                                   '--supplier', 'a').returncode, 0)
        self.assertEqual(self.summary(), [dict(supplier='z', count=2, total_cents=35)])

    def test_summary_migrates_legacy_and_sums_large_prices_exactly(self):
        with sqlite3.connect(self.db) as connection:
            connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
            connection.executemany('INSERT INTO catalog VALUES (?,?,?)',
                                   [('a', 'A', 9223372036854775807),
                                    ('b', 'B', 9223372036854775807), ('c', 'Free', 0)])
        self.assertEqual(self.summary(), [dict(supplier='legacy', count=2,
                                              total_cents=18446744073709551614)])
        self.assertEqual(len(self.items()), 3)

    def test_import_skips_malformed_rows_and_sorts_list(self):
        result = self.load('sku,name,price_cents\nz,"A, name",0025\nb,Bad,-1\nc,Bad,1.5\nd,Bad,no\ne,,10\n,Empty,10\nf,F,5,extra\ng,G,99999999999999999999999\na,Free,0\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stderr.count('Skipped line'), 7)
        self.assertEqual(self.items(), [dict(supplier='legacy', sku='a', name='Free', price_cents=0),
                                        dict(supplier='legacy', sku='z', name='A, name', price_cents=25)])

    def test_duplicates_reject_entire_file_even_if_identical_or_invalid(self):
        for second in ('a,A,1', 'a,B,bad'):
            with self.subTest(second=second):
                result = self.load(f'sku,name,price_cents\nx,X,2\na,A,1\n{second}\n')
                self.assertNotEqual(result.returncode, 0)
                self.assertIn('repeated SKU', result.stderr)
                self.assertEqual(self.items(), [])

    def test_later_batch_updates_and_bad_row_preserves_item(self):
        self.assertEqual(self.load('sku,name,price_cents\na,Original,10\n').returncode, 0)
        result = self.load('sku,name,price_cents\n A ,Replacement,20\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [dict(supplier='legacy', sku='a', name='Replacement', price_cents=20)])
        result = self.load('sku,name,price_cents\na,Bad,no\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('Skipped', result.stderr)
        self.assertEqual(self.items()[0]['price_cents'], 20)

    def test_import_normalizes_sku_keys(self):
        result = self.load('sku,name,price_cents\n  MiXeD  ,Original,10\n   ,Empty,20\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('Skipped line 3', result.stderr)
        self.assertEqual(self.items(), [dict(supplier='legacy', sku='mixed', name='Original', price_cents=10)])

    def test_normalized_file_duplicates_reject_all_rows(self):
        for second in (' mixed ,Same,10', 'MIXED,Same,10', 'mixed,Bad,no',
                       ' MIXED ,Bad,10,extra'):
            with self.subTest(second=second):
                result = self.load(f'sku,name,price_cents\nnew,New,1\n MiXeD ,Same,10\n{second}\n')
                self.assertNotEqual(result.returncode, 0)
                self.assertIn('repeated SKU', result.stderr)
                self.assertEqual(self.items(), [])

    def test_migration_preserves_legacy_items(self):
        with sqlite3.connect(self.db) as connection:
            connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
            connection.execute('INSERT INTO catalog VALUES (?,?,?)', (' MiXeD ', 'Original', 0))
        self.assertEqual(self.items(), [dict(supplier='legacy', sku='mixed', name='Original', price_cents=0)])
        result = self.load('sku,name,price_cents\nMIXED,Updated,20\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(len(self.items()), 1)
        self.assertEqual(self.items()[0]['name'], 'Updated')

    def test_failed_migration_preserves_original_schema_and_rows(self):
        with sqlite3.connect(self.db) as connection:
            connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
            connection.executemany('INSERT INTO catalog VALUES (?,?,?)',
                                   [('a', 'First', 10), (' A ', 'Second', 20)])
        result = self.cli('list')
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('migration rolled back', result.stderr)
        with sqlite3.connect(self.db) as connection:
            self.assertEqual(connection.execute('SELECT * FROM catalog ORDER BY sku').fetchall(),
                             [(' A ', 'Second', 20), ('a', 'First', 10)])
            self.assertEqual([r[1] for r in connection.execute('PRAGMA table_info(catalog)')],
                             ['sku', 'name', 'price_cents'])
            self.assertEqual(connection.execute("SELECT name FROM sqlite_master WHERE name='successful_batches'").fetchall(), [])

    def test_replay_is_exact_scoped_and_does_not_reapply(self):
        old = 'sku,name,price_cents\n A ,Old,10\n'
        new = 'sku,name,price_cents\na,New,20\n'
        self.assertEqual(self.load(old, '--supplier', 'z', '--batch-id', 'one').returncode, 0)
        self.assertEqual(self.load(new, '--supplier', 'z', '--batch-id', 'two').returncode, 0)
        self.assertEqual(self.load(old, '--supplier', 'z', '--batch-id', 'one').returncode, 0)
        before = self.items()
        result = self.load(old.replace('10', '010'), '--supplier', 'z', '--batch-id', 'one')
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(self.items(), before)
        self.assertEqual(self.load(old, '--supplier', 'a', '--batch-id', 'one').returncode, 0)
        self.assertEqual([(r['supplier'], r['price_cents']) for r in self.items()], [('a', 10), ('z', 20)])
        with sqlite3.connect(self.db) as connection:
            self.assertEqual(connection.execute('SELECT count(*) FROM successful_batches').fetchone()[0], 3)

    def test_rejected_batch_does_not_claim_key(self):
        bad = 'sku,name,price_cents\na,A,10\n A ,A,10\n'
        self.assertNotEqual(self.load(bad, '--batch-id', 'one').returncode, 0)
        self.assertEqual(self.items(), [])
        good = 'sku,name,price_cents\na,A,10\nb,Bad,no\n'
        self.assertEqual(self.load(good, '--batch-id', 'one').returncode, 0)
        self.assertEqual(self.load('sku,name,price_cents\na,New,20\n').returncode, 0)
        self.assertEqual(self.load(good, '--batch-id', 'one').returncode, 0)
        self.assertEqual(self.items()[0]['price_cents'], 20)

    def test_bad_header_or_broken_csv_is_atomic(self):
        for contents in ('wrong,header\na,A,1\n',
                         'sku,name,price_cents\na,A,1\nb,"unterminated,2\n'):
            result = self.load(contents)
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(self.items(), [])

    def test_missing_file_reports_error(self):
        result = self.cli('import', str(self.root / 'missing.csv'))
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('catalog:', result.stderr)
        self.assertEqual(self.items(), [])


if __name__ == '__main__':
    unittest.main()
