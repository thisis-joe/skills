import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class BillingSmoke(unittest.TestCase):
    def test_read_then_small_refund(self):
        with tempfile.TemporaryDirectory() as temp:
            requests = [{'op': 'invoice', 'tenant': 'north', 'invoice': 'inv-a'},
                        {'op': 'refund', 'tenant': 'north', 'invoice': 'inv-a',
                         'amount': 1, 'request_key': 'smoke'}]
            run = subprocess.run([sys.executable, 'billing.py', '--db',
                                  str(Path(temp) / 'billing.db')],
                                 input=''.join(json.dumps(r) + '\n' for r in requests),
                                 capture_output=True, text=True, check=True)
            replies = [json.loads(line) for line in run.stdout.splitlines()]
            self.assertEqual(len(replies), 2)
            self.assertTrue(all(reply['ok'] for reply in replies))
