# Billing operations CLI

The existing CLI reads invoices from a local SQLite database. The proposed
change adds an in-process invoice cache and persistent refund requests.

Run `python3 billing.py --db PATH`. Send one JSON object per stdin line; receive
one JSON object per stdout line. Several requests can share one process. State
must also survive separate invocations with the same database. A new database
starts with the sample invoices in seed.json. Request-level errors return
`{"ok": false, "error": "..."}` and keep the process available. Successful reads
return `{"ok": true, "invoice": {...}}` or `{"ok": true, "invoices": [...]}`.

Requests:

- `{"op":"invoice","tenant":"north","invoice":"inv-a"}` reads one invoice.
- `{"op":"list","tenant":"north","order":"id"}` lists that tenant's invoices.
  Order is ascending and may be id, amount or refunded; the default is id.
- `{"op":"refund","tenant":"north","invoice":"inv-a","amount":200,
  "request_key":"refund-001"}` adds a refund and returns a receipt object with
  tenant, request_key, invoice and amount. Amount is a strictly positive JSON
  integer; booleans, strings and fractional numbers are invalid.

Invoice objects expose id, tenant, amount (original integer cents), and refunded
(cumulative integer cents). Every request enforces tenant ownership, including
cached reads and refunds. A missing invoice or a tenant mismatch returns the
same not-found error and never exposes the other tenant's invoice contents.

Request keys are scoped to a tenant. An exact replay with the same invoice and
amount returns the original receipt without applying another refund, including
after restart. Reusing that key with a different invoice or amount returns an
error without changing stored state. A refund cannot make cumulative refunded
exceed the original amount. Any rejected refund leaves both invoice totals and
request-key history unchanged, so a later valid retry of its key can succeed.
Reads and list results reflect accepted refunds even after a cached read.

The API is used sequentially; simultaneous writers and remote authentication
are outside this change. Existing read operations and default list ordering
remain compatible. Run `python3 -m unittest discover -v` for the smoke tests.
