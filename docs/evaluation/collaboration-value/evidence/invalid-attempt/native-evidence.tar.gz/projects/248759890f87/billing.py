import argparse
import json
import sys
from service import Billing
from storage import connect


def dispatch(service, request):
    if not isinstance(request, dict):
        raise ValueError('request must be an object')
    tenant = request.get('tenant')
    if not isinstance(tenant, str) or not tenant:
        raise ValueError('tenant is required')
    operation = request.get('op')
    if operation == 'list':
        return {'invoices': service.list(tenant, request.get('order', 'id'))}
    invoice_id = request.get('invoice')
    if not isinstance(invoice_id, str) or not invoice_id:
        raise ValueError('invoice is required')
    if operation == 'invoice':
        return {'invoice': service.invoice(tenant, invoice_id)}
    if operation == 'refund':
        return {'receipt': service.refund(tenant, invoice_id,
                                         request.get('amount'),
                                         request.get('request_key'))}
    raise ValueError('unknown operation')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    args = parser.parse_args()
    connection = connect(args.db)
    service = Billing(connection)
    try:
        for line in sys.stdin:
            try:
                payload = dispatch(service, json.loads(line))
                response = {'ok': True, **payload}
            except (ValueError, TypeError) as exc:
                response = {'ok': False, 'error': str(exc)}
            print(json.dumps(response), flush=True)
    finally:
        connection.close()


if __name__ == '__main__':
    main()
