import json
import sqlite3
from pathlib import Path


def connect(path):
    connection = sqlite3.connect(path)
    connection.row_factory = sqlite3.Row
    connection.execute("CREATE TABLE IF NOT EXISTS invoices ("
                       "id TEXT PRIMARY KEY, tenant TEXT NOT NULL, "
                       "amount INTEGER NOT NULL, refunded INTEGER NOT NULL)")
    connection.execute("CREATE TABLE IF NOT EXISTS refund_requests ("
                       "tenant TEXT NOT NULL, request_key TEXT NOT NULL, "
                       "invoice TEXT NOT NULL, amount INTEGER NOT NULL, "
                       "PRIMARY KEY (tenant, request_key))")
    if not connection.execute("SELECT 1 FROM invoices LIMIT 1").fetchone():
        seed = json.loads(Path(__file__).with_name('seed.json').read_text())
        connection.executemany("INSERT INTO invoices VALUES (?, ?, ?, 0)",
                               [(row['id'], row['tenant'], row['amount'])
                                for row in seed])
        connection.commit()
    return connection


def invoice(connection, invoice_id):
    row = connection.execute("SELECT * FROM invoices WHERE id = ?",
                             (invoice_id,)).fetchone()
    return dict(row) if row else None


def invoices(connection, tenant, order):
    allowed = {'id': 'id', 'amount': 'amount', 'refunded': 'refunded'}
    if order not in allowed:
        raise ValueError('unsupported ordering')
    column = allowed[order]
    rows = connection.execute(f"SELECT * FROM invoices WHERE tenant = ? "
                              f"ORDER BY {column}, id", (tenant,))
    return [dict(row) for row in rows]
