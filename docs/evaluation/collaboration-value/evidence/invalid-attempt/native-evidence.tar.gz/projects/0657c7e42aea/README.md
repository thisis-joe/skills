# Purchasing catalog

Python standard library only. Public CLI:

```
python3 catalog.py --db PATH import CSV_PATH [--supplier NAME] [--batch-id ID]
python3 catalog.py --db PATH list
python3 catalog.py --db PATH summary
```

Imports default to supplier `legacy` and no replay key. Existing three-column
catalog databases migrate transactionally: all existing values are preserved,
and their rows receive supplier `legacy`. Other tables are left alone.
Item identity is supplier plus the trimmed, case-sensitive SKU: `ABC` and `abc`
are different items. Supplier names and batch IDs are used exactly as supplied.
List returns a JSON array of `{supplier,sku,name,price_cents}`, sorted by supplier
then SKU.

CSV requires the exact header `sku,name,price_cents` and UTF-8 encoding (a BOM
is accepted). Incoming fields have surrounding whitespace trimmed. SKU/name must
then be nonempty. Prices contain ASCII digits only and must fit a nonnegative
SQLite integer, at most 9223372036854775807 cents. Zero is accepted.

Within a file, the first occurrence of each trimmed SKU wins, even if invalid;
later occurrences are skipped. Malformed rows are skipped with source-line
explanations on stderr. Imports with skipped rows succeed. Valid rows insert or
update the name and price for that supplier/SKU. Items absent from a file stay
unchanged. Imports produce no stdout; use `list` to inspect items.

A batch key is `(supplier, batch-id)`. A successful keyed import stores its exact
source bytes atomically with item updates. Repeating those bytes under that key
succeeds without reapplying rows, including after newer imports. Different bytes
under a previously successful key fail without changing items or batch history.
Different suppliers may reuse an ID independently. Without a batch ID, every
import applies normally. Missing files, invalid headers, decoding failures and
storage failures fail the command and roll back the transaction, including any
migration. Failed imports do not reserve their batch keys.

`summary` returns a JSON array with one `{supplier,count,total_cents}` object
per nonempty supplier group, sorted by supplier, with `[]` when no groups exist.
Count includes zero-priced items. Totals are exact integer cents, even when a
group total exceeds the SQLite integer range. Summary preserves stored items
and successful import batch history.

Local regression command: `python3 -m unittest discover -v`.
Work locally; preserve unrelated files. Do not publish.
