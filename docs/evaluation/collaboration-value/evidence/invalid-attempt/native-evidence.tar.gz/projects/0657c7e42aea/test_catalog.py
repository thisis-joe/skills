import json,subprocess,sys,tempfile,unittest
class Catalog(unittest.TestCase):
 def test_empty_list(self):
  with tempfile.TemporaryDirectory() as d:
   self.assertEqual(json.loads(subprocess.check_output([sys.executable,'catalog.py','--db',d+'/x.sqlite','list'])),[])

class ImportCatalog(unittest.TestCase):
 def test_import_updates_stored_rows_preserves_first_and_skips_bad_rows(self):
  from pathlib import Path
  with tempfile.TemporaryDirectory() as d:
   db = d + '/catalog.sqlite'
   source = Path(d) / 'daily.csv'
   def run(*args):
    return subprocess.run([sys.executable, 'catalog.py', '--db', db, *args], text=True, capture_output=True)
   source.write_text('sku,name,price_cents\nold,Stored,10\n', encoding='utf-8')
   self.assertEqual(run('import', str(source)).returncode, 0)
   source.write_text('sku,name,price_cents\nold,Replacement,99\na,First,20\na,Second,30\nb,Bad,no\nb,Later,40\nc,Negative,-1\nd,Huge,9223372036854775808\ne,,3\nf,Extra,3,column\ng,"Valid, quoted",0005\nh,Zero,0\n', encoding='utf-8')
   imported = run('import', str(source))
   self.assertEqual(imported.returncode, 0, imported.stderr)
   self.assertEqual(imported.stdout, '')
   self.assertEqual(len(imported.stderr.splitlines()), 7)
   expected = [dict(supplier='legacy', sku='a', name='First', price_cents=20), dict(supplier='legacy', sku='g', name='Valid, quoted', price_cents=5), dict(supplier='legacy', sku='h', name='Zero', price_cents=0), dict(supplier='legacy', sku='old', name='Replacement', price_cents=99)]
   self.assertEqual(json.loads(run('list').stdout), expected)
   self.assertEqual(run('import', str(source)).returncode, 0)
   self.assertEqual(json.loads(run('list').stdout), expected)

 def test_file_errors_do_not_change_items(self):
  from pathlib import Path
  with tempfile.TemporaryDirectory() as d:
   source = Path(d) / 'bad.csv'
   db = d + '/catalog.sqlite'
   for content in (b'wrong,header\n', b'sku,name,price_cents\na,Valid,5\n' + b'\xff' * 10000):
    source.write_bytes(content)
    result = subprocess.run([sys.executable, 'catalog.py', '--db', db, 'import', str(source)], capture_output=True)
    self.assertNotEqual(result.returncode, 0)
    self.assertEqual(json.loads(subprocess.check_output([sys.executable, 'catalog.py', '--db', db, 'list'])), [])

class SummaryCatalog(unittest.TestCase):
 def test_summary_empty_and_existing_catalog_with_large_total(self):
  import sqlite3
  with tempfile.TemporaryDirectory() as d:
   db = d + '/catalog.sqlite'
   def run(command):
    result = subprocess.run([sys.executable, 'catalog.py', '--db', db, command], text=True, capture_output=True)
    self.assertEqual(result.returncode, 0, result.stderr)
    self.assertEqual(result.stderr, '')
    return json.loads(result.stdout)
   self.assertEqual(run('summary'), [])
   with sqlite3.connect(db) as connection:
    connection.executemany("INSERT INTO catalog (sku,name,price_cents,supplier) VALUES (?,?,?, 'legacy')", [('A', 'First', 9223372036854775807), ('B', 'Second', 1), ('C', 'Free', 0)])
   before = run('list')
   self.assertEqual(run('summary'), [dict(supplier='legacy', count=3, total_cents=9223372036854775808)])
   self.assertEqual(run('list'), before)

 def test_supplier_groups_are_sorted_exact_and_preserve_catalog_and_batches(self):
  from pathlib import Path
  import sqlite3
  with tempfile.TemporaryDirectory() as d:
   db = d + '/catalog.sqlite'
   source = Path(d) / 'daily.csv'
   def run(*args):
    result = subprocess.run([sys.executable, 'catalog.py', '--db', db, *args], text=True, capture_output=True)
    self.assertEqual(result.returncode, 0, result.stderr)
    self.assertEqual(result.stderr, '')
    return result.stdout
   source.write_text('sku,name,price_cents\nA,Maximum,9223372036854775807\nB,Extra,1\nC,Free,0\n')
   run('import', str(source), '--supplier', 'zeta', '--batch-id', 'daily')
   source.write_text('sku,name,price_cents\nA,Free,0\n')
   run('import', str(source), '--supplier', 'alpha')
   run('import', str(source))
   before = run('list')
   with sqlite3.connect(db) as connection:
    batches = connection.execute('SELECT * FROM successful_batches').fetchall()
   self.assertEqual(json.loads(run('summary')), [
    dict(supplier='alpha', count=1, total_cents=0),
    dict(supplier='legacy', count=1, total_cents=0),
    dict(supplier='zeta', count=3, total_cents=9223372036854775808)])
   self.assertEqual(run('list'), before)
   with sqlite3.connect(db) as connection:
    self.assertEqual(connection.execute('SELECT * FROM successful_batches').fetchall(), batches)

 def test_summary_migrates_legacy_rows_without_changing_values(self):
  import sqlite3
  with tempfile.TemporaryDirectory() as d:
   db = d + '/catalog.sqlite'
   with sqlite3.connect(db) as connection:
    connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
    connection.execute("INSERT INTO catalog VALUES ('A', ' Original ', 7)")
   result = subprocess.run([sys.executable, 'catalog.py', '--db', db, 'summary'], text=True, capture_output=True)
   self.assertEqual(result.returncode, 0, result.stderr)
   self.assertEqual(json.loads(result.stdout), [dict(supplier='legacy', count=1, total_cents=7)])
   with sqlite3.connect(db) as connection:
    self.assertEqual(connection.execute('SELECT * FROM catalog').fetchall(), [('legacy', 'A', ' Original ', 7)])

class ImportIdentity(unittest.TestCase):
 def test_trimmed_case_sensitive_identity_and_collisions(self):
  from pathlib import Path
  import sqlite3
  with tempfile.TemporaryDirectory() as d:
   db = d + '/catalog.sqlite'
   source = Path(d) / 'daily.csv'
   def run(*args):
    return subprocess.run([sys.executable, 'catalog.py', '--db', db, *args], text=True, capture_output=True)
   run('list')
   with sqlite3.connect(db) as connection:
    connection.execute("INSERT INTO catalog (sku,name,price_cents,supplier) VALUES (?,?,?, 'legacy')", ('Stored', ' Original name ', 77))
   source.write_text('sku,name,price_cents\n Stored ,Replacement,99\n ABC , First , 10 \nABC,Later,20\nabc, Lower ,30\n abc ,Later lower,40\n BAD ,Invalid,no\nBAD,Later valid,50\n ,Blank,60\nNEW,  ,70\n', encoding='utf-8')
   result = run('import', str(source))
   self.assertEqual(result.returncode, 0, result.stderr)
   self.assertEqual(result.stdout, '')
   self.assertIn("duplicate SKU 'ABC'", result.stderr)
   self.assertIn("duplicate SKU 'abc'", result.stderr)
   self.assertEqual(len(result.stderr.splitlines()), 6)
   expected = [dict(supplier='legacy', sku='ABC', name='First', price_cents=10), dict(supplier='legacy', sku='Stored', name='Replacement', price_cents=99), dict(supplier='legacy', sku='abc', name='Lower', price_cents=30)]
   self.assertEqual(json.loads(run('list').stdout), expected)
   self.assertEqual(run('import', str(source)).returncode, 0)
   self.assertEqual(json.loads(run('list').stdout), expected)
   self.assertEqual(json.loads(run('summary').stdout), [dict(supplier='legacy', count=3, total_cents=139)])

class SupplierBatches(unittest.TestCase):
 def test_migration_supplier_identity_and_exact_replays(self):
  from pathlib import Path
  import sqlite3
  with tempfile.TemporaryDirectory() as d:
   db = d + '/catalog.sqlite'
   source = Path(d) / 'daily.csv'
   with sqlite3.connect(db) as connection:
    connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
    connection.execute('INSERT INTO catalog VALUES (?,?,?)', ('Kept', ' Original ', 0))
    connection.execute('CREATE TABLE unrelated (value TEXT)')
    connection.execute("INSERT INTO unrelated VALUES ('untouched')")
   def run(*args, ok=True):
    result = subprocess.run([sys.executable, 'catalog.py', '--db', db, *args], capture_output=True, text=True)
    self.assertEqual(result.returncode == 0, ok, result.stderr)
    return result
   self.assertEqual(json.loads(run('list').stdout), [dict(supplier='legacy', sku='Kept', name=' Original ', price_cents=0)])
   first = b'sku,name,price_cents\n X , First , 10 \nX,Duplicate,999\nx,Lower,0\nBAD,Broken,no\n'
   source.write_bytes(first)
   imported = run('import', str(source), '--supplier', 'alpha', '--batch-id', 'one')
   self.assertEqual(len(imported.stderr.splitlines()), 2)
   run('import', str(source), '--supplier', 'beta', '--batch-id', 'one')
   source.write_bytes(b'sku,name,price_cents\nX,Newer,20\n')
   run('import', str(source), '--supplier', 'alpha', '--batch-id', 'two')
   before = json.loads(run('list').stdout)
   source.write_bytes(first)
   run('import', str(source), '--supplier', 'alpha', '--batch-id', 'one')
   self.assertEqual(json.loads(run('list').stdout), before)
   with sqlite3.connect(db) as connection:
    batches_before = connection.execute('SELECT * FROM successful_batches ORDER BY supplier,batch_id').fetchall()
   # Even semantically equivalent CSV bytes cannot reuse a key.
   source.write_bytes(first.replace(b'\n', b'\r\n'))
   run('import', str(source), '--supplier', 'alpha', '--batch-id', 'one', ok=False)
   self.assertEqual(json.loads(run('list').stdout), before)
   with sqlite3.connect(db) as connection:
    self.assertEqual(connection.execute('SELECT * FROM successful_batches ORDER BY supplier,batch_id').fetchall(), batches_before)
    self.assertEqual(connection.execute('SELECT * FROM unrelated').fetchall(), [('untouched',)])
   self.assertEqual([(r['supplier'], r['sku']) for r in before], [('alpha', 'X'), ('alpha', 'x'), ('beta', 'X'), ('beta', 'x'), ('legacy', 'Kept')])
   self.assertEqual(before[0]['price_cents'], 20)
   source.write_bytes(b'sku,name,price_cents\nKept,Updated,7\n')
   run('import', str(source))
   self.assertEqual(json.loads(run('list').stdout)[-1]['price_cents'], 7)
   source.write_bytes(b'sku,name,price_cents\nKept,Updated again,8\n')
   run('import', str(source))
   self.assertEqual(json.loads(run('list').stdout)[-1]['price_cents'], 8)

 def test_failed_import_does_not_claim_batch_or_migrate(self):
  from pathlib import Path
  import sqlite3
  with tempfile.TemporaryDirectory() as d:
   db = d + '/catalog.sqlite'
   with sqlite3.connect(db) as connection:
    connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
    connection.execute("INSERT INTO catalog VALUES ('A','Original',5)")
   source = Path(d) / 'daily.csv'
   source.write_bytes(b'wrong,header\n')
   command = [sys.executable, 'catalog.py', '--db', db, 'import', str(source), '--batch-id', 'retry']
   self.assertNotEqual(subprocess.run(command, capture_output=True).returncode, 0)
   with sqlite3.connect(db) as connection:
    self.assertEqual(connection.execute('SELECT * FROM catalog').fetchall(), [('A','Original',5)])
    self.assertEqual(connection.execute("SELECT name FROM sqlite_master WHERE name='successful_batches'").fetchall(), [])
   source.write_bytes(b'sku,name,price_cents\nA,Updated,6\n')
   result = subprocess.run(command, capture_output=True)
   self.assertEqual(result.returncode, 0, result.stderr)

class AtomicBatchFailure(unittest.TestCase):
 def test_storage_failure_rolls_back_updates_and_replay_key(self):
  from pathlib import Path
  import sqlite3
  with tempfile.TemporaryDirectory() as d:
   db = d + '/catalog.sqlite'
   source = Path(d) / 'daily.csv'
   subprocess.check_call([sys.executable, 'catalog.py', '--db', db, 'list'], stdout=subprocess.DEVNULL)
   with sqlite3.connect(db) as connection:
    connection.execute("INSERT INTO catalog VALUES ('legacy','A','Original',5)")
    connection.execute("CREATE TRIGGER reject_b BEFORE INSERT ON catalog WHEN NEW.sku='B' BEGIN SELECT RAISE(ABORT, 'rejected'); END")
   source.write_text('sku,name,price_cents\nA,Changed,6\nB,Rejected,7\n')
   command = [sys.executable, 'catalog.py', '--db', db, 'import', str(source), '--batch-id', 'retry']
   result = subprocess.run(command, capture_output=True)
   self.assertNotEqual(result.returncode, 0)
   with sqlite3.connect(db) as connection:
    self.assertEqual(connection.execute('SELECT * FROM catalog').fetchall(), [('legacy','A','Original',5)])
    self.assertEqual(connection.execute('SELECT * FROM successful_batches').fetchall(), [])
    connection.execute('DROP TRIGGER reject_b')
   self.assertEqual(subprocess.run(command, capture_output=True).returncode, 0)
