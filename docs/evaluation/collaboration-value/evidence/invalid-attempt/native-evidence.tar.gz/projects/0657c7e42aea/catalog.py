import argparse
import csv
import json
import io
from pathlib import Path
import re
import sqlite3
import sys


SCHEMA = ('CREATE TABLE catalog '
          '(supplier TEXT NOT NULL, sku TEXT NOT NULL, name TEXT NOT NULL, '
          'price_cents INTEGER NOT NULL, PRIMARY KEY (supplier, sku))')


def prepare_storage(connection):
    columns = [row[1] for row in connection.execute('PRAGMA table_info(catalog)')]
    if not columns:
        connection.execute(SCHEMA)
    elif columns == ['sku', 'name', 'price_cents']:
        connection.execute('ALTER TABLE catalog RENAME TO catalog_legacy_migration')
        connection.execute(SCHEMA)
        connection.execute(
            "INSERT INTO catalog SELECT 'legacy',sku,name,price_cents "
            'FROM catalog_legacy_migration')
        connection.execute('DROP TABLE catalog_legacy_migration')
    elif columns != ['supplier', 'sku', 'name', 'price_cents']:
        raise ValueError('unsupported catalog schema')
    connection.execute(
        'CREATE TABLE IF NOT EXISTS successful_batches '
        '(supplier TEXT NOT NULL, batch_id TEXT NOT NULL, source BLOB NOT NULL, '
        'PRIMARY KEY (supplier, batch_id))')


def import_csv(connection, path, supplier, batch_id):
    source_bytes = Path(path).read_bytes()
    if batch_id is not None:
        previous = connection.execute(
            'SELECT source FROM successful_batches WHERE supplier=? AND batch_id=?',
            (supplier, batch_id)).fetchone()
        if previous is not None:
            if previous[0] != source_bytes:
                raise ValueError('batch-id already used with different source bytes')
            return
    apply_rows(connection, source_bytes, supplier)
    if batch_id is not None:
        connection.execute('INSERT INTO successful_batches VALUES (?,?,?)',
                           (supplier, batch_id, source_bytes))


def apply_rows(connection, source_bytes, supplier):
    seen = set()
    with io.StringIO(source_bytes.decode('utf-8-sig'), newline='') as source:
        rows = csv.reader(source, strict=True)
        if next(rows, None) != ['sku', 'name', 'price_cents']:
            raise ValueError('CSV header must be sku,name,price_cents')
        while True:
            try:
                row = next(rows)
            except StopIteration:
                break
            except csv.Error as error:
                print(f'line {rows.line_num}: skipped malformed CSV: {error}', file=sys.stderr)
                continue
            line = rows.line_num
            row = [field.strip() for field in row]
            sku = row[0] if row else ''
            if sku in seen:
                print(f'line {line}: skipped duplicate SKU {sku!r}', file=sys.stderr)
                continue
            if sku:
                seen.add(sku)
            if (len(row) != 3 or not sku or not row[1]
                    or not re.fullmatch(r'[0-9]+', row[2])):
                print(f'line {line}: skipped invalid SKU, name, price or column count', file=sys.stderr)
                continue
            # SQLite INTEGER stores signed 64-bit values.
            digits = row[2].lstrip('0') or '0'
            if len(digits) > 19 or (len(digits) == 19 and digits > '9223372036854775807'):
                print(f'line {line}: skipped price outside SQLite integer range', file=sys.stderr)
                continue
            connection.execute(
                'INSERT INTO catalog (supplier,sku,name,price_cents) VALUES (?,?,?,?) '
                'ON CONFLICT(supplier,sku) DO UPDATE SET '
                'name=excluded.name, price_cents=excluded.price_cents',
                (supplier, sku, row[1], int(digits)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    commands.add_parser('summary')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    importer.add_argument('--supplier', default='legacy')
    importer.add_argument('--batch-id')
    args = parser.parse_args()
    try:
        connection = sqlite3.connect(args.db)
        try:
            with connection:
                connection.execute('BEGIN IMMEDIATE')
                prepare_storage(connection)
                if args.command == 'import':
                    import_csv(connection, args.path, args.supplier, args.batch_id)
                elif args.command == 'summary':
                    groups = {}
                    for supplier, price in connection.execute(
                            'SELECT supplier,price_cents FROM catalog ORDER BY supplier'):
                        group = groups.setdefault(
                            supplier, dict(supplier=supplier, count=0, total_cents=0))
                        group['count'] += 1
                        group['total_cents'] += price
                    print(json.dumps(list(groups.values())))
                else:
                    print(json.dumps([
                        dict(supplier=supplier, sku=sku, name=name, price_cents=price)
                        for supplier, sku, name, price in connection.execute(
                            'SELECT supplier,sku,name,price_cents FROM catalog ORDER BY supplier,sku')]))
        finally:
            connection.close()
    except (OSError, UnicodeError, ValueError, csv.Error, sqlite3.Error) as error:
        parser.exit(1, f'catalog: {error}\n')


if __name__ == '__main__':
    main()
