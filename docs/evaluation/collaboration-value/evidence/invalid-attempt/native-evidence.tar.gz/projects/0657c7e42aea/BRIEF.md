We apply daily supplier CSV files to a purchasing catalog. Add an `import PATH`
command and a `summary` command to the existing catalog.py CLI. Daily files can
contain duplicate item codes and malformed prices; those cases must not mess up
our catalog. The purchasing summary should show useful item counts and total
prices. Keep existing stored items and the list command usable.

We have not settled the detailed import rules or purchasing-summary behavior.
Ask me about business choices you cannot establish from the project.
First deliver and commit the runnable import/list slice, then stop for
my trial of that slice before implementing summary. Summary's output is a JSON
array of objects with count and total_cents, initially for supplier legacy. I
will give you the next checkpoint after trying the first slice.
