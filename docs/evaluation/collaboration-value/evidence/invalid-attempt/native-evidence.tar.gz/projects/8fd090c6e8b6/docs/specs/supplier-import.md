# Supplier and batch import/storage

Import accepts optional --supplier NAME (default legacy) and --batch-id ID
(default absent). Supplier and batch IDs are exact, case-sensitive strings;
reject whitespace-only identifiers, preserve other supplied text. Item identity
is supplier plus trimmed lowercase SKU. Last file row wins, all rows validate,
and ordinary later imports update matching items within that supplier only.
List adds supplier and sorts by supplier then SKU.

Migrate the original three-column catalog transactionally to a composite
(supplier,sku) primary key, assigning every existing row to legacy and preserving
all field values. As in the identity repair, old SKU aliases are replaced only
when their identity is imported; unrelated rows remain unchanged.

Successful batch keys are (supplier,batch_id). Persist exact source bytes and
original imported count atomically with item updates. Same key and exact bytes
returns success without writes or reapplying, even after newer updates. Different
bytes reject without changing catalog or successful keys. No batch ID means no
replay tracking. Read source once; parse and compare the same bytes. Serialize
check/write with BEGIN IMMEDIATE. Failures roll back migration, item writes and
batch records. Prices retain the agreed integer validation, including zero.

Summary changes are explicitly deferred to next session: future output will be
one object per nonempty supplier, sorted, or []. Existing summary implementation
is outside this slice and remains the old single legacy aggregate.
