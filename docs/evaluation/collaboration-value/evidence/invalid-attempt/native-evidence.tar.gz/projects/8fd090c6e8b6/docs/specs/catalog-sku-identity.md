# Canonical SKU identity repair

User trial reported chosen_identity_and_file_collision. SKU identity is
`sku.strip().lower()`: trim surrounding whitespace and lowercase before file
deduplication and persistence. Last valid row for the canonical SKU wins;
every row must still pass validation or the entire import is rejected.
A later import updates the same item regardless of input case/spacing.

For an imported key, any matching older stored spelling is replaced by the
canonical key and incoming values in the same transaction. Multiple stored
spellings of that imported identity collapse to the incoming row. Untouched
stored identities are preserved, with no blanket migration during list/summary.
Name text remains preserved. Import reporting counts canonical input keys.
Existing all-or-nothing, list, summary, schema and local-only rules remain.
