# Catalog import/list slice

Add `python3 catalog.py --db PATH import CSV_PATH` using stdlib only.
CSV header is exactly `sku,name,price_cents`. SKU and name must contain
non-whitespace text. SKU identity is trimmed and lowercased; preserve name text.
Prices use ASCII decimal digits only, nonnegative and within SQLite's signed 64-bit integer range.
Reject missing/extra fields, invalid CSV, invalid encoding and invalid prices
with a nonzero exit and a useful error. Validate every row before database
writes: even an invalid duplicate later superseded rejects the entire file.
Last row for a repeated SKU wins; existing SKUs update name and price.
Apply all rows in one transaction, preserving unrelated catalog items.
An empty file is invalid; a header-only file imports zero items. Successful
import prints JSON with `imported` equal to the number of distinct input SKUs.
Existing list output and schema stay compatible. No supplier/schema changes.

Summary is deferred until the user's trial and next checkpoint. No publication.

SKU identity repair and legacy-alias behavior: see catalog-sku-identity.md.
