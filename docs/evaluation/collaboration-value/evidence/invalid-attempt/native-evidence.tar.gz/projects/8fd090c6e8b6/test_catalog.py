import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest


class Catalog(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.db = str(Path(self.temp.name) / 'catalog.sqlite')
        self.csv = Path(self.temp.name) / 'items.csv'

    def cli(self, *args):
        return subprocess.run(
            [sys.executable, 'catalog.py', '--db', self.db, *args],
            capture_output=True, text=True,
        )

    def items(self):
        result = self.cli('list')
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def load(self, contents):
        self.csv.write_text(contents, encoding='utf-8')
        return self.cli('import', str(self.csv))

    def test_supplier_identity_and_migration(self):
        with sqlite3.connect(self.db) as connection:
            connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
            connection.execute('INSERT INTO catalog VALUES (?,?,?)', ('old', 'Keep', 5))
        self.assertEqual(self.items(), [{'supplier': 'legacy', 'sku': 'old', 'name': 'Keep', 'price_cents': 5}])
        self.csv.write_text('sku,name,price_cents\n X ,First,9\nx,Last,0\n')
        for supplier in ['zeta', 'alpha']:
            result = self.cli('import', str(self.csv), '--supplier', supplier)
            self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [
            {'supplier': 'alpha', 'sku': 'x', 'name': 'Last', 'price_cents': 0},
            {'supplier': 'legacy', 'sku': 'old', 'name': 'Keep', 'price_cents': 5},
            {'supplier': 'zeta', 'sku': 'x', 'name': 'Last', 'price_cents': 0},
        ])

    def test_batch_replay_conflict_and_supplier_scope(self):
        first = b'sku,name,price_cents\n X ,First,9\nx,Last,10\n'
        self.csv.write_bytes(first)
        args = ('import', str(self.csv), '--supplier', 'alpha', '--batch-id', 'daily')
        result = self.cli(*args)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {'imported': 1})
        self.csv.write_text('sku,name,price_cents\nx,Newer,30\n')
        self.assertEqual(self.cli('import', str(self.csv), '--supplier', 'alpha').returncode, 0)
        before = self.items()
        # A valid but different source, even at another path, cannot reuse the key.
        state = Path(self.db).read_bytes()
        result = self.cli(*args)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('batch', result.stderr)
        self.assertEqual(Path(self.db).read_bytes(), state)
        self.csv.write_bytes(first)
        result = self.cli(*args)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), before)
        self.assertEqual(Path(self.db).read_bytes(), state)
        # Newline-only changes are different bytes despite equivalent CSV rows.
        self.csv.write_bytes(first.replace(b'\n', b'\r\n'))
        self.assertNotEqual(self.cli(*args).returncode, 0)
        self.assertEqual(Path(self.db).read_bytes(), state)
        # Same batch ID is independent for a different supplier.
        result = self.cli('import', str(self.csv), '--supplier', 'beta', '--batch-id', 'daily')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [
            {'supplier': 'alpha', 'sku': 'x', 'name': 'Newer', 'price_cents': 30},
            {'supplier': 'beta', 'sku': 'x', 'name': 'Last', 'price_cents': 10},
        ])
        # Re-running without a replay key really reapplies ordinary updates.
        self.csv.write_bytes(first)
        self.assertEqual(self.cli('import', str(self.csv), '--supplier', 'alpha').returncode, 0)
        self.assertEqual(self.items()[0]['price_cents'], 10)

    def test_failed_batch_does_not_reserve_key(self):
        self.items()
        with sqlite3.connect(self.db) as connection:
            connection.execute("CREATE TRIGGER reject_z BEFORE INSERT ON catalog "
                               "WHEN NEW.sku='z' BEGIN SELECT RAISE(ABORT, 'blocked'); END")
        self.csv.write_text('sku,name,price_cents\na,Good,1\nz,Blocked,2\n')
        args = ('import', str(self.csv), '--batch-id', 'retry')
        self.assertNotEqual(self.cli(*args).returncode, 0)
        self.assertEqual(self.items(), [])
        with sqlite3.connect(self.db) as connection:
            connection.execute('DROP TRIGGER reject_z')
        # Different contents are permitted after an unsuccessful attempt.
        self.csv.write_text('sku,name,price_cents\na,Fixed,3\n')
        result = self.cli(*args)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [{'supplier': 'legacy', 'sku': 'a', 'name': 'Fixed', 'price_cents': 3}])

    def test_migration_and_batch_record_failure_roll_back_together(self):
        with sqlite3.connect(self.db) as connection:
            connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
            connection.execute("INSERT INTO catalog VALUES ('old','Original',7)")
            connection.execute('CREATE TABLE unrelated (note TEXT)')
            connection.execute("INSERT INTO unrelated VALUES ('keep')")
            connection.execute('CREATE TABLE successful_batches (supplier TEXT NOT NULL, '
                               'batch_id TEXT NOT NULL, source_bytes BLOB NOT NULL, imported INTEGER NOT NULL, '
                               'PRIMARY KEY(supplier,batch_id))')
            connection.execute("CREATE TRIGGER fail_batch BEFORE INSERT ON successful_batches "
                               "BEGIN SELECT RAISE(ABORT, 'batch record blocked'); END")
        before = Path(self.db).read_bytes()
        self.csv.write_text('sku,name,price_cents\nnew,New,1\n')
        args = ('import', str(self.csv), '--batch-id', 'migration')
        result = self.cli(*args)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('batch record blocked', result.stderr)
        self.assertEqual(Path(self.db).read_bytes(), before)
        with sqlite3.connect(self.db) as connection:
            self.assertEqual(connection.execute('SELECT * FROM catalog').fetchall(), [('old', 'Original', 7)])
            self.assertEqual(connection.execute('SELECT * FROM successful_batches').fetchall(), [])
            connection.execute('DROP TRIGGER fail_batch')
        self.assertEqual(self.cli(*args).returncode, 0)
        with sqlite3.connect(self.db) as connection:
            self.assertEqual(connection.execute('SELECT note FROM unrelated').fetchall(), [('keep',)])
        self.assertEqual(self.items(), [
            {'supplier': 'legacy', 'sku': 'new', 'name': 'New', 'price_cents': 1},
            {'supplier': 'legacy', 'sku': 'old', 'name': 'Original', 'price_cents': 7},
        ])

    def test_malformed_and_empty_batches(self):
        self.csv.write_text('sku,name,price_cents\nA,Bad,-1\na,Valid,1\n')
        args = ('import', str(self.csv), '--supplier', 'alpha', '--batch-id', 'empty')
        self.assertNotEqual(self.cli(*args).returncode, 0)
        self.assertFalse(Path(self.db).exists())
        self.csv.write_text('sku,name,price_cents\n')
        result = self.cli(*args)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {'imported': 0})
        before = Path(self.db).read_bytes()
        self.assertEqual(self.cli(*args).returncode, 0)
        self.assertEqual(Path(self.db).read_bytes(), before)
        for option in ['--supplier', '--batch-id']:
            self.assertNotEqual(self.cli('import', str(self.csv), option, '  ').returncode, 0)
            self.assertEqual(Path(self.db).read_bytes(), before)

    def test_empty_list(self):
        self.assertEqual(self.items(), [])

    def test_duplicate_last_wins_and_later_import_updates(self):
        result = self.load('sku,name,price_cents\nB,Keep,7\nA,Old,10\nA,New,20\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {'imported': 2})
        self.assertEqual(self.items(), [
            {'supplier': 'legacy', 'sku': 'a', 'name': 'New', 'price_cents': 20},
            {'supplier': 'legacy', 'sku': 'b', 'name': 'Keep', 'price_cents': 7},
        ])
        result = self.load('sku,name,price_cents\nA,Updated,30\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [
            {'supplier': 'legacy', 'sku': 'a', 'name': 'Updated', 'price_cents': 30},
            {'supplier': 'legacy', 'sku': 'b', 'name': 'Keep', 'price_cents': 7},
        ])

    def test_normalized_identity_and_file_collision(self):
        result = self.load('sku,name,price_cents\n Widget ,First,10\nWIDGET,Last,20\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {'imported': 1})
        self.assertEqual(self.items(), [{'supplier': 'legacy', 'sku': 'widget', 'name': 'Last', 'price_cents': 20}])
        self.assertEqual(self.load('sku,name,price_cents\n WiDgEt ,Updated,30\n').returncode, 0)
        self.assertEqual(self.items(), [{'supplier': 'legacy', 'sku': 'widget', 'name': 'Updated', 'price_cents': 30}])
        self.assertEqual(self.summary(), [{'supplier': 'legacy', 'count': 1, 'total_cents': 30}])

    def test_import_updates_legacy_variants_and_preserves_unrelated_rows(self):
        self.items()
        with sqlite3.connect(self.db) as connection:
            connection.executemany('INSERT INTO catalog (sku,name,price_cents) VALUES (?,?,?)', [
                (' Widget ', 'Old', 10), ('WIDGET', 'Other spelling', 15),
                ('Unrelated ', 'Keep', 7),
            ])
        original = self.items()
        result = self.load('sku,name,price_cents\nwidget,Bad,nope\n WIDGET ,Valid,20\n')
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(self.items(), original)
        self.assertEqual(self.load('sku,name,price_cents\n widget ,Latest,20\n').returncode, 0)
        self.assertEqual(self.items(), [
            {'supplier': 'legacy', 'sku': 'Unrelated ', 'name': 'Keep', 'price_cents': 7},
            {'supplier': 'legacy', 'sku': 'widget', 'name': 'Latest', 'price_cents': 20},
        ])

    def test_malformed_rows_leave_catalog_unchanged(self):
        self.assertEqual(self.load('sku,name,price_cents\nA,Original,9\n').returncode, 0)
        original = self.items()
        bad_rows = [
            'A,Bad,-1', 'A,Bad,1.5', 'A,Bad,abc', 'A,Bad,',
            'A,Bad,9223372036854775808', 'A,Bad,+1', 'A,Bad,١',
            ',Missing SKU,1', 'A,   ,1', 'A,Missing', 'A,Extra,1,field',
            '', 'A,"Unclosed,1',
        ]
        for bad in bad_rows:
            with self.subTest(row=bad):
                result = self.load('sku,name,price_cents\nB,New,4\n' + bad + '\nA,Later,5\n')
                self.assertNotEqual(result.returncode, 0)
                self.assertIn('error:', result.stderr)
                self.assertEqual(self.items(), original)

    def test_header_only_and_quoted_fields(self):
        result = self.load('sku,name,price_cents\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {'imported': 0})
        result = self.load('sku,name,price_cents\nA,"A, multiline\nname",0002\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.items(), [{'supplier': 'legacy', 'sku': 'a', 'name': 'A, multiline\nname', 'price_cents': 2}])

    def test_database_failure_rolls_back_prior_rows(self):
        self.assertEqual(self.load('sku,name,price_cents\nA,Original,9\n').returncode, 0)
        with sqlite3.connect(self.db) as connection:
            connection.execute("UPDATE catalog SET sku=' A '")
            connection.execute("CREATE TRIGGER reject_z BEFORE INSERT ON catalog "
                               "WHEN NEW.sku = 'z' BEGIN SELECT RAISE(ABORT, 'blocked'); END")
        result = self.load('sku,name,price_cents\nA,Changed,1\nB,New,2\nZ,Blocked,3\n')
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('blocked', result.stderr)
        self.assertEqual(self.items(), [{'supplier': 'legacy', 'sku': ' A ', 'name': 'Original', 'price_cents': 9}])

    def summary(self):
        result = self.cli('summary')
        self.assertEqual(result.returncode, 0, result.stderr)
        return json.loads(result.stdout)

    def test_empty_summary(self):
        self.assertEqual(self.summary(), [])

    def test_summary_groups_suppliers_with_exact_totals_and_zero_prices(self):
        self.csv.write_text('sku,name,price_cents\na,Large,9223372036854775807\nb,Large,9223372036854775807\nc,Free,0\n')
        result = self.cli('import', str(self.csv), '--supplier', 'zeta', '--batch-id', 'day')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(self.load('sku,name,price_cents\na,Legacy,7\n').returncode, 0)
        self.csv.write_text('sku,name,price_cents\na,Paid,2\nb,Free,0\n')
        for supplier in ['alpha', 'Alpha']:
            self.assertEqual(self.cli('import', str(self.csv), '--supplier', supplier).returncode, 0)
        self.csv.write_text('sku,name,price_cents\na,Free,0\n')
        self.assertEqual(self.cli('import', str(self.csv), '--supplier', 'zero').returncode, 0)
        # A replay-only supplier has no items and must not produce a group.
        self.csv.write_text('sku,name,price_cents\n')
        self.assertEqual(self.cli('import', str(self.csv), '--supplier', 'empty', '--batch-id', 'day').returncode, 0)
        before = Path(self.db).read_bytes()
        listed = self.items()
        self.assertEqual(sum(row['price_cents'] == 0 for row in listed), 4)
        self.assertEqual(self.summary(), [
            {'supplier': 'Alpha', 'count': 1, 'total_cents': 2},
            {'supplier': 'alpha', 'count': 1, 'total_cents': 2},
            {'supplier': 'legacy', 'count': 1, 'total_cents': 7},
            {'supplier': 'zeta', 'count': 2, 'total_cents': 18446744073709551614},
        ])
        self.assertEqual(self.items(), listed)
        self.assertEqual(Path(self.db).read_bytes(), before)
        self.csv.write_text('sku,name,price_cents\na,Now free,0\n')
        for supplier in ['Alpha', 'alpha', 'legacy', 'zeta']:
            self.assertEqual(self.cli('import', str(self.csv), '--supplier', supplier).returncode, 0)
        # zeta still has one paid item; all other groups are now zero-only.
        self.assertEqual(self.summary(), [
            {'supplier': 'zeta', 'count': 1, 'total_cents': 9223372036854775807},
        ])
        self.csv.write_text('sku,name,price_cents\nb,Now free,0\n')
        self.assertEqual(self.cli('import', str(self.csv), '--supplier', 'zeta').returncode, 0)
        self.assertEqual(self.summary(), [])
        self.assertTrue(self.items())

    def test_summary_uses_current_imported_items(self):
        self.assertEqual(self.load('sku,name,price_cents\nA,First,10\nA,Last,20\nB,Keep,7\n').returncode, 0)
        self.assertEqual(self.load('sku,name,price_cents\nA,Updated,30\n').returncode, 0)
        self.assertNotEqual(self.load('sku,name,price_cents\nA,Wrong,99\nC,Bad,nope\n').returncode, 0)
        before = self.items()
        self.assertEqual(self.summary(), [
            {'supplier': 'legacy', 'count': 2, 'total_cents': 37},
        ])
        self.assertEqual(self.items(), before)

    def test_legacy_rows_and_exact_totals_survive_migration(self):
        with sqlite3.connect(self.db) as connection:
            connection.execute('CREATE TABLE catalog (sku TEXT PRIMARY KEY, '
                               'name TEXT NOT NULL, price_cents INTEGER NOT NULL)')
            connection.executemany('INSERT INTO catalog (sku,name,price_cents) VALUES (?,?,?)', [
                ('A', 'Legacy A', 9223372036854775807),
                ('B', 'Legacy B', 9223372036854775807),
                ('C', 'Free item', 0),
            ])
        self.assertEqual(self.items(), [
            {'supplier': 'legacy', 'sku': 'A', 'name': 'Legacy A', 'price_cents': 9223372036854775807},
            {'supplier': 'legacy', 'sku': 'B', 'name': 'Legacy B', 'price_cents': 9223372036854775807},
            {'supplier': 'legacy', 'sku': 'C', 'name': 'Free item', 'price_cents': 0},
        ])
        before = Path(self.db).read_bytes()
        self.assertEqual(self.summary(), [
            {'supplier': 'legacy', 'count': 2, 'total_cents': 18446744073709551614},
        ])
        self.assertEqual(Path(self.db).read_bytes(), before)
        with sqlite3.connect(self.db) as connection:
            self.assertEqual([row[1] for row in connection.execute('PRAGMA table_info(catalog)')],
                             ['supplier', 'sku', 'name', 'price_cents'])

    def test_bad_files_do_not_create_database(self):
        for contents in [b'', b'name,sku,price_cents\n', b'sku,name,price_cents\nA,\xff,1\n']:
            with self.subTest(contents=contents):
                self.csv.write_bytes(contents)
                self.assertNotEqual(self.cli('import', str(self.csv)).returncode, 0)
                self.assertFalse(Path(self.db).exists())
        self.assertNotEqual(self.cli('import', str(self.csv) + '.missing').returncode, 0)
        self.assertFalse(Path(self.db).exists())


if __name__ == '__main__':
    unittest.main()
