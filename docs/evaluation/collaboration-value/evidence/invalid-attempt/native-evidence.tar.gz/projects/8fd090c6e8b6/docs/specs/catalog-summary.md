# Catalog summary

The user supplied the next checkpoint by instructing continuation with reversible
implementation details and no further business preferences.

Add `python3 catalog.py --db PATH summary`. Output is a JSON array containing
one object: `supplier` is `legacy`, `count` is the number of current catalog
items, and `total_cents` is the exact sum of their current prices. Existing
stored and newly imported items belong to this initial legacy summary. Empty
catalogs return a legacy object with count and total both zero. No quantities,
new supplier input, schema migration or changes to import/list contracts.
Sum using Python integers so totals may exceed SQLite's signed integer range
without overflow or floating-point rounding. Preserve existing data.
