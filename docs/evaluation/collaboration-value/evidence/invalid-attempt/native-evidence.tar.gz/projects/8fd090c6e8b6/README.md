# Purchasing catalog
Python standard library only. Public entry: `python3 catalog.py --db PATH list`.
List returns a JSON array of {supplier,sku,name,price_cents}, sorted by supplier
then SKU. SQLite item identity is the composite key (supplier,sku). Original
three-column databases migrate automatically and transactionally: existing rows
become supplier `legacy`, preserving their fields and unrelated tables.
CSV has header sku,name,price_cents. SKU/name must be nonempty; prices are
nonnegative integer cents. Agreed import rules are documented below.
Use the existing public CLI entry for added commands. Local regression command:
`python3 -m unittest discover -v`. Work locally; preserve unrelated files.

Import a daily file with:

```sh
python3 catalog.py --db catalog.sqlite import daily.csv
python3 catalog.py --db catalog.sqlite list
```

The CSV must be UTF-8 with the exact header `sku,name,price_cents` and three
fields per row. SKU/name must contain non-whitespace text. SKU keys are trimmed
and lowercased before comparison and storage; name text is preserved. Prices
are ASCII decimal digits, from 0 through 9223372036854775807
cents. Quoted fields, including commas and newlines, are supported.

Every row is validated, including duplicates. Any malformed row rejects the
whole import with a nonzero exit and an error on stderr, leaving stored items
unchanged. Otherwise the last row for each normalized SKU wins and existing
items update within the chosen supplier,
including older stored case/space variants of an imported key. Such variants
collapse to the normalized key with the incoming values. Unrelated items remain
unchanged, including their original stored keys. Writes occur in one transaction.
Success prints `{"imported": N}`, counting distinct normalized input SKUs. A
header-only file imports zero items; a missing header is an error.

Choose a supplier and an optional replay key with:

```sh
python3 catalog.py --db catalog.sqlite import daily.csv --supplier acme --batch-id 2026-10-23
```

Without options, supplier is `legacy` and no replay key is recorded. Supplier
names and batch IDs are exact, case-sensitive values and cannot be blank.
Different suppliers can store the same normalized SKU independently.

A batch ID is scoped to its supplier. A successful keyed import stores the exact
source bytes with its item updates in one transaction. Repeating those bytes
with that supplier/key succeeds without reapplying them, even after newer imports
changed the items. Success returns the original `{"imported": N}` response.
Reusing the key with different bytes fails and leaves both items and successful
batch records unchanged; even newline differences count. Different paths with
identical bytes replay successfully. Unkeyed imports always apply normally.
Failed imports never reserve a key. Replay records retain full source bytes.

Show purchasing totals with:

```sh
python3 catalog.py --db catalog.sqlite summary
```

Summary returns a JSON array with one `{supplier,count,total_cents}` object per
supplier that has positive-price items, sorted by supplier. Empty catalogs return `[]`.
Summary excludes zero-price rows from both count and total and omits zero-only
suppliers. List retains all items, including zero-price rows.
Totals use exact integer cents even above SQLite's signed integer range.
Only current stored items contribute; empty successful batches add no group.
Summary preserves stored items and replay records.
