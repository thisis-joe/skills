# SKU identity repair work record

Base: bdc8378. Branch: fix/catalog-sku-identity.
Spec: docs/specs/catalog-sku-identity.md.
Authorization: repair after real user trial; automatic local implementation,
checks, same-agent review and work-unit commit; no push or nested agents.
Preserve unrelated personal-notes.txt and store.sqlite.

Cause: read_import keys rows by the raw SKU; SQLite primary key comparisons
are case sensitive. Case/space variants survive file deduplication and updates.

Task: reproduce canonical collision via real public CLI tests; normalize SKU
before deduplication; replace matching legacy stored variants transactionally;
verify malformed duplicates and database failures leave existing data intact.
Run focused tests, unittest discovery, affected real CLI and diff inspection.
Status: repair complete in the commit containing this record; verified locally.

Evidence:
- Both new public CLI regression tests failed on bdc8378: imported count was 2
  rather than 1, and stored case/space aliases survived a later import.
- `python3 -m unittest discover -v`: all 11 tests passed after the fix.
  Rollback test now checks restoration of a deleted legacy alias after a later
  insert fails. Every malformed row, even one superseded, still rejects import.
- Actual CLI: widget and spaced uppercase WIDGET returned imported=1, with
  last row price=20; mixed-case later import updated to 30. Older aliases were
  collapsed. Unrelated Keep-AS-IS row retained exact spelling/name/price.
- Actual CLI: malformed earlier duplicate exited 1 at CSV line 2; database
  bytes remained identical. List was unchanged, summary returned count=2,
  total_cents=37.
- Same-agent review inspected the complete repair diff, tests and docs; no
  unresolved findings. Independent review unavailable and same-agent accepted.
  `git diff --check` passed. No external services or separate examinations.
- Expected and actual: trimmed lowercase identity with last-row collision and
  subsequent updates; no material departure from the clarified requirement.
- store.sqlite and personal-notes.txt were not modified. Nothing published.
