import argparse
import csv
from contextlib import closing
import io
import json
from pathlib import Path
import re
import sqlite3


def normalize_sku(sku):
    return sku.strip().lower()


def read_import(source_bytes):
    items = {}
    with io.StringIO(source_bytes.decode('utf-8'), newline='') as source:
        reader = csv.reader(source, strict=True)
        if next(reader, None) != ['sku', 'name', 'price_cents']:
            raise ValueError('expected CSV header sku,name,price_cents')
        for row in reader:
            location = f'CSV line {reader.line_num}'
            if len(row) != 3:
                raise ValueError(f'{location}: expected three fields')
            sku, name, price = row
            sku = normalize_sku(sku)
            if not sku.strip() or not name.strip():
                raise ValueError(f'{location}: SKU and name must be nonempty')
            if not re.fullmatch(r'[0-9]+', price):
                raise ValueError(f'{location}: price must be nonnegative integer cents')
            # Compare strings before conversion to handle arbitrarily long input.
            normalized = price.lstrip('0') or '0'
            if (len(normalized), normalized) > (19, '9223372036854775807'):
                raise ValueError(f'{location}: price exceeds SQLite integer range')
            items[sku] = (sku, name, int(normalized))
    return list(items.values())


def ensure_schema(connection):
    columns = [row[1] for row in connection.execute('PRAGMA table_info(catalog)')]
    if columns and 'supplier' not in columns:
        connection.execute('ALTER TABLE catalog RENAME TO catalog_legacy_migration')
    connection.execute(
        'CREATE TABLE IF NOT EXISTS catalog ('
        "supplier TEXT NOT NULL DEFAULT 'legacy', sku TEXT NOT NULL, "
        'name TEXT NOT NULL, price_cents INTEGER NOT NULL CHECK(price_cents >= 0), '
        'PRIMARY KEY(supplier,sku))'
    )
    if columns and 'supplier' not in columns:
        connection.execute(
            'INSERT INTO catalog (supplier,sku,name,price_cents) '
            "SELECT 'legacy',sku,name,price_cents FROM catalog_legacy_migration"
        )
        connection.execute('DROP TABLE catalog_legacy_migration')

    connection.execute(
        'CREATE TABLE IF NOT EXISTS successful_batches ('
        'supplier TEXT NOT NULL, batch_id TEXT NOT NULL, source_bytes BLOB NOT NULL, '
        'imported INTEGER NOT NULL, PRIMARY KEY(supplier,batch_id))'
    )


def apply_import(connection, supplier, batch_id, source_bytes, items):
    if batch_id is not None:
        previous = connection.execute(
            'SELECT source_bytes,imported FROM successful_batches '
            'WHERE supplier=? AND batch_id=?', (supplier, batch_id),
        ).fetchone()
        if previous is not None:
            if previous[0] != source_bytes:
                raise ValueError('batch ID already used with different source bytes for this supplier')
            return {'imported': previous[1]}
    if items:
        incoming_keys = {sku for sku, _, _ in items}
        # Only replace aliases of identities in this supplier's import.
        aliases = [(supplier, sku) for (sku,) in connection.execute(
            'SELECT sku FROM catalog WHERE supplier=?', (supplier,))
            if sku != normalize_sku(sku) and normalize_sku(sku) in incoming_keys]
        connection.executemany('DELETE FROM catalog WHERE supplier=? AND sku=?', aliases)
    connection.executemany(
        'INSERT INTO catalog (supplier,sku,name,price_cents) VALUES (?,?,?,?) '
        'ON CONFLICT(supplier,sku) DO UPDATE SET '
        'name=excluded.name, price_cents=excluded.price_cents',
        [(supplier, *item) for item in items],
    )
    if batch_id is not None:
        connection.execute(
            'INSERT INTO successful_batches (supplier,batch_id,source_bytes,imported) '
            'VALUES (?,?,?,?)', (supplier, batch_id, source_bytes, len(items)),
        )
    return {'imported': len(items)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    commands.add_parser('summary')
    importer = commands.add_parser('import')
    importer.add_argument('path')
    importer.add_argument('--supplier', default='legacy')
    importer.add_argument('--batch-id')
    args = parser.parse_args()
    try:
        if args.command == 'import' and not args.supplier.strip():
            raise ValueError('supplier must be nonempty')
        if args.command == 'import' and args.batch_id is not None and not args.batch_id.strip():
            raise ValueError('batch ID must be nonempty')
        # Read once so replay comparison and parsing use exactly the same bytes.
        source_bytes = Path(args.path).read_bytes() if args.command == 'import' else None
        items = read_import(source_bytes) if source_bytes is not None else None
        with closing(sqlite3.connect(args.db)) as connection:
            with connection:
                connection.execute('BEGIN IMMEDIATE')
                ensure_schema(connection)
                if items is not None:
                    output = apply_import(connection, args.supplier, args.batch_id, source_bytes, items)
                elif args.command == 'summary':
                    groups = {}
                    # Python integers keep totals exact beyond SQLite SUM's range.
                    for supplier, price in connection.execute(
                            'SELECT supplier,price_cents FROM catalog WHERE price_cents > 0 ORDER BY supplier'):
                        group = groups.setdefault(
                            supplier, dict(supplier=supplier, count=0, total_cents=0))
                        group['count'] += 1
                        group['total_cents'] += price
                    output = list(groups.values())
                else:
                    output = [dict(supplier=supplier, sku=sku, name=name, price_cents=price)
                              for supplier, sku, name, price in connection.execute(
                                  'SELECT supplier,sku,name,price_cents FROM catalog ORDER BY supplier,sku')]
        print(json.dumps(output))
    except (OSError, UnicodeError, csv.Error, ValueError, sqlite3.Error) as error:
        parser.exit(1, f'error: {error}\n')


if __name__ == '__main__':
    main()
