# Supplier purchasing summary

Continue the deferred summary in supplier-import.md and README.md.
`summary` returns one {supplier,count,total_cents} object for each supplier
with positive-price stored items, sorted by exact supplier value; empty catalogs return [].
Exclude zero-price rows from both count and total. Omit zero-only suppliers;
list still retains their items. Sum cents with Python
integers, including totals above SQLite integer range. Preserve import/replay,
list, stored items and batch records. No new business decisions or schema changes.
